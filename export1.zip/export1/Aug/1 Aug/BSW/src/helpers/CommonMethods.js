export const validateModalForm = (
  validateData,
  modalFormErrors,
  errorMessage,
  handleModalFormErrors
) => {
  let errorObj = {
    isFormValid: true,
    formErrors: {}
  };
  const setErrorMessage = (fieldName, fieldNameError) => {
    errorObj.isFormValid = false;
    errorObj.formErrors[fieldName] = true;
    errorObj.formErrors[fieldNameError] = errorMessage;
  };

  for (const fieldName in validateData) {
    if (validateData[fieldName] === "" || validateData[fieldName] === null || validateData[fieldName] === undefined) {
      setErrorMessage(fieldName, `${fieldName}ErrorMsg`);
    } else {
      if (modalFormErrors[fieldName]) {
        errorObj.isFormValid = false;
      }
    }
  }
  handleModalFormErrors(errorObj.formErrors);
  return errorObj.isFormValid;
};

export const validateString = (value) => {
  let regExp = new RegExp("^[a-zA-Z0-9_. -]+$");
  let status = regExp.test(value) ? true : false;
  return status;
};

export const validateDigits = (value) => {
  let regExp = new RegExp("^[0-9]+$");
  let status = regExp.test(value) ? true : false;
  return status;
};

export const validateFloatAndIntValue = (value) => {
  let regExp = new RegExp("^[0-9]+(\.\[0-9]{1,2})?$");
  let status = regExp.test(value) ? true : false;
  return status;
};
