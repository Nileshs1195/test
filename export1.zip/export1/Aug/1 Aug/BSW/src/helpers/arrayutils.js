export const upsert = (array, item) => {
  const i = array.findIndex((elem) => elem.field === item.field);
  if (i > -1) array[i] = { ...array[i], ...item };
  else array.push(item);
  return array;
};

export const removeField = (array, field) => {
  return array.filter((elem) => elem.field !== field);
};

export const addOrRemove = (array, item) => {
  const newArray = [...array];
  const index = newArray.indexOf(item);
  if (index > -1) {
    newArray.splice(index, 1);
    return newArray;
  } else {
    newArray.push(item);
    return newArray;
  }
};
