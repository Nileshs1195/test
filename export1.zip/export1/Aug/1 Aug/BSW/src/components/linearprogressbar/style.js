import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(({
    root: {
        width: "100%"
    },
    bar: {
        "&.MuiLinearProgress-root": {
            height: "8px",
            borderRadius: "4px"
        }
    }
}));