import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import LinearProgress from "@material-ui/core/LinearProgress";
import Typography from "@material-ui/core/Typography";
import { useHistory, useParams } from "react-router-dom";
import Box from "@material-ui/core/Box";
import { useStyles } from "./style";
import IO from "socket.io-client";
import { SETTINGS } from "../../appsettings";
import { useTranslation } from "react-i18next";
const socket = IO(SETTINGS.SOCKET_URL, {
  withCredentials: true,
  upgrade: true,
  // transports:["socket"]
});

const LinearProgressWithLabel = props => {
  const classes = useStyles();
  const { t } = useTranslation();

  return (
    <div>
      <Box display="flex">
        <Box width="50%">
          <Typography variant="body2">{`${t(
            "pages.training.training-parameter.dataset-mode.auto-param-search.progress"
          )}: ${Math.round(props?.value)}%`}</Typography>
        </Box>
        <Box>
          <Typography variant="body2">
            {`${t(
              "pages.training.training-parameter.dataset-mode.auto-param-search.passed-time"
            )}:
              ${props?.passedTime?.hours +
              ":" +
              props?.passedTime?.minutes +
              ":" +
              props?.passedTime?.seconds}`}
          </Typography>
        </Box>
      </Box>
      <Box display="flex" alignItems="center" mt={1}>
        <Box width="100%" mr={1}>
          <LinearProgress
            className={classes.bar}
            variant="determinate"
            {...props}
          />
        </Box>
      </Box>
    </div>
  );
};

const LinearProgressBar = props => {
  const {
    setResultSet,
    displayData,
    method,
    inputData,
    stopExecution,
    executionMethodName
  } = props;
  const params = useParams();
  const { history } = useHistory;
  const classes = useStyles();
  const [progressPercentage, setProgressPercentage] = useState(0);
  const [elapsedTime, setElapsedTime] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0,
    milliseconds: 0
  });

  useEffect(() => {
    if (!socket.connected) {
      socket.connect();
    }
    if (method == "subclassification") {
      getExecuteResult(progressPercentage, inputData);
    } else {
      getSearchResult(progressPercentage);
    }
  }, []);

  useEffect(() => {
    if (stopExecution && socket.connected) {
      socket.disconnect();
    }
  }, [stopExecution]);

  // useEffect(() => {
  //   window.addEventListener("beforeunload", () => alert());

  //   // returned function will be called on component unmount 
  //   return () => {
  //     window.addEventListener("beforeunload", disconnectSocket);
  //   }
  // }, [])

  const disconnectSocket = () => {
    return history.listen(location => {
      if (location.action === "POP") {
        // alert();
        // Do your stuff
      }
    });
  }

  const getExecuteResult = () => {
    window.addEventListener("beforeunload", disconnectSocket);
    if (params?.id) {
      socket.emit("subclassificationProgress", params.id, result => {
        if (result) {
          if (result.progress <= 100) {
            if (result.status === 8) {
              socket.disconnect();
              setResultSet(result);
            } else {
              result.progress < 100 && getExecuteResult(result.progress);
              renderSubcalssificationData(result);
            }
          }
        } else {
          console.log("error occurred while fetching result");
        }
      });
    } else {
      getExecuteResult();
    }
  };

  const getSearchResult = pgr => {
    socket.emit(method, pgr, result => {
      if (result) {
        if (result.pgr <= 100) {
          getSearchResult(result.pgr);
          renderData(result);
        }
      } else {
        console.log("error occurred while fetching result");
      }
    });
  };
  const renderData = data => {
    setProgressPercentage(data.pgr);
    msToTime(data.elptime);
    if (data.pgr === 100 || (data.pgr === 10 && executionMethodName === "trainingExecution")) {
      handleResultSetData(data);
    }
  };
  const renderSubcalssificationData = data => {
    setProgressPercentage(data.progress);
    msToTime(data.elapsedTime);
    if (data.progress === 100 || (data.progress === 10 && executionMethodName === "trainingExecution")) {
      handleResultSetData(data);
    }
  };

  const handleResultSetData = (data) => {
    displayData();
    setResultSet(data);
    if (data?.pgr===100||data?.progress === 100 && socket.connected) {
      socket.disconnect();
    }
  };

  const msToTime = duration => {
    var milliseconds = parseInt((duration % 1000) / 100),
      seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = hours < 10 ? "0" + hours : hours;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;
    setElapsedTime({
      hours: hours,
      minutes: minutes,
      seconds: seconds,
      milliseconds: milliseconds
    });
  };

  return (
    <div className={classes.root}>
      <LinearProgressWithLabel
        value={progressPercentage}
        passedTime={elapsedTime}
      />
    </div>
  );
};
export default LinearProgressBar;

LinearProgressBar.propTypes = {
  value: PropTypes.number.isRequired
};
