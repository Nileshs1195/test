import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  buttonMArgin: {
    marginRight: theme.spacing(2),
    maxWidth: 35,
    maxHeight: 35,
    minWidth: 35,
    minHeight: 35
  }
}));
