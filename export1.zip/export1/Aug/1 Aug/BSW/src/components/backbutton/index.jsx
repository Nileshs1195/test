import { Button } from "@material-ui/core";
import { ArrowBack } from "@material-ui/icons";
import React from "react";
import { useStyles } from "./style";

const BackButton = props => {
  const classes = useStyles();
  return (
    <Button
      variant="outlined"
      onClick={props.handleBackButton}
      className={classes.buttonMArgin}
    >
      <ArrowBack />
    </Button>
  );
};

export default BackButton;