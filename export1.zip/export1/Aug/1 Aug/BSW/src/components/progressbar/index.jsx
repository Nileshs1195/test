import LinearProgress from "@material-ui/core/LinearProgress";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import { IconButton, Snackbar } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import React from "react";
import PropTypes from "prop-types";
import Draggable from "react-draggable";

const ProgressBar = props => {
  const {
    isVisible,
    message,
    progressData,
    closeProgressBar,
    horizontalPosition,
    verticalPosition
  } = props;

  const LinearProgressWithLabel = props => {
    return (
      <Box>
        <Box>{message}</Box>
        <Box display="flex" alignItems="center">
          <Box width="180px" mr={0}>
            <LinearProgress variant="determinate" {...props} />
          </Box>
          <Box minWidth={35}>
            <Typography variant="body2">
              {props.data.completedCount + "/" + props.data.totalCount}
            </Typography>
          </Box>
        </Box>
      </Box>
    );
  };

  return (
    <Draggable>
      <Snackbar
        open={isVisible}
        style={{ cursor: "move" }}
        message={
          <LinearProgressWithLabel
            value={
              (progressData.completedCount * 100) / progressData.totalCount
            }
            data={progressData}
          />
        }
        autoHideDuration={null}
        anchorOrigin={{
          horizontal: horizontalPosition,
          vertical: verticalPosition
        }}
        action={
          <React.Fragment>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={closeProgressBar}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      ></Snackbar>
    </Draggable>
  );
};

export default ProgressBar;

ProgressBar.propTypes = {
  isVisible: PropTypes.bool,
  message: PropTypes.string,
  progressData: PropTypes.any,
  closeProgressBar: PropTypes.func,
  verticalPosition: PropTypes.string,
  horizontalPosition: PropTypes.string
};
