import IO from "socket.io-client";
import { Button } from "@material-ui/core";
import React from "react";
import { useState, useEffect, useContext, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useStyles } from "./style";
import { useHistory, useParams } from "react-router-dom";
import AppStore from "../../stores/appstore";
import TrainingManagementStore from "./../../stores/trainingmanagementstore";
import ImageManagementStore from "../../stores/imagemanagementstore";
import ModalComponent from "../../pages/training/training-parameter-setting/dataset/dataset-list/modal";
import { SETTINGS } from "../../appsettings";
import ProgressBar from "../progressbar";
import Loader from "../../shared/components/ui/loader";
import CustomSnackBar from "../snackbar";
const socket = IO(SETTINGS.SOCKET_URL, {
  withCredentials: true,
  upgrade: true
  // transports:["socket"]
});

export default function ImageUploader(props) {
  const params = useParams();
  const appStore = useContext(AppStore);
  const classes = useStyles();
  const { t } = useTranslation();
  const inputFileRef = useRef(null);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { traingingId, setReloadList, fetchTrainingDatasetWithTraining, setTrainingDataset } = trainingManagementStore;
  const { uploaderAction, handleFileUploadClose } = props;
  const { showUploader, setShowUploader } = imageManagementStore;
  const [action, setAction] = useState({ actionName: "", isOpen: false });
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [formloader, setformloader] = useState(false);
  const [imageDetailsList, setImageDetailsList] = useState([]);
  const [imageList, setImageList] = useState([]);
  const [snapbar, setSnapbar] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [progressBarData, setProgressBarData] = useState({
    completedCount: 0,
    totalCount: 0
  });
  const [isProgressBarVisible, setProgressBarVisibility] = useState(false);
  const [classNames, setclassNames] = useState([]);

  useEffect(() => {
    if (uploaderAction.isOpen) {
      inputFileRef.current.click();
      // hideUploader();
    }
  }, [uploaderAction]);

  const onFileChange = (event) => {
    if (socket.disconnected) {
      socket.connect();
    }
    let files = event.target.files;
    let imageDetailsArray = [];
    let imageArray = [];
    let originalClassName = props.className;
    let classArrayName = [];
    Object.entries(files).forEach((image) => {
      if (image && image[1] && (image[1].type === "image/png" || image[1].type === "image/jpg" || image[1].type === "image/jpeg")) {
        if (originalClassName) {
          image[1].className = originalClassName;
        } else {
          let path = image[1].webkitRelativePath.substr(image[1].webkitRelativePath.indexOf("/") + 1);
          image[1].path = path;
          let className = path.substring(0, path.lastIndexOf("/")).replaceAll("/", "_");
          image[1].className = className !== null && className !== "" ? className : "Unlabelled";
        }
        if (!classArrayName.includes(image[1].className)) {
          classArrayName.push(image[1].className);
        }

        imageDetailsArray.push({
          className: image[1].className,
          fileName: image[1].name,
          fileType: image[1].type,
          fileSize: image[1].size
        });
        imageArray.push({
          fileName: image[1].name,
          source: image[1]
        });
      }
    });
    if (imageDetailsArray.length > 0) {
      setImageDetailsList(imageDetailsArray);
      setImageList(imageArray);
      handleModalActions("UPLOAD-FILES");
      if(uploaderAction.uploaderType === "add-class") {
        setclassNames(classArrayName);
      }
    }
  };

  const handleModalActions = (name) => {
    setAction({ actionName: name, isOpen: true });
  };

  const setModalActive = () => {
    setAction({ actionName: action.actionName, isOpen: false }); // display file upload confirmation modal
  };

  const handleAPICall = (API, data) => {
    setSnapbar(false);
    uploadImages();
  };

  const uploadImages = () => {
    setSnapbar(false);
    if (socket.disconnected) {
      socket.connect();
    }
    const saveRequestData = {
      files: imageDetailsList,
      priorKnowledge: false
    };
    imageManagementStore
      .saveImageDetails(params.id, saveRequestData)
      .then((result) => {
        if (result && result.duplicate && result.duplicate.length > 0) {
          setSnapbar(true);
          setsnapbarMessage({ message: t("pages.training.errors.image-upload.duplicate"), type: "error" });
          // result.result ? result.result : "Unknown error occurred while uploading images, please try again."
          if (socket.connected) {
            socket.disconnect();
          }
          handleFileUploadClose();
          return;
        }
        if (result && result.data && result.data.length > 0) {
          const imageUploadData = result.data.map((item, i) => {
            if (item.fileName === imageList[i].fileName) {
              //merging two objects
              return Object.assign({}, item, imageList[i]);
            }
          });
          setReloadList(true);
          if (props.reloadCurrentList) {
            props.reloadCurrentList("uploadProgress", classNames);
          }
          // fetchTrainingDatasetWithTraining(params.id);
          setformloader(true);
          setTimeout(() => {
            imageUploadHandler(imageUploadData);
          }, 1000);
          setformloader(false);
        } else {
          setSnapbar(true);
          setsnapbarMessage({ message: t("pages.training.errors.image-upload.unknown"), type: "error" });
          if (socket.connected) {
            socket.disconnect();
          }
          // result.result ? result.result :
          handleFileUploadClose();
        }
      })
      .catch((err) => {
        console.log("rr", err);
        handleFileUploadClose();
        if (socket.connected) {
          socket.disconnect();
        }
      });
  };

  const imageUploadHandler = async (imageGroupList) => {
    let obj = {
      imageArray: imageGroupList,
      currentImageIndex: 0,
      imageContext: {
        failedImgs: {
          f_count: 0,
          f_array: []
        },
        succeedImgs: {
          s_count: 0
        }
      }
    };

    if (socket.disconnected) {
      socket.connect();
    }
    initUpload(obj);
  };

  const initUpload = (imageObj) => {
    if (imageObj && imageObj.imageArray.length > 0 && imageObj.currentImageIndex < imageObj.imageArray.length) {
      setProgressBarVisibility(true);
      // setformloader(true);
      setProgressBarData({
        completedCount: imageObj.currentImageIndex,
        totalCount: imageObj.imageArray.length
      });
      var file = imageObj.imageArray[imageObj.currentImageIndex];
      readFileChunk(file.fileName, file, 0, imageObj);
    } else {
      setReloadList(true);
      if (props.reloadCurrentList) {
        props.reloadCurrentList("uploadComplete", classNames);
      }
      setProgressBarData({
        completedCount: imageObj.imageArray.length,
        totalCount: imageObj.imageArray.length
      });
      handleFileUploadClose();
      if (socket.connected) {
        socket.disconnect();
      }
      console.log("Upload completed here");
      setProgressBarVisibility(false);
      setSnapbar(false);
      setSnapbar(true);
      setsnapbarMessage({ message: t("pages.training.success.image-upload.uploadMsg"), type: "success" });
    }
  };

  const readFileChunk = (filename, file, offset, imageObj) => {
    var CHUNK_SIZE = 500000; // 500kb
    let end_offset = offset + CHUNK_SIZE;
    if (end_offset > file.source.size) {
      end_offset = file.source.size;
    }
    let r = new FileReader();
    r.onload = function (filename, file, offset, length, imageObj, event) {
      if (event.target.error != null) {
        console.log("Error in readFileChunk");
        imageObj.currentImageIndex++;
        // update failure count and update array
        imageObj.imageContext.failedImgs.f_count++;
        initUpload(imageObj);
      } else {
        onReadSuccess(filename, file, offset, length, event.target.result, imageObj);
      }
    }.bind(r, filename, file, offset, CHUNK_SIZE, imageObj);
    let blob = file.source.slice(offset, end_offset);
    r.readAsArrayBuffer(blob);
  };

  const onReadSuccess = (filename, file, offset, length, chunk, imageObj) => {
    if (socket.disconnected) {
      socket.connect();
    }
    const end_offset = offset + length;
    socket.emit(
      "imageUpload",
      {
        id: file.id,
        seqNo: file.seqNo,
        fileName: filename,
        imgName: file.imgName,
        offset,
        chunk,
        isLastChunk: end_offset >= file.source.size
      },
      function (offset, imageObj, ack) {
        if (!ack) {
          console.log("Transfer aborted by server" + offset);
        } else {
          // const porcentage = (end_offset / file.source.size) * 100;
          if (end_offset < file.source.size) {
            readFileChunk(filename, file, end_offset, imageObj);
          } else {
            console.log("update success");
            imageObj.currentImageIndex++; // increment index for reading next file
            imageObj.imageContext.succeedImgs.s_count++; // update success count
            // renderFileDetails()                         // display the uploaded file name or progress bar
            initUpload(imageObj);
          }
        }
      }.bind(this, offset, imageObj)
    );
  };

  const handleProgressBarClose = () => {
    setProgressBarVisibility(false);
  };

  return (
    <>
      {snapbar && <CustomSnackBar snapbarMessage={snapbarMessage} />}
      {formloader && <Loader size={24} />}
      {isProgressBarVisible ? (
        <ProgressBar
          isVisible={isProgressBarVisible}
          progressData={progressBarData}
          message={t("pages.image-management.image-group-list.modal.image-uploading-message")}
          closeProgressBar={handleProgressBarClose}
          horizontalPosition="center"
          verticalPosition="top"
        />
      ) : null}

      <ModalComponent
        action={action}
        imageList={imageDetailsList && imageDetailsList.length > 0 && imageDetailsList}
        setModalActive={setModalActive}
        handleAPICall={handleAPICall}
        disableAddButton={disableAddButton}
      />
      {uploaderAction &&
      uploaderAction.uploaderType &&
      (uploaderAction.uploaderType === "add-dataset" || uploaderAction.uploaderType === "add-class") ? (
        <>
          <input
            type="file"
            accept="image/*"
            directory=""
            webkitdirectory=""
            ref={inputFileRef}
            onClick={(e) => (e.target.value = null)}
            onChange={onFileChange}
            multiple
            className={classes.fileUpload}
          />
        </>
      ) : (
        <input
          type="file"
          accept="image/*"
          ref={inputFileRef}
          onClick={(e) => (e.target.value = null)}
          onChange={onFileChange}
          multiple
          className={classes.fileUpload}
        />
      )}
    </>
  );
}
