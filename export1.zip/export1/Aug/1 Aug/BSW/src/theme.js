import { createMuiTheme } from "@material-ui/core";
import { colors } from "./appcolors";
import RobotoBold from "./assets/font/Roboto-Bold.ttf";
import RobotoLight from "./assets/font/Roboto-Light.ttf";
import RobotoMedium from "./assets/font/Roboto-Medium.ttf";
import RobotoRegular from "./assets/font/Roboto-Regular.ttf";

const fontWeight = {
  light: 300,
  regular: 400,
  medium: 500,
  bold: 700
};
const robotoLight = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoLight}) format("truetype")`,
  fontWeight: fontWeight.light,
  fontStyle: "normal"
};

const robotoRegular = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoRegular}) format("truetype")`,
  fontWeight: fontWeight.regular,
  fontStyle: "normal"
};

const robotoMedium = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoMedium}) format("truetype")`,
  fontWeight: fontWeight.medium,
  fontStyle: "normal"
};

const robotoBold = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoBold}) format("truetype")`,
  fontWeight: fontWeight.bold,
  fontStyle: "normal"
};

export const theme = createMuiTheme({
  palette: {
    primary: {
      main: colors.primary.main,
      dark: colors.primary.dark
    }
  },
  typography: {
    fontSize: 14,
    fontFamily: "Roboto, sans-serif",
    fontWeightLight: fontWeight.light,
    fontWeightRegular: fontWeight.regular,
    fontWeightMedium: fontWeight.medium,
    fontWeightBold: fontWeight.bold,
    fontWeight: fontWeight.light
  },
  overrides: {
    MuiCssBaseline: {
      "@global": {
        "@font-face": [robotoLight, robotoRegular, robotoMedium, robotoBold],
        "*::-webkit-scrollbar": {
          width: "0.5em",
          height: "0.5em",
          backgroundColor: colors.scrollBar.bg
        },
        "*::-webkit-scrollbar-thumb": {
          borderRadius: 10,
          backgroundColor: colors.scrollBar.thumb.bg,
          "&:hover": {
            backgroundColor: colors.scrollBar.thumb.hoverBg
          }
        },
        body: {
          fontWeight: fontWeight.light,
          color: "#000"
        }
      }
    },
    MuiButton: {
      root: {
        fontSize: 14,
        fontWeight: fontWeight.medium
      }
    },
    MuiInput: {
      root: {
        fontWeight: fontWeight.regular
      }
    },
    MuiTableCell: {
      head: {
        fontWeight: fontWeight.regular
      },
      root: {
        padding: "0px 16px !important"
      },
      body: {
        "& p": {
          fontWeight: fontWeight.light
        }
      }
    },

    MuiTableBody: {
      root: {
        "& tr td[class^='MuiTableCell-root MuiTableCell-body makeStyles-stickyCell-']": {
          width: "48px !important",
          padding: "0px !important",
          textAlign: "center",
          boxSizing: "border-box",
          "& .MuiCheckbox-root": {
            paddingLeft: 0,
            paddingRight: 0
          }
        },
        "& tr.Mui-selected td[class^='MuiTableCell-root MuiTableCell-body makeStyles-stickyCell-'], & tr:hover td[class^='MuiTableCell-root MuiTableCell-body makeStyles-stickyCell-']": {
          backgroundColor: "#f1f2ff !important"
        },
        "& tr.MuiTableRow-root:hover, & tr.Mui-selected:hover": {
          backgroundColor: "#f1f2ff !important"
        }
      }
    },

    MuiSelect: {
      root: {
        fontSize: 14,
        fontWeight: fontWeight.regular,
        color: colors.select.textColor,
        display: "flex",
        alignItems: "center",
        padding: 8,
        "& > *": {
          marginRight: 4
        }
      },
      icon: {
        color: colors.select.icon
      }
    },
    MuiMenuItem: {
      root: {
        fontSize: 12,
        display: "flex",
        alignItems: "center"
      }
    },
    MuiChip: {
      root: {
        fontSize: 12,
        minWidth: 80,
        justifyContent: "space-around"
      }
    },
    MuiFormControlLabel: {
      label: {
        fontSize: 14
      }
    },

    MuiTableHead: {
      root: {
        "& tr th[class^='MuiTableCell-root MuiTableCell-head makeStyles-stickyHeader-']": {
          width: "48px !important",
          padding: "0px !important",
          textAlign: "center",
          boxSizing: "border-box"
        }
      }
    },
    //button spacing in modal popup
    MuiPaper: {
      root: {
        "& .MuiBox-root button[class~='MuiButton-containedPrimary']": {
          marginLeft: 16
        }
      }
    },
    MuiSnackbar: {
      root: {
        "&.react-draggable": {
          left: "42%"
        },
        "& .MuiSnackbarContent-root": {
          backgroundColor: "rgb(0 0 0 / 60%)"
        },
        "&.MuiSnackbar-anchorOriginTopCenter": {
          top: "80px"
        }
      }
    }
  }
});
