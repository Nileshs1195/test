import { useTranslation } from "react-i18next";
import Loader from "./shared/components/ui/loader";

const I18nProvider = ({ children }) => {
  const { ready } = useTranslation(null, { useSuspense: false });

  if (ready) {
    return children;
  }

  return <Loader size={24} />;
};

export default I18nProvider;
