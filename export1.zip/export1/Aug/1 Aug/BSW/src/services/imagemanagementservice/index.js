import { API_URL } from "../../appconstants";
import { get, post, put, deletes } from "../../core/api";

export const getImageGroupData = async (data) => {
  return await get(API_URL.IMAGE_GROUP_DATA);
};

export const updateGroupNameServices = async (editData, GroupId) => {
  return await put(API_URL.EDIT_GROUP_NAME.replace("{id}", GroupId), editData);
};

export const insertGroupRecord = async (data) => {
  return await post(API_URL.GROUP_RECORD, data);
};

export const getImageList = async (id) => {
  return await get(API_URL.IMAGE_DETAILS, id);
};

export const saveImageDetails = async (trainingId, requestData) => {
  return await post(API_URL.SAVE_IMAGE_DETAILS.replace("{id}", trainingId), requestData);
};

export const getImagesForDataset = async (trainingId, datasetSeqId, paginationData) => {
  return await get(API_URL.GET_IMAGES_FOR_DATASET.replace("{trainingId}", trainingId).replace("{seqId}", datasetSeqId), paginationData);
};

export const deleteImagesForDataset = async (trainingId, datasetSeqId, data) => {
  return await deletes(API_URL.DELETE_DATASET_IMAGES.replace("{tid}", trainingId).replace("{seqNo}", datasetSeqId), data);
};

export const saveEditImageClassDetails = async (trainingId, datasetSeqId, imageData) => {
  return await put(API_URL.GET_IMAGES_FOR_DATASET.replace("{trainingId}", trainingId).replace("{seqId}", datasetSeqId), imageData);
};
