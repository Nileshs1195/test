import { API_URL } from "../../appconstants";
import { get, getImg, post, put, deletes } from "../../core/api";

export const getTrainingDataset = async trainingId => {
  return await get(API_URL.DATASET_LIST.replace("{id}", trainingId));
};

export const getTrainingWithDataset = async trainingId => {
  return await get(
    API_URL.DATASET_LIST_WITH_TRAINING.replace("{id}", trainingId)
  );
};

export const getInputParameter = async () => {
  let mockdata = [
    {
      _id: 101,
      className: "ClassA",
      priorKnowledge: true,
      totalImages: 37,
      maskedImages: 0
    },
    {
      _id: 102,
      className: "ClassB",
      priorKnowledge: false,
      totalImages: 70,
      maskedImages: 0
    },
    {
      _id: 103,
      className: "ClassC",
      priorKnowledge: true,
      totalImages: 140,
      maskedImages: 0
    },
    {
      _id: 104,
      className: "ClassD",
      priorKnowledge: false,
      totalImages: 100,
      maskedImages: 6
    }
  ];
  // return await get(API_URL.DATASET_LIST, data);
  return mockdata;
};

export const editDatasetService = async (trainingId, reqPayload) => {
  return await put(
    API_URL.EDIT_DATASET.replace("{tId}", trainingId),
    reqPayload
  );
};

export const deleteDatasetRecords = async (trainingId, reqPayload) => {
  return await deletes(
    API_URL.DELETE_DATASET.replace("{tid}", trainingId),
    reqPayload
  );
};

export const createDuplicateDataset = async (trainingId, reqPayload) => {
  return await put(
    API_URL.COPY_PAST_MODAL_DATA.replace("{tId}", trainingId),
    reqPayload
  );
};

export const getTrainedDataSetRecords = async (trainingID) => {
  return await get(API_URL.COPY_PAST_MODAL_DATA.replace("{tId}",trainingID));
};

export const fetchExecutedModalList = async () => {
  return await get(API_URL.GET_PAST_MODAL_LIST);
};

export const getImageGrouptData = async (editData, GroupId) => {
  return await get(API_URL.IMAGE_GROUP_DATA);
};

export const getTrainingListtData = async () => {
  return await get(API_URL.TRAINING_LIST_DATA);
};

export const insertDatasetRecord = async data => {
  return await post(API_URL.CREATE_DATASET, data);
};

export const insertInputParameterRecord = async data => {
  return await post(API_URL, data);
};

export const getTrainParamsData = async trainingId => {
  return await get(API_URL.TRAIN_PARAMS.replace("{id}", trainingId));
};
export const getTrainParamsCommonData = async trainingId => {
  return await get(API_URL.TRAIN_PARAMS_DEVELOPER.replace("{id}", trainingId));
};

export const insertTrainParamsCommonData = async (trainingId, data) => {
  return await post(API_URL.TRAIN_PARAMS.replace("{id}", trainingId), data);
};

export const insertTrainParamsData = async (trId, data) => {
  return await post(API_URL.TRAIN_PARAMS_DEVELOPER.replace("{id}", trId), data);
};

export const updateInputParameterServices = async (editData, GroupId) => {
  return true;
};

export const getTrainingListData = async () => {
  return await get(API_URL.TRAINING_LIST_DATA);
};

export const insertParameterData = async (trId, data) => {
  return await post(
    API_URL.EDIT_SUBCLASS_PARAMETER.replace("{id}", trId),
    data
  );
};

export const changeTrainingStatus = async (id, mode, reqPayload) => {
  if (id && mode) {
    return await post(
      API_URL.TEMP_CHANGE_TRAINING_STATUS.replace("{id}", id).replace(
        "{mode}",
        mode
      ),
      reqPayload
    );
  }
};

export const stopExecution = async (id) => {
  if (id) {
    return await put(
      API_URL.STOP_EXECUTION.replace("{id}", id)
    );
  }
};

export const insertTrainingListRecord = async data => {
  return await post(API_URL.TRAINING_LIST_DATA, data);
};

export const updateTrainingRecordData = async(recordID, updateData) => {
    return await put(
        API_URL.EDIT_TRAINING_RECORD.replace("{id}", recordID),
        updateData
    );
};

export  const cloneTrainingListRecord = async(recordID, data) =>{
  return await post( API_URL.TRAINING_CLONE.replace("{id}",recordID),data);
}

export const deleteTrainingListRecord = async (recordID) => {
  return await deletes(API_URL.DELETE_TRAININGLIST.replace("{id}",recordID));
}

export const saveAugmentationMode = async (trainingId, data) => {
    return await put(API_URL.AUGMENTATION_MODE.replace("{id}", trainingId), data);
};

export const getAugmentationMode = async (trainingId) => {
    return await get(API_URL.AUGMENTATION_MODE.replace("{id}", trainingId));
};

export const getExecutionLogData = async (trainingId) => {
  return await get(API_URL.TRAIN_EXECUTION_LOG.replace("{id}", trainingId));
};

export const getListingExecuteModal = async () => {
  return await get(API_URL.LISTING_EXISTING_MODAL);
};

export const saveExecutedDatasetClone = async (data) => {
  return await post(API_URL.EXECUTED_DATASET_CLONE, data);
}

export const stopTrainingExecution = async (id, seqNo) => {
  return await put(API_URL.STOP_TRAINING_EXECUTION.replace("{id}", id).replace("seqNo", seqNo));
};

export const fetchBatchSeqNo = async (id, mode) => {
  return await post(API_URL.GET_BATCH_SEQ_NO.replace("{id}", id).replace("{mode}", mode));
};
