import { CssBaseline } from "@material-ui/core";
import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./i18n";
import I18nProvider from "./i18nprovider";

ReactDOM.render(
  <React.StrictMode>
    <I18nProvider>
      <CssBaseline />
      <App />
    </I18nProvider>
  </React.StrictMode>,
  document.getElementById("root")
);
