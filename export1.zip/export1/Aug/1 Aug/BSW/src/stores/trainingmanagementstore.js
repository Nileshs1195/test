import { action, computed, makeObservable, observable } from "mobx";
import { createContext } from "react";
import * as TrainingManagementService from "../services/trainingmanagementservice";
import { API_RESPONSE } from "../appconstants";

class TrainingManagementStore {
  TrainingDataset = [];
  selectedTrainingDataset = [];

  TrainingInputparameter = [];
  selectedInputParameter = [];
  InputParameterTotalCount = null;
  viewParameter = false;
  snapbarMessage = {
    message: "",
    type: "success",
    open: false
  };
  // batchSeqNo = null;
  isActionDisabled = false;
  trainingListData = [];
  trainingListDataCount = null;
  selectedTrainingListData = [];
  reloadList = false;
  TrainingDatasetTotalCount = null;
  executionLogData = [];
  selectedExecutionLogData = [];
  trainingId = null;
  //TrainingDatasetTotalCount = 0;
  sortParameter = {
    sortBy: "waferId",
    sortOrder: "Ascending"
  };

  updateGroupName = {};

  constructor() {
    makeObservable(this, {
      TrainingDataset: observable,
      TrainingInputparameter: observable,
      sortParameter: observable,
      selectedTrainingDataset: observable,
      selectedTrainingListData: observable,
      TrainingDatasetTotalCount: observable,
      trainingListData: observable,
      trainingListDataCount: observable,
      snapbarMessage: observable,
      isActionDisabled: observable,
      reloadList: observable,
      trainingId: observable,
      viewParameter:observable,
      setViewParameter: action,
      setTrainingId: action,
      setActionDisabled: action,
      setSnapbarMessage: action,
      setTrainingDataset: action,
      setInputparameter: action,
      setSelectedTrainingDataset: action,
      removeSelectedTrainingDataset: action,
      removeSelectedTrainingDatasets: action,
      clearSelectedTrainingDataset: action,
      selectedDataSetCount: computed,
      setSelectedTrainingListRecord: action,
      removeSelectedTrainingListData: action,
      removeSelectedTrainingListDataList: action,
      clearSelectedTrainingListData: action,
      selectedTrainingListDataCount: computed,
      setTrainingListData: action,
      setTrainingListDataTotalCount: action,
      setTrainingDatasetTotalCount: action,
      setImageGroupGridSortParams: action,
      setReloadList: action,

      selectedInputParameter: observable,
      setselectedInputParameter: action,
      selectedInputParameterCount: computed,
      setInputParameterTotalCount: action,
      removeselectedInputParameter: action,
      removeselectedInputParameters: action,
      clearselectedInputParameter: action,
      clearTrainingDataset: action,
      executionLogData: observable,
      selectedExecutionLogData: observable
    });
  }

  setTrainingId = (id) => {
    this.trainingId = id;
  };

  setSnapbarMessage = (data) => {
    this.snapbarMessage = data;
  };

  setTrainingDataset = (data) => {
    this.TrainingDataset = data;
  };

  setReloadList = (data) => {
    this.reloadList = data;
  };

  setTrainingDatasetTotalCount = (data) => {
    this.TrainingDatasetTotalCount = data;
  };

  clearTrainingDataset = () => {
    this.TrainingDataset = [];
  };

  fetchTrainingDataset = async (data) => {
    // await TrainingManagementService.getTrainingDataset(data).then((response) => {
    //   if (response && response.data) {
    //     this.setTrainingDataset(response.data);
    //     this.setTrainingDatasetTotalCount(response.data.length);
    //   }
    // });
    await TrainingManagementService.getTrainingWithDataset(data).then((response) => {
      if (response && response.data) {
        this.setTrainingDataset(response.data);
        this.setTrainingDatasetTotalCount(response.data.length);
        if (response.training) {
          this.setSelectedTrainingListRecord(response.training);
        }
      }
    });
  };

  fetchTrainingDatasetWithTraining = async (data) => {
    await TrainingManagementService.getTrainingWithDataset(data).then((response) => {
      if (response && response.data) {
        this.setTrainingDataset(response.data);
        this.setTrainingDatasetTotalCount(response.data.length);
        if (response.training) {
          this.setSelectedTrainingListRecord(response.training);
        }
      }
    });
  };

  fetchTrainingListDataData = async () => {
    return await TrainingManagementService.getTrainingListtData();
  };

  setSelectedTrainingDataset = (selectedRow) => {
    selectedRow.selected = true;
    this.selectedTrainingDataset = [...this.selectedTrainingDataset, selectedRow];
  };
  setInputparameter = (data) => {
    this.TrainingInputparameter = data;
  };

  setInputParameterTotalCount = (data) => {
    this.InputParameterTotalCount = data;
  };

  setViewParameter = (data) => {
    this.viewParameter = data;
  };
  
  setActionDisabled = (data) => {
    this.isActionDisabled = data;
  };

  setselectedInputParameter = (selectedRow) => {
    selectedRow.selected = true;
    this.selectedInputParameter = [...this.selectedInputParameter, selectedRow];
  };

  // setBatchSeqNo = (seqNo) => {
  //   this.batchSeqNo = seqNo;
  // };

  get selectedInputParameterCount() {
    return this.selectedInputParameter.length;
  }
  removeselectedInputParameter = (inputParameterId) => {
    this.selectedInputParameter = this.selectedInputParameter.filter((inputParameter) => inputParameter.seqNo !== inputParameterId);
  };

  removeselectedInputParameters = (inputParameterIds) => {
    this.selectedInputParameter = this.selectedInputParameter.filter((inputParameter) => !inputParameterIds.includes(inputParameter.seqNo));
  };

  clearselectedInputParameter = () => {
    this.selectedInputParameter = [];
  };

  removeSelectedTrainingDataset = (dataSetId) => {
    this.selectedTrainingDataset = this.selectedTrainingDataset.filter((dataSet) => dataSet.seqNo !== dataSetId);
  };

  removeSelectedTrainingDatasets = (dataSetIds) => {
    this.selectedTrainingDataset = this.selectedTrainingDataset.filter((dataSet) => !dataSetIds.includes(dataSet.seqNo));
  };

  clearSelectedTrainingDataset = () => {
    this.selectedTrainingDataset = [];
  };

  get selectedDataSetCount() {
    return this.selectedTrainingDataset.length;
  }

  setTrainingListData = (data) => {
    this.trainingListData = data;
  };

  setTrainingListDataTotalCount = (data) => {
    this.trainingListDataCount = data;
  };

  fetchTrainingListData = async () => {
    await TrainingManagementService.getTrainingListData().then((response) => {
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        this.setTrainingListData(response.data);
        this.setTrainingListDataTotalCount(response.data.length);
      } else {
        console.log("Error occurred while fetching training list data");
      }
    });
  };

  fetchImageGroupData = async (data) => {
    const imageGroupList = [];
    const imageGroupData = await TrainingManagementService.getImageGrouptData();
    if (imageGroupData && imageGroupData.data) {
      const groupData = imageGroupData.data.map((item) => {
        const container = {};
        container["id"] = item._id;
        container["groupName"] = item.groupName;
        return container;
      });
      return groupData;
    } else {
      return imageGroupList;
    }
  };

  setSelectedTrainingListRecord = (selectedRow) => {
    selectedRow.selected = true;
    this.selectedTrainingListData = [...this.selectedTrainingListData, selectedRow];
  };

  removeSelectedTrainingListData = (dataSetId) => {
    this.selectedTrainingListData = this.selectedTrainingListData.filter((dataSet) => dataSet._id !== dataSetId);
  };

  removeSelectedTrainingListDataList = (dataSetIds) => {
    this.selectedTrainingListData = this.selectedTrainingListData.filter((dataSet) => !dataSetIds.includes(dataSet._id));
  };

  clearSelectedTrainingListData = () => {
    this.selectedTrainingListData = [];
  };

  get selectedTrainingListDataCount() {
    return this.selectedTrainingListData.length;
  }

  setImageGroupGridSortParams = (key, val) => {
    this.sortParameter[key] = val;
  };

  editDatasetAPI = async (trainingId, reqPayload) => {
    return await TrainingManagementService.editDatasetService(trainingId, reqPayload);
  };

  deleteDatasetRecords = async (trainingId, reqPayload) => {
    return await TrainingManagementService.deleteDatasetRecords(trainingId, reqPayload);
  };

  createDuplicateDataset = async (trainingId, reqPayload) => {
    return await TrainingManagementService.createDuplicateDataset(trainingId, reqPayload);
  };

  fetchTrainedDataSetRecords = async (trainingId) =>{
    return await TrainingManagementService.getTrainedDataSetRecords(trainingId);
  };

  setExecutionLogData = (data) => {
    this.executionLogData = data;
  };
  
    clearExecutionLogData = () => {
    this.executionLogData = [];
  };

  insertDatasetRecord = async (traningId, data) => {
    var result;
    await TrainingManagementService.insertDatasetRecord(traningId, data).then((response) => {
      result = response;
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        console.log("Dataset record saved successfully");
      } else {
        console.log("Error occurred while saving dataset record");
      }
    });
    return result;
  };

  fetchTrainParamsData = async (data) => {
    return await TrainingManagementService.getTrainParamsData(data);
  };

  updateTrainingInputparameterList = async (data, seqNo) => {
    const trainListData = this.TrainingInputparameter;
    const trainData = trainListData.map((item) => {
      if (item.seqNo === seqNo) {
        item.priorKnowledge = data.priorKnowledge ? "Yes" : "No";
        item.className = data.className;
      }
      return item;
    });
    this.setInputparameter(trainData);
  };

  saveParameterData = async (trainingId, data) => {
    return await TrainingManagementService.insertParameterData(trainingId, data);
  };

  fetchInputSelectedData = (async) => {
    const selectedData = this.selectedInputParameter;
    const trainData = selectedData.map((item) => item.seqNo);
    return trainData.join();
  };

  fetchTrainParamsDeveleperMode = async (data) => {
    return await TrainingManagementService.getTrainParamsCommonData(data);
  };

  insertTrainParamsCommonData = async (traningId, commonData) => {
    return await TrainingManagementService.insertTrainParamsCommonData(traningId, commonData);
  };

  insertTrainParamsData = async (traningId, insertData) => {
    return await TrainingManagementService.insertTrainParamsData(traningId, insertData);
  };

  insertTrainingListRecord = async (trainingListData) => {
    return await TrainingManagementService.insertTrainingListRecord(trainingListData);
  };

  cloneTrainingListRecord = async (recordID, data) =>{
    return await TrainingManagementService.cloneTrainingListRecord(recordID, data);
  };

  updateTrainingRecordData = async (recordID, updateData) => {
    return await TrainingManagementService.updateTrainingRecordData(recordID, updateData);
  };

  deleteTrainingListRecord = async (recordID) => {
    return await TrainingManagementService.deleteTrainingListRecord(recordID);
  }

  insertInputParameterRecord = async (inputParameterData) => {
    let status = false;
    const response = await TrainingManagementService.insertInputParameterRecord(inputParameterData);
    if (response.result === "Record Created Successfully") {
      //this.selectedInputParameter(response.data);
      status = true;
    }
    return status;
  };

  updateInputParameter = async (editData, inputId) => {
    const response = await TrainingManagementService.updateInputParameterServices(editData, inputId);
    if (response !== undefined && response[0].result === "successfully updated") {
      return true;
    } else {
      return null;
    }
  };

  changeTrainingStatus = async (id, mode, reqPayload) => {
    const response = await TrainingManagementService.changeTrainingStatus(id, mode, reqPayload);
    if (response !== undefined && response[0].result === "successfully updated") {
      return true;
    } else {
      return null;
    }
  };

  stopExecution = async (id) => {
    return await TrainingManagementService.stopExecution(id);
  };

  saveAugmentationMode = async (trainingId, data) => {
    return await TrainingManagementService.saveAugmentationMode(
      trainingId,
      data
    );
  };

  getAugmentationMode = async (trainingId) => {
    return await TrainingManagementService.getAugmentationMode(
      trainingId
    );
  };

  fetchExecutedModalList = async (trainingId) => {
    return await TrainingManagementService.fetchExecutedModalList(
      trainingId
    );
  };

  fetchExecutionLogData = async (trainingId) => {
    return await TrainingManagementService.getExecutionLogData(
      trainingId
    );
  };

  fetchListingExecutedModal = async () =>{
    return await TrainingManagementService.getListingExecuteModal();
  };

  saveExecutedDatasetClone = async (data) => {
    console.log(data)
    return await TrainingManagementService.saveExecutedDatasetClone(data);
  };

  stopTrainingExecution = async (id, seqNo) => {
    return await TrainingManagementService.stopTrainingExecution(id, seqNo);
  };
  
  fetchBatchSeqNo = async (trainingId, mode) =>{
    return await TrainingManagementService.fetchBatchSeqNo(trainingId, mode);
  };
}
export default createContext(new TrainingManagementStore());
