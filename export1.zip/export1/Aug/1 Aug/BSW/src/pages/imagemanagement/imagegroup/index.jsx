import {
  Button,
  Divider,
  Paper,
  TextField,
  Snackbar,
  IconButton,
  FormControl
} from "@material-ui/core";
import { Observer } from "mobx-react-lite";
import { useCallback, useContext, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import {
  APP_ROUTES,
  IMAGE_MANAGEMENT_TABS as TABS,
  IMAGE_GROUP_LIST
} from "../../../appconstants";
import Pagination from "../../../shared/components/basictable/pagination";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import Modal from "../../../shared/components/ui/modal";
import AppStore from "../../../stores/appstore";
import ImageManagementStore from "./../../../stores/imagemanagementstore";
import Grid from "./grid";
import { columnDefinitions } from "./grid/columndefinitions";
import { useStyles } from "./style";
import Loader from "../../../shared/components/ui/loader";
import CloseIcon from "@material-ui/icons/Close";
import IO from "socket.io-client";
import ProgressBar from "../../../components/progressbar";
// var socket = IO("http://localhost:5000", {
//   withCredentials: true,
//   upgrade: true
// });

const ImageGroupList = () => {
  const classes = useStyles();
  const history = useHistory();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const [loading, setLoading] = useState(false);
  const [isToDateInvalid, setIsToDateInvalid] = useState(false);
  const [isFromDateInvalid, setIsFromDateInvalid] = useState(false);
  const [visibleColumns, setVisibleItems] = useState(
    appStore.inspectionGridColumnPreference.filter((c) => c.isSticky !== true)
  );
  const [hiddenColumns, setHiddenItems] = useState(
    appStore.inspectionGridHiddenColumns
  );
  const [doGetValidItems, setDoGetValidItems] = useState(false);
  const [isDefault, setIsDefault] = useState(false);
  const { inspectionSearchFilter, getUserPreferences } = appStore;
  const { imageGroupData, fetchImageGroupData } = imageManagementStore;
  const { addBreadcrumb, removeAllBreadcrumbs } = appStore;

  const inputFileRef = useRef(null);
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [isEditAndNextDisabled, disableEditButton] = useState(false);
  const [isImageGroupModalOpen, toggoleImageGroupModal] = useState(false);
  const [isFileUploadModal, toggoleFileUploadModal] = useState(false);

  const [modal_title, setModalTitle] = useState("");
  const [imageData, setImageGroupData] = useState({
    _id: "",
    seqNo: "",
    groupName: "",
    commant: "",
    imgageCount: 0,
    createdAt: "",
    updatedAt: "",
    updatedBy: ""
  });

  const [modalFormErrors, setModalFormErrors] = useState({});
  const [formloader, setformloader] = useState(false);
  const [snapbar, setSnapbar] = useState(false);
  const [progressBarData, setProgressBarData] = useState({
    completedCount: 0,
    totalCount: 0
  });
  const [isProgressBarVisible, setProgressBarVisibility] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [open, setOpen] = useState(true);
  const [imageGroupList, setImageGroupList] = useState([]);
  const [seqNo, setSequenceNo] = useState(null);

  useEffect(() => {
    imageManagementStore.setImageGroupGridSortParams(
      "sortOrder",
      IMAGE_GROUP_LIST.SORT_DIRECTION.ASCENDING
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setColumnPreference = ({ inspectionList: { columnPreference } }) => {
    let visibleColumn = [];
    const hiddenColumns = [];
    if (columnPreference) {
      columnDefinitions.forEach((column) => {
        const col = columnPreference.filter(
          (item) => item.columnId === column.key
        )[0];
        if (col) {
          visibleColumn.splice(col.position, 0, column);
        } else {
          hiddenColumns.push(column);
        }
      });
    } else {
      visibleColumn = columnDefinitions;
    }
    setVisibleItems(visibleColumn.filter((col) => col.isSticky !== true));
    setHiddenItems(hiddenColumns);
    appStore.addInspectionGridColumnPreference(visibleColumn);
    appStore.addInspectionGridHiddenColumns(hiddenColumns);
  };

  const getImageGroupData = useCallback(async () => {
    setLoading(true);
    // let data = await appStore.fetchUserPreference();
    // if (data) {
    //   setColumnPreference(data);
    // } else {
    appStore.addInspectionGridColumnPreference(columnDefinitions);
    setVisibleItems(columnDefinitions.filter((col) => col.isSticky !== true));
    // }

    if (!appStore.initialFilterUserPreferenceAvailable) {
      const data = await getUserPreferences();
      if (data) {
        appStore.updateUserPreferences(data.inspectionList.filterPreference);
      }
      appStore.initialFilterUserPreferenceAvailable = true;
    }

    await fetchImageGroupData(inspectionSearchFilter);

    setLoading(false);
  }, [fetchImageGroupData, inspectionSearchFilter]);

  useEffect(() => {
    const breadcrumb = {
      path: APP_ROUTES.IMAGE_MANAGEMENT_PAGES.IMAGE_GROUP_LIST,
      label: "pages.image-management.image-group-list.title"
    };
    removeAllBreadcrumbs();
    addBreadcrumb(breadcrumb);
    // if (imageGroupData.length === 0) {
    getImageGroupData();
    // }
  }, [addBreadcrumb, getImageGroupData, imageGroupData.length]);

  const onPagination = (options) => {
    const pageNo = options.pageNo;
    appStore.updateInspectionGridPageNo(pageNo > 0 ? pageNo - 1 : 0);
    appStore.updateInspectionGridPageSize(options.pageSize);
    getImageGroupData();
  };

  const handleFromDateChange = (date) => {
    appStore.updateFromDate(date);
    if (isValidDateRange(date, appStore.inspectionSearchFilter.toDate)) {
      setIsFromDateInvalid(false);
      setIsToDateInvalid(false);
    } else {
      setIsFromDateInvalid(true);
    }
  };

  const handleToDateChange = (date) => {
    appStore.updateToDate(date);
    if (isValidDateRange(appStore.inspectionSearchFilter.fromDate, date)) {
      setIsToDateInvalid(false);
      setIsFromDateInvalid(false);
    } else {
      setIsToDateInvalid(true);
    }
  };

  const isValidDateRange = (from, to) => {
    return new Date(to) >= new Date(from);
  };

  const validItemsOnChange = async (event) => {
    const { checked } = event.target;
    setDoGetValidItems((prevOpen) => !prevOpen);
    appStore.updateInspectionListValidStatus(checked);
    await fetchImageGroupData(inspectionSearchFilter);
  };

  const handleFilterPreference = () => {
    ///fetchData();
  };

  const onFileChange = (event) => {
    let files = event.target.files;
    let imageArray = [];
    Object.entries(files).forEach((image) => {
      imageArray.push({
        name: image[1].name,
        type: image[1].type,
        size: image[1].size,
        source: image[1]
      });
    });

    setImageGroupList(imageArray);
    imageData.imgageCount = imageArray.length;

    // display file upload confirmation modal
    fileUploadConfirmModal();
  };

  const fileUploadConfirmModal = () => {
    toggoleFileUploadModal((isOpen) => !isOpen);
  };

  // add new group record
  const saveGroupRecord = () => {
    setformloader(true);
    const insertData = {
      groupName: imageData.groupName,
      commant: imageData.commant
    };
    const response = imageManagementStore.insertGroupRecord(
      insertData
    );
    // setOpen(true);
    response.then((result) => {
      if (result) {
        getImageGroupData();
        setSequenceNo(result.data._id);
        // Opens up image upload box after adding new Image Group
        setTimeout(() => {
          setformloader(false);
          inputFileRef.current && inputFileRef.current.click();
        }, 3000);
      } else {
        setSnapbar(true);
        const newMessageObj = { message: "Error occurred while saving record" };
        setsnapbarMessage(newMessageObj);
        setformloader(false);
      }
    });
  };

  // add new image record
  const handleUploadImages = () => {
    let obj = {
      imageArray: imageGroupList,
      currentImageIndex: 0,
      seqNo: seqNo,
      imageContext: {
        failedImgs: {
          f_count: 0,
          f_array: []
        },
        succeedImgs: {
          s_count: 0
        }
      }
    };
    setProgressBarVisibility(true);
    initUpload(obj);
  };

  const initUpload = (imageObj) => {
    if (
      imageObj &&
      imageObj.imageArray.length > 0 &&
      imageObj.currentImageIndex < imageObj.imageArray.length
    ) {
      // setformloader(true);
      setProgressBarData({
        completedCount: imageObj.currentImageIndex,
        totalCount: imageObj.imageArray.length
      });
      var file = imageObj.imageArray[imageObj.currentImageIndex];
      // socket.emit(
      //   "uploadStart",
      //   {
      //     UploadFileName: file.name
      //   },
      //   (name) => {
      //     if (name) {
      //       readFileChunk(name, file, 0, imageObj);
      //     } else {
      //       console.log("error on file upload");
      //     }
      //   }
      // );
    } else {
      // setformloader(false);
      setProgressBarVisibility(false);
      setOpen(true);
      setSnapbar(true);
      const newMessageObj = {
        message: `${imageObj.imageContext.succeedImgs.s_count}/${imageObj.imageArray.length
          } ${t(
            "pages.image-management.image-group-list.modal.image-upload-success-message"
          )}`
      };
      setsnapbarMessage(newMessageObj);
      getImageGroupData();
    }
  };

  const readFileChunk = (filename, file, offset, imageObj) => {
    var CHUNK_SIZE = 500000; // 500kb
    let end_offset = offset + CHUNK_SIZE;
    if (end_offset > file.size) {
      end_offset = file.size;
    }
    let r = new FileReader();
    r.onload = function (filename, file, offset, length, imageObj, event) {
      if (event.target.error != null) {
        console.log("Error in readFileChunk");
        imageObj.currentImageIndex++;
        // update failure count and update array
        imageObj.imageContext.failedImgs.f_count++;
        initUpload(imageObj);
      } else {
        onReadSuccess(
          filename,
          file,
          offset,
          length,
          event.target.result,
          imageObj
        );
      }
    }.bind(r, filename, file, offset, CHUNK_SIZE, imageObj);
    let blob = file.source.slice(offset, end_offset);
    r.readAsArrayBuffer(blob);
  };

  // Send chunk
  const onReadSuccess = (filename, file, offset, length, chunk, imageObj) => {
    // socket.emit(
    //   "imageUpload",
    //   { UploadFileName: filename, offset, chunk },
    //   function (offset, imageObj, ack) {
    //     if (!ack) {
    //       console.log("Transfer aborted by server" + offset);
    //     } else {
    //       const end_offset = offset + length;
    //       const porcentage = (end_offset / file.size) * 100;
    //       if (end_offset < file.size) {
    //         readFileChunk(filename, file, end_offset, imageObj);
    //       } else {
    //         console.log("update success");
    //         socket.emit("uploadComplete", {
    //           group_id: imageObj.seqNo,
    //           UploadFileName: file.name,
    //           fileType: file.type,
    //           filesize: file.size
    //         });
    //         imageObj.currentImageIndex++; // increment index for reading next file
    //         imageObj.imageContext.succeedImgs.s_count++; // update success count
    //         // renderFileDetails()                         // display the uploaded file name or progress bar
    //         initUpload(imageObj);
    //       }
    //     }
    //   }.bind(this, offset, imageObj)
    // );
  };

  const handleImageGroupModal = (label, apply = false) => {
    switch (label) {
      case "ADD":
        setImageGroupData({
          _id: "",
          seqNo: "",
          groupName: "",
          commant: "",
          imgageCount: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
          updatedBy: ""
        });
        setModalFormErrors({});
        toggoleImageGroupModal((isOpen) => !isOpen);
        setModalTitle(
          t(
            "pages.image-management.image-group-list.modal.create-new-image-group"
          )
        );
        break;
      case "EDIT":
        setModalFormErrors({});
        toggoleImageGroupModal((isOpen) => !isOpen);
        setModalTitle(
          t("pages.image-management.image-group-list.modal.edit-image-group")
        );
        setImageGroupData(imageManagementStore.selectedImageGroups[0]);
        break;
      case "DELETE":
        imageManagementStore.imageGroupData =
          imageManagementStore.imageGroupData.filter(
            (item) => !imageManagementStore.selectedImageGroups.includes(item)
          );
        imageManagementStore.selectedImageGroups = [];
        disableAddButton(false);
        break;
      case "CLOSE":
        toggoleImageGroupModal((isOpen) => !isOpen);
        imageManagementStore.selectedImageGroups = [];
        disableAddButton(false);
        break;
      case "NEXT":
        const groupId = imageManagementStore.selectedImageGroups[0]._id;
        history.push({
          pathname: APP_ROUTES.IMAGE_MANAGEMENT_PAGES.IMAGE_LIST,
          groupId: groupId
        });
        imageManagementStore.selectedImageGroups = [];
    }
  };

  const handleGroupRecord = () => {
    let isValid = validateModalForm();
    if (isValid) {
      saveGroupRecord();
    } else {
      // if the modal form fields are empty, the modal will be opened up using below function
      toggoleImageGroupModal((isOpen) => !isOpen);
    }
  };

  const updateGroupRecord = () => {
    let isValid = validateModalForm();
    if (isValid) {
      setOpen(true);
      setformloader(true);
      const updateObj = {
        groupName: imageData.groupName,
        commant: imageData.commant
      };
      const groupId = imageManagementStore.selectedImageGroups[0]._id;
      const response = imageManagementStore.updateGroupName(
        updateObj,
        groupId
      );
      setformloader(false);
      response.then((result) => {
        if (result) {
          getImageGroupData();
          disableAddButton(false);
          setSnapbar(true);
          const newMessageObj = { message: "Imagegroup updated successfully" };
          setsnapbarMessage(newMessageObj);
        } else {
          setSnapbar(true);
          const newMessageObj = { message: "Error while updating image group" };
          setsnapbarMessage(newMessageObj);
        }
      });
    } else {
      // if the modal form fields are empty, the modal will be opened up using below function
      toggoleImageGroupModal((isOpen) => !isOpen);
    }
  };

  const handleClose = (event, reason) => {
    setOpen(false);
  };

  const renderSnackBar = (snapbarMessage) => (
    <Snackbar
      open={open}
      message={snapbarMessage.message}
      alertType="success"
      autoHideDuration={10}
      anchorOrigin={{
        vertical: "center",
        horizontal: "center"
      }}
      action={
        <IconButton
          key="close"
          aria-label="close"
          color="inherit"
          className={classes.close}
          onClick={handleClose}
        >
          <CloseIcon />
        </IconButton>
      }
    ></Snackbar>
  );

  const handleImageGroupData = (name, value) => {
    setImageGroupData((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleModalFormErrors = (errorData) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, errorData));
  };

  const onChangeImageGroupData = (event) => {
    const { name, value } = event.target;
    switch (name) {
      case "groupName":
        if (value.length > 0) {
          handleImageGroupData(name, value);
          handleModalFormErrors({
            ["groupName"]: false,
            ["groupErrorMsg"]: ""
          });
        } else {
          handleImageGroupData(name, value);
        }
        break;
      case "commant":
        if (value.length > 0) {
          handleImageGroupData(name, value);
          handleModalFormErrors({
            ["comment"]: false,
            ["commentErronMsg"]: ""
          });
        } else {
          handleImageGroupData(name, value);
        }
    }
  };

  // validate each field
  const validateField = (errorObj, fieldName, fieldNameError) => {
    errorObj.isFormValid = false;
    errorObj.modalFormErrors[fieldName] = true;
    errorObj.modalFormErrors[fieldNameError] = t(
      "pages.image-management.image-group-list.modal.error-text"
    );
    return errorObj;
  };

  const validateModalForm = () => {
    let errorObj = {
      isFormValid: true,
      modalFormErrors: {}
    };

    if (imageData.groupName === "") {
      errorObj = validateField(errorObj, "groupName", "groupErrorMsg");
    }
    if (imageData.commant === "") {
      errorObj = validateField(errorObj, "comment", "commentErronMsg");
    }

    setModalFormErrors(errorObj.modalFormErrors);
    return errorObj.isFormValid;
  };

  const handleProgressBarClose = () => {
    setProgressBarVisibility(false);
  };

  const doDisableSearch = isFromDateInvalid || isToDateInvalid;
  return (
    <Observer>
      {() => (
        <div>
          <Paper className={classes.pageContent}>
            {snapbar && renderSnackBar(snapbarMessage)}
            {formloader && <Loader size={24} />}
            {isProgressBarVisible ? (
              <ProgressBar
                isVisible={isProgressBarVisible}
                progressData={progressBarData}
                message={t(
                  "pages.image-management.image-group-list.modal.image-uploading-message"
                )}
                closeProgressBar={handleProgressBarClose}
                horizontalPosition="center"
                verticalPosition="top"
              />
            ) : null}
            <div className={classes.top}>
              <Breadcrumb
                breadcrumbs={appStore.breadcrumbs}
                removeBreadcrumb={appStore.removeBreadcrumb}
              />
              <input
                type="file"
                accept="image/*"
                ref={inputFileRef}
                onChange={onFileChange}
                multiple
                className={classes.fileUpload}
              />
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={isAddButtonDisabled}
                  onClick={() => handleImageGroupModal("ADD")}
                >
                  {t(
                    "pages.image-management.image-group-list.controls.add-btn"
                  )}
                </Button>
                <Modal
                  open={isImageGroupModalOpen}
                  onClose={() => handleImageGroupModal("CLOSE")}
                  onSubmit={
                    modal_title ===
                      t(
                        "pages.image-management.image-group-list.modal.create-new-image-group"
                      )
                      ? handleGroupRecord
                      : updateGroupRecord
                  }
                  widthClass={classes.modalWidth}
                  showControls
                  primaryButtonTextKey={
                    "pages.image-management.image-group-list.controls.ok"
                  }
                  secondaryButtonTextKey={
                    "pages.image-management.image-group-list.grid.cutomization.modal.cancel-btn"
                  }
                >
                  <div className={classes.modalTextPadding}>
                    <strong className={classes.modal1Title}>
                      {modal_title}
                    </strong>
                    <form autoComplete="off">
                      <FormControl className={classes.formControl}>
                        <TextField
                          fullWidth
                          id="groupName"
                          name="groupName"
                          label={t(
                            "pages.image-management.image-group-list.grid.group-name"
                          )}
                          margin="normal"
                          value={imageData.groupName}
                          onChange={onChangeImageGroupData}
                          error={modalFormErrors["groupName"]}
                          helperText={
                            modalFormErrors["groupErrorMsg"] !== "" &&
                            modalFormErrors["groupErrorMsg"]
                          }
                        />
                      </FormControl>
                      <FormControl className={classes.formControl}>
                        <TextField
                          fullWidth
                          id="commant"
                          name="commant"
                          label={t(
                            "pages.image-management.image-group-list.grid.comment"
                          )}
                          margin="normal"
                          value={imageData.commant}
                          onChange={onChangeImageGroupData}
                          error={modalFormErrors["comment"]}
                          helperText={
                            modalFormErrors["commentErronMsg"] !== "" &&
                            modalFormErrors["commentErronMsg"]
                          }
                        />
                      </FormControl>
                    </form>
                  </div>
                </Modal>

                <Modal
                  open={isFileUploadModal}
                  onClose={fileUploadConfirmModal}
                  onSubmit={handleUploadImages}
                  widthClass={classes.confirmationModalWidth}
                  showControls
                  primaryButtonTextKey={
                    "pages.image-management.image-group-list.controls.upload"
                  }
                  secondaryButtonTextKey={
                    "pages.image-management.image-group-list.modal.cancel-btn"
                  }
                >
                  <div className={classes.modalTextPadding}>
                    <strong>
                      {t(
                        "pages.image-management.image-group-list.modal.confirmation-modal-title"
                      )}
                    </strong>
                    <div className={classes.confirmationModalPadding}>
                      <label htmlFor="">
                        {t(
                          "pages.image-management.image-group-list.modal.image-count-text"
                        )}{" "}
                        : {imageGroupList.length}
                      </label>
                      <br />
                      <label htmlFor="">
                        {t(
                          "pages.image-management.image-group-list.modal.confirm-upload"
                        )}{" "}
                      </label>
                    </div>
                  </div>
                </Modal>

                <Button
                  color="primary"
                  variant="contained"
                //onClick={handleFilterPreference}
                >
                  {t(
                    "pages.image-management.image-group-list.controls.apply-default-filter-btn"
                  )}
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                //onClick={handleCustomizeModal}
                >
                  {t(
                    "pages.image-management.image-group-list.controls.customize-btn"
                  )}
                </Button>
              </div>
            </div>

            <Divider className={classes.divider} />
            <div className={classes.controlContainer}>
              <Pagination
                disabled={doDisableSearch}
                onChange={onPagination}
                itemCount={imageManagementStore.imageGroupDataTotalCount}
                pageNo={appStore.inspectionSearchFilter.pageNo + 1}
                pageSize={appStore.inspectionSearchFilter.pageSize}
              />
            </div>
            <Grid
              loading={loading}
              records={imageManagementStore.imageGroupData}
              containerClassName={
                imageManagementStore.selectedImageGroupCount > 0
                  ? classes.tableContainerFooter
                  : classes.tableContainer
              }
              columnDefinitions={appStore.inspectionGridColumnPreference}
              disableAddButton={disableAddButton}
              disableEditButton={disableEditButton}
            />
            {imageManagementStore.selectedImageGroupCount > 0 && (
              <div className={classes.footerContainer}>
                <div className={classes.buttonGroup}>
                  <span className={classes.noOfDevicesWrapper}>
                    {t(
                      "pages.image-management.image-group-list.controls.selected"
                    )}
                    {" : "}
                    {imageManagementStore.selectedImageGroupCount}
                  </span>
                </div>

                <div className={classes.buttonGroup}>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleImageGroupModal("DELETE")}
                  >
                    {t(
                      "pages.image-management.image-group-list.controls.delete"
                    )}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleImageGroupModal("EDIT")}
                  >
                    {t("pages.image-management.image-group-list.controls.edit")}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleImageGroupModal("NEXT")}
                  >
                    {t("pages.image-management.image-group-list.controls.next")}
                  </Button>
                </div>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default ImageGroupList;
