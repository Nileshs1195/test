export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true,
  },
  {
    key: "updatedAt",
    text: "pages.image-management.image-group-list.grid.update-date-time",
    type: "date",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "createdAt",
    text: "pages.image-management.image-group-list.grid.create-date-time",
    type: "date",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "groupName",
    text: "pages.image-management.image-group-list.grid.group-name",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "commant",
    text: "pages.image-management.image-group-list.grid.comment",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "imageCount",
    text: "pages.image-management.image-group-list.grid.no-of-images",
    type: "number",
    validation: { required: true, pattern: "//" },
  }
];
