import { Observer } from "mobx-react-lite";
import { useContext, useState, useEffect } from "react";
import { CssBaseline, Container } from "@material-ui/core";
import SignIn from "../../shared/pages/signIn";
import Routes from "../../routes";
import { useStyles } from "./style";
import UserStore from "../../shared/stores/userstore";
import ImageManagementStore from "../../stores/imagemanagementstore";
import TrainingManagementStore from "../../stores/trainingmanagementstore";
import AppBarSection from "../../shared/components/appbar";
import AppDrawerSection from "../../components/drawer";
import CustomSnackBar from "../../components/snackbar";
// import ImageUploader from "../../components/imageuploader";

const AppContainer = () => {
  const classes = useStyles();
  const userStore = useContext(UserStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  // const { uploaderAction } = imageManagementStore;
  const { snapbarMessage } = trainingManagementStore;
  const [open, setOpen] = useState(true);
  const handleDrawerToggle = () => setOpen(prevState => !prevState);
  const [uploaderAction, setUploaderAction] = useState({ uploaderType: "", isOpen: false });

  useEffect(() => {
    if (uploaderAction.isOpen) {
    }
  }, [uploaderAction.isOpen]);

  useEffect(() => {
    // console.log('snapbarMessage', snapbarMessage);
  }, [snapbarMessage]);

  return (
    <Observer>
      {() => (
        <div className={classes.root}>
          <CssBaseline />
          {
            snapbarMessage?.open && <CustomSnackBar snapbarMessage={snapbarMessage} />
          }

          <AppBarSection handleDrawerToggle={handleDrawerToggle} open={open} />
          <AppDrawerSection open={open} />

          <main className={classes.content}>
            <div className={classes.appBarSpacer} />
            <Container
              maxWidth="xl"
              classes={{
                root: classes.container,
                maxWidthXl: classes.containerMaxWidth
              }}
            >
              {/* img: {imageManagementStore.showUploader} {showUploader}
              {imageManagementStore.showUploader && <ImageUploader show={imageManagementStore.showUploader} uploaderType="add-dataset" />} */}
              {userStore.currentUser ? <Routes /> : <SignIn />}
            </Container>
          </main>
        </div>
      )}
    </Observer>
  );
};

export default AppContainer;
