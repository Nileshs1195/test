import React, { useState, useContext, useEffect, useRef } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, ButtonGroup, Grow, ClickAwayListener, Popper, MenuList, MenuItem } from "@material-ui/core";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import AppStore from "../../../../stores/appstore";
import { APP_ROUTES } from "../../../../appconstants";
import Breadcrumb from "../../../../shared/components/ui/breadcrumb";
import { useHistory, useParams } from "react-router-dom";
import TrainingManagementStore from "../../../../stores/trainingmanagementstore";
import ClassComponent from "./classcomponent";
import BackButton from "../../../../components/backbutton";
import ImageManagementStore from "../../../../stores/imagemanagementstore";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import Pagination from "../../../../shared/components/basictable/pagination";

const ImageList = (props) => {
  const params = useParams();
  const classes = useStyles();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb } = appStore;
  const history = useHistory();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const [trainingClassData, setTrainingClassData] = useState([]);
  const [classNames, setClassNames] = useState([]);
  const [trainingDetails, setTrainingDetails] = useState([]);
  const anchorRef = useRef(null);
  const [expanded, setExpanded] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [open, setOpen] = useState(false);
  const [imageType, setImageType] = useState("all");
  const [updatedTrainingClassData, setUpdatedTrainingClassData] = useState([]);

  const options = [
    {
      label: t("pages.training.manageImages.controls.showAllImages"),
      value: "Show all Images"
    },
    {
      label: t("pages.training.manageImages.controls.showOnlyValidationImages"),
      value: "Show only validation images"
    },
    {
      label: t("pages.training.manageImages.controls.showOnlyTrainingImages"),
      value: "Show only training images"
    }
  ];

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const handleClose = (event) => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }
    setOpen(false);
  };

  useEffect(() => {
    var urlArray = window.location.href.split("/");
    let currentTrainingId = params.id ? params.id : urlArray[urlArray.length - 2];
    removeLastBreadcrumb();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", currentTrainingId),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", currentTrainingId).replace(":classes", params.classes),
      label: "pages.training.training-parameter.breadcrumb.manageImages"
    });
    trainingManagementStore.fetchTrainingDatasetWithTraining(currentTrainingId);
    return () => {
      imageManagementStore.clearSelectedClassImages();
      trainingManagementStore.clearSelectedTrainingDataset();
      trainingManagementStore.setReloadList(true);
    };
  }, [addBreadcrumb]);

  let checkArray = (arr, target) => target.every((v) => arr.includes(v));

  useEffect(async () => {
    if (props?.reloadCurrentList && props?.newClassNamesList?.length > 0 && props.uploadStatus === "uploadComplete") {
      let selectedSeqNos = [];
      let seqNos = params.classes.split(",").map((item) => Number(item));
      trainingManagementStore.TrainingDataset.forEach((dataset) => {
        if (props?.newClassNamesList?.includes(dataset.className)) {
          selectedSeqNos.push(Number(dataset.seqNo));
        }
      });
      if (checkArray(seqNos, selectedSeqNos)) {
        selectedSeqNos = seqNos;
      } else {
        selectedSeqNos = [...selectedSeqNos, ...seqNos].sort().reverse();
        history.replace(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST.replace(":id", params.id).replace(":classes", selectedSeqNos.join()));
      }
      props.setnewClassNamesList([]);
    }

    if (trainingManagementStore?.TrainingDataset?.length > 0) {
      getImageList();
    }
  }, [props.reloadCurrentList, props.newClassNamesList, props.uploadStatus, trainingManagementStore.TrainingDataset]);

  const getImageList = async () => {
    let trainingList = await JSON.parse(JSON.stringify(trainingManagementStore.selectedTrainingListData));
    setTrainingDetails(trainingList[0]);
    let className = [];
    trainingManagementStore.TrainingDataset.forEach((element) => {
      className.push({ label: element.className, value: element.seqNo });
    });
    setClassNames(className);
    const selectedClassSeqNos = params.classes.split(",").map(Number);
    const trainingClassData = JSON.parse(
      JSON.stringify(trainingManagementStore.TrainingDataset.filter((item) => selectedClassSeqNos.includes(item.seqNo)))
    );
    console.log("trainingClassData", trainingClassData, trainingDetails);
    setTrainingClassData(trainingClassData);
  };

  const handleEditImageClass = async () => {
    const urlArray = window.location.href.split("/");
    const currentTrainingId = params.id ? params.id : urlArray[urlArray.length - 2];
    await trainingManagementStore.fetchTrainingDatasetWithTraining(currentTrainingId);
    getImageList();
  };

  const onPagination = (indexObj) => {
    imageManagementStore.updateclassPaginationStartIndex((indexObj.pageNo > 0 ? indexObj.pageNo - 1 : indexObj.pageNo) * indexObj.pageSize);
    getClassList();
  };
  const getSlectedClassList = () => {
    const selectedClassSeqNos = params.classes.split(",").map(Number);
    const trainingClassData = JSON.parse(
      JSON.stringify(trainingManagementStore.TrainingDataset.filter((item) => selectedClassSeqNos.includes(item.seqNo)))
    );
    return trainingClassData;
  }

  const getClassList = () => {   
    const trainingClassData = getSlectedClassList();
    let  updatedTrainingClassData = trainingClassData.reverse();
    setUpdatedTrainingClassData(updatedTrainingClassData.slice(imageManagementStore.classPaginationStartIndex, imageManagementStore.classPaginationStartIndex + 5));
  };

  const getImageAccodian = () => {
    if (updatedTrainingClassData?.length > 0) {
      let result = [];
      updatedTrainingClassData.forEach((element, index) => {
        result.push(
          <ClassComponent
            key={element.seqNo}
            classData={element}
            handleFileUploadOpen={props.handleFileUploadOpen}
            params={params}
            expand={expanded}
            trainingDetails={trainingDetails}
            classesAvailable={classNames}
            handleImageEdit={() => handleEditImageClass()}
            imageType={imageType}
          />
        );
      });
      return result;
    }
  };

  const handleBackButton = () => {
    history.goBack();
  };

  const handleClick = (index) => {
    let message = "all";
    switch (index) {
      case 1:
        message = "validation";
        break;
      case 2:
        message = "training";
        break;
    }
    setSelectedIndex(index);
    setImageType(message);
    setOpen(false);
  };

  return (
    <Observer>
      {() => (
        <React.Fragment>
          <div>
            <Paper className={classes.pageContent}>
              <div className={classes.pageHeader}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <Divider className={classes.divider} />
              <div className={classes.top}>
                <div>
                  <hr className={classes.imageLegendTraining} />
                  <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.trainingLegand")}</div>
                  <hr className={classes.imageLegendValidation} />
                  <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.validationLegand")}</div>
                </div>
                <div className={classes.buttonWrapper}>
                  <Button color="primary" variant="contained" disabled={false} onClick={() => props.handleFileUploadOpen("add-class")}>
                    {t("pages.training.manageImages.controls.addClass")}
                  </Button>
                  <ButtonGroup variant="contained" color="primary" ref={anchorRef} aria-label="split button">
                    <Button>{options[selectedIndex].label}</Button>
                    <Button
                      color="primary"
                      size="small"
                      aria-controls={open ? "split-button-menu" : undefined}
                      aria-expanded={open ? "true" : undefined}
                      aria-label="select image manipulation method"
                      aria-haspopup="menu"
                      onClick={handleToggle}
                    >
                      <ArrowDropDownIcon />
                    </Button>
                  </ButtonGroup>
                  <Popper open={open} anchorEl={anchorRef.current} role={undefined} transition disablePortal>
                    {({ TransitionProps, placement }) => (
                      <Grow
                        {...TransitionProps}
                        style={{
                          transformOrigin: placement === "bottom" ? "center top" : "center bottom"
                        }}
                      >
                        <Paper>
                          <ClickAwayListener onClickAway={handleClose}>
                            <MenuList id="split-button-menu">
                              {options.map((option, index) => (
                                <MenuItem
                                  key={option.value}
                                  disabled={index === selectedIndex}
                                  selected={index === selectedIndex}
                                  onClick={() => handleClick(index)}
                                >
                                  {option.label}
                                </MenuItem>
                              ))}
                            </MenuList>
                          </ClickAwayListener>
                        </Paper>
                      </Grow>
                    )}
                  </Popper>
                  <Button color="primary" variant="contained" onClick={() => setExpanded(!expanded)}>
                    {expanded ? t("pages.training.manageImages.controls.expandAll") : t("pages.training.manageImages.controls.collapseAll")}
                  </Button>
                </div>
              </div>
              <br/><Pagination
                      onChange={onPagination}
                      itemCount={trainingClassData.length}
                      pageNo={imageManagementStore.classPaginationStartIndex + 1}
                      pageSize={5}
                      disableItemPerPage={true}
                      disabled={false}
                    />
              {getImageAccodian()}
            </Paper>
          </div>
        </React.Fragment>
      )}
    </Observer>
  );
};

export default ImageList;
