import { useContext } from "react";
import {
  Table,
  TableBody,
  TableHead,
} from "../../../../shared/components/basictable";
import AppStore from "./../../../../stores/appstore";
import TrainingManagementStore from "../../../../stores/trainingmanagementstore";

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions,
  disableAddButton,
  disableEditButton,
}) => {
  const trainingManagementStore = useContext(TrainingManagementStore);
  const appStore = useContext(AppStore);
  let selectedRowCount = 0;
  const isSelected = (id) => {
    const selected = trainingManagementStore.selectedTrainingListData.filter(
      (item) => item._id === id
    );
    return selected.length > 0;
  };

  const getBodyData = (data) => {
    data = JSON.parse(JSON.stringify(data));
    return data.map((item) => {
      item.selected = isSelected(item._id);
      if (item.selected) {
        selectedRowCount++;
      }
      return item;
    });
  };

  const handleSelectAllClick = (event) => {
    const { checked } = event.target;
    if (checked) {
      records.forEach((trainingList) => {
        const isTrainingListPresent =
          trainingManagementStore.selectedTrainingListData.filter(
            (selectedTrainingList) =>
              selectedTrainingList._id === trainingList._id
          );
        if (!(isTrainingListPresent.length > 0)) {
          trainingManagementStore.setSelectedTrainingListRecord(trainingList);
        }
      });
      disableAddButton(true);
      if (trainingManagementStore.selectedTrainingListData.length > 1) {
        disableEditButton(true);
      }
    } else {
      const deselectedTrainingList = [];
      records.forEach((trainingList) => {
        if (
          trainingManagementStore.selectedTrainingListData.some(
            (selectedTrainingList) =>
              selectedTrainingList._id === trainingList._id
          )
        ) {
          deselectedTrainingList.push(trainingList._id);
        }
      });
      trainingManagementStore.removeSelectedTrainingListDataList(
        deselectedTrainingList
      );
      disableAddButton(false);
      disableEditButton(false);
    }
  };

  const onRowSelect = (event, trainingListId) => {
    const rowData = records.filter((item) => item._id === trainingListId);
    const selected = isSelected(trainingListId);

    if (selected) {
      trainingManagementStore.removeSelectedTrainingListData(trainingListId);
    } else {
      trainingManagementStore.setSelectedTrainingListRecord(rowData[0]);
    }

    if (trainingManagementStore.selectedTrainingListData.length > 0) {
      disableAddButton(true);
      if (trainingManagementStore.selectedTrainingListData.length > 1) {
        disableEditButton(true);
      } else {
        disableEditButton(false);
      }
    } else {
      disableAddButton(false);
    }
  };

  const data = getBodyData(records);
  return (
    <Table loading={loading} className={containerClassName}>
      <TableHead
        rowCount={records.length}
        headerData={columnDefinitions}
        onAllRowSelected={handleSelectAllClick}
        selectedRowCount={selectedRowCount}
        filters={appStore.inspectionSearchFilter.filter}
        sort={appStore.inspectionSearchFilter.sort}
      />
      <TableBody
        bodyData={data}
        onRowSelect={onRowSelect}
        headerData={columnDefinitions}
      />
    </Table>
  );
};

export default Grid;
