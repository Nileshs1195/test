import { useContext } from "react";
import {
  Table,
  TableBody,
  TableHead
} from "../../../../../shared/components/basictable";
import AppStore from "./../../../../../stores/appstore";
import TrainingManagementStore from "../../../../../stores/trainingmanagementstore";

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions,
  disableAddButton,
  disableEditButton
}) => {
  const trainingManagementStore = useContext(TrainingManagementStore);
  const appStore = useContext(AppStore);

  let selectedRowCount = 0;
  const isSelected = id => {
    const selected = trainingManagementStore.selectedInputParameter.filter(
      item => item.seqNo === id
    );
    return selected.length > 0;
  };

  const getBodyData = data => {
    data = JSON.parse(JSON.stringify(data));
    return data.map(item => {
      item._id = item.seqNo;
      item.selected = isSelected(item._id);
      if (item.selected) {
        selectedRowCount++;
      }
      return item;
    });
  };

  const handleSelectAllClick = event => {
    const { checked } = event.target;
    if (checked) {
      disableAddButton(true);
      disableEditButton(true);
      records.forEach(inputParameter => {
        const isInputParameterPresent = trainingManagementStore.selectedInputParameter.filter(
          selectedInputParameter =>
            selectedInputParameter._id === inputParameter.seqNo
        );
        if (!(isInputParameterPresent.length > 0)) {
          trainingManagementStore.setselectedInputParameter(inputParameter);
        }
      });
    } else {
      disableAddButton(false);
      disableEditButton(false);
      const deselectedInputParameter = [];
      records.forEach(inputParameter => {
        if (
          trainingManagementStore.selectedInputParameter.some(
            selectedInputParameter =>
              selectedInputParameter.seqNo === inputParameter.seqNo
          )
        ) {
          deselectedInputParameter.push(inputParameter.seqNo);
        }
      });
      trainingManagementStore.removeselectedInputParameters(
        deselectedInputParameter
      );
    }
  };

  const onRowSelect = (event, inputParameterId) => {
    const rowData = records.filter(item => item.seqNo === inputParameterId);
    const selected = isSelected(inputParameterId);
    if (selected) {
      trainingManagementStore.removeselectedInputParameter(inputParameterId);
    } else {
      trainingManagementStore.setselectedInputParameter(rowData[0]);
    }

    if (trainingManagementStore.selectedInputParameter.length > 0) {
      disableAddButton(true);
      if (trainingManagementStore.selectedInputParameter.length > 1) {
        disableEditButton(true);
      } else {
        disableEditButton(false);
      }
    } else {
      disableAddButton(false);
    }
  };

  const data = getBodyData(records);
  return (
    <Table loading={loading} className={containerClassName}>
      <TableHead
        rowCount={records.length}
        headerData={columnDefinitions}
        onAllRowSelected={handleSelectAllClick}
        selectedRowCount={selectedRowCount}
        filters={appStore.inspectionSearchFilter.filter}
        sort={appStore.inspectionSearchFilter.sort}
      />
      <TableBody
        bodyData={data}
        onRowSelect={onRowSelect}
        headerData={columnDefinitions}
      />
    </Table>
  );
};

export default Grid;
