import React from "react";
import { Button, Divider, TextField, FormControl } from "@material-ui/core";
import ArrowRightAltIcon from "@material-ui/icons/ArrowRightAlt";
import { useEffect, useContext, useState } from "react";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import AppStore from "../../../../stores/appstore";
import { APP_ROUTES } from "../../../../appconstants";
import GridMaterial from "@material-ui/core/Grid";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import Box from "@material-ui/core/Box";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import Select from "@material-ui/core/Select";
import FormHelperText from "@material-ui/core/FormHelperText";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import { Observer } from "mobx-react-lite";
import { API_RESPONSE } from "../../../../appconstants";
import { useParams, useHistory } from "react-router-dom";
import { validateModalForm, validateFloatAndIntValue, validateDigits } from "../../../../helpers/CommonMethods";
import CustomSnackBar from "../../../../components/snackbar";

export default function TrainParameter(props) {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb } = appStore;
  const [trainRadioValue, setTrainRadioValue] = useState(null);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const {
    fetchTrainingListDataData,
    fetchListingExecutedModal,
    fetchTrainParamsDeveleperMode,
    insertTrainParamsCommonData,
    insertTrainParamsData,
    fetchBatchSeqNo
  } = trainingManagementStore;
  const [trainingListData, setTrainingListData] = useState([]);
  const [trainingId, setTrainingId] = useState(params.id);
  const [trainParamData, setTrainParamData] = useState({
    trainingModel: "",
    learningRateCLoss: "",
    learningRatePLoss: "",
    learningRate: "",
    FeatureSize: "",
    batchSize: "",
    maxIter: ""
  });
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [batchSeqNo, setBatchSeqNo] = useState(null);

  useEffect(() => {
    removeLastBreadcrumb();
    const breadcrumb = {
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", trainingId),
      label: "pages.training.training-parameter.trainParameter"
    };
    addBreadcrumb(breadcrumb);
  }, [addBreadcrumb]);

  useEffect(() => {
    fetchTrainingListData();
    trainingManagementStore.fetchListingExecutedModal();

    fetchTrainDevelopertData();
  }, []);


  useEffect(() => {
    let selectedTraining = Object.assign({}, trainingManagementStore?.selectedTrainingListData?.[0] ?? trainingManagementStore.selectedTrainingListData[0]);
    if (selectedTraining?.trainParameter?.mode) {
      let parameter = Object.assign({}, selectedTraining?.trainParameter);
      setTrainRadioValue(parameter.mode);
      handleSetTrainData("trainingModel", parameter.preModel);
    }
  }, [trainingManagementStore]);

  const fetchTrainingListData = () => {
    fetchListingExecutedModal().then((response)=>{
      if(response.data && response.status === API_RESPONSE.SUCCESS_STATUS_CODE){
        let excludeCurrentTraining = response.data.filter((obj)=>obj.id !== params.id);
        let trainingListList = excludeCurrentTraining.map((item) => {
          const container = {};
          container["id"] = item.id;
          container["title"] = item.modelName;
          return container;
        });
        setTrainingListData(trainingListList);
      } else {
        fetchTrainParamsData();
        // setsnapbarMessage({ message: t("pages.training.errors.training-list.fetch-failed") });
      }
    }).catch((err)=>{
      console.log("err",err);
    })
    // fetchTrainingListDataData()
    //   .then((response) => {
    //     if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
    //       let trainingListList = response.data.map((item) => {
    //         const container = {};
    //         container["id"] = item._id;
    //         container["title"] = item.modelName;
    //         return container;
    //       });
    //       setTrainingListData(trainingListList);
    //     } else {
    //       console.log("Error occurred while fetching training list data");
    //       fetchTrainParamsData();
    //     }
    //   }).catch((err) => {
    //     console.log('error', err);
    //   });
  }

  const fetchTrainParamsData = () => {
    trainingManagementStore.fetchTrainParamsData(
      trainingId
    ).then((response) => {
      if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setTrainRadioValue(response.data.mode);
        handleSetTrainData("trainingModel", response.data.preModel !== "None" ? response.data.preModel : "");
      } else {
        console.log("Error occurred while fetching training params data");
      }
    }).catch((err) => {
      console.log('error', err);
    });
  }

  const fetchTrainDevelopertData = () => {
    fetchTrainParamsDeveleperMode(
      trainingId
    ).then((response) => {
      if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        const develpModeData = response.data;
        for (const fieldName in develpModeData) {
          handleSetTrainData(fieldName, develpModeData[fieldName]);
        }
      } else {
        console.log("Error occurred while fetching training params data");
      }
    }).catch((err) => {
      console.log('error', err);
    });
  }

  const handleTrainRadioChange = event => {
    setModalFormErrors({});
    setTrainRadioValue(event.target.value);
  };

  const handleValidation = (data) => {
    let errorMessage = t("pages.training.training-list.modal.error-text");
    let status = validateModalForm(
      data,
      modalFormErrors,
      errorMessage,
      handleModalFormErrors
    );
    return status;
  }

  const handleSetTrainData = (name, value) => {
    setTrainParamData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleModalFormErrors = data => {
    setModalFormErrors(Object.assign({}, modalFormErrors, data));
  };

  const onChangeTrainData = event => {
    const { name, value } = event.target;
    const fieldName = name;
    const fieldError = `${name}ErrorMsg`;
    let isFloatAndIntValue = validateFloatAndIntValue(value);
    let isIntOnly = validateDigits(value);

    if (fieldName === "trainingModel") {
      handleSetTrainData(fieldName, value);
    } else {
      isFloatAndIntValue ? handleSetTrainData(fieldName, Number(value)) : handleSetTrainData(fieldName, value);
    }

    if (value.length > 0) {
      if (fieldName === "trainingModel") {
        handleModalFormErrors({
          [fieldName]: false,
          [fieldError]: ""
        });
      } else {
        if (fieldName === "learningRateCLoss" || fieldName === "learningRatePLoss" || fieldName === "learningRate") {
          if (isFloatAndIntValue) {
            handleModalFormErrors({
              [fieldName]: false,
              [fieldError]: ""
            });
          } else {
            handleModalFormErrors({
              [fieldName]: true,
              [fieldError]: t("pages.training.errors.modal-errors.floatAndIntError")
            });
          }
        } else {
          if (isIntOnly) {
            handleModalFormErrors({
              [fieldName]: false,
              [fieldError]: ""
            });
          } else {
            handleModalFormErrors({
              [fieldName]: true,
              [fieldError]: t("pages.training.errors.modal-errors.digits")
            });
          }
        }
      }
    } else {
      handleModalFormErrors({
        [fieldName]: false,
        [fieldError]: ""
      });
    }
  };

  const getBatchSeqNo = () => {
    fetchBatchSeqNo(
      trainingId,
      "parameterSearch"
    ).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setBatchSeqNo(response?.data?.seqNo) 
      }
    });
  };

  const onClickSave = () => {
    if (trainRadioValue === "developerMode") {
      var data = {
        trainingModel: trainParamData.trainingModel,
        learningRateCLoss: trainParamData.learningRateCLoss,
        learningRatePLoss: trainParamData.learningRatePLoss,
        learningRate: trainParamData.learningRate,
        FeatureSize: trainParamData.FeatureSize,
        batchSize: trainParamData.batchSize,
        maxIter: trainParamData.maxIter
      };
    } else {
      data = { trainingModel: trainParamData?.trainingModel };
    }
    let isValid = handleValidation(data);
    if (isValid) {
     saveTrainParamsData();
    }
  };

  const saveTrainParamsData = () => {
    if(trainRadioValue === "developerMode") {
      saveTrainParamModeData();
      saveDeveloperModeData();
    } else {
      saveTrainParamModeData();
    }
  };

  const saveTrainParamModeData = () => {
    const commonData = {
      preModel: trainParamData.trainingModel,
      mode: trainRadioValue
    };
    insertTrainParamsCommonData(
      trainingId,
      commonData
    ).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setsnapbarMessage({ message: t("pages.training.success.train-param.mode-updated") });
        if(trainRadioValue !== "developerMode") {
          getBatchSeqNo();
          setTimeout(() => {
            gotoProgressBarScreen();
          }, 2000);
        }
      } else {
        setsnapbarMessage({ message: t("pages.training.errors.train-param.update-mode-failed") });
      }
    });
    setsnapbarMessage({ message: "" });
  };

  const saveDeveloperModeData = () => {
    const reqPayload = {
      optFlag: "standard",
      ftFlag: 101,
      FeatureSize: trainParamData.FeatureSize,
      learningRateCLoss: trainParamData.learningRateCLoss,
      learningRatePLoss: trainParamData.learningRatePLoss,
      learningRate: 25.00,
      batchSize: trainParamData.batchSize,
      maxIter: trainParamData.maxIter,
      holdTemp: 20,
      gpuID: 1233
    };

    insertTrainParamsData(
      trainingId,
      reqPayload
    ).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setsnapbarMessage({ message: t("pages.training.success.train-param.mode-updated") });
        setTimeout(() => {
          gotoProgressBarScreen();
        }, 2000);
      } else {
        setsnapbarMessage({ message: t("pages.training.errors.train-param.developer-data-failed") });
        console.log("Error occurred while saving train parameter developermode");
      }
    });
    setsnapbarMessage({ message: "" });
  };

  const gotoProgressBarScreen = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH.replace(":id", trainingId).replace(":seqNo", batchSeqNo));
  };

  return (
    <Observer>
      {() => (
        <Box p={2} className={classes.pageContent}>
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          {<Box className={classes.trainParameterContainer} alignItems="center">
            <GridMaterial container justify="center">
              <GridMaterial item xs={12} md={8} lg={8} className={classes.border}>
                <div className={classes.paperTitle}>
                  {t("pages.training.training-parameter.train-parameter.train-parameter-mode")}
                </div>
                <Divider className={classes.divider} />
                <div className={classes.timeInfo}>
                  {t("pages.training.training-parameter.train-parameter.low")}{" "}
                  <ArrowRightAltIcon className={classes.arrowFlip} />
                  <ArrowRightAltIcon className={classes.arrowFlip} />{" "}
                  {t("pages.training.training-parameter.train-parameter.training-time")}{" "}
                  <ArrowRightAltIcon />
                  <ArrowRightAltIcon />{" "}
                  {t("pages.training.training-parameter.train-parameter.high")}
                </div>
                <FormControl component="fieldset" alignItems="center">
                  <Box display="flex" alignItems="center">
                    <RadioGroup
                      aria-label="mode"
                      name="mode"
                      value={trainRadioValue}
                      onChange={handleTrainRadioChange}
                      row="true"
                    >
                      <FormControlLabel
                        value="simple"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.simple")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        value="recommended"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.recommended")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        value="advanced"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.advanced")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        value="developerMode"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.developer")}
                        labelPlacement="end"
                      />
                    </RadioGroup>
                  </Box>
                </FormControl>
              </GridMaterial>
            </GridMaterial>
            <form autoComplete="off">
              <GridMaterial container justify="center">
                <GridMaterial container item xs={12} md={10} lg={8} justify="center" spacing={2}>
                  <GridMaterial item xs={12} md={4} lg={3}>
                    <FormControl
                      className={classes.formControl}
                      error={modalFormErrors["trainingModel"]}
                      margin="none"
                    >
                      <InputLabel
                        id="demo-simple-select-label"
                        className={classes.formSelectLabel}
                      >
                        {t("pages.training.training-parameter.train-parameter.select-training-model")}
                      </InputLabel>
                      <Select
                        labelId="demo-simple-select-helper-label"
                        id="demo-simple-select-helper"
                        disabled={props.isActionDisabled}
                        className={classes.formFields}
                        value={trainParamData.trainingModel}
                        onChange={onChangeTrainData}
                        name="trainingModel"
                      >
                        {trainingListData.map(item => {
                          return <MenuItem value={item.id}>{item.title}</MenuItem>;
                        })}
                      </Select>
                      <FormHelperText>
                        {modalFormErrors["trainingModelErrorMsg"]}
                      </FormHelperText>
                    </FormControl>
                  </GridMaterial>
                </GridMaterial>

                {trainRadioValue && trainRadioValue == "developerMode" && (
                  <GridMaterial container item xs={12} md={10} lg={8} justify="center" spacing={2}>
                    <GridMaterial item xs={6} md={4} lg={3}>
                      <FormControl className={classes.formControl} margin="dense">
                        <TextField
                          fullWidth
                          disabled={props.isActionDisabled}
                          id="batchSize"
                          name="batchSize"
                          label={t("pages.training.training-parameter.train-parameter.batch-size")}
                          value={trainParamData.batchSize}
                          onChange={onChangeTrainData}
                          error={modalFormErrors["batchSize"]}
                          helperText={
                            modalFormErrors["batchSizeErrorMsg"] !== "" &&
                            modalFormErrors["batchSizeErrorMsg"]
                          }
                        />
                      </FormControl>
                    </GridMaterial>
                    <GridMaterial item xs={6} md={4} lg={3}>
                      <FormControl className={classes.formControl} margin="dense">
                        <TextField
                          fullWidth
                          disabled={props.isActionDisabled}
                          id="FeatureSize"
                          name="FeatureSize"
                          label={t("pages.training.training-parameter.train-parameter.training-features")}
                          value={trainParamData.FeatureSize}
                          onChange={onChangeTrainData}
                          error={modalFormErrors["FeatureSize"]}
                          helperText={
                            modalFormErrors["FeatureSizeErrorMsg"] !== "" &&
                            modalFormErrors["FeatureSizeErrorMsg"]
                          }
                        />
                      </FormControl>
                    </GridMaterial>
                    <GridMaterial item xs={6} md={4} lg={3}>
                      <FormControl className={classes.formControl} margin="dense">
                        <TextField
                          fullWidth
                          disabled={props.isActionDisabled}
                          id="maxIter"
                          name="maxIter"
                          label={t("pages.training.training-parameter.train-parameter.Iterations")}
                          value={trainParamData.maxIter}
                          onChange={onChangeTrainData}
                          error={modalFormErrors["maxIter"]}
                          helperText={
                            modalFormErrors["maxIterErrorMsg"] !== "" &&
                            modalFormErrors["maxIterErrorMsg"]
                          }
                        />
                      </FormControl>
                    </GridMaterial>
                  </GridMaterial>
                )}
                {trainRadioValue && trainRadioValue == "developerMode" && (
                  <GridMaterial container item xs={12} md={10} lg={8} justify="center" spacing={2} >
                    <GridMaterial item xs={6} md={4} lg={3}>
                      <FormControl className={classes.formControl} margin="dense">
                        <TextField
                          fullWidth
                          disabled={props.isActionDisabled}
                          id="learningRateCLoss"
                          name="learningRateCLoss"
                          label={t("pages.training.training-parameter.train-parameter.closs-factor")}
                          value={trainParamData.learningRateCLoss}
                          onChange={onChangeTrainData}
                          error={modalFormErrors["learningRateCLoss"]}
                          helperText={
                            modalFormErrors["learningRateCLossErrorMsg"] !== "" &&
                            modalFormErrors["learningRateCLossErrorMsg"]
                          }
                        />
                      </FormControl>
                    </GridMaterial>
                    <GridMaterial item xs={6} md={4} lg={3}>
                      <FormControl className={classes.formControl} margin="dense">
                        <TextField
                          fullWidth
                          disabled={props.isActionDisabled}
                          id="learningRatePLoss"
                          name="learningRatePLoss"
                          label={t("pages.training.training-parameter.train-parameter.ploss-factor")}
                          value={trainParamData.learningRatePLoss}
                          onChange={onChangeTrainData}
                          error={modalFormErrors["learningRatePLoss"]}
                          helperText={
                            modalFormErrors["learningRatePLossErrorMsg"] !== "" &&
                            modalFormErrors["learningRatePLossErrorMsg"]
                          }
                        />
                      </FormControl>
                    </GridMaterial>
                    <GridMaterial item xs={6} md={4} lg={3}>
                      <FormControl className={classes.formControl} margin="dense">
                        <TextField
                          fullWidth
                          disabled={props.isActionDisabled}
                          id="learningRate"
                          name="learningRate"
                          label={t("pages.training.training-parameter.train-parameter.eloss-factor")}
                          value={trainParamData.learningRate}
                          onChange={onChangeTrainData}
                          error={modalFormErrors["learningRate"]}
                          helperText={
                            modalFormErrors["learningRateErrorMsg"] !== "" &&
                            modalFormErrors["learningRateErrorMsg"]
                          }
                        />
                      </FormControl>
                    </GridMaterial>
                  </GridMaterial>
                )}
              </GridMaterial>
            </form>
          </Box>}
          <div className={classes.buttonWrapper} justifyContent="flex-end">
            <Button
              color="primary"
              variant="contained"
              disabled={props.isActionDisabled}
              onClick={onClickSave}
            >
              {t("pages.training.training-parameter.train-parameter.save-proceed")}
            </Button>
          </div>
        </Box>
      )}
    </Observer>
  );
}
