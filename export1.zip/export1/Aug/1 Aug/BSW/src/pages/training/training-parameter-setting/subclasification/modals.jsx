import {
  TextField,
  FormControl,
  FormControlLabel,
  Checkbox
} from "@material-ui/core";
import GridMaterial from "@material-ui/core/Grid";
import { useTranslation } from "react-i18next";
import { useStyles } from "./style";
import Modal from "../../../../shared/components/ui/modal";

const Modals = props => {
  const {
    modalType,
    open,
    onClose,
    onSubmit,
    onChangeFieldData,
    modalFormErrors,
    inputParameter
  } = props;
  const classes = useStyles();
  const { t } = useTranslation();

  switch (modalType) {
    case "subDeleteConfirmModal":
      return (
        <Modal
          open={open}
          onClose={onClose}
          onSubmit={onSubmit}
          widthClass={classes.confirmationModalWidth}
          showControls
          primaryButtonTextKey={t(
            "pages.training.input-parameter.modal.delete-btn"
          )}
          secondaryButtonTextKey={t(
            "pages.training.input-parameter.modal.cancel-btn"
          )}
        >
          <div className={classes.modalTextPadding}>
            <h3 className={classes.modalTitle}>
              {t("pages.training.input-parameter.modal.deleteRecordTitle")}
            </h3>
            <div className={classes.confirmationModalPadding}>
              <label htmlFor="">
                {t("pages.training.input-parameter.modal.deleteRecordMessage")}
              </label>
            </div>
          </div>
        </Modal>
      );
      break;
    case "subEdit":
      return (
        <Modal
          open={open}
          onClose={onClose}
          onSubmit={onSubmit}
          widthClass={classes.modalWidth}
          showControls
          primaryButtonTextKey={"OK"}
          secondaryButtonTextKey={
            "pages.training.input-parameter.grid.cutomization.modal.cancel-btn"
          }
        >
          <h3 className={classes.modalTitle}>
            {t("pages.training.input-parameter.modal.edit-class")}
          </h3>
          <div className={classes.modalTextPadding}>
            <form autoComplete="off">
              <GridMaterial container spacing={2} className={classes.mT1}>
                <GridMaterial item xs={12}>
                  <FormControl className={classes.formControl} margin="none">
                    <TextField
                      fullWidth
                      id="className"
                      name="className"
                      label={t(
                        "pages.training.input-parameter.grid.class-name"
                      )}
                      value={inputParameter.className}
                      onChange={onChangeFieldData}
                      error={modalFormErrors["className"]}
                      helperText={
                        modalFormErrors["classNameErrorMsg"] !== "" &&
                        modalFormErrors["classNameErrorMsg"]
                      }
                    />
                  </FormControl>
                </GridMaterial>
                <GridMaterial item xs={12} className={classes.mB1}>
                  <FormControl className={classes.formControl} margin="none">
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={
                            inputParameter.priorKnowledge === "Yes" ||
                            inputParameter.priorKnowledge === true
                              ? true
                              : false
                          }
                          onChange={onChangeFieldData}
                          name="priorKnowledge"
                          color="primary"
                        />
                      }
                      label={t(
                        "pages.training.input-parameter.grid.prior-knowledge"
                      )}
                    />
                  </FormControl>
                </GridMaterial>
              </GridMaterial>
            </form>
          </div>
        </Modal>
      );
      break;
    case 'addClass':
      return (
        <Modal
        open={open}
        onClose={onClose}
        onSubmit={onSubmit}
        widthClass={classes.modalWidth}
        showControls
        primaryButtonTextKey={"OK"}
        secondaryButtonTextKey={
          "pages.training.input-parameter.grid.cutomization.modal.cancel-btn"
        }
      >
        <h3 className={classes.modalTitle}>
          {t("pages.training.input-parameter.modal.add-class")}
        </h3>
        <div className={classes.modalTextPadding}>
          <form autoComplete="off">
            <GridMaterial container spacing={2} className={classes.mT1}>
              <GridMaterial item xs={12}>
                <FormControl className={classes.formControl} margin="none">
                  <TextField
                    fullWidth
                    id="className"
                    name="className"
                    label={t(
                      "pages.training.input-parameter.grid.class-name"
                    )}
                    onChange={onChangeFieldData}
                    error={modalFormErrors["className"]}
                    helperText={
                      modalFormErrors["classNameErrorMsg"] !== "" &&
                      modalFormErrors["classNameErrorMsg"]
                    }
                  />
                </FormControl>
              </GridMaterial>
            </GridMaterial>
          </form>
        </div>
      </Modal>
      )
    default:
      return null;
  }
};

export default Modals;
