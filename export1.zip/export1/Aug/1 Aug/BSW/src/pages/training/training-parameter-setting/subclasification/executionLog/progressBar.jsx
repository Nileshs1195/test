import React from "react";
import { useEffect, useContext, useState } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Grid, Typography } from "@material-ui/core";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useHistory, useParams } from "react-router-dom";
import { useStyles } from "./style";
import AppStore from "../../../../../stores/appstore";
import { API_RESPONSE, APP_ROUTES } from "../../../../../appconstants";
import Breadcrumb from "../../../../../shared/components/ui/breadcrumb";
import LinearProgressBar from "../../../../../components/linearprogressbar";
import { useTranslation } from "react-i18next";
import TrainingManagementStore from "./../../../../../stores/trainingmanagementstore";
import BackButton from "../../../../../components/backbutton";
import CustomSnackBar from "../../../../../components/snackbar";
import CancelExecutionModal from "../../../../../components/modal";

const ProgressBar = (props) => {
  const params = useParams();
  const history = useHistory();
  const classes = useStyles();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, updateLastBreadcrumb, removeLastBreadcrumb } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [isResultSetVisible, setResultSetVisibility] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [stopExecution, setStopExecution] = useState(false);
  const [snapbarMessage, setSnapbarMessage] = useState({
    message: ""
  });
  const [resultSet, setResultSet] = useState({
    progress: 0,
    Rate: 0,
    Ploss: 0,
    Closs: 0,
    elapsedTime: 0,
    modelName: "",
    noOfFeatures: 0,
    status: 0,
    mode: 0
  });
  const [inputData, setInputData] = useState({
    trainingId: "",
    seqNos: ""
  });

  useEffect(() => {
    window.addEventListener("beforeunload", () => alert());
    removeLastBreadcrumb();
    updateLastBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });

    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.subclassificationExecutionLog"
    });
  }, [addBreadcrumb]);

  useEffect(() => {
    setInputData((prevState) => ({
      ...prevState,
      trainingId: params.id
    }));
    async function fetchInputParamsData() {
      let response = await trainingManagementStore.fetchInputSelectedData();
      if (response !== "") {
        setInputData((prevState) => ({
          ...prevState,
          seqNos: response
        }));
      }
    }
    fetchInputParamsData();
  }, []);

  useEffect(async () => {
    if (resultSet?.status === 8) {
      // await trainingManagementStore.stopExecution(params.id);
      trainingManagementStore.setSnapbarMessage({
        message: t("pages.training.errors.subclassification.execution-failed"),
        type: "error",
        open: true
      });
      // setTimeout(() => {
      //   history.goBack();
      // }, 1000);
    }
  }, [resultSet]);

  const displayData = () => {
    setResultSetVisibility(true);
  };

  const handleBackButton = async () => {
    setOpenModal(false);
    if (resultSet?.progress === 100) {
      history.replace();
      history.goBack();
    } else {
      await trainingManagementStore
        .stopExecution(params.id)
        .then(async (response) => {
          if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            await setStopExecution(true);
            // trainingManagementStore.setSnapbarMessage({
            //   message: "Successfully stopped execution",
            //   type: "success",
            //   open: true
            // })
            setTimeout(() => {
              history.replace();
              history.goBack();
            }, 1000);
          } else {
          }
        })
        .catch((xhr) => {});
    }
  };

  const goToSuggestionResultPage = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX.replace(":id", params.id));
  };

  return (
    <Observer>
      {() => (
        <div>
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton
                  handleBackButton={() => {
                    resultSet?.progress < 100
                      ? setOpenModal(true)
                      : history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
                  }}
                />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <div>
                {/* <Button color="primary" variant="contained" onClick={() => {
                  history.goBack()
                }} disabled={resultSet?.progress < 100}>
                  {t("pages.training.input-parameter.controls.back")}
                </Button> */}{" "}
                &nbsp;
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => {
                    setOpenModal(true);
                  }}
                  disabled={resultSet?.progress >= 100}
                >
                  {t("pages.training.input-parameter.controls.cancel-btn")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.mtop}>
              <CancelExecutionModal
                open={openModal}
                onClose={() => {
                  setOpenModal(false);
                }}
                onSubmit={handleBackButton}
              />
              <LinearProgressBar
                stopExecution={stopExecution}
                setResultSet={setResultSet}
                displayData={displayData}
                method="subclassification"
                inputData={inputData}
              />
            </div>

            {isResultSetVisible && (
              <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                  <Typography className={classes.heading}>{t("pages.training.input-parameter.show-hide")}</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Box m={1} p={1} bgcolor="background.paper" className={classes.resultBox} flexGrow={1}>
                    <Box p={1} className={classes.boxwidth}>
                      <Paper variant="outlined" className={classes.paperPadd}>
                        <Grid container spacing={1}>
                          <Grid item xs={12} className={classes.textCenter}>
                            <Typography variant="h6" gutterBottom>
                              {t("pages.training.input-parameter.result")}
                            </Typography>
                            <Divider />
                          </Grid>

                          <Grid item xs={12} className={classes.buttonWrapper}>
                            <Button color="primary" variant="contained" onClick={() => goToSuggestionResultPage()}>
                              {t("pages.training.input-parameter.controls.show-suggestion-result")}
                            </Button>
                          </Grid>
                        </Grid>
                      </Paper>
                    </Box>
                  </Box>
                </AccordionDetails>
              </Accordion>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default ProgressBar;
