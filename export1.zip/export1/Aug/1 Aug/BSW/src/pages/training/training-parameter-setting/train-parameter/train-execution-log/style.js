import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    minHeight: "100vh"
  },
  paper: {
    maxHeight: "35%"
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  divider: {
    marginTop: theme.spacing(2),
  },
  accordionContainer: {
    marginTop: "24px"
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2),
    },
  },
  mtop: {
    marginTop: "16px"
  },
  textRight: {
    textAlign: "right"
  },
  textCenter: {
    textAlign: "center"
  },
  paperPadd: {
    padding: "12px 16px 16px 16px",
  },
  boxwidth: {
    width: "65%",
  },
  space: {
    margin: "16px 0px 0px 0px"
  },
  resultBox: {
    display: "flex",
    justifyContent: "center"
  },
  pad8: {
    textAlign: "center",
    "&.MuiGrid-item": {
      paddingBottom: "16px"
    }
  },
  breadcrumbWraper: {
    display: "flex"
  },
  tableContainerFooter: {
    height: "calc(100vh - 405px)",
    marginTop: "8px"
  },
  tableContainer: {
    height: "calc(100vh - 357px)",
      "& table thead th:first-child": {
        transform: "translateY(-1px) scaleX(1)"
    }
  },
  accSummary: {
    "&.Mui-expanded": {
      minHeight: "48px !important"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  accSumTitle: {
    fontWeight: "500"
  },
  accDetails: {
    padding: "0px 16px 16px"
  }
}));