import { Paper, Divider, FormControlLabel, Switch, Slider, Button, TextField, Grid } from "@material-ui/core";
import { Observer } from "mobx-react-lite";
import { useStyles } from "./style";
import { useContext, useEffect, useState } from "react";
import Pagination from "../../../shared/components/basictable/pagination";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import AppStore from "../../../stores/appstore";
import { APP_ROUTES } from "../../../appconstants";
import ClassComponent from "./droppableclasscomponent/droppableclasscomponent";
import { DragDropContext } from "react-beautiful-dnd";
import { useParams } from "react-router-dom";
import ImageManagementStore from '../../../stores/imagemanagementstore'
import  CompareImageView  from './compareimageview';

const SuggestionResultDisplayFix = () => {
  const params = useParams()
  const classes = useStyles();
  const [value, setValue] = useState(0);
  const appStore = useContext(AppStore);
  const { addBreadcrumb, updateLastBreadcrumb, removeLastBreadcrumb } = appStore;
  const imageManagementStore = useContext(ImageManagementStore)
  const [isCompareImageview, setCompareImageview] = useState(false);
  const [selectedImagesCount,setSelectedImagesCount] = useState(0)

  const initialColumns = [
    {
      className: "class1",
      seqNo: 1,
      list: [
        {
          dimentionX: 259,
          dimentionY: 194,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 28,
          size: 6109,
          uploadFileName: "ADC-IG-image-group-1.6.jpg",
          probability: "0.5252"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 27,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (9).png",
          probability: "0.6584"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 26,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (8).png",
          probability: "0.2175"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 25,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (7).png",
          probability: "0.6582"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 24,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (6).png",
          probability: "0.9695"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 23,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (5).png",
          probability: "0.2349"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 22,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (4).png",
          probability: "0.5568"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 21,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (3).png",
          probability: "0.9447"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 20,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (15).png",
          probability: "0.3235"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 200,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (15).png",
          probability: "0.9845"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 201,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (15).png",
          probability: "0.3245"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 202,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (15).png",
          probability: "0.7645"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 203,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (15).png",
          probability: "0.6545"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 204,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (15).png",
          probability: "0.5746"
        },
        {
          dimentionX: 1920,
          dimentionY: 1080,
          fileName: "000000000000000920.png",
          imageMode: "none",
          imageType: "image/png",
          seqNo: 205,
          size: 88925,
          uploadFileName: "ADC-IG-image-group-1.7 - Copy (15).png",
          probability: "0.3215"
        }
      ]
    },
    {
      className: "class2",
      seqNo: 2,
      list: [
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 12,
          size: 5544,
          uploadFileName: "7.jpg",
          probability: "0.9989"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 11,
          size: 4531,
          uploadFileName: "6.jpg",
          probability: "0.2456"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 10,
          size: 5994,
          uploadFileName: "5.jpg",
          probability: "0.1212"
        }
      ]
    },
    {
      className: "class2",
      seqNo: 3,
      list: [
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 12,
          size: 5544,
          uploadFileName: "7.jpg",
          probability: "0.9989"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 11,
          size: 4531,
          uploadFileName: "6.jpg",
          probability: "0.2456"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 10,
          size: 5994,
          uploadFileName: "5.jpg",
          probability: "0.1212"
        }
      ]
    },
    {
      className: "class2",
      seqNo: 4,
      list: [
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 12,
          size: 5544,
          uploadFileName: "7.jpg",
          probability: "0.9989"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 11,
          size: 4531,
          uploadFileName: "6.jpg",
          probability: "0.2456"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 10,
          size: 5994,
          uploadFileName: "5.jpg",
          probability: "0.1212"
        }
      ]
    },
    {
      className: "class2",
      seqNo: 5,
      list: [
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 12,
          size: 5544,
          uploadFileName: "7.jpg",
          probability: "0.9989"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 11,
          size: 4531,
          uploadFileName: "6.jpg",
          probability: "0.2456"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 10,
          size: 5994,
          uploadFileName: "5.jpg",
          probability: "0.1212"
        }
      ]
    },
    {
      className: "class2",
      seqNo: 6,
      list: [
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 12,
          size: 5544,
          uploadFileName: "7.jpg",
          probability: "0.9989"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 11,
          size: 4531,
          uploadFileName: "6.jpg",
          probability: "0.2456"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 10,
          size: 5994,
          uploadFileName: "5.jpg",
          probability: "0.1212"
        }
      ]
    },
    {
      className: "class2",
      seqNo: 7,
      list: [
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 12,
          size: 5544,
          uploadFileName: "7.jpg",
          probability: "0.9989"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 11,
          size: 4531,
          uploadFileName: "6.jpg",
          probability: "0.2456"
        },
        {
          dimentionX: 275,
          dimentionY: 183,
          fileName: "000000000000000920.jpg",
          imageMode: "none",
          imageType: "image/jpeg",
          seqNo: 10,
          size: 5994,
          uploadFileName: "5.jpg",
          probability: "0.1212"
        }
      ]
    }
  ];

  const [columns, setColumns] = useState(initialColumns);



  useEffect(() => {
    window.addEventListener("beforeunload", () => alert());
    removeLastBreadcrumb();
    updateLastBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes",params.classes),
      label: "pages.training.training-parameter.breadcrumb.subclassification"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX,
      label: "pages.training.training-parameter.breadcrumb.suggestionResultDisplay"
    });
    getClassesData();
  }, [addBreadcrumb,selectedImagesCount]);

  const handleImageCount =(count) =>{
    setSelectedImagesCount(count);
  }
  
  const getImageAccodian = () => {
    let result = [];
    columns.forEach((element) => {
      let higher = [];
      let lower = [];
      element.list.forEach((item) => {
        if (item.probability >= value) {
          higher.push(item);
        } else {
          lower.push(item);
        }
      });
      result.push(<ClassComponent selectedImageCount={handleImageCount} classData={element} key={element.seqNo} higherImages={higher} lowerImages={lower} />);
    });
    return result;
  };
  const handleSuggestionResultModal = (label) => {
    switch(label) {
      case "RESET-ALL":
      break;
      case "RESET":
      break;
      case "COMPARE-IMAGES":
        setCompareImageview((isOpen)=>!isOpen);
      break;
      case "TRANSFERRED-IMAGES":
      break;
      case "FINISH":
      break;
      default:
    }
  } 

  const onDragEnd = ({ source, destination }) => {
    // Make sure we have a valid destination
    if (destination === undefined || destination === null || source.droppableId === destination.droppableId) return null;

    // Set start and end variables
    const start = columns.filter((element) => {
      return element.className === source.droppableId;
    })[0];
    const end = columns.filter((element) => {
      return element.className === destination.droppableId;
    })[0];

    // Filter the start list
    const newStartList = start.list.filter((_, idx) => idx !== source.index);

    // Create a new source column
    const newStartCol = {
      seqNo: start.seqNo,
      className: start.className,
      list: newStartList
    };

    // Make a new destination list array
    const newEndList = end.list;

    // Insert the item into the end list
    newEndList.splice(destination.index, 0, start.list[source.index]);

    // Create a new destination column
    const newEndCol = {
      seqNo: end.seqNo,
      className: end.className,
      list: newEndList
    };

    const otherColumns = JSON.parse(JSON.stringify(columns));
    const startIndex = otherColumns.findIndex((x) => x.seqNo === newStartCol.seqNo);
    const endIndex = otherColumns.findIndex((x) => x.seqNo === newEndCol.seqNo);
    otherColumns[startIndex] = newStartCol;
    otherColumns[endIndex] = newEndCol;

    setColumns(otherColumns);
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const onPagination = (options) => {
    appStore.updatePaginationStartIndex((options.pageNo > 0 ? options.pageNo - 1 : options.pageNo) * options.pageSize)
    getClassesData();
  }

  const getClassesData = () =>{
    setColumns(initialColumns.slice(appStore.paginationStartIndex,appStore.paginationStartIndex+5))
  }

  return (
    <Observer>
      {() => (
        <div>
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
            </div>
            <CompareImageView
              open={isCompareImageview}
              onClose={()=>setCompareImageview((isOpen)=>!isOpen)}
            />
            <Divider className={classes.divider} />
            <div className={classes.controlContainer}>
              <Pagination
                disabled={false}
                disableItemPerPage={true}
                itemCount={initialColumns.length}
                onChange={onPagination}
                pageNo={appStore.inspectionSearchFilter.pageNo + 1}
                pageSize={5}
              />
              <div className={classes.buttonWrapper}>
                <FormControlLabel
                  control={<Switch /*checked={state.checkedA} onChange={handleChange}*/ name="checkedA" color="primary" />}
                  label="Show Graph"
                  labelPlacement="start"
                />
                <div className={classes.root}>
                  <Slider value={value} onChange={handleChange} aria-labelledby="continuous-slider" max={1.0} step={0.0001} />
                </div>
                <TextField
                  id="probabilityThreshold"
                  name="probabilityThreshold"
                  margin="normal"
                  value={value}
                  onChange={(event) => handleChange(event, event.target.value)}
                />
              </div>
            </div>
            <DragDropContext onDragEnd={onDragEnd}>{getImageAccodian()}</DragDropContext>
            <div className={classes.footerContainer}>
              <div className={classes.buttonGroup}>
                <Button variant="outlined" size="small" className={classes.buttons} disabled={false}>
                  {"RESET ALL"}
                </Button>
                <Button variant="outlined" size="small" className={classes.buttons} disabled={false}>
                  {"RESET"}
                </Button>
                <Button 
                  variant="outlined" 
                  onClick={()=>handleSuggestionResultModal('COMPARE-IMAGES')} 
                  size="small" 
                  className={classes.buttons} 
                  disabled={selectedImagesCount == 2?false:true}>
                  {"COMPARE IMAGES"}
                </Button>
                <Button variant="outlined" size="small" className={classes.buttons} disabled={false}>
                  {"TRANSFERRED IMAGES"}
                </Button>
                <Button variant="outlined" size="small" className={classes.buttons} disabled={false}>
                  {"FINISH"}
                </Button>
              </div>
            </div>
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default SuggestionResultDisplayFix;
