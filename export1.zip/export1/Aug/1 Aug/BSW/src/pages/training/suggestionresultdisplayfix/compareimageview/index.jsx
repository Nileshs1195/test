import { Grid } from '@material-ui/core'
import React, { useContext } from 'react'
import Modal from '../../../../shared/components/ui/modal'
import ImageManagementStore from '../../../../stores/imagemanagementstore'
import { SETTINGS } from "../../../../appsettings";
import { useStyles } from './style';

function CompareImageView(props) {
  const { open, onClose } = props;
  
  const classes = useStyles();
  const imageThumbnailURL = SETTINGS.BASE_API_URL + "/api/image/";
  const imageManagementStore = useContext(ImageManagementStore)
  console.log(imageManagementStore.selectedClassImages);
  return (
    <Modal
      open={open}
      onClose={onClose}
      widthClass={classes.modalwidth}
      showControls
      primaryButtonTextKey="ok"
      secondaryButtonTextKey="cancel"
    >
      <div className={classes.modalTextPadding}>
        <h3 className={classes.modalTitle}>
          Compare Images
          </h3>
      
        <div className={classes.content}>
            {imageManagementStore.selectedClassImages.map((item, index) => (
              <Grid item xs={12} sm={6} className={classes.box} key={index}>
                <img
                  src={imageThumbnailURL + item.imageData.fileName}
                  alt={item.imageData.uploadFileName}
                  className={classes.imageCenter}
                />
                <label className={classes.imageLabel} >
                  File Name: {item.imageData.fileName}{" "} File Size: {item.imageData.size}kb {" "} Class Name: {item.imageData.className}
                </label>
              </Grid>
            ))}
        </div>
      </div>
    </Modal>
  )
}
export default CompareImageView
