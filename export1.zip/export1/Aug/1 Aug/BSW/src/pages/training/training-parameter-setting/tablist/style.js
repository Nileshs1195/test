import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles({
  tabRootCustom: {
    fontSize: "18px !important"
    //fontWeight: "600"
  }
});
