import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  paperCustom: {
    padding: 16
  },
  paperTitle: {
    textAlign: "center",
    lineHeight: "100%",
    fontWeight: theme.typography.fontWeightRegular
  },
  alignCenter: {
    textAlign: "center"
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2)
  },
  mB1: {
    marginBottom: 8
  },
  mT1: {
    marginTop: 8
  }
}));
