export const columnDefinitions = [
  {
    key: "iteration",
    text: "pages.training.training-execution-log.grid.iteration",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainLoss",
    text: "pages.training.training-execution-log.grid.main-loss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainEloss",
    text: "pages.training.training-execution-log.grid.main-eloss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainCloss",
    text: "pages.training.training-execution-log.grid.main-closs",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainPloss",
    text: "pages.training.training-execution-log.grid.main-ploss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validMainLoss",
    text: "pages.training.training-execution-log.grid.validation-main-loss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validMainEloss",
    text: "pages.training.training-execution-log.grid.validation-main-eloss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validMainCloss",
    text: "pages.training.training-execution-log.grid.validation-main-closs",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validMainPloss",
    text: "pages.training.training-execution-log.grid.validation-main-ploss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "passedTime",
    text: "pages.training.training-execution-log.grid.passed-time",
    type: "number",
    validation: { required: true, pattern: "//" }
  }
];
