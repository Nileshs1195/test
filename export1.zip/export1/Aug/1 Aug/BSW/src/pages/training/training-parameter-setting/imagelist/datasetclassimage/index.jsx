import { Observer } from "mobx-react-lite";
import { Grid, Popover, Checkbox } from "@material-ui/core";
import { useStyles } from "./style";
import ImageDetailsBox from "../imagedetailsbox";
import { useState } from "react";
import { SETTINGS } from "../../../../../appsettings";

const DatasetClassImage = ({ imageData, index, onImageSelect }) => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const imageThumbnailURL = SETTINGS.BASE_API_URL + "/api/image/";

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
    // get the specific image data by comparing in array that we get from calling getImageGroupDetailss api
    // store the imageData of matched id and pass it as props to Tabel component in PopOver component
    // pass the id to handlePopoverOpen while renering/iterating multiple images
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const opened = Boolean(anchorEl);
  return (
    <Observer>
      {() => (
        <>
          <Grid item xs={4} sm={4} md className={classes.thumbItem} key={imageData.seqNo}>
            <Checkbox
              className={classes.thumbCheckbox}
              color="primary"
              checked={imageData.selected}
              onChange={(event) => onImageSelect(event, imageData.seqNo)}
              id={index}
            />
            <div
              key={imageData.seqNo}
              aria-owns={opened ? "mouse-over-popover" : undefined}
              aria-haspopup="true"
              onMouseEnter={handlePopoverOpen}
              onMouseLeave={handlePopoverClose}
              className={imageData.imageMode === "validation" ? classes.validationThumbImg : classes.trainingThumbImg}
            >
              <img src={imageThumbnailURL + imageData.fileName} alt={imageData.uploadFileName} id={index} className={classes.imageCenter} />
            </div>
          </Grid>

          <Popover
            id="mouse-over-popover"
            className={classes.popover}
            classes={{
              paper: classes.popover_paper
            }}
            open={opened}
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left"
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "left"
            }}
            onClose={handlePopoverClose}
            disableRestoreFocus
          >
            <ImageDetailsBox imageData={imageData} />
          </Popover>
        </>
      )}
    </Observer>
  );
};
export default DatasetClassImage;
