export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true
  },
  {
    key: "priorKnowledge",
    text: "pages.training.input-parameter.grid.prior-knowledge",
    type: "string"
  },
  {
    key: "className",
    text: "pages.training.input-parameter.grid.class-name",
    type: "string",
    validation: { required: true, pattern: "//" }
  },

  {
    key: "imgCount",
    text: "pages.training.input-parameter.grid.total-images",
    type: "string",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "maskedImages",
    text: "pages.training.input-parameter.grid.masked-images",
    type: "string",
    validation: { required: true, pattern: "//" }
  }
];
