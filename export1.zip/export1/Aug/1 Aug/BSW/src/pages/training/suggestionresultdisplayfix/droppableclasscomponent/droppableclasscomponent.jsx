import { Observer } from "mobx-react-lite";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { Droppable, Draggable } from "react-beautiful-dnd";
import { useStyles } from "./style";
import { useCallback, useState, useRef, useContext, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Grid, Accordion, AccordionSummary, AccordionDetails, Checkbox, FormControlLabel, RootRef, Divider } from "@material-ui/core";
import ImageManagementStore from "../../../../stores/imagemanagementstore";
import DatasetClassImage from "../datasetclassimage";
import Pagination from "../../../../shared/components/basictable/pagination";
import CustomSnackBar from "../../../../components/snackbar";

const ClassComponent = ({ classData, key, higherImages, lowerImages, selectedImageCount }) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const anchorRef = useRef(null);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [alertSnackBar, toggleAlertSnackBar] = useState(false);
  const [totalImageCount, setTotalImageCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [higherPagination, setHigherPagination] = useState(0);
  const [lowerPagination, setLowerPagination] = useState(0);
  const imageManagementStore = useContext(ImageManagementStore);
  const [imageArray, setImageArray] = useState([]);

  useEffect(()=>{
    selectedImageCount(imageManagementStore.selectedClassImages.length);
  },[imageArray])

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const onHigherPagination = (indexObj) => {
    setHigherPagination((indexObj.pageNo > 0 ? indexObj.pageNo - 1 : indexObj.pageNo) * indexObj.pageSize);
  };

  const onLowerPagination = (indexObj) => {
    setLowerPagination((indexObj.pageNo > 0 ? indexObj.pageNo - 1 : indexObj.pageNo) * indexObj.pageSize);
  };

  const isSelected = (seqNo) => {
    const selected = imageManagementStore.selectedClassImages.filter((item) => item.imageSeqNo === seqNo && item.classSeqNo === classData.seqNo);
    return selected.length > 0;
  };

  const onImageSelect = (event,seqNo) => {
    const selected = isSelected(seqNo);
    if(selected) {
      removeSelectedImages(seqNo);
    } else {
      handleSelectedImages(seqNo);
    }
  }

  const handleSelectedImages = (seqNo) => {
    const imageList = [...classData.list];
    const objIndex = imageList.findIndex((obj) => obj.seqNo === seqNo);
    // imageList[objIndex]['selected'] = true;
    imageList[objIndex]['className'] = classData.className
    setImageArray((prevState)=>[...prevState,imageList[objIndex]]);
    imageManagementStore.setSelectedClassImage(seqNo, classData.seqNo,imageList[objIndex]);
  };

  const removeSelectedImages = (seqNo) => {
    const imageList = [...imageArray];
    const objIndex = imageList.findIndex((obj) => obj.seqNo === seqNo);
    // imageList[objIndex]['selected'] = false;
    setImageArray(imageList);
    imageManagementStore.removeSelectedClassImage([seqNo], classData.seqNo,imageArray);
  };

  const renderClassImages = () => {
    let higherImageList = [];
    let lowerImageList = [];
    for (let index = 0; index < 5; index++) {
      const higherImageItem = higherImages[index + higherPagination];
      const lowerImageItem = lowerImages[index + lowerPagination];
      if (higherImageItem) {
        higherImageList.push(
          <Draggable draggableId={higherImageItem.seqNo.toString()} index={index}>
            {(provided) => (
              <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
                <DatasetClassImage onImageSelect={onImageSelect}  imageData={higherImageItem} index={index} />
              </div>
            )}
          </Draggable>
        );
      }
      if (lowerImageItem && index < 4) {
        lowerImageList.push(
          <Draggable draggableId={lowerImageItem.seqNo.toString()} index={index}>
            {(provided) => (
              <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
                <DatasetClassImage onImageSelect={onImageSelect} imageData={lowerImageItem} index={index} />
              </div>
            )}
          </Draggable>
        );
      }
    }
    return (
      <Grid container className={classes.gridClass} key={key} spacing={2}>
        <div>{higherImageList}</div>
        <Divider orientation="vertical" flexItem={true} className={classes.probabilityThresholdDivider}></Divider>
        <div>{lowerImageList}</div>
      </Grid>
    );
  };

  const setAlertMessage = () => {
    toggleAlertSnackBar((isOpen) => !isOpen);
  };

  return (
    <Observer>
      {() => (
        <>
          {alertSnackBar ? <CustomSnackBar snapbarMessage={snapbarMessage} /> : null}
          <div className={classes.accMarginTop}>
            <Accordion defaultExpanded={true} className={classes.accMarginTop}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
                className={classes.accSummary}
              >
                <Grid container>
                  <FormControlLabel
                    control={
                      <Checkbox
                        // className={classes.thumbCheckbox}
                        color="primary"
                        checked={classData.selected}
                        id={classData.className}
                        name={classData.className}
                      />
                    }
                    label={classData.className}
                  />
                </Grid>
              </AccordionSummary>
              <AccordionDetails className={classes.accDetails}>
                <Droppable droppableId={classData.className}>
                  {(provided) => (
                    <div {...provided.droppableProps} ref={provided.innerRef}>
                      <div className={classes.container}>
                        <div className={classes.thumbWrap}>{renderClassImages()}</div>
                      </div>
                    </div>
                  )}
                </Droppable>
                <div className={classes.bottom}>
                  <Pagination
                    onChange={onHigherPagination}
                    itemCount={higherImages.length}
                    pageNo={higherPagination + 1}
                    pageSize={5}
                    disableItemPerPage={true}
                    disabled={false}
                  />
                  <Pagination
                    onChange={onLowerPagination}
                    itemCount={lowerImages.length}
                    pageNo={lowerPagination + 1}
                    pageSize={4}
                    disableItemPerPage={true}
                    disabled={false}
                  />
                </div>
              </AccordionDetails>
            </Accordion>
          </div>
        </>
      )}
    </Observer>
  );
};

export default ClassComponent;
