import { useContext } from "react";
import {
  Table,
  TableBody,
  TableHead
} from "../../../../../../shared/components/basictable";
import AppStore from "./../../../../../../stores/appstore";
import TrainingManagementStore from "../../../../../../stores/trainingmanagementstore";

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions,
  disableAddButton,
  disableButton
}) => {
  const trainingManagementStore = useContext(TrainingManagementStore);
  const appStore = useContext(AppStore);
  const { fetchImageGroupData } = trainingManagementStore;
  let selectedRowCount = 0;
  const isSelected = id => {
    const selected = trainingManagementStore.selectedTrainingDataset.filter(
      item => item.seqNo === id
    );
    return selected.length > 0;
  };

  const getBodyData = data => {
    data = JSON.parse(JSON.stringify(data));
    if (data.length > 0) {
      return data.map(item => {
        item._id = item.seqNo;
        item.selected = isSelected(item._id);
        if (item.selected) {
          selectedRowCount++;
        }
        return item;
      });
    }
  };

  const handleSelectAllClick = event => {
    const { checked } = event.target;
    if (checked) {
      disableAddButton(true);
      disableButton(true);
      records.forEach(imageGroup => {
        const isImageGroupPresent = trainingManagementStore.selectedTrainingDataset.filter(
          selectedImageGroup => selectedImageGroup._id === imageGroup.seqNo
        );
        if (!(isImageGroupPresent.length > 0)) {
          trainingManagementStore.setSelectedTrainingDataset(imageGroup);
        }
      });
    } else {
      disableAddButton(false);
      disableButton(false);
      const deselectedTrainingDataset = [];
      records.forEach(imageGroup => {
        if (
          trainingManagementStore.selectedTrainingDataset.some(
            selectedImageGroup => selectedImageGroup.seqNo === imageGroup.seqNo
          )
        ) {
          deselectedTrainingDataset.push(imageGroup.seqNo);
        }
      });
      trainingManagementStore.removeSelectedTrainingDatasets(
        deselectedTrainingDataset
      );
    }
  };

  const onRowSelect = (event, imageGroupId) => {
    const rowData = records.filter(item => item.seqNo === imageGroupId);
    const selected = isSelected(imageGroupId);

    if (selected) {
      trainingManagementStore.removeSelectedTrainingDataset(imageGroupId);
    } else {
      trainingManagementStore.setSelectedTrainingDataset(rowData[0]);
    }

    if (trainingManagementStore.selectedTrainingDataset.length > 0) {
      disableAddButton(true);
      if (trainingManagementStore.selectedTrainingDataset.length > 1) {
        disableButton(true);
      } else {
        disableButton(false);
      }
    } else {
      disableAddButton(false);
    }
  };

  const data = getBodyData(records);
  return (
    <Table loading={loading} className={containerClassName}>
      <TableHead
        rowCount={records.length}
        headerData={columnDefinitions}
        onAllRowSelected={handleSelectAllClick}
        selectedRowCount={selectedRowCount}
        filters={appStore.inspectionSearchFilter.filter}
        sort={appStore.inspectionSearchFilter.sort}
      />
      <TableBody
        bodyData={data}
        onRowSelect={onRowSelect}
        headerData={columnDefinitions}
      />
    </Table>
  );
};

export default Grid;
