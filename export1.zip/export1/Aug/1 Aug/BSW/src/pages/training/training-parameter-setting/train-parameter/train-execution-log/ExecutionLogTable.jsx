import React, { useState, useContext } from 'react'
import Grid from "./grid";
import { useStyles } from "./style";
import { columnDefinitions } from "./grid/columndefinitions";

const ExecutionLogTable = (props) => {
    const { executionLogData, loading } = props;
    const classes = useStyles();
    const [isAddButtonDisabled, disableAddButton] = useState(false);
    const [isButtonDisabled, disableButton] = useState(false);

    return (
        <>
            <Grid
                loading={loading}
                records={executionLogData}
                containerClassName={classes.tableContainer}
                columnDefinitions={columnDefinitions}
                disableAddButton={disableAddButton}
                disableButton={disableButton}
            />
        </>
    )
}

export default ExecutionLogTable
