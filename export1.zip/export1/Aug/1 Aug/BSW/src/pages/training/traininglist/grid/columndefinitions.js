export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true,
  },
  {
    key: "updatedAt",
    text: "pages.training.training-list.grid.update-date-time",
    type: "date",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "modelName",
    text: "pages.training.training-list.grid.title",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "comment",
    text: "pages.training.training-list.grid.comment",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "status",
    text: "pages.training.training-list.grid.status",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "classes",
    text: "pages.training.training-list.grid.no-of-classes",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "datasetMode",
    text: "pages.training.training-list.grid.dataset-mode",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "augmentationMode",
    text: "pages.training.training-list.grid.augmentation-mode",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "trainParamMode",
    text: "pages.training.training-list.grid.trainParam-mode",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "premodelUsed",
    text: "pages.training.training-list.grid.premodel-used",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "progress",
    text: "pages.training.training-list.grid.progress",
    type: "number",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "elapsedTime",
    text: "pages.training.training-list.grid.elapsed-time",
    type: "number",
    validation: { required: true, pattern: "//" },
  },
];
