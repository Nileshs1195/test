import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between"
  },
  thumbWrap: {
    margin: "16px 16px 8px 16px"
  },
  thumbItem: {
    position: "relative",
    zIndex: 0,
    "&:hover $thumbCheckbox": {
      display: "flex",
      backgroundColor: "white"
    },
    "@media (min-width: 960px)": {
      maxWidth: "11.11%"
    }
  },
  thumbCheckbox: {
    display: "none",
    position: "absolute",
    zIndex: 5,
    right: 12,
    top: 12,
    width: "16px",
    height: "16px",
    backgroundColor: "white",
    "&.Mui-checked": {
      display: "flex",
      backgroundColor: "white"
    }
  },
  trainingThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #3a5faa"
  },
  validationThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #dd0a55"
  },
  popover: {
    pointerEvents: "none"
  },
  popover_paper: {
    padding: theme.spacing(2)
  },
  bottom: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingBottom: "16px",
    padding: "0px 16px",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  buttonWrapper: {
    display: "flex",
    alignSelf: "center",
    zIndex: 1
  },
  accMarginTop: {
    marginTop: theme.spacing(2)
  },
  accSummary: {
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      minHeight: "48px !important"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  accDetails: {
    padding: 0,
    display: "block"
  },
  fileUpload: {
    display: "none"
  },
  modalTextPadding: {
    paddingBottom: "16px"
  },
  confirmationModalPadding: {
    paddingTop: theme.spacing(2)
  },
  confirmationModalWidth: {
    minWidth: "370px",
    maxWidth: "25%",
    minHeight: "auto"
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: 18,
    fontWeight: "normal",
    Height: "42px",
    margin: "-16px -16px 0px -16px",
    padding: "8px 16px",
    borderRadius: "4px 4px 0 0"
  },
  formControl: {
    minWidth: "100%"
  }
}));
