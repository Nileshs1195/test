import {
  Button,
  Divider,
  Paper,
  TextField,
  FormControl,
} from '@material-ui/core';
import { Observer } from 'mobx-react-lite';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router-dom';
import { APP_ROUTES, IMAGE_GROUP_LIST } from '../../../appconstants';
import Pagination from '../../../shared/components/basictable/pagination';
import Breadcrumb from '../../../shared/components/ui/breadcrumb';
import Modal from '../../../shared/components/ui/modal';
import AppStore from '../../../stores/appstore';
import TrainingManagementStore from './../../../stores/trainingmanagementstore';
import { columnDefinitions } from './grid/columndefinitions';
import Grid from './grid';
import { useStyles } from './style';
import { useCallback, useContext, useEffect, useState } from 'react';
import { API_RESPONSE } from '../../../appconstants';
import CustomSnackBar from '../../../components/snackbar';
import {
  validateModalForm,
  validateString,
} from '../../../helpers/CommonMethods';

const TrainingList = () => {
  const classes = useStyles();
  const history = useHistory();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { inspectionSearchFilter, getUserPreferences } = appStore;
  const { trainingListData, fetchTrainingListData } = trainingManagementStore;
  const { addBreadcrumb, removeAllBreadcrumbs } = appStore;
  const [loading, setLoading] = useState(false);
  const [visibleColumns, setVisibleItems] = useState(
    appStore.inspectionGridColumnPreference.filter((c) => c.isSticky !== true),
  );
  const [hiddenColumns, setHiddenItems] = useState(
    appStore.inspectionGridHiddenColumns,
  );
  const [modalTitle, setModalTitle] = useState('');
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [isEditAndNextDisabled, disableEditButton] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: '' });
  const [isTrainingListModalOpen, toggoleTrainingListModal] = useState(false);
  const [trainingData, setTrainingData] = useState({
    active: "",
    updatedAt: "",
    modelName: "",
    comment: "",
    status: 0,
    noOfClasses: 0,
    datasetMode: "",
    augmentationMode: "",
    trainParamMode: "",
    premodelUsed: "",
    progress: 0,
    elapsedTime: 0,
  });

  useEffect(() => {
    trainingManagementStore.setImageGroupGridSortParams(
      "sortOrder",
      IMAGE_GROUP_LIST.SORT_DIRECTION.ASCENDING,
    );
    if (trainingManagementStore?.selectedTrainingListData?.length > 0) {
      trainingManagementStore.clearSelectedTrainingListData();
      disableAddButton(false);
    }
  }, []);

  useEffect(() => {
    const breadcrumb = {
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-list.title",
    };
    removeAllBreadcrumbs();
    addBreadcrumb(breadcrumb);
  }, [addBreadcrumb]);

  // get traininglist
  const getTrainingListData = useCallback(async () => {
    setLoading(true);
    appStore.addInspectionGridColumnPreference(columnDefinitions);
    // let columns = columnDefinitions.filter((col) => col.isSticky !== true);
    // setVisibleItems(columnDefinitions.filter((col) => col.isSticky !== true));
    // if (!appStore.initialFilterUserPreferenceAvailable) {
    //   const data = await getUserPreferences();
    //   if (data) {
    //     appStore.updateUserPreferences(data.inspectionList.filterPreference);
    //   }
    //   appStore.initialFilterUserPreferenceAvailable = true;
    // }
    await fetchTrainingListData();
    setLoading(false);
  }, [fetchTrainingListData, trainingListData.length]);

  useEffect(() => {
    if(trainingListData.length === 0) {
      getTrainingListData();
    }
    trainingManagementStore.clearSelectedTrainingDataset();
    trainingManagementStore.setViewParameter(false);
  }, [getTrainingListData, trainingListData.length]);

  const handleTrainingListModal = (label, apply = false) => {
    switch (label) {
      case "ADD":
        setTrainingData({
          modelName: "",
          comment: "",
          isSave: "",
          datasetMode: "",
          augmentationMode: "",
          trainParamMode: "",
          preModelTrainSeqNo: "",
          updatedAt: new Date(),
          updateCount: 1,
        });
        setModalDetails(t("pages.training.training-list.modal.new-training"));
        break;
      case "EDIT":
        setModalDetails(t("pages.training.training-list.modal.update-training"))
        setTrainingData(trainingManagementStore.selectedTrainingListData[0])
        break
      case "COPY-TO-NEW":
        setModalDetails(
          t("pages.training.training-list.modal.copy-to-new-training"),
        );
        setTrainingData((prev) => ({
          ...trainingManagementStore.selectedTrainingListData[0],
          ["modelName"]: 'Copy ' + trainingManagementStore.selectedTrainingListData[0].modelName,
          ["comment"]: 'Copy of ' + trainingManagementStore.selectedTrainingListData[0].modelName,
          ["Status"]: 'Ready'
        }));
        break;
      case 'DELETE':
        setModalDetails("DELETE");
        disableAddButton(false);
        break
      case 'NEXT':
        if (trainingManagementStore?.selectedTrainingListData?.[0]?._id) {
          gotoTraining(trainingManagementStore.selectedTrainingListData[0]._id);
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.selected-id-unavailable") });
        }
        break;
      case "VIEW-PARAMETER":
        if (trainingManagementStore?.selectedTrainingListData?.[0]?._id) {
          trainingManagementStore.clearTrainingDataset();
          trainingManagementStore.setViewParameter(true);
          history.push(
            APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER.replace(
              ":id",
              trainingManagementStore.selectedTrainingListData[0]._id,
            ),
          );
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.selected-id-unavailable") });
        }
        break;
      case "RE-EXECUTE":
        gotoTraining(trainingManagementStore.selectedTrainingListData[0]._id);
      case "CLOSE":
        toggoleTrainingListModal((isOpen) => !isOpen);
        trainingManagementStore.clearSelectedTrainingListData();
        disableAddButton(false);
        break;
      default:
        break;
    }
  }

  const setModalDetails = (title) => {
    setModalFormErrors({});
    toggoleTrainingListModal((isOpen) => !isOpen);
    setModalTitle(title);
  }

  const gotoTraining = (trainingId) => {
    trainingManagementStore.clearTrainingDataset();
    history.push(
      APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(
        ':id',
        trainingId,
      ),
    );
  }

  const handleTrainingListData = (name, value) => {
    setTrainingData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    console.log(trainingData);
  }

  const handleModalFormErrors = (errorData) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, errorData));
  }

  const onChangeTrainingData = (event) => {
    const { name, value } = event.target;
    const fieldName = name;
    const fieldError = `${name}ErrorMsg`;
    let isValidString = validateString(value);
    handleTrainingListData(name, value);
    if (value.length > 0) {
      if (fieldName === "modelName" || fieldName === "comment") {
        if (isValidString) {
          handleModalFormErrors({
            [fieldName]: false,
            [fieldError]: "",
          });
        } else {
          handleModalFormErrors({
            [fieldName]: true,
            [fieldError]: t("pages.training.errors.modal-errors.alphanumeric"),
          });
        }
      }
    } else {
      handleModalFormErrors({
        [fieldName]: false,
        [fieldError]: "",
      });
    }
  }

  // create training record
  const saveTrainingListData = (reqPayload) => {
    setsnapbarMessage({ message: '' });
    trainingManagementStore
      .insertTrainingListRecord(reqPayload)
      .then((response) => {
        if (
          response?.data &&
          response?.status === API_RESPONSE.SUCCESS_STATUS_CODE
        ) {
          trainingManagementStore.setSelectedTrainingListRecord(response.data);
          getTrainingListData();
          gotoTraining(response.data._id);
          console.log("training record saved successfully");
        } else {
          setsnapbarMessage({
            message: t("pages.training.errors.training-list.save-failed"),
          });
          console.log("Error occurred while saving training record");
        }
      })
      .catch((err) => {
        console.log("error", err);
      })
  }

  const saveCloneTrainingListData = (id, data) => {
    // console.log(id,data)
    trainingManagementStore
      .cloneTrainingListRecord(id, data)
      .then((response) => {
        console.log(response)
        if (
          response?.data &&
          response?.status === API_RESPONSE.SUCCESS_STATUS_CODE
        ) {
          trainingManagementStore.setSelectedTrainingListRecord(response.data);
          getTrainingListData();
          gotoTraining(response.data.data._id);
          console.log("training record saved successfully");
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.save-failed") });
          console.log("Error occurred while saving training record");
        }
      })
      .catch((err) => {
        console.log("error", err);
      })
  }

  const handleDeleteTrainingListRecord = () => {
    trainingManagementStore
      .deleteTrainingListRecord(trainingManagementStore?.selectedTrainingListData?.[0]?._id)
      .then((response) => {
        console.log(response)
        if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          getTrainingListData();
          setsnapbarMessage({ message: t("pages.training.success.training-list.deleted") });
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.delete-failed") });
        }
      })
      .catch((err) => {
        console.log("error", err);
      })
  }

  const handleValidation = (data) => {
    let errorMessage = t("pages.training.training-list.modal.error-text");
    let status = validateModalForm(
      data,
      modalFormErrors,
      errorMessage,
      handleModalFormErrors,
    );
    return status;
  }

  const handleDuplicateEntry = (data) => {
    let find = trainingManagementStore.trainingListData.filter(e => e.modelName === data.modelName);
    return !find.length;
  }

  const createTrainingListRecord = () => {
    const data = {
      modelName: trainingData.modelName,
      comment: trainingData.comment,
    }
    let isValid = handleValidation(data);
    let isNotDuplicate = handleDuplicateEntry(data);
    if (isValid && isNotDuplicate) {
      saveTrainingListData(data);
    } else {
      // if the modal form fields are empty, the modal will be opened up using below function
      toggoleTrainingListModal((isOpen) => !isOpen);
      const alert = !isNotDuplicate
        ? setsnapbarMessage({
          message: "Duplicate Entry",
        }) : "";
    }
  }

  const copyTrainingListRecord = () => {
    const data = {
      modelName: trainingData.modelName,
      comment: trainingData.comment,
    }
    let isValid = handleValidation(data);
    let isNotDuplicate = handleDuplicateEntry(data);
    if (isValid && isNotDuplicate) {
      saveCloneTrainingListData(trainingData._id, data);
    }
    else {
      toggoleTrainingListModal((isOpen) => !isOpen);
      const alert = !isNotDuplicate
        ? setsnapbarMessage({ message: "Duplicate Entry" }) : "";
    }
  }

  // update training record
  const updateTrainingRecordData = (reqPayload) => {
    setsnapbarMessage({ message: '' });
    const trainingId = trainingData._id;
    trainingManagementStore
      .updateTrainingRecordData(trainingId, reqPayload)
      .then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          getTrainingListData();
          setsnapbarMessage({ message: t("pages.training.success.training-list.update") });
          console.log("Training record updated successfully");
        } else {
          setsnapbarMessage({
            message: t("pages.training.errors.training-list.update-failed"),
          });
          console.log("Error occurred while updating training record");
        }
      })
      .catch((err) => {
        console.log("error", err)
      })
  }

  const updateTrainingListRecord = () => {
    const data = {
      modelName: trainingData.modelName,
      comment: trainingData.comment,
      status: trainingData.status,
    }
    let isValid = handleValidation(data);
    let isNotDuplicate = handleDuplicateEntry(data);
    if (isValid && isNotDuplicate) {
      updateTrainingRecordData(data);
    } else {
      toggoleTrainingListModal((isOpen) => !isOpen);
      const alert = !isNotDuplicate
        ? setsnapbarMessage({ message: "Duplicate Entry" }) : "";
    }
  }

  const onPagination = (options) => {
    const pageNo = options.pageNo;
    appStore.updateInspectionGridPageNo(pageNo > 0 ? pageNo - 1 : 0);
    appStore.updateInspectionGridPageSize(options.pageSize);
    getTrainingListData();
  }

  const delteTrainingModal = () => {
    return <Modal
      open={isTrainingListModalOpen}
      onClose={() => handleTrainingListModal('CLOSE')}
      onSubmit={() => {
        handleDeleteTrainingListRecord();
        trainingManagementStore.clearSelectedTrainingListData();
      }}
      widthClass={classes.modalWidth}
      showControls
      primaryButtonTextKey={'pages.training.training-list.controls.delete'}
      secondaryButtonTextKey={'pages.training.training-list.controls.cancel-btn'}
    >
      <div className={classes.modalTextPadding}>
        <h3 className={classes.modalTitle}>{t("pages.training.training-parameter.dataset-mode.modal.delete")}</h3>
        <div className={classes.mT1}>{t("pages.training.training-parameter.dataset-mode.modal.deleteMsg")}</div>
      </div>
    </Modal>
  }

  const newTrainingModel = () => {
    return <Modal
      open={isTrainingListModalOpen}
      onClose={() => handleTrainingListModal('CLOSE')}
      onSubmit={
        modalTitle ===
          t('pages.training.training-list.modal.new-training')
          ? createTrainingListRecord
          : modalTitle ===
            t('pages.training.training-list.modal.update-training')
            ? updateTrainingListRecord
            : copyTrainingListRecord
      }
      widthClass={classes.modalWidth}
      showControls
      primaryButtonTextKey={
        'pages.training.training-list.controls.ok'
      }
      secondaryButtonTextKey={
        'pages.training.training-list.controls.cancel-btn'
      }
    >
      <div className={classes.modalTextPadding}>
        <h3 className={classes.modalTitle}>{modalTitle}</h3>
        <form autoComplete="off">
          <FormControl className={classes.formControl}>
            <TextField
              fullWidth
              id="modelName"
              name="modelName"
              label={t('pages.training.training-list.grid.title')}
              margin="normal"
              value={trainingData.modelName}
              onChange={onChangeTrainingData}
              error={modalFormErrors['modelName']}
              helperText={
                modalFormErrors['modelNameErrorMsg'] !== '' &&
                modalFormErrors['modelNameErrorMsg']
              }
            />
          </FormControl>
          <FormControl className={classes.formControl}>
            <TextField
              fullWidth
              id="comment"
              name="comment"
              label={t('pages.training.training-list.grid.comment')}
              margin="normal"
              value={trainingData.comment}
              onChange={onChangeTrainingData}
              error={modalFormErrors['comment']}
              helperText={
                modalFormErrors['commentErrorMsg'] !== '' &&
                modalFormErrors['commentErrorMsg']
              }
            />
          </FormControl>
        </form>
      </div>
    </Modal>
  }

  return (
    <Observer>
      {() => (
        <div>
          <Paper className={classes.pageContent}>
            {snapbarMessage?.message && (
              <CustomSnackBar snapbarMessage={snapbarMessage} />
            )}
            <div className={classes.top}>
              <Breadcrumb
                breadcrumbs={appStore.breadcrumbs}
                removeBreadcrumb={appStore.removeBreadcrumb}
              />
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={isAddButtonDisabled}
                  onClick={() => handleTrainingListModal('ADD')}
                >
                  {t('pages.training.training-list.controls.add-btn')}
                </Button>
                {isTrainingListModalOpen && modalTitle == "DELETE" ? delteTrainingModal() : isTrainingListModalOpen && newTrainingModel()}

                {/* t("pages.training.training-parameter.dataset-mode.modal.deleteMsg") */}
                <Button
                  color="primary"
                  variant="contained"
                //onClick={handleFilterPreference}
                >
                  {t(
                    "pages.training.training-list.controls.apply-default-filter-btn"
                  )}
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                //onClick={handleCustomizeModal}
                >
                  {t("pages.training.training-list.controls.customize-btn")}
                </Button>
              </div>
            </div>

            <Divider className={classes.divider} />
            <div className={classes.controlContainer}>
              <Pagination
                disabled={false}
                onChange={onPagination}
                itemCount={trainingManagementStore.trainingListDataCount}
                pageNo={appStore.inspectionSearchFilter.pageNo + 1}
                pageSize={appStore.inspectionSearchFilter.pageSize}
              />
            </div>
            <Grid
              loading={loading}
              records={trainingManagementStore.trainingListData}
              //containerClassName={classes.tableContainer}
              containerClassName={
                trainingManagementStore.selectedTrainingListDataCount > 0
                  ? classes.tableContainerFooter
                  : classes.tableContainer
              }
              columnDefinitions={appStore.inspectionGridColumnPreference}
              disableAddButton={disableAddButton}
              disableEditButton={disableEditButton}
            />
            {trainingManagementStore.selectedTrainingListDataCount > 0 && (
              <div className={classes.footerContainer}>
                <div className={classes.buttonGroup}>
                  <span className={classes.noOfDevicesWrapper}>
                    {t('pages.training.training-list.controls.selected')}
                    {' : '}
                    {trainingManagementStore.selectedTrainingListDataCount}
                  </span>
                </div>

                <div className={classes.buttonGroup}>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('COPY-TO-NEW')}
                  >
                    {t('pages.training.training-list.controls.copy-to-new')}
                  </Button>
                  {/* Only needed for release 0.2  */}
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('DELETE')}
                  >
                    {t('pages.training.training-list.controls.delete')}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('EDIT')}
                  >
                    {t('pages.training.training-list.controls.edit')}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('VIEW-PARAMETER')}
                  >
                    {t('pages.training.training-list.controls.view-params')}
                  </Button>
                  {/* Only needed for release 0.2 */}
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('RE-EXECUTE')}
                  >
                    {t('pages.training.training-list.controls.re-execute')}
                  </Button>
                </div>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  )
}

export default TrainingList
