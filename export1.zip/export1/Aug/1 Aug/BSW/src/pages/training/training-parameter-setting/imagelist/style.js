import { makeStyles, withStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    height: "calc(100vh - 82px)"
  },
  paper: {
    maxHeight: "35%"
  },
  pageHeader: {
    display: "flex"
  },
  top: {
    marginTop: theme.spacing(2),
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  container: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between"
  },
  thumbheader: {
    display: "flex",
    padding: "16px 16px 0 16px"
  },
  thumbWrap: {
    padding: "16px 16px 8px 16px"
  },
  thumbItem: {
    position: "relative",
    zIndex: 0,
    "&:hover $thumbCheckbox": {
      display: "flex",
      backgroundColor: "white"
    }
  },
  thumbCheckbox: {
    display: "none",
    position: "absolute",
    zIndex: 5,
    right: 12,
    top: 12,
    width: "16px",
    height: "16px",
    backgroundColor: "white",
    "&.Mui-checked": {
      display: "flex",
      backgroundColor: "white"
    }
  },
  thumbImg: {
    width: "100%",
    height: "auto",
    borderRadius: "4px"
  },
  text: {
    fontWeight: "bold"
  },
  fWeight: {
    fontWeight: "600"
  },
  whiteSpaceWrap: {
    whiteSpace: "nowrap"
  },
  popover: {
    pointerEvents: "none"
  },
  popover_paper: {
    padding: theme.spacing(2)
  },
  bottom: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    paddingBottom: "16px",
    padding: "0px 16px",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  buttonWrapper: {
    display: "flex",
    alignSelf: "center",
    "& > *": {
      marginLeft: theme.spacing(2)
    },
    zIndex: 1
  },
  accMarginTop: {
    marginTop: "16px"
  },
  accSummary: {
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      minHeight: "48px !important"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  accDetails: {
    padding: 0
  },
  imageLegendTraining: {
    display: "inline-block",
    width: "13px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    backgroundColor: "#3a5faa",
    verticalAlign: "middle"
  },
  imageLegendValidation: {
    display: "inline-block",
    width: "13px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    backgroundColor: "#dd0a55",
    verticalAlign: "middle"
  },
  imageLegendText: {
    display: "inline-block",
    verticalAlign: "middle",
    marginRight: "16px"
  }
}));
