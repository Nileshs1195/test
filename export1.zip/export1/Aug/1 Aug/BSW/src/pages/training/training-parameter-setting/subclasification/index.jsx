import { Button, Divider, Paper } from "@material-ui/core";
import GridMaterial from "@material-ui/core/Grid";
import { Observer } from "mobx-react-lite";
import { useHistory, useParams } from "react-router-dom";
import { useCallback, useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import Breadcrumb from "../../../../shared/components/ui/breadcrumb";
import AppStore from "../../../../stores/appstore";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import { APP_ROUTES } from "../../../../appconstants";
import InputSetting from "./inputsettings";
import ParameterSetting from "./parameterSetting";
import { useStyles } from "./style";
import { API_RESPONSE } from "../../../../appconstants";
import BackButton from "../../../../components/backbutton";
import CustomSnackBar from "../../../../components/snackbar";
import * as CommonMethod from "./commonMethods";
import Modals from "./modals";

const SubClasicication = (props) => {
  const classes = useStyles();
  const params = useParams();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { inspectionSearchFilter, addBreadcrumb, removeLastBreadcrumb } = appStore;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [isEditAndNextDisabled, disableEditButton] = useState(false);
  const [isInputParameterModalOpen, toggoleInputParameterModal] = useState(false);
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [trainingId, setTrainingId] = useState(true);
  const [inputParameter, setTrainingInputParameter] = useState({
    className: "",
    priorKnowledge: ""
  });
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [isFileDeleteModal, toggleFileDeleteModal] = useState(false);
  const [isAddClassModal, toggleAddclassModal] = useState(false);

  const fetchInputParameter = (data) => {
    if (data.length > 0) {
      data.map((item) => {
        if (item.priorKnowledge === true || item.priorKnowledge === "Yes") {
          item.priorKnowledge = "Yes";
        } else {
          item.priorKnowledge = "No";
        }
      });
      trainingManagementStore.setInputparameter(data);
      trainingManagementStore.setInputParameterTotalCount(data.length);
    }
  };

  const getTrainingInputParameter = useCallback(
    async (data) => {
      setLoading(true);
      await fetchInputParameter(data);
      setLoading(false);
    },
    [fetchInputParameter, inspectionSearchFilter]
  );

  useEffect(() => {
    if (trainingManagementStore.TrainingInputparameter.length === 0) {
      getTrainingInputParameter(trainingManagementStore.selectedTrainingDataset);
    }
  }, [getTrainingInputParameter, trainingManagementStore.TrainingInputparameter.length]);

  useEffect(() => {
    let currentTrainingId = params.id;
    setTrainingId(currentTrainingId);
    removeLastBreadcrumb();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX.replace(":id", currentTrainingId).replace(
        ":classes",
        params.classes
      ),
      label: "pages.training.training-parameter.breadcrumb.subclassification"
    });
  }, [addBreadcrumb]);

  useEffect(() => {
    return () => {
      trainingManagementStore.TrainingInputparameter = [];
      trainingManagementStore.clearSelectedTrainingDataset();
      trainingManagementStore.clearselectedInputParameter();
    };
  }, []);

  let checkArray = (arr, target) => target.every((v) => arr.includes(v));

  useEffect(async () => {
    if (props?.reloadCurrentList && props?.newClassNamesList && props.newClassNamesList.length > 0) {
      let datasets = [];
      let selectedSeqNos = [];
      let seqNos = params.classes.split(",").map((item) => Number(item));
      props.TrainingDataset.forEach((dataset) => {
        if (props && props.newClassNamesList && props.newClassNamesList.includes(dataset.className)) {
          selectedSeqNos.push(Number(dataset.seqNo));
        }
      });
      if (checkArray(seqNos, selectedSeqNos)) {
        selectedSeqNos = seqNos;
      } else {
        selectedSeqNos = [...selectedSeqNos, ...seqNos].sort().reverse();
        history.replace(
          APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", selectedSeqNos.join())
        );
      }
      if (selectedSeqNos && selectedSeqNos.length > 0) {
        props.TrainingDataset.forEach((dataset) => {
          if (selectedSeqNos.includes(dataset.seqNo)) {
            datasets.push(dataset);
          }
        });
      }
      fetchInputParameter(datasets.reverse());
      props.setnewClassNamesList([]);
    } else {
      if (trainingManagementStore?.TrainingDataset) {
        let selectedSeqNos = params.classes.split(",").map((item) => Number(item));
        if (selectedSeqNos?.length > 0) {
          addSelectedDatasets(selectedSeqNos);
        }
      }
    }
  }, [props.reloadCurrentList, props.newClassNamesList]);

  useEffect(() => {
    if (props?.reloadCurrentList !== true && trainingManagementStore?.TrainingDataset.length > 0) {
      let selectedSeqNos = params.classes.split(",").map((item) => Number(item));
      let datasets = [];
      if (selectedSeqNos && selectedSeqNos.length > 0) {
        trainingManagementStore.TrainingDataset.forEach((dataset) => {
          if (selectedSeqNos.includes(dataset.seqNo)) {
            datasets.push(dataset);
          }
        });
      }
      fetchInputParameter(datasets.reverse());
    }
  }, [trainingManagementStore && trainingManagementStore.TrainingDataset]);

  const addSelectedDatasets = async (seqList) => {
    let selectedDatasets = [];
    trainingManagementStore.TrainingDataset.forEach((dataset) => {
      if (dataset.seqNo && seqList && seqList.includes(dataset.seqNo)) {
        selectedDatasets.push(dataset);
      }
    });
    fetchInputParameter(selectedDatasets);
  };

  const handleModalFormErrors = (data) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, data));
  };

  const handleSetTrainingData = (name, value) => {
    setTrainingInputParameter((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };

  const checkClassName = (name) => {
    let exist = false;
    if (trainingManagementStore.TrainingDataset.length > 0) {
      const trainingListData = trainingManagementStore.TrainingDataset.map((item) => {
        const container = {};
        container["name"] = item.className;
        return container;
      });
      const result = trainingListData.some((item) => item.name === name);
      exist = result;
    }
    return exist;
  };

  const onChangeFieldData = (event) => {
    let errMsg = [];
    errMsg["errExist"] = t("pages.training.input-parameter.modal.already-exist");
    errMsg["errAlphanumeric"] = t("pages.training.input-parameter.modal.alphanumeric");
    CommonMethod.onChangeDataSetting(event, handleSetTrainingData, handleModalFormErrors, checkClassName, errMsg);
  };

  const deleteFileConfirmModal = () => {
    toggleFileDeleteModal((isOpen) => !isOpen);
  };

  const handleAddClassRecord = () => {
    let isValid = CommonMethod.ValidateModalForm(inputParameter, handleModalFormErrors, setErrorMessage, modalFormErrors);
    if (isValid) {
      props.handleFileUploadOpen("add-class", inputParameter.className);
    }
  };
  const handleNewInputParameterModal = (label) => {
    switch (label) {
      case "ADD":
        toggleAddclassModal((isOpen) => !isOpen);
        break;
      case "EDIT":
        setModalFormErrors({});
        toggoleInputParameterModal((isOpen) => !isOpen);
        const seqNo = trainingManagementStore.selectedInputParameter[0].seqNo;
        const data = {
          className: trainingManagementStore.selectedInputParameter[0].className,
          priorKnowledge: trainingManagementStore.selectedInputParameter[0].priorKnowledge == "Yes" ? true : false,
          seqNos: seqNo
        };
        setTrainingInputParameter(data);
        break;
      case "EXECUTE":
        if (params.id) {
          let reqPayload = {
            seqNos: trainingManagementStore.selectedInputParameter.map((item) => item.seqNo)
          };
          let selectedTraining = Object.assign(
            {},
            trainingManagementStore?.selectedTrainingListData?.[0] ?? trainingManagementStore.selectedTrainingListData[0]
          );
          if (selectedTraining?.mode === 4 && (selectedTraining?.status === 2 || selectedTraining?.status === 7)) {
            //Execuation already in progress or already completed
          } else {
          }
          trainingManagementStore.changeTrainingStatus(params.id, "subclassification", reqPayload);
        }
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION.replace(":id", params.id));
        break;
      case "DELETE":
        deleteFileConfirmModal();
        break;
      case "MASKING":
        break;
      case "CLOSE":
        trainingManagementStore.selectedInputParameter = [];
        toggoleInputParameterModal((isOpen) => !isOpen);
        disableAddButton(false);
    }
  };

  const deleteSubclassification = () => {
    let reqPayload = {
      seqNo: trainingManagementStore.selectedInputParameter.map((item) => item.seqNo)
    };

    trainingManagementStore
      .deleteDatasetRecords(trainingId, reqPayload)
      .then((response) => {
        if (response && response.data && response.data.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          fetchTrainingSubClass();
          if (response?.data?.data) {
            trainingManagementStore.clearselectedInputParameter();
            trainingManagementStore.setTrainingDataset(response?.data?.data);
            trainingManagementStore.setTrainingDatasetTotalCount(response?.data?.data.length);
          }
          let seqNos = params.classes.split(",").filter((item) => !reqPayload.seqNo.includes(Number(item)));
          history.replace(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", seqNos.join()));
          setsnapbarMessage({
            message: t("pages.training.success.dataset.deleted")
          });
        } else {
          setsnapbarMessage({
            message: t("pages.training.errors.dataset.delete-failed")
          });
          console.log("Error occurred while deleting dataset record");
        }
      })
      .catch((err) => {
        console.log("error", err);
      });
    setsnapbarMessage({ message: "" });
    disableAddButton(false);
  };

  const fetchTrainingSubClass = () => {
    const filterData = trainingManagementStore.TrainingInputparameter.filter(
      (item) => !trainingManagementStore.selectedInputParameter.includes(item)
    );
    fetchInputParameter(filterData);
  };

  const setErrorMessage = (errorObj, fieldName, fieldNameError) => {
    errorObj.isFormValid = false;
    errorObj.modalFormErrors[fieldName] = true;
    errorObj.modalFormErrors[fieldNameError] = t("pages.image-management.image-group-list.modal.error-text");
    return errorObj;
  };

  const updateInputParameterDetails = async () => {
    let isValid = CommonMethod.ValidateModalForm(inputParameter, handleModalFormErrors, setErrorMessage, modalFormErrors);

    if (isValid) {
      setsnapbarMessage({ message: "" });
      await trainingManagementStore
        .editDatasetAPI(trainingId, inputParameter)
        .then((response) => {
          if (response && response[0].status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            trainingManagementStore.updateTrainingInputparameterList(inputParameter, response[1].data[0].seqNo);
            setsnapbarMessage({
              message: t("pages.training.success.dataset.updated")
            });
          } else {
            setsnapbarMessage({
              message: t("pages.training.errors.dataset.update-failed")
            });
            console.log("Error occurred while updating dataset record");
          }
        })
        .catch((err) => {
          console.log("error", err);
        });
    } else {
      // if the modal form fields are empty, the modal will be open using below function
      toggoleInputParameterModal((isOpen) => !isOpen);
    }
  };

  const handleBackButton = () => {
    history.goBack();
  };

  return (
    <Observer>
      {() => (
        <div>
          <Paper className={classes.pageContent}>
            {snapbarMessage && snapbarMessage.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
            <div className={classes.top}>
              <div className={classes.buttonWrapper}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <Modals
                modalType="subDeleteConfirmModal"
                open={isFileDeleteModal}
                onClose={deleteFileConfirmModal}
                onSubmit={deleteSubclassification}
              />
              <Modals
                modalType="subEdit"
                open={isInputParameterModalOpen}
                onClose={() => handleNewInputParameterModal("CLOSE")}
                onSubmit={updateInputParameterDetails}
                onChangeFieldData={onChangeFieldData}
                modalFormErrors={modalFormErrors}
                inputParameter={inputParameter}
              />
              <Modals
                modalType="addClass"
                open={isAddClassModal}
                onClose={() => toggleAddclassModal((isOpen) => !isOpen)}
                onChangeFieldData={onChangeFieldData}
                onSubmit={handleAddClassRecord}
                modalFormErrors={modalFormErrors}
              />
              <div className={classes.buttonWrapper}>
                <Button color="primary" variant="contained" disabled={isAddButtonDisabled} onClick={() => handleNewInputParameterModal("ADD")}>
                  {t("pages.training.input-parameter.controls.add-class")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <GridMaterial container spacing={2}>
              <GridMaterial item xs={12} md={8}>
                <InputSetting
                  loading={loading}
                  uploadStatus={props.uploadStatus}
                  disableAddButton={disableAddButton}
                  disableEditButton={disableEditButton}
                  isEditAndNextDisabled={isEditAndNextDisabled}
                  handleNewInputParameterModal={handleNewInputParameterModal}
                />
              </GridMaterial>
              <GridMaterial item xs={12} md={4}>
                <ParameterSetting />
              </GridMaterial>
            </GridMaterial>
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default SubClasicication;
