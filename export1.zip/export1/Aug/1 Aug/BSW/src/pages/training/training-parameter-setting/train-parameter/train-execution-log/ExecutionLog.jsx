import React from "react";
import { useEffect, useContext, useState, useCallback } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Typography, Accordion, AccordionSummary, AccordionDetails } from "@material-ui/core";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { useStyles } from "./style";
import AppStore from "../../../../../stores/appstore";
import { APP_ROUTES } from "../../../../../appconstants";
import Breadcrumb from "../../../../../shared/components/ui/breadcrumb";
import LinearProgressBar from "../../../../../components/linearprogressbar";
import { useTranslation } from "react-i18next";
import { useParams, useHistory } from "react-router-dom";
import BackButton from "../../../../../components/backbutton";
import ExecutionLogTable from "./ExecutionLogTable";
import CancelExecutionModal from "../../../../../components/modal";
import TrainingManagementStore from "./../../../../../stores/trainingmanagementstore";
import { API_RESPONSE } from "../../../../../appconstants";

const ExecutionLog = () => {
    const classes = useStyles();
    const { t } = useTranslation();
    const params = useParams();
    const history = useHistory();
    const appStore = useContext(AppStore);
    const { addBreadcrumb, removeLastBreadcrumb, breadcrumbs } = appStore;
    const trainingManagementStore = useContext(TrainingManagementStore);
    const { fetchExecutionLogData, stopTrainingExecution } = trainingManagementStore;
    const [isResultSetVisible, setResultSetVisibility] = useState(false);
    const [openModal, setOpenModal] = useState(false);
    const [loading, setLoading] = useState(false);
    const [resultSet, setResultSet] = useState({
        pgr: 0,
        Rate: 0,
        Ploss: 0,
        Closs: 0,
        elptime: 0,
        modelName: "",
        noOfFeatures: 0
    });

    const [executionLogData, setExecutionLogData] = useState([]);

    useEffect(() => {
        removeLastBreadcrumb();
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
            label: "pages.training.training-parameter.breadcrumb.training"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
            label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING,
            label: "pages.training.training-parameter.breadcrumb.train-param-search.execution-log"
        });
    }, [addBreadcrumb]);

    const displayData = () => {
        getExecutionLogDataList();
    };

    const fetchExecutionLogDataList = async () => {
        await fetchExecutionLogData(params.id).then((response) => {
            setResultSetVisibility(true);
            if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                let data = [
                    {
                        iteration: 1,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    }
                    ,
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    },
                    {
                        iteration: 2,
                        mainLoss: 0.01,
                        mainEloss: 0.02,
                        mainCloss: 0.03,
                        mainPloss: 0.04,
                        validMainLoss: 0.05,
                        validMainEloss: 0.06,
                        validMainCloss: 0.07,
                        validMainPloss: 0.08,
                        passedTime: 2000
                    }
                ];
                setExecutionLogData(data);
                // setExecutionLogData(response.data);
                console.log("Log result data fetched successfully");
            } else {
                console.log("Error occurred while fetching log result data");
            }
        }).catch((err) => {
            console.log('error', err);
        });
    };

    const getExecutionLogDataList = useCallback(async () => {
        setLoading(true);
        await fetchExecutionLogDataList();
        setLoading(false);
    },[fetchExecutionLogDataList]);

    const gotoTrainParameterSetting = () => {
        cancelTrainingExecution();
        setOpenModal(false);
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
    };

    const gotoTrainingList = () => {
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING);
    };

    const handleBackButton = () => {
        resultSet?.pgr < 100 ? setOpenModal(true) : gotoTrainParameterSetting();
    };

    const cancelTrainingExecution = () => {
        stopTrainingExecution(params.id).then((response) => {
            if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                console.log("Training Executon Cancelled");
            } else {
                console.log("Error occurred while cancelling Training Executon");
            }
        }).catch((err) => {
            console.log('error', err);
        });
    };

    return (
        <Observer>
            {() => (
                <div>
                    <Paper className={classes.pageContent}>
                        <div className={classes.top}>
                            <div className={classes.breadcrumbWraper}>
                                <BackButton
                                    handleBackButton={handleBackButton}
                                />
                                <Breadcrumb
                                    breadcrumbs={appStore.breadcrumbs}
                                    removeBreadcrumb={appStore.removeBreadcrumb}
                                />
                            </div>
                            <div className={classes.buttonWrapper}>
                                <Button
                                    color="primary"
                                    variant="contained"
                                    disabled={!isResultSetVisible}
                                >
                                    {t("pages.training.training-parameter.train-parameter.controls.run-advisor")}
                                </Button>
                                <Button
                                    color="primary"
                                    variant="contained"
                                    disabled={!isResultSetVisible}
                                //   onClick={gotoTrainParameterSetting}
                                >
                                    {t("pages.training.training-parameter.train-parameter.controls.test-model")}
                                </Button>
                                <Button
                                    color="primary"
                                    variant="contained"
                                    onClick={gotoTrainingList}
                                >
                                    {t("pages.training.training-parameter.train-parameter.controls.return-training")}
                                </Button>
                                <Button
                                    color="primary"
                                    variant="contained"
                                    onClick={() => handleBackButton()}
                                >
                                    {t("pages.training.training-parameter.train-parameter.controls.cancel")}
                                </Button>
                            </div>
                        </div>
                        <Divider className={classes.divider} />
                        <div className={classes.mtop}>
                            <LinearProgressBar
                                setResultSet={setResultSet}
                                displayData={displayData}
                                method="parameterSearch"
                                executionMethodName="trainingExecution"
                            />
                        </div>
                        <CancelExecutionModal
                            open={openModal}
                            onClose={() => { setOpenModal(false) }}
                            onSubmit={gotoTrainParameterSetting}
                        />
                        {
                            isResultSetVisible && (
                                <div className={classes.accordionContainer}>
                                    <Accordion>
                                        <AccordionSummary
                                            expandIcon={<ExpandMoreIcon />}
                                            aria-controls="panel1a-content"
                                            id="panel1a-header"
                                            className={classes.accSummary}
                                        >
                                            <Typography className={classes.accSumTitle}>
                                                {t("pages.training.training-parameter.train-parameter.accordian.title")}
                                            </Typography>
                                        </AccordionSummary>
                                        <AccordionDetails className={classes.accDetails}>
                                            <ExecutionLogTable
                                                loading={loading}
                                                executionLogData={executionLogData}
                                            />
                                        </AccordionDetails>
                                    </Accordion>
                                </div>
                            )
                        }
                    </Paper>
                </div>
            )}
        </Observer>
    );
};

export default ExecutionLog;
