import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    minHeight: "100vh"
  },
  paper: {
    maxHeight: "35%"
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  breadcrumbWraper: {
    display: "flex"
  },
  mtop: {
    marginTop: "16px",
    marginBottom: "16px"
  },
  textRight: {
    textAlign: "right"
  },
  textCenter: {
    textAlign: "center"
  },
  paperPadd: {
    padding: "12px 16px 16px 16px"
  },
  boxwidth: {
    width: "65%"
  },
  space: {
    margin: "16px 0px"
  },
  resultBox: {
    display: "flex",
    justifyContent: "center"
  }
}));
