import React from "react";
import { useEffect, useContext, useState } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Grid, Typography } from "@material-ui/core";
import { useStyles } from "./style";
import AppStore from "../../../../../stores/appstore";
import { APP_ROUTES } from "../../../../../appconstants";
import Breadcrumb from "../../../../../shared/components/ui/breadcrumb";
import LinearProgressBar from "../../../../../components/linearprogressbar";
import { useTranslation } from "react-i18next";
import { useParams, useHistory } from "react-router-dom";
import BackButton from "../../../../../components/backbutton";
import CancelExecutionModal from "../../../../../components/modal";
import TrainingManagementStore from "./../../../../../stores/trainingmanagementstore";
import { API_RESPONSE } from "../../../../../appconstants";

const AutomaticParameterSearch = () => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb, breadcrumbs } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { stopTrainingExecution } = trainingManagementStore;
  const [isResultSetVisible, setResultSetVisibility] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [resultSet, setResultSet] = useState({
    pgr: 0,
    Rate: 0,
    Ploss: 0,
    Closs: 0,
    elptime: 0,
    modelName: "",
    noOfFeatures: 0
  });

  useEffect(() => {
    console.log(breadcrumbs);
    removeLastBreadcrumb();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING,
      label: "pages.training.training-parameter.dataset-mode.auto-param-search.title"
    });
  }, [addBreadcrumb]);

  const displayData = () => {
    setResultSetVisibility(true);
  };

  const gotoTrainParameterSetting = () => {
    cancelTrainingExecution();
    setOpenModal(false);
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
  };

  const cancelTrainingExecution = () => { 
    let seqNo = 123;
    stopTrainingExecution(params.id, seqNo).then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            console.log("Training Executon Cancelled");
        } else {
            console.log("Error occurred while cancelling Training Executon");
        }
    }).catch((err) => {
        console.log('error', err);
    });
};

  const handleBackButton = () => {
    resultSet?.pgr < 100 ? setOpenModal(true) : gotoTrainParameterSetting();
  };

  const gotoExecutionLogScreen = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(":id", params.id));
  };

  return (
    <Observer>
      {() => (
        <div>
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton
                  handleBackButton={handleBackButton}
                />
                <Breadcrumb
                  breadcrumbs={appStore.breadcrumbs}
                  removeBreadcrumb={appStore.removeBreadcrumb}
                />
              </div>
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={!isResultSetVisible}
                  onClick={gotoExecutionLogScreen}
                >
                  {t("pages.training.training-parameter.dataset-mode.auto-param-search.run-training")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={!isResultSetVisible}
                  onClick={gotoTrainParameterSetting}
                >
                  {t("pages.training.training-parameter.dataset-mode.auto-param-search.back")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => handleBackButton()}
                >
                  {t("pages.training.training-parameter.dataset-mode.auto-param-search.cancel")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.mtop}>
              <LinearProgressBar
                setResultSet={setResultSet}
                displayData={displayData}
                method="parameterSearch"
              />
            </div>
            <CancelExecutionModal
              open={openModal}
              onClose={() => { setOpenModal(false) }}
              onSubmit={gotoTrainParameterSetting}
            />

            {isResultSetVisible && (
              <div>
                <Box m={1} p={1} bgcolor="background.paper" className={classes.resultBox}>
                  <Box p={1} className={classes.boxwidth}>
                    <Paper variant="outlined" className={classes.paperPadd}>
                      <Grid container spacing={1}>
                        <Grid item xs={12} className={classes.pad8}>
                          <Typography variant="h6" gutterBottom>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.result"
                            )}
                          </Typography>
                          <Divider />
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.num-of-features"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.noOfFeatures}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.rate"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Rate}</div>
                        </Grid>{" "}
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.closs"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Closs}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.ploss"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Ploss}</div>
                        </Grid>
                        <Grid item xs={6} className={classes.space}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.model"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6} className={classes.space}>
                          <div>: {resultSet.modelName}</div>
                        </Grid>
                      </Grid>
                    </Paper>
                  </Box>
                </Box>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default AutomaticParameterSearch;
