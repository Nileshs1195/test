import { Observer } from "mobx-react-lite";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import CloseIcon from "@material-ui/icons/Close";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import { useStyles } from "./style";
import { useCallback, useState, useRef, useContext, useEffect } from "react";
import { useTranslation } from "react-i18next";
import {
  Grid,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  ButtonGroup,
  Popper,
  Grow,
  Paper,
  ClickAwayListener,
  MenuItem,
  MenuList,
  FormControl,
  TextField
} from "@material-ui/core";
import { Autocomplete } from "@material-ui/lab";
import Modal from "../../../../../shared/components/ui/modal";
import ImageManagementStore from "../../../../../stores/imagemanagementstore";
import DatasetClassImage from "../datasetclassimage";
import Pagination from "../../../../../shared/components/basictable/pagination";
import { API_RESPONSE } from "../../../../../appconstants";
import CustomSnackBar from "../../../../../components/snackbar";
import TrainingManagementStore from "../../../../../stores/trainingmanagementstore";
import { set } from "mobx";

const ClassComponent = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const { key, classData, params, trainingDetails, expand, classesAvailable, handleImageEdit, handleFileUploadOpen, imageType } = props;
  const anchorRef = useRef(null);
  const [isFileDeleteModal, toggleFileDeleteModal] = useState(false);
  const [imageClassModal, toggleImageClassModal] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [alertSnackBar, toggleAlertSnackBar] = useState(false);
  const [imageArray, setImageArray] = useState([]);
  const [totalImageCount, setTotalImageCount] = useState(0);
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [open, setOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [expanded, setExpanded] = useState(expand);
  const imageManagementStore = useContext(ImageManagementStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { getImagesForDataset, deleteImagesForDataset, selectedClassImages } = imageManagementStore;
  let selectedImageClass;
  const options = [
    {
      label: t("pages.training.manageImages.controls.addImages"),
      value: "Add Images"
    },
    {
      label: t("pages.training.manageImages.controls.deleteImages"),
      value: "Delete Images"
    },
    {
      label: t("pages.training.manageImages.controls.editImageClass"),
      value: "Edit Image Class"
    }
  ];
  const classNameList = classesAvailable.filter((item, index, inputArray) => item.label !== classData.className);

  const getImageDataforDataset = useCallback(
    async (imageTypeDetails) => {
      const paginationData = {
        from_index: imageManagementStore.imagePaginationStartIndex,
        end_index: imageManagementStore.imagePaginationStartIndex + 9,
        order: "desc",
        image: imageTypeDetails
      };
      if (params.id) {
        const imageData = await getImagesForDataset(params.id, classData.seqNo, paginationData);
        if (imageData && imageData.data && imageData.data.count > 0) {
          imageData.data.images.forEach((element) => {
            const selected = isSelected(element.seqNo);
            element.selected = selected;
            element.className = classData.className;
          });
          toggleAlertSnackBar(false);
          setImageArray(imageData.data.images);
          setTotalImageCount(imageData.data.count);
        } else {
          setImageArray([]);
          setTotalImageCount(0);
          setAlertMessage();
          setsnapbarMessage({
            message: t("pages.training.errors.image-list.no-data")
          });
        }
      }
      imageManagementStore.setUpdateImageListForClass(false);
    },
    [getImagesForDataset]
  );

  useEffect(() => {
    getImageDataforDataset(imageType);
    setExpanded(expand);
  }, [
    getImageDataforDataset,
    expand,
    imageArray.length,
    imageManagementStore.updateImageListForClass,
    trainingManagementStore.TrainingDataset,
    imageType
  ]);

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  const deleteFileConfirmModal = () => {
    toggleFileDeleteModal((isOpen) => !isOpen);
  };

  const setChangeImageClassModel = () => {
    toggleImageClassModal((isOpen) => !isOpen);
  };

  const handleClick = (index) => {
    setSelectedIndex(index);
    if (index === 0) {
      handleFileUploadOpen("add-images", classData.className);
    } else if (index === 1) {
      deleteFileConfirmModal();
    } else {
      changeSelectedImageClass();
    }
    setOpen(false);
  };

  const handleClose = (event) => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }
    setOpen(false);
  };

  const onPagination = (indexObj) => {
    imageManagementStore.updateImagePaginationStartIndex((indexObj.pageNo > 0 ? indexObj.pageNo - 1 : indexObj.pageNo) * indexObj.pageSize);
    getImageDataforDataset();
  };

  const isSelected = (seqNo) => {
    const selected = imageManagementStore.selectedClassImages.filter((item) => item.imageSeqNo === seqNo && item.classSeqNo === classData.seqNo);
    return selected.length > 0;
  };

  const onImageSelect = (event, seqNo) => {
    const selected = isSelected(seqNo);
    if (selected) {
      removeSelectedImages(seqNo);
    } else {
      handleSelectedImages(seqNo);
    }
  };

  const handleSelectedImages = (seqNo) => {
    const imageList = [...imageArray];
    const objIndex = imageList.findIndex((obj) => obj.seqNo === seqNo);
    imageList[objIndex].selected = true;
    setImageArray(imageList);
    imageManagementStore.setSelectedClassImage(seqNo, classData.seqNo);
  };

  const removeSelectedImages = (seqNo) => {
    const imageList = [...imageArray];
    const objIndex = imageList.findIndex((obj) => obj.seqNo === seqNo);
    imageList[objIndex].selected = false;
    setImageArray(imageList);
    imageManagementStore.removeSelectedClassImage([seqNo], classData.seqNo);
  };

  const handleDeleteImages = () => {
    const newMessageObj = {
      message: t("pages.training.manageImages.messages.imageRecordDeleted")
    };

    let deletedImagesArray = selectedClassImages.filter((image) => image.classSeqNo === classData.seqNo).map((item) => item.imageSeqNo);
    const reqPayload = {
      img_seqNo: deletedImagesArray
    };
    deleteImagesForDataset(params.id, classData.seqNo, reqPayload).then((response) => {
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setAlertMessage();
        setsnapbarMessage(newMessageObj);
        imageManagementStore.removeSelectedClassImage(deletedImagesArray, classData.seqNo);
        getImageDataforDataset();
        console.log("dataset images deleted successfully");
      } else {
        console.log("Error occurred while deleting dataset images");
      }
    });
  };

  const changeSelectedImageClass = () => {
    setModalFormErrors({});
    setChangeImageClassModel();
  };

  // validate each field
  const validateField = (errorObj, fieldName, fieldNameError) => {
    errorObj.isFormValid = false;
    errorObj.modalFormErrors[fieldName] = true;
    errorObj.modalFormErrors[fieldNameError] = t("pages.image-management.image-group-list.modal.error-text");
    return errorObj;
  };

  const validateModalForm = () => {
    let errorObj = {
      isFormValid: true,
      modalFormErrors: {}
    };

    if (!selectedImageClass || selectedImageClass === "" || selectedImageClass === null) {
      errorObj = validateField(errorObj, "className", "classNameErrorMsg");
    }

    setModalFormErrors(errorObj.modalFormErrors);
    return errorObj.isFormValid;
  };

  const handleImageClassEdit = async () => {
    const selectedImages = imageManagementStore.selectedClassImages
      .filter((item) => item.classSeqNo === classData.seqNo)
      .map((element) => element.imageSeqNo);

    const saveImageData = { img_seqNo: selectedImages, dst_seqNo: selectedImageClass.value };

    await imageManagementStore.saveEditImageClassDetails(params.id, classData.seqNo, saveImageData).then((response) => {
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        const newMessageObj = {
          message: t("pages.training.manageImages.messages.imageRecordUpdated")
        };
        setAlertMessage();
        setsnapbarMessage(newMessageObj);
        imageManagementStore.removeSelectedClassImage(selectedImages, classData.seqNo);
        handleImageEdit();
        imageManagementStore.setUpdateImageListForClass(true);
        console.log("Image group record modified successfully");
      } else {
        console.log("Error occurred while saving image group record");
      }
    });
  };

  const confirmChangeImageClass = () => {
    let isValid = validateModalForm();
    if (isValid) {
      handleImageClassEdit();
    } else {
      // if the modal form fields are empty, the modal will be opened up using below function
      setChangeImageClassModel();
    }
  };

  const renderClassImages = () => {
    return imageArray.map((item, index) => <DatasetClassImage imageData={item} index={index} onImageSelect={onImageSelect} />);
  };

  const isMenuItemDisabled = (selectedIndex) => {
    return (
      (selectedIndex === 2 && classesAvailable.length < 2) ||
      !(selectedIndex === 0 || imageManagementStore.getSelectedClassImagesCount(classData.seqNo) > 0)
    );
  };

  const setAlertMessage = () => {
    toggleAlertSnackBar((isOpen) => !isOpen);
  };

  const onSelectImageClass = (event, value) => {
    selectedImageClass = value;
  };

  return (
    <Observer>
      {() => (
        <>
          {alertSnackBar ? <CustomSnackBar snapbarMessage={snapbarMessage} /> : null}
          <div className={classes.accMarginTop}>
            <Modal
              open={isFileDeleteModal}
              onClose={deleteFileConfirmModal}
              onSubmit={handleDeleteImages}
              widthClass={classes.confirmationModalWidth}
              showControls
              primaryButtonTextKey={t("pages.training.manageImages.modal.delete-btn")}
              secondaryButtonTextKey={t("pages.training.manageImages.modal.cancel-btn")}
            >
              <div className={classes.modalTextPadding}>
                <h3 className={classes.modalTitle}>{t("pages.training.manageImages.modal.deleteRecordTitle")}</h3>
                <div className={classes.confirmationModalPadding}>
                  <label htmlFor="">{t("pages.training.manageImages.modal.deleteRecordMessage")}</label>
                </div>
              </div>
            </Modal>
            <Modal
              open={imageClassModal}
              onClose={setChangeImageClassModel}
              onSubmit={confirmChangeImageClass}
              widthClass={classes.confirmationModalWidth}
              showControls
              primaryButtonTextKey={"pages.training.manageImages.modal.ok-btn"}
              secondaryButtonTextKey={"pages.training.manageImages.modal.cancel-btn"}
            >
              <div className={classes.modalTextPadding}>
                <h3 className={classes.modalTitle}>{t("pages.training.manageImages.modal.editImageClassTitle")}</h3>
                <div className={classes.confirmationModalPadding}>
                  <label htmlFor="">{t("pages.training.manageImages.modal.editImageClassMessage")}</label>
                  <br />
                  <form autoComplete="off">
                    <FormControl className={classes.formControl}>
                      <Autocomplete
                        id="combo-box"
                        clearOnEscape
                        options={classNameList}
                        getOptionLabel={(option) => option.label}
                        onChange={(event, value) => onSelectImageClass(event, value)}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Class Name"
                            id="className"
                            name="className"
                            margin="normal"
                            error={modalFormErrors["className"]}
                            helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
                          />
                        )}
                      />
                    </FormControl>
                  </form>
                </div>
              </div>
            </Modal>
            <Accordion
              key={key}
              expanded={!expanded}
              onChange={() => setExpanded(!expanded)}
              defaultExpanded={true}
              className={classes.accMarginTop}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
                className={classes.accSummary}
              >
                {trainingDetails && (
                  <Grid container>
                    <Grid item xs={2}>
                      <label htmlFor="">{classData.className}</label>
                    </Grid>
                    <Grid item xs={2}>
                      <label htmlFor="">{trainingDetails.modelName}</label>
                    </Grid>
                  </Grid>
                )}
              </AccordionSummary>
              <AccordionDetails className={classes.accDetails}>
                <div className={classes.container}>
                  <div className={classes.thumbWrap}>
                    <Grid key={key} container spacing={2}>
                      {renderClassImages()}
                    </Grid>
                  </div>
                  <div className={classes.bottom}>
                    <Pagination
                      onChange={onPagination}
                      itemCount={totalImageCount}
                      pageNo={imageManagementStore.imagePaginationStartIndex + 1}
                      pageSize={9}
                      disableItemPerPage={true}
                      disabled={false}
                    />
                    <div className={classes.buttonWrapper}>
                      <ButtonGroup variant="contained" color="primary" ref={anchorRef} aria-label="split button">
                        <Button onClick={() => handleClick(selectedIndex)} disabled={isMenuItemDisabled(selectedIndex)}>
                          {options[selectedIndex].label}
                        </Button>
                        <Button
                          color="primary"
                          size="small"
                          aria-controls={open ? "split-button-menu" : undefined}
                          aria-expanded={open ? "true" : undefined}
                          aria-label="select image manipulation method"
                          aria-haspopup="menu"
                          onClick={handleToggle}
                        >
                          <ArrowDropDownIcon />
                        </Button>
                      </ButtonGroup>
                      <Popper open={open} anchorEl={anchorRef.current} role={undefined} transition disablePortal>
                        {({ TransitionProps, placement }) => (
                          <Grow
                            {...TransitionProps}
                            style={{
                              transformOrigin: placement === "bottom" ? "center top" : "center bottom"
                            }}
                          >
                            <Paper>
                              <ClickAwayListener onClickAway={handleClose}>
                                <MenuList id="split-button-menu">
                                  {options.map((option, index) => (
                                    <MenuItem
                                      key={option.value}
                                      disabled={index === selectedIndex || isMenuItemDisabled(index)}
                                      selected={index === selectedIndex}
                                      onClick={() => handleClick(index)}
                                    >
                                      {option.label}
                                    </MenuItem>
                                  ))}
                                </MenuList>
                              </ClickAwayListener>
                            </Paper>
                          </Grow>
                        )}
                      </Popper>
                    </div>
                  </div>
                </div>
              </AccordionDetails>
            </Accordion>
          </div>
        </>
      )}
    </Observer>
  );
};

export default ClassComponent;
