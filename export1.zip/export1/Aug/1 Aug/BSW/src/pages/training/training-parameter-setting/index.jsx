import { Button, Divider, Paper } from "@material-ui/core";
import { Observer } from "mobx-react-lite";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import { useHistory } from "react-router-dom";
import AppStore from "../../../stores/appstore";
import TrainingManagementStore from "./../../../stores/trainingmanagementstore";
import { useStyles } from "./style";
import TabListComponent from "./tablist";
import { useCallback, useContext, useEffect, useState } from "react";
import { APP_ROUTES } from "../../../appconstants";
import BackButton from "../../../components/backbutton";
import SubClasicication from "./subclasification";
import ImageUploader from "../../../components/imageuploader";
import ImageList from "./imagelist";
import ProgressBar from "./subclasification/executionLog/progressBar";
import CustomSnackBar from "../../../components/snackbar";

const TrainParameterSetting = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { inspectionSearchFilter } = appStore;
  const { TrainingDataset, selectedDataSetCount, fetchTrainingDatasetWithTraining, setTrainingId } = trainingManagementStore;
  const [uploaderAction, setUploaderAction] = useState({
    uploaderType: "",
    isOpen: false
  });
  const [loading, setLoading] = useState(false);
  const [isActionDisabled, setActionDisabled] = useState(false);
  const [reloadCurrentList, setReloadCurrentList] = useState(false);
  const [newClassNamesList, setnewClassNamesList] = useState([]);
  const [className, setClassName] = useState("");
  const [uploadStatus, setUploadStatus] = useState([]);
  const [snapbarMessage, setSnapbarMessage] = useState({
    message: ""
  });

  const getTrainingDataset = useCallback(
    async (status, newClassNames) => {
      setLoading(true);
      await fetchTrainingDatasetWithTraining(params.id);
      setReloadCurrentList(true);
      setLoading(false);
      redirectToNewClass(newClassNames, status);
    },
    [fetchTrainingDatasetWithTraining, inspectionSearchFilter]
  );

  const redirectToNewClass = (newClassNames, status) => {
    setUploadStatus(status);
    if (status) {
      if (status === "uploadProgress") {
        disaleActions(true);
      } else {
        disaleActions(false);
      }
    } else {
      //
    }
    // if (
    //   props.match.path ===
    //   APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION && newClassNames
    // ) {
    setnewClassNamesList(newClassNames);
    // }
  };

  useEffect(() => {
    let selectedTraining = Object.assign(
      {},
      trainingManagementStore?.selectedTrainingListData?.[0] ?? trainingManagementStore.selectedTrainingListData[0]
    );
    if (selectedTraining?.mode === "training" && (selectedTraining?.status === "Ok" || selectedTraining?.status === "Executed")) {
      disaleActions(true);
    }
  }, [trainingManagementStore.selectedTrainingListData]);

  useEffect(() => {
    let snapbar = Object.assign({}, trainingManagementStore?.snapbarMessage);
    setSnapbarMessage(snapbar);
  }, [trainingManagementStore?.snapbarMessage?.open]);

  useEffect(() => {
    if (props?.match?.path) {
      if (
        props.match.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER ||
        trainingManagementStore?.viewParameter
      ) {
        disaleActions(true);
      }
    }
  }, [props]);

  const disaleActions = (action = false) => {
    setTrainingId(params.id);
    setActionDisabled(action);
  };

  useEffect(() => {
    if (TrainingDataset.length === 0) {
      getTrainingDataset();
    }
  }, [getTrainingDataset, TrainingDataset.length]);

  const handleBackButton = () => {
    history.goBack();
  };

  const handleFileUploadOpen = (type = "add-dataset", originalClassName = "") => {
    setUploaderAction({ uploaderType: type, isOpen: true });
    setReloadCurrentList(false);
    if (originalClassName !== "") {
      setClassName(originalClassName);
    }
  };

  const handleFileUploadClose = () => {
    setUploaderAction({ uploaderType: "", isOpen: false });
  };

  const gotoTrainingList = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING);
  };

  return (
    <Observer>
      {() => (
        <div>
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          <ImageUploader
            reloadCurrentList={getTrainingDataset}
            isActionDisabled={isActionDisabled}
            uploaderAction={uploaderAction}
            className={className}
            handleFileUploadClose={handleFileUploadClose}
          />
          {props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST ? (
            <ImageList
              handleFileUploadOpen={handleFileUploadOpen}
              reloadCurrentList={reloadCurrentList}
              newClassNamesList={newClassNamesList}
              uploadStatus={uploadStatus}
              setnewClassNamesList={setnewClassNamesList}
            />
          ) : props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION ? (
            <SubClasicication
              reloadCurrentList={reloadCurrentList}
              TrainingDataset={TrainingDataset}
              handleFileUploadOpen={handleFileUploadOpen}
              newClassNamesList={newClassNamesList}
              uploadStatus={uploadStatus}
              setnewClassNamesList={setnewClassNamesList}
            />
          ) : props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION ? (
            <ProgressBar
              reloadCurrentList={reloadCurrentList}
              TrainingDataset={TrainingDataset}
              handleFileUploadOpen={handleFileUploadOpen}
              newClassNamesList={newClassNamesList}
              uploadStatus={uploadStatus}
              setnewClassNamesList={setnewClassNamesList}
            />
          ) : (
            <Paper className={classes.pageContent}>
              <div className={classes.top}>
                <div className={classes.breadcrumbWraper}>
                  <BackButton handleBackButton={handleBackButton} />
                  <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
                </div>
                <div className={classes.buttonWrapper}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={gotoTrainingList}
                    disabled={isActionDisabled}
                  >
                    {t("pages.training.training-parameter.controls.cancel-btn")}
                  </Button>
                </div>
              </div>
              <Divider className={classes.divider} />
              <TabListComponent
                handleFileUploadOpen={handleFileUploadOpen}
                loading={loading}
                params={params}
                TrainingDataset={TrainingDataset}
                selectedDataSetCount={selectedDataSetCount}
                isActionDisabled={isActionDisabled}
              />
            </Paper>
          )}
        </div>
      )}
    </Observer>
  );
};

export default TrainParameterSetting;
