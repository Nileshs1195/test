import { WAFER } from "./appconstants";

export const SETTINGS = {
  I18N: {
    LANGUAGES: {
      EN: "en",
      JP: "jp",
    },
    DEFAULT_LANG: "en",
  },
  DATE_TIME_FORMAT: "yyyy/MM/dd HH:mm:ss",
  BASE_API_URL: window.APP_SETTINGS.APP_URL,
  SOCKET_URL: window.APP_SETTINGS.APP_URL,
  API_CONFIG: {
    TIMEOUT: 5000,
  },
  INSPECTION_GRID: {
    DATE_OFFSET: 30,
  },
  GRID: {
    PAGINATION: {
      DIRECTIONS: {
        PREV: "prev",
        NEXT: "next",
      },
      PAGE_SIZES: [
        { value: 25, label: 25 },
        { value: 50, label: 50 },
        { value: 75, label: 75 },
        { value: 100, label: 100 },
      ],
    },
  },
  DEFECT_IMAGE_INDEX: 1,
  LOCAL_STORAGE_KEYS: {
    I18N: "i18nextLng",
    INSPECTION_LIST_SORT_DATA: "inspectionGridSortData",
    SHOW_WAFER_SCALE: "showWaferScale",
  },
  WAFER_DETAILS: {
    WAFER_SIZE: {
      MODAL: 600,
      CHART: 450,
      SPLIT: WAFER.DEFAULT_SIZE,
    },
  },
  IMAGE_LIST: {
    ITEM_PER_PAGE: 12,
  },
};
