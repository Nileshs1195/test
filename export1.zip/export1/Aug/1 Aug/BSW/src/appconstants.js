export const APP_ROUTES = {
  ROOT: "/",
  IMAGE_MANAGEMENT: "/imagemanagement",
  SIGN_IN: "/signIn",
  IMAGE_MANAGEMENT_PAGES: {
    IMAGE_GROUP_LIST: "/imagemanagement/imagegrouplist",
    IMAGE_LIST: "/imagemanagement/imagelist"
  },
  TRAINING_MANAGEMENT_PAGES: {
    TRAINING: "/training",
    TRAINING_PARAMETER_SETTING: "/training/trainingparametersetting/:id",
    TRAINING_PARAMETER_SETTING_AUGMENTATION: "/training/trainingparametersetting/:id/augmentation",
    TRAINING_PARAMETER_SETTING_SEARCH: "/training/trainingparametersetting/:id/search",
    TRAINING_PARAMETER_SETTING_VIEW_PARAMETER: "/training/trainingparametersetting/:id/viewparameter",
    AUTOMATIC_PARAMETER_SEARCH: "/training/trainingparametersetting/:id/train-parameter-search/:seqNo",
    IMAGE_LIST: "/training/trainingparametersetting/:id/imagelist/:classes",
    SUB_CLASIFICATION: "/training/trainingparametersetting/:id/subclasification/:classes",
    SUB_CLASIFICATION_EXECUTION: "/training/trainingparametersetting/:id/subclasification-execution-log",
    TRAIN_PARAMETER_EXECUTION_LOG: "/training/trainingparametersetting/:id/train-parameter/execution-log",
    SUGGESTION_RESULT_DISPLAY_AND_FIX: "/training/trainingparametersetting/:id/subclasification-suggestion-result/:classes"
  }
};

export const IMAGE_MANAGEMENT_TABS = {
  IMAGE_GROUP: 0,
  IMAGE_LIST: 1
};

export const API_URL = {
  IMAGE_GROUP_DATA: "api/image-group",
  FILTER_PREFERENCEDATA: "api/user/preference",
  USER_COLUMN_PREFERENCE: "api/user/preference/",
  EDIT_GROUP_NAME: "api/image-group/{id}",
  GROUP_RECORD: "api/image-group",
  IMAGE_RECORD: "api/image-collection",
  CREATE_DATASET: "api/training/dataset",
  DATASET_LIST: "api/training/{id}/dataset",
  DATASET_LIST_WITH_TRAINING: "api/training/{id}/training-dataset",
  EDIT_DATASET: "api/training/{tId}/dataset",
  TRAINING_LIST_DATA: "api/training/list",
  IMAGE_DETAILS: "api/image-group/imagelist/{id}",
  EDIT_TRAINING_RECORD: "/api/training/list/{id}",
  TRAIN_PARAMS: "api/training/{id}/params",
  TRAIN_PARAMS_DEVELOPER: "api/training/{id}/developermode",
  SAVE_IMAGE_DETAILS: "api/training/{id}/image/upload",
  DELETE_DATASET_IMAGES: "/api/training/{tid}/dataset/{seqNo}/image",
  GET_IMAGES_FOR_DATASET: "api/training/{trainingId}/dataset/{seqId}/image",
  DELETE_DATASET: "api/training/{tid}/dataset",
  COPY_PAST_MODAL_DATA: "api/training/{tId}/dataset",
  GET_PAST_MODAL_LIST: "api/training/list",
  TEMP_CHANGE_TRAINING_STATUS: "api/training/{id}/mode/{mode}",
  AUGMENTATION_MODE: "api/training/{id}/augmentation",
  STOP_EXECUTION: "api/training/{id}/stopRequest",
  EDIT_SUBCLASS_PARAMETER: "api/training/{id}/invariant",
  TRAIN_EXECUTION_LOG: "api/training/{id}/trainlog",
  TRAINING_CLONE: "api/training/{id}/clone",
  DELETE_TRAININGLIST: "api/training/list/{id}",
  LISTING_EXISTING_MODAL: "api/training/executed/list",
  EXECUTED_DATASET_CLONE: "/api/training/dataset/clone",
  STOP_TRAINING_EXECUTION: "/api/training/{id}/stop_request/{seqNo}",
  GET_BATCH_SEQ_NO: "/api/training/{id}/execute/{mode}"
};

export const IMAGE_GROUP_LIST = {
  PAGINATION: {
    // total space is 12. so to get columns divide 12
    // eg - 12/4 = 3 columns
    PAGE_SIZES: [
      { value: 8, label: 2, gridSize: 6, waferSize: 450 },
      { value: 12, label: 3, gridSize: 4, waferSize: 330 },
      { value: 16, label: 4, gridSize: 3, waferSize: 270 }
    ],
    DEFAULT: { value: 12, label: 3, gridSize: 4, waferSize: 330 }
  },
  SORT_DIRECTION: {
    ASCENDING: "Ascending",
    DESCENDING: "Descending"
  }
};

export const WAFER = {
  DEFAULT_SIZE: 340,
  EDGE_MARGIN: 0,
  NOTCH_SIZE: 0,
  ZOOM_FACTOR: 0.5,
  DEFECT_SIZE_SCALE: 2,
  SELECTED_DEFECT_OFFSET: 2,
  WAFER_SCRIBE_LINE_OPACITY: 0.3,
  SELECTED_DEFECT_COLOR: 0xff4040,
  SELECTED_DEFECT_OUTLINE_COLOR: 0x5c5cfc,
  DIE_FILL_COLOR: 0xffffff,
  ZOOM_SCALE: {
    IN: 1.6,
    OUT: 0.6
  },
  MAX_SCALE: 64,
  MIN_SCALE: 2,
  SELECTION_RECT_BORDER: 0xff0000
};

export const GRAPH = {
  AXIS_LINE_COLOR: "#0000001f",
  AXIS_LINE_WIDTH: 1
};
export const WAFER_DETAILS = {
  ABSCISSA: {
    MIN: 1,
    STEP: 1
  }
};

export const API_RESPONSE = {
  SUCCESS_STATUS_CODE: 200
};

//application menu list
export const APPMENULIST = [
  {
    title: "Training",
    shortName: "TR",
    url: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
    active: true
  },
  {
    title: "Classification Test",
    shortName: "CT",
    url: "/clasification-test",
    active: false
  }
  // {
  //   title: "Image Management",
  //   shortName: "IM",
  //   url: APP_ROUTES.IMAGE_MANAGEMENT_PAGES.IMAGE_GROUP_LIST,
  //   active: true
  // }
];
