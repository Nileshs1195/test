import { APP_ROUTES } from "../appconstants";
import { Switch, Route } from "react-router-dom";
import TrainingList from "../pages/training/traininglist";
import TrainingParameterSetting from "../pages/training/training-parameter-setting";
import SignIn from "../shared/pages/signIn";
import AutomaticParameterSearch from "../pages/training/training-parameter-setting/train-parameter/train-parameter-search/AutomaticParameterSearch";
import ExecutionLog from "../pages/training/training-parameter-setting/train-parameter/train-execution-log/ExecutionLog";
import SuggestionResultDisplayAndFix from "../pages/training/suggestionresultdisplayfix/suggestionresultdisplayfix";

const Routes = () => {
  return (
    <Switch>
      <Route exact path="/" component={TrainingList} />

      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING} component={TrainingList} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH} component={AutomaticParameterSearch} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_AUGMENTATION} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_SEARCH} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.SIGN_IN} component={SignIn} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG} component={ExecutionLog} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX} component={SuggestionResultDisplayAndFix} />
    </Switch>
  );
};

export default Routes;
