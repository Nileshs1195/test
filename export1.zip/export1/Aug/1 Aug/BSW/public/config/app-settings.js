window.APP_SETTINGS = {
    APP_URL: "http://localhost:5000/"
}