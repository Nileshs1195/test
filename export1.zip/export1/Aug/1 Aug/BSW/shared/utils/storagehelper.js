export const setItem = (key, value) => {
  localStorage.setItem(key, value);
};

export const getItem = (key) => {
  return localStorage.getItem(key);
};

export const getItemAsObject = (key) => {
  const value = getItem(key);
  if (value) return JSON.parse(value);
};
