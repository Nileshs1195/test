export const REG_EX = {
  NUMBER: /^[0-9]{0,}$/,
};
