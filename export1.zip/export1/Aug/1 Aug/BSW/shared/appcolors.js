export const colors = {
  primary: {
    main: "#3a5faa",
    dark: "#2c4373",
  },
  scrollBar: {
    bg: "#e8e8e8",
    thumb: {
      bg: "#c2c2c2",
    },
  },
  select: {
    textColor: "#000000bf",
    icon: "#000000",
  },
  layout: {
    bg: "#f8f8f8",
  },
  button: {
    active: "#628adc",
    hover: "#446ec1",
    disabled: {
      bg: "#cbcbcb",
      color: "#00000042",
    },
    outlined: {
      active: "#3a5faa3d",
      hover: "#3a5faa1f",
    },
  },
  iconButton: {
    hover: "#0000000d",
    active: "#3a5faa26",
    border: "#0000003b",
  },
  breadcrumb: {
    activeLink: "#000000e6",
    color: "#00000099",
    hover: "#3a5faa",
  },
  tab: {
    bg: "#f6f6f6",
    color: "#00000099",
  },
  slider: {
    railbg: "#00000038",
  },
  tooltip: {
    color: "#000000de",
    border: "#00000024",
  },
  chip: {
    outlined: {
      border: "#0000001f",
      color: "#000000bf",
      hover: "#0000000a",
      active: "#3a5faa26",
    },
    delete: {
      color: "#f53232",
      hoverBg: "#f532320d",
    },
  },
  inputLabel: {
    color: "#000000bf",
  },
  radio: {
    color: "#00000038",
  },
  muiSwitch: {
    trackBg: "#143371",
  },
  input: {
    validationError: "#f53232",
  },
  table: {
    hoverBg: "#ebf1ff",
    cellBorder: "#0000001f",
    dropIcon: "#bdbdbd",
  },
};
