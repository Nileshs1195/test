import { common } from "@material-ui/core/colors";
import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    height: "42vh",
    alignItems: "center",
    justifyContent: "center",
  },
  box: {
    width: "46%",
    height: "100%",
    border: "1px solid grey",
  },
  btnHolder: {
    display: "flex",
    width: "8%",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    padding: theme.spacing(2),
    "& > *": {
      marginBottom: theme.spacing(1),
    },
  },
  transferButton: {
    minWidth: "1.5em",
    width: "2.5em",
    height: "2.5em",
    marginBottom: "1em",
  },
  columnTitle: {
    textAlign: "left",
    color: "white",
    height: "13%",
    backgroundColor: theme.palette.primary.main,
    fontSize: theme.typography.fontSize,
  },
  columnWrapper: {
    boxShadow: "none",
    borderRadius: 0,
    height: "100%",
  },
  itemContainer: {
    overflow: "auto",
    height: "87%",
  },
  listItem: {
    padding: 0,
    "&:hover": {
      backgroundColor: "#f6f7ff",
      "& $iconButtonHolder": {
        display: "block",
      },
    },
  },
  listItemIcon: {
    minWidth: 0,
  },
  iconButtonHolder: {
    display: "none",
    marginRight: ".5em",
    "& > *": {
      marginLeft: theme.spacing(1.5),
    },
  },
  iconButton: {
    height: 20,
    width: 20,
    borderRadius: 6,
    background: common.white,
    "&:hover": {
      background: theme.palette.primary.main,
      "& > *": {
        color: common.white,
      },
    },
  },
  icon: {
    fontSize: 18,
  },
  rotate90: {
    transform: "rotate(90deg)",
  },
  moveIcon: {
    color: common.black,
  },
}));
