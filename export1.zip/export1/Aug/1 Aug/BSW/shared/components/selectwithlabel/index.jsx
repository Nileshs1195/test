import { FormControl, InputLabel } from "@material-ui/core";
import SelectField from "../ui/select";
import { useStyles } from "./style";

const SelectWithLabel = ({ label, fullWidth, width, list, ...props }) => {
  const classes = useStyles();
  return (
    <FormControl fullWidth={fullWidth}>
      {label && (
        <InputLabel shrink id={label}>
          {label}
        </InputLabel>
      )}
      <SelectField
        classes={{ root: classes.selectRoot }}
        labelId={label}
        items={list}
        {...props}
      />
    </FormControl>
  );
};
export default SelectWithLabel;
