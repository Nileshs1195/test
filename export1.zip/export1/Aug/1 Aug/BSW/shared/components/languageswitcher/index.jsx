import { Box, Switch } from "@material-ui/core";
import { useState } from "react";
import { SETTINGS } from "../../appsettings";
import { changeLanguage, getCurrentLanguage } from "../../i18n";
import { useStyles } from "./style";

const { EN, JP } = SETTINGS.I18N.LANGUAGES;

const isJapaneseSelected = (language) => {
  let isSelected;
  switch (language) {
    case JP:
      isSelected = true;
      break;
    case EN:
      isSelected = false;
      break;
    default:
      isSelected = false;
      break;
  }
  return isSelected;
};

const LanguageSwitch = ({ ...props }) => {
  const language = getCurrentLanguage();
  const classes = useStyles();
  const [checked, setChecked] = useState(isJapaneseSelected(language));

  const handleLanguageSwitch = (event) => {
    const { checked } = event.target;
    setChecked(checked);
    const language = checked ? JP : EN;
    changeLanguage(language);
  };

  return (
    <Box {...props} className={classes.root}>
      <span className={classes.lang}>EN</span>
      <Switch
        id="language-switch"
        checked={checked}
        onChange={handleLanguageSwitch}
        name="languageSwitch"
        color="default"
        size="small"
        classes={{
          track: classes.track,
          switchBase: classes.base,
          checked: classes.checked,
        }}
      />
      <span className={classes.lang}>JP</span>
    </Box>
  );
};

export default LanguageSwitch;
