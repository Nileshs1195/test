import { makeStyles } from "@material-ui/core";
import { colors } from "../../appcolors";

export const useStyles = makeStyles((theme) => ({
  root: {
    height: 16,
    display: "flex",
    alignItems: "center",
  },
  lang: {
    fontSize: theme.typography.fontSize,
    verticalAlign: "middle",
  },
  track: {
    background: colors.muiSwitch.trackBg,
    opacity: 1,
  },
  base: {
    "&$checked": {
      "& + $track": {
        background: colors.muiSwitch.trackBg,
        opacity: 1,
      },
    },
  },
  checked: {},
}));
