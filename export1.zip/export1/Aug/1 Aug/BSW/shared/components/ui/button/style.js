import { makeStyles } from "@material-ui/core";
import { common } from "@material-ui/core/colors";
import { colors } from "../../../appcolors";

export const useStyles = makeStyles((theme) => ({
  iconButton: {
    height: 36,
    width: 36,
    borderRadius: 5,
    border: `1px solid ${colors.iconButton.border}`,
    "&:hover": {
      background: colors.iconButton.hover,
    },
    "&:active": {
      background: colors.iconButton.active,
    },
  },
  btnSecondary: {
    background: common.white,
    color: theme.palette.primary.main,
    boxShadow: "0px 0px 4px 0px #0000004f",
  },
}));
