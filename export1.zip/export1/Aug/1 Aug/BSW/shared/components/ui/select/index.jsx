import { MenuItem, Select } from "@material-ui/core";
import PropTypes from "prop-types";

const SelectField = ({
  items,
  onClick,
  paperClassName,
  placeholderText,
  ...props
}) => {
  const onItemClick = (item) => {
    if (onClick) {
      onClick(item);
    }
  };

  return (
    <Select
      {...props}
      MenuProps={{
        anchorOrigin: {
          vertical: "bottom",
          horizontal: "left",
        },
        transformOrigin: {
          vertical: "top",
          horizontal: "left",
        },
        getContentAnchorEl: null,
        classes: { paper: paperClassName },
      }}
      inputProps={{ "aria-label": "Without label" }}
    >
      {placeholderText && (
        <MenuItem value="" disabled>
          {placeholderText}
        </MenuItem>
      )}
      {items &&
        items.map((item) => {
          return (
            <MenuItem
              id={`${props.id}-${item.value}`}
              value={item.value}
              onClick={() => onItemClick(item)}
              key={item.value}
            >
              {item.label}
            </MenuItem>
          );
        })}
    </Select>
  );
};

export default SelectField;
SelectField.propTypes = {
  items: PropTypes.array.isRequired,
  onClick: PropTypes.func,
};
