import { Typography } from "@material-ui/core";
import PropTypes from "prop-types";
import { useStyles } from "./style";

const Scale = ({ unit, value, alignment, ...remainProps }) => {
  const classes = useStyles();
  return (
    <div
      className={classes.root}
      {...remainProps}
      style={{ alignItems: alignment }}
    >
      <div className={classes.wrapper}>
        <div className={classes.iconContainer}>
          <div className={classes.icon} />
        </div>
      </div>
      <div className={classes.text}>
        <Typography variant="inherit">
          {value || 0}
          {unit}
        </Typography>
      </div>
    </div>
  );
};

export default Scale;
Scale.propTypes = {
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
  unit: PropTypes.string,
  alignment: PropTypes.oneOf(["center", "flex-end", "flex-start", "baseline"]),
};
