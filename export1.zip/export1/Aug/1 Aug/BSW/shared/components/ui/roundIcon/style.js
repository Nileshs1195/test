import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    height: 28,
    width: 28,
    borderRadius: "50%",
    display: "grid",
    placeItems: "center",
    fontSize: 12,
    border: "1px solid #3a5faa",
    background: "#ffffff",
    color: "#3a5faa",
    textTransform: "capitalize",
    overflow: "hidden",
    cursor: "pointer",
  },
  active: {
    background: theme.palette.primary.main,
    color: "#ffffff",
    border: "none",
  },
}));
