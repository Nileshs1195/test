import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    width: 40,
    height: 16,
    padding: 0,
  },
  switchBase: {
    padding: 1,
    top: -1,
    "&$checked": {
      transform: "translateX(23px)",
      color: theme.palette.common.white,
      "& + $track": {
        backgroundColor: theme.palette.primary.main,
        opacity: 1,
        border: "none",
      },
    },
    "&$disabled + $track": {
      opacity: 0.24,
    },
  },
  thumb: {
    width: 15,
    height: 15,
  },
  track: {
    borderRadius: 16 / 2,
    backgroundColor: theme.palette.primary.main,
    opacity: 1,
    transition: theme.transitions.create(["background-color", "border"]),
  },

  // Don't remove this empty class.
  checked: {},

  switchRoot: {
    display: "flex",
    position: "relative",
    alignItems: "center",
    cursor: "pointer",
    width: 50,
    height: 16,
    verticalAlign: "middle",
  },
  label: {
    fontSize: 10,
    position: "absolute",
    zIndex: 1,
    bottom: 2,
    color: theme.palette.common.white,
    userSelect: "none",
    top: "10%",
    pointerEvents: "none",
  },
  on: {
    left: 6,
  },
  off: {
    left: 17,
  },
  disabled: {
    color: "#ffffff !important",
  },
}));
