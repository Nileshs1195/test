import {
  Box,
  Button,
  Fade,
  IconButton,
  Modal as MuiModal,
  Paper,
} from "@material-ui/core";
import { Close } from "@material-ui/icons";
import clsx from "clsx";
import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { useStyles } from "./style";

const Modal = (props) => {
  const {
    id,
    onClose,
    onSubmit,
    primaryButtonTextKey,
    secondaryButtonTextKey,
    showControls,
    widthClass,
    noPadding,
    buttonClass,
    noImmediateClose,
    timeout = 250,
    disableApply = false,
    ...remainProps
  } = props;
  const classes = useStyles();
  const { t } = useTranslation();

  const handleApply = () => {
    onSubmit();
    if (noImmediateClose) return;
    onClose();
  };

  return (
    <MuiModal {...remainProps}>
      <Fade in={props.open} timeout={timeout}>
        <Box className={classes.root}>
          <Paper className={clsx(classes.container, widthClass)}>
            <IconButton
              id={`${id}-btn-close`}
              className={classes.closeBtn}
              onClick={onClose}
              size="small"
            >
              <Close fontSize="small" />
            </IconButton>

            <Box
              className={clsx(classes.parent, noPadding && classes.noPadding)}
            >
              <Box className={classes.content}>{props.children}</Box>
              {showControls && (
                <Box className={clsx(classes.btnContainer, buttonClass)}>
                  <Button
                    onClick={onClose}
                    variant="outlined"
                    color="primary"
                    id={`${id}-btn-secondary`}
                    className={clsx(classes.button, classes.buttonHover)}
                  >
                    {t(secondaryButtonTextKey)}
                  </Button>
                  <Button
                    onClick={handleApply}
                    variant="contained"
                    color="primary"
                    id={`${id}-btn-primary`}
                    className={classes.button}
                    disabled={disableApply}
                  >
                    {t(primaryButtonTextKey)}
                  </Button>
                </Box>
              )}
            </Box>
          </Paper>
        </Box>
      </Fade>
    </MuiModal>
  );
};

export default Modal;

Modal.propTypes = {
  onClose: PropTypes.func,
  onSubmit: PropTypes.func,
  open: PropTypes.bool.isRequired,
  showControls: PropTypes.bool,
  widthClass: PropTypes.string,
  primaryButtonTextKey: PropTypes.string,
  secondaryButtonTextKey: PropTypes.string,
  noPadding: PropTypes.bool,
  timeout: PropTypes.oneOfType([
    PropTypes.exact({
      enter: PropTypes.number,
      exit: PropTypes.number,
    }),
    PropTypes.number,
  ]),
  buttonClass: PropTypes.string,
  noImmediateClose: PropTypes.bool,
  disableApply: PropTypes.bool,
};
