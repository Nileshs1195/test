import { Tooltip as MuiTooltip } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import { colors } from "../../../appcolors";

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    border: `1px solid ${colors.tooltip.border}`,
    borderBottom: 0,
    color: colors.tooltip.color,
    boxShadow: theme.shadows[2],
    fontSize: theme.typography.fontSize,
    fontWeight: theme.typography.fontWeightLight,
    marginTop: 0,
  },
}))(MuiTooltip);

export default LightTooltip;
