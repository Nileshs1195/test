import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    minHeight: "52vh",
    border: "1px solid #D3D3D3",
    borderRadius: 5,
    display: "grid",
    placeItems: "center",
    marginTop: theme.spacing(1),
    width: "100%",
  },
}));
