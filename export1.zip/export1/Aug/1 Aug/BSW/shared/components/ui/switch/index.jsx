import { Switch as MuiSwitch, Typography } from "@material-ui/core";
import clsx from "clsx";
import PropTypes from "prop-types";
import { useStyles } from "./style";

const Switch = ({ checked, onClick, ...props }) => {
  const classes = useStyles();

  return (
    <div className={classes.switchRoot} onClick={onClick}>
      {checked && (
        <Typography variant="body1" className={clsx(classes.label, classes.on)}>
          ON
        </Typography>
      )}
      <MuiSwitch
        checked={checked}
        disableRipple
        onClick={onClick}
        classes={{
          root: classes.root,
          switchBase: classes.switchBase,
          thumb: classes.thumb,
          track: classes.track,
          checked: classes.checked,
          disabled: classes.disabled,
        }}
        {...props}
      />
      {!checked && (
        <Typography
          variant="body1"
          className={clsx(classes.label, classes.off)}
        >
          OFF
        </Typography>
      )}
    </div>
  );
};

export default Switch;

Switch.propTypes = {
  checked: PropTypes.bool.isRequired,
};
