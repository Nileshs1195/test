import { Avatar, Menu, MenuItem, Typography } from "@material-ui/core";
import { ExitToApp } from "@material-ui/icons";
import React, { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import UserStore from "../../../stores/userstore";
import { useStyles } from "./style";

const UserWidget = ({ dropdownItems }) => {
  const userStore = useContext(UserStore);
  const [anchorEl, setAnchorEl] = useState(null);
  const history = useHistory();
  const open = Boolean(anchorEl);
  const { t } = useTranslation();
  const classes = useStyles();

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleSignOut = () => {
    userStore.logout();
    history.push("/");
  };

  return (
    <div>
      <Avatar
        style={{ cursor: "pointer" }}
        aria-label="user-menu"
        aria-controls="user-menu"
        onClick={handleClick}
        className={classes.small}
      >
        {userStore.currentUser.username}
      </Avatar>
      <Menu
        id="user-menu"
        anchorEl={anchorEl}
        keepMounted
        open={open}
        onClose={handleClose}
        getContentAnchorEl={null}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
      >
        <MenuItem onClick={handleSignOut}>
          <div className={classes.menuItemStyles}>
            <ExitToApp fontSize="small" />
            <Typography variant="subtitle2">
              {t("pages.signin.sign-out")}
            </Typography>
          </div>
        </MenuItem>
      </Menu>
    </div>
  );
};

export default UserWidget;
