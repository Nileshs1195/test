import { Slide, Snackbar as MuiSnackbar } from "@material-ui/core";
import Alert from "@material-ui/lab/Alert";
import PropTypes from "prop-types";

const Transition = (props) => {
  return <Slide {...props} direction={props.direction} />;
};

const Snackbar = (props) => {
  const {
    open,
    message,
    alertType,
    autoHideDuration,
    closeSnackBar,
    vertical,
    horizontal,
    direction,
  } = props;

  return (
    <div>
      <MuiSnackbar
        open={open}
        anchorOrigin={{ vertical, horizontal }}
        autoHideDuration={autoHideDuration}
        onClose={closeSnackBar}
        TransitionComponent={Transition}
        TransitionProps={{ direction }}
      >
        <Alert severity={alertType} onClose={closeSnackBar}>
          <div>{message}</div>
        </Alert>
      </MuiSnackbar>
    </div>
  );
};
export default Snackbar;

Snackbar.propTypes = {
  open: PropTypes.bool,
  message: PropTypes.string,
  alertType: PropTypes.oneOf(["error", "warning", "info", "success"]),
  autoHideDuration: PropTypes.number,
  closeSnackBar: PropTypes.func,
  vertical: PropTypes.string,
  horizontal: PropTypes.string,
  direction: PropTypes.string,
};
