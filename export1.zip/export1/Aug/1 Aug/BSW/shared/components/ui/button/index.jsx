import { Button, IconButton as MuiIconBtn } from "@material-ui/core";
import { useStyles } from "./style";

const IconButton = ({ children, ...props }) => {
  const classes = useStyles();
  return (
    <MuiIconBtn {...props} classes={{ root: classes.iconButton }}>
      {children}
    </MuiIconBtn>
  );
};

export default IconButton;

export const SecondaryButton = ({ children, classes, ...props }) => {
  const styles = useStyles();
  return (
    <Button {...props} classes={{ root: styles.btnSecondary, ...classes }}>
      {children}
    </Button>
  );
};
