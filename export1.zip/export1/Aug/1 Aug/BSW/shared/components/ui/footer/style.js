import { makeStyles } from "@material-ui/core";
export const useStyles = makeStyles((theme) => ({
  root: {
    position: "fixed",
    bottom: 0,
    width: "100%",
    backgroundColor: "#808080",
    color: "white",
    textAlign: "center",
  },
  text: {
    margin: "8px 0",
    lineHeight: 1,
  },
}));
