import { makeStyles } from "@material-ui/core";
import { colors } from "../../../appcolors";

export const useStyles = makeStyles((theme) => ({
  root: {
    "& ol li": {
      "& a": {
        textDecoration: "none",
        fontSize: 18,
        color: colors.breadcrumb.color,
        fontWeight: 300,
        "&:hover": {
          color: colors.breadcrumb.hover,
        },
      },
      "&:last-child": {
        "& a": {
          pointerEvents: "none",
          color: colors.breadcrumb.activeLink,
        },
      },
    },
  },
  capitalize: {
    textTransform: "capitalize",
  },
}));
