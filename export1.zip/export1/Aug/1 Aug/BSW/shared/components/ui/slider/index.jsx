import { Slider as MuiSlider } from "@material-ui/core";
import PropTypes from "prop-types";
import { useCallback, useEffect, useState } from "react";
import { debounce } from "../../../utils";
import { useStyles } from "./style";

const Slider = ({ value, delay, onChange, ...props }) => {
  const classes = useStyles();
  const [sliderValue, setSliderValue] = useState(value);

  useEffect(() => {
    setSliderValue(value);
  }, [value]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const handleUpdate = useCallback(
    debounce((e, value) => onChange(value, e), delay ?? 250),
    []
  );

  const handleChange = (e, value) => {
    setSliderValue(() => {
      handleUpdate(e, value);
      return value;
    });
  };

  return (
    <MuiSlider
      onChange={handleChange}
      value={sliderValue}
      {...props}
      classes={{ rail: classes.slider }}
    />
  );
};

export default Slider;

Slider.propTypes = {
  value: PropTypes.number.isRequired,
  delay: PropTypes.number,
  onChange: PropTypes.func,
};
