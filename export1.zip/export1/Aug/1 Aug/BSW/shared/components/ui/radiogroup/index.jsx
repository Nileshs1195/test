import {
  FormControlLabel,
  Radio,
  RadioGroup as MuiRadioGroup,
} from "@material-ui/core";
import PropTypes from "prop-types";

const RadioGroup = ({ items, selected, ...props }) => {
  return (
    <MuiRadioGroup {...props}>
      {items.map((item) => (
        <FormControlLabel
          key={item.label}
          value={item.value}
          control={<Radio color="primary" checked={item.value === selected} />}
          label={item.label}
        />
      ))}
    </MuiRadioGroup>
  );
};

export default RadioGroup;
RadioGroup.propTypes = {
  items: PropTypes.array.isRequired,
};
