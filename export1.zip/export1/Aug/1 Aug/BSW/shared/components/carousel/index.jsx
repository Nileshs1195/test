import { Box } from "@material-ui/core";
import { ChevronLeft, ChevronRight } from "@material-ui/icons";
import clsx from "clsx";
import PropTypes from "prop-types";
import { useCallback, useEffect, useState } from "react";
import { IconButton } from "../ui";
import CarouselContent from "./carouselcontent";
import { useStyles } from "./style";

const Carousel = (props) => {
  const classes = useStyles();
  const { carouselData, maxItemCount, onChange, carouselIndex, disabled, id } =
    props;
  const [selectedIndex, setSelectedIndex] = useState(carouselIndex);
  const [hideFromLeft, setHideFromLeft] = useState(0);

  const goToSlide = (index) => {
    if (disabled) return;
    setSelectedIndex(index);
    onChange(index);
  };

  const moveToSelected = useCallback(
    (index) => {
      if (index > maxItemCount - 1) {
        setHideFromLeft(index - (maxItemCount - 1));
      }
      setSelectedIndex(index);
    },
    [maxItemCount]
  );

  useEffect(() => {
    moveToSelected(carouselIndex);
  }, [carouselIndex, moveToSelected]);

  const goToPrevSlide = (e, moveToBegining = false) => {
    e.preventDefault();
    let index = 1;

    if (!moveToBegining) index = selectedIndex;

    --index;

    if (index >= maxItemCount - 1) {
      setHideFromLeft(index - (maxItemCount - 1));
    } else {
      setHideFromLeft(0);
    }
    setSelectedIndex(index);
    onChange(index);
  };

  const goToNextSlide = (e, moveToEnd = false) => {
    e.preventDefault();

    let slidesLength = carouselData.length - 1;
    let index = slidesLength - 1;

    if (!moveToEnd) index = selectedIndex;

    ++index;

    if (index > maxItemCount - 1) {
      setHideFromLeft(index - (maxItemCount - 1));
    }
    setSelectedIndex(index);
    onChange(index);
  };

  const disableLeft = selectedIndex === 0 || !carouselData.length;
  const disableRight =
    selectedIndex + 1 === carouselData.length || !carouselData.length;

  return (
    <div className={classes.root}>
      <IconButton
        className={classes.button}
        disabled={disabled || disableLeft}
        onClick={(e) => goToPrevSlide(e, true)}
        id={`${id}-carousel-to-start-btn`}
      >
        <ChevronLeft
          className={clsx((disabled || !disableLeft) && classes.icon)}
        />
        <ChevronLeft
          className={clsx(
            (disabled || !disableLeft) && classes.icon,
            classes.left
          )}
        />
      </IconButton>
      <IconButton
        className={classes.button}
        disabled={disabled || disableLeft}
        onClick={goToPrevSlide}
        id={`${id}-carousel-prev-btn`}
      >
        <ChevronLeft
          className={clsx((disabled || !disableLeft) && classes.icon)}
        />
      </IconButton>
      {carouselData.length && (
        <Box className={clsx(classes.box, disabled && classes.noPointerEvents)}>
          {carouselData.map((element, index) => {
            return (
              <CarouselContent
                {...props}
                carouselData={element}
                key={index}
                index={index}
                activeIndex={selectedIndex}
                isActive={selectedIndex === index && !disabled}
                onClick={(e) => goToSlide(index)}
                hideFromLeft={hideFromLeft > index}
                isMaxAvailable={carouselData.length >= maxItemCount}
              />
            );
          })}
        </Box>
      )}
      <IconButton
        className={classes.button}
        onClick={goToNextSlide}
        disabled={disabled || disableRight}
        id={`${id}-carousel-next-btn`}
      >
        <ChevronRight
          className={clsx((disabled || !disableRight) && classes.icon)}
        />
      </IconButton>
      <IconButton
        id={`${id}-carousel-to-end-btn`}
        className={classes.button}
        disabled={disabled || disableRight}
        onClick={(e) => goToNextSlide(e, true)}
      >
        <ChevronRight
          className={clsx((disabled || !disableRight) && classes.icon)}
        />
        <ChevronRight
          className={clsx(
            (disabled || !disableRight) && classes.icon,
            classes.left
          )}
        />
      </IconButton>
    </div>
  );
};

export default Carousel;

Carousel.propTypes = {
  carouselData: PropTypes.array,
  maxItemCount: PropTypes.number,
  onChange: PropTypes.func,
  carouselIndex: PropTypes.number,
  disabled: PropTypes.bool,
};
