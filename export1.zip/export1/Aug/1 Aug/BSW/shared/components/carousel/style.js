import { makeStyles } from "@material-ui/core";
import { common } from "@material-ui/core/colors";

export const useStyles = makeStyles((theme) => ({
  root: {
    color: "white",
    display: "flex",
    alignItems: "center",
  },
  box: {
    display: "-webkit-box",
    overflow: "hidden",
    padding: "10px 2px",
    maxWidth: "100%",
    width: "100%",
    position: "relative",
    margin: "0 auto",
  },
  left: {
    marginLeft: "-18px",
  },
  button: {
    position: "relative",
    margin: theme.spacing(0, 0.25),
  },
  noPointerEvents: {
    pointerEvents: "none",
  },
  icon: {
    color: common.black,
  },
}));
