import { ListItem, ListItemIcon, ListItemText } from "@material-ui/core";
import clsx from "clsx";
import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import { RoundIcon } from "../../components/ui";
import { useStyles } from "./styles";

const Sidebar = (props) => {
  const { appMenus, children, renderTabs, open } = props;
  const classes = useStyles();
  const history = useHistory();
  const { t } = useTranslation();

  const handleNavigation = (url, active) => {
    if (active) history.push(url);
    else window.location = url;
  };

  const renderAppSubIcons = (apps) => {
    return (
      <div
        id={`app-icon-${apps.shortName}`}
        key={apps.shortName}
        className={clsx(renderTabs && classes.menuHorizontal)}
      >
        <ListItem
          button
          onClick={() => handleNavigation(apps.url, apps.active)}
          className={
            apps.active
              ? classes.sidebarAppMenuSelectOpen
              : classes.sidebarAppMenuOpen
          }
        >
          <ListItemIcon>
            <div className={clsx(!renderTabs && classes.sidebarAppIconText)}>
              <RoundIcon
                title={apps.shortName}
                active={apps.active}
                size={renderTabs && !open && 34}
              />
            </div>
            {!renderTabs && <ListItemText primary={t(apps.title)} />}
          </ListItemIcon>
        </ListItem>
      </div>
    );
  };

  return (
    <>
      {open &&
        appMenus.map(function (data) {
          return renderAppSubIcons(data);
        })}

      {!open && (
        <>
          <div className={classes.root}>
            {!renderTabs
              ? appMenus.map((data) => renderAppSubIcons(data))
              : children}
          </div>
          {renderTabs && (
            <div className={classes.submenuOuter}>
              {appMenus.map((data) => renderAppSubIcons(data))}
            </div>
          )}
        </>
      )}
    </>
  );
};

export default Sidebar;

Sidebar.propTypes = {
  children: PropTypes.node,
  appMenus: PropTypes.array.isRequired,
  renderTabs: PropTypes.bool,
  open: PropTypes.bool,
};
