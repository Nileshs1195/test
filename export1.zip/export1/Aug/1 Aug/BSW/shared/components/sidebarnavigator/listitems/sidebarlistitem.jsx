import { ListItemText, Typography } from "@material-ui/core";
import { Checkbox, LightTooltip, RadioGroup } from "../../ui";
import { useStyles } from "../styles";

const SidebarListItem = (props) => {
  const { type, item, fieldName, handleCheck, check, ...restProps } = props;
  const classes = useStyles();

  if (type === "checkbox") {
    return (
      <ListItemText
        classes={{ primary: classes.listItemText }}
        primaryTypographyProps={{ component: "label" }}
      >
        <Checkbox
          color="default"
          checked={check}
          id={fieldName}
          className={classes.checkBox}
          onChange={(event) =>
            handleCheck(item, fieldName, event.target.checked)
          }
          {...restProps}
        />
        <LightTooltip title={item.length > 28 ? item : ""}>
          <Typography noWrap>{item}</Typography>
        </LightTooltip>
      </ListItemText>
    );
  } else if (type === "radiogroup") {
    return (
      <ListItemText className={classes.radioGroup}>
        <RadioGroup
          id={fieldName}
          selected={check}
          items={item}
          onChange={(event) => handleCheck(item, fieldName, event.target.value)}
          {...restProps}
        />
      </ListItemText>
    );
  }
};

export default SidebarListItem;
