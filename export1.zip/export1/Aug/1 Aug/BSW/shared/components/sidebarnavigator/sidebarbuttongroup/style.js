import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    textAlign: "right",
    padding: theme.spacing(2, 0),
    "& button:last-child": {
      margin: theme.spacing(0, 2),
    },
  },
}));
