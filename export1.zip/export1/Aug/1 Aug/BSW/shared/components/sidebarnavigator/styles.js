import { makeStyles } from "@material-ui/core";
export const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.background.paper,
    width: 280,
    flexDirection: "Column",
    height: "calc(100% - 48px)",
  },
  listItemText: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
  },
  checkBox: {
    marginLeft: theme.spacing(1),
    height: "1em",
    borderRadius: "0.25em",
    "&.Mui-disabled +.MuiTypography-root": {
      color: " rgba(0, 0, 0, 0.38)",
    },
    "& +.MuiTypography-root": {
      fontSize: 14,
      paddingRight: 5,
    },
  },
  collapseWrapper: {
    paddingBottom: theme.spacing(1),
  },

  menuHorizontal: {
    display: "inline-block",
  },
  submenuOuter: {
    width: "100%",
    overflow: "auto",
    position: "absolute",
    bottom: 0,
    left: 0,
    padding: 0,
    background: "#FFF",
    boxShadow:
      "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
    borderTop: "0.5px solid #0000000d",
  },
  sidebarAppMenuOpen: {
    backgroundColor: "white",
    padding: "0px",
    height: 48,

    "& span": {
      fontSize: theme.typography.fontSize,
      paddingLeft: 10,
      color: "#323130",
    },
    "& div": {
      justifyContent: "center",
      alignItems: "center",
    },
    "& > div": {
      minWidth: "48px",
    },
  },
  sidebarItemText: {
    fontSize: 18,
  },
  defaultSidebarSelectionOpen: {
    backgroundColor: "rgba(0 0 0 0.07)",
    padding: "0",
    marginTop: "0",
    height: "48px",
    width: "100%",
    textAlign: "center",
    alignItems: "center",
    "& span": {
      color: "#3a5faa",
      fontSize: theme.typography.fontSize,
      paddingLeft: 10,
      fontWeight: 600,
    },
    "& div": {
      justifyContent: "center",
      alignItems: "center",
    },
    "& > div": {
      minWidth: "48px",
    },
  },
  sidebarAppMenuSelectOpen: {
    backgroundColor: "rgba(0, 0, 0, 0.07)",
    padding: "0px",
    height: 48,
    "& span": {
      color: "#3a5faa",
      fontSize: theme.typography.fontSize,
      paddingLeft: 10,
      fontWeight: 600,
    },
    "& div": {
      justifyContent: "center",
      alignItems: "center",
    },
    "& > div": {
      minWidth: "48px",
    },
  },
  sidebarAppIconText: {
    marginLeft: 10,
  },
  radioGroup: {
    marginLeft: theme.spacing(3),
  },
}));
