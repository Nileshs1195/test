import { Collapse, Divider, ListItem, ListItemText } from "@material-ui/core";
import { ExpandLess, ExpandMore } from "@material-ui/icons";
import { useState } from "react";
import { useStyles } from "../styles";

const SidebarList = (props) => {
  const { dataTitle } = props;
  const classes = useStyles();
  const [isOpen, setIsOpen] = useState(false);

  const handleClick = () => setIsOpen((prev) => !prev);

  return (
    <>
      <ListItem button onClick={handleClick}>
        <ListItemText
          classes={{ primary: classes.sidebarItemText }}
          primary={dataTitle}
        />
        {isOpen ? <ExpandLess /> : <ExpandMore />}
      </ListItem>
      <Collapse
        in={isOpen}
        timeout="auto"
        unmountOnExit={props.unmountOnExit ?? true}
        classes={{ wrapper: classes.collapseWrapper }}
      >
        {props.children}
      </Collapse>
      <Divider />
    </>
  );
};
export default SidebarList;
