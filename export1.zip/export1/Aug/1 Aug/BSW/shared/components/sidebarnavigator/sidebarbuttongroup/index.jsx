import { Box, Divider } from "@material-ui/core";
import clsx from "clsx";
import { useStyles } from "./style";

const SidebarButtonGroup = ({ children, className, ...props }) => {
  const classes = useStyles();
  return (
    <>
      <Divider />
      <Box {...props} className={clsx(classes.root, className)}>
        {children}
      </Box>
    </>
  );
};

export default SidebarButtonGroup;
