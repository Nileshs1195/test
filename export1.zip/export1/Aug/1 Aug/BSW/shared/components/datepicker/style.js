import { makeStyles } from "@material-ui/core";
import { common } from "@material-ui/core/colors";
import { colors } from "../../appcolors";

export const useStyles = makeStyles((theme) => ({
  root: {
    marginTop: "0px !important",
  },
  paper: {
    marginTop: theme.spacing(0.5),
  },
  input: {
    color: common.black,
  },
  label: {
    color: colors.inputLabel.color,
  },
}));
