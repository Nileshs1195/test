import DateFnsUtils from "@date-io/date-fns";
import { IconButton, InputAdornment } from "@material-ui/core";
import { CalendarTodaySharp } from "@material-ui/icons";
import { DateTimePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import "date-fns";
import { SETTINGS } from "../../appsettings";
import { useStyles } from "./style";

const DatePicker = (props) => {
  const {
    id,
    date,
    label,
    handleDateChange,
    maxDate,
    minDate,
    className,
    validation,
  } = props;
  const classes = useStyles();

  const valueDate =
    validation && validation.valueDate ? validation.valueDate : null;

  return (
    <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <DateTimePicker
        id={id}
        classes={{ root: classes.root }}
        variant="inline"
        autoOk
        error={valueDate}
        helperText={valueDate}
        ampm={false}
        className={className}
        margin="normal"
        label={label}
        format={SETTINGS.DATE_TIME_FORMAT}
        allowKeyboardControl={false}
        value={date}
        onChange={handleDateChange}
        maxDate={maxDate}
        minDate={minDate}
        PopoverProps={{
          className: classes.paper,
        }}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton>
                <CalendarTodaySharp />
              </IconButton>
            </InputAdornment>
          ),
          classes: { root: classes.input },
        }}
        InputLabelProps={{
          classes: { root: classes.label },
        }}
      />
    </MuiPickersUtilsProvider>
  );
};
export default DatePicker;
