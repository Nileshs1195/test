import { makeStyles } from "@material-ui/core";
import { colors } from "../../appcolors";

export const useStyles = makeStyles((theme) => ({
  table: {
    "& thead th": {
      color: "white",
      backgroundColor: theme.palette.primary.main,
      width: "max-content",
      position: "sticky",
      top: 0,
    },
    "& thead tr": {
      backgroundColor: theme.palette.primary.main,
    },
    "& thead th:first-child": {
      left: 0,
      zIndex: 1,
      position: "sticky",
    },
    "& tbody td": {
      fontWeight: theme.typography.fontWeightLight,
      width: "max-content",
      whiteSpace: "nowrap",
    },
    "& tbody tr:hover": {
      backgroundColor: `${colors.table.hoverBg} !important`,
    },
    "& tbody tr.Mui-selected, tbody tr.Mui-selected:hover": {
      backgroundColor: colors.table.hoverBg,
    },
  },
  headerContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    height: "100%",
    whiteSpace: "nowrap",
  },
  filterWrapper: {
    width: "40px",
    display: "flex",
    paddingLeft: theme.spacing(1),
    cursor: "pointer",
  },
  tablebodyContent: {
    fontSize: 14,
    overflow: "hidden",
    fontWeight: theme.typography.fontWeightLight,
  },
  checkboxIcon: {
    borderRadius: 5,
    width: 16,
    height: 16,
    boxShadow: "inset 0 0 0 1px #10161a, inset 0 -1px 0 #10161a",
  },
  stickyCell: {
    position: "sticky",
    left: "0px",
    backgroundColor: "white",
  },
  stickyHeader: {
    left: 0,
    zIndex: 1,
  },
  fixedWrapper: {
    position: "fixed",
    display: "flex",
    placeContent: "center",
    alignItems: "center",
  },
  displayNone: { display: "none" },
  noContentLabel: {
    marginTop: "-.5em",
  },
  noContent: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
  },
  fixedContent: {
    backgroundColor: "#ffffff",
    position: "relative",
  },
  warningIcon: {
    fontSize: "4rem",
    color: "#00000020",
  },
  hidden: {
    visibility: "hidden",
  },
  tableBodyCell: {
    borderRight: `1px solid ${colors.table.cellBorder}`,
    height: 42,
  },
  resizeWrapper: {
    top: 0,
    right: 0,
    width: 8,
    position: "absolute",
    cursor: "col-resize",
    userSelect: "none",
    height: "100%",
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    "&:hover": {
      "& > *": {
        width: 2,
        background: "#ffffff",
      },
    },
  },
  resizer: {
    pointerEvents: "none",
    userSelect: "none",
    background: "#ffffff80",
    width: 1,
    height: "40%",
  },
  textStyle: {
    textOverflow: "ellipsis",
    overflow: "hidden",
  },
  cellWrapper: {
    display: "flex",
    flex: 1,
    justifyContent: "space-between",
  },
  dropIcon: {
    color: colors.table.dropIcon,
    cursor: "pointer",
  },
  checkbox: {
    padding: 0,
  },
}));
