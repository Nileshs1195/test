import { TextField, Typography } from "@material-ui/core";
import { ChevronLeft, ChevronRight } from "@material-ui/icons";
import PropTypes from "prop-types";
import { useCallback, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { REG_EX } from "../../../appconstants";
import { SETTINGS } from "../../../appsettings";
import { debounce } from "../../../utils";
import { IconButton, SelectField } from "../../ui/";
import { useStyles } from "./styles";

const Pagination = (props) => {
  const maxPage = useRef();
  const classes = useStyles();
  const { t } = useTranslation();

  const {
    id,
    itemCount,
    onChange,
    disabled,
    resetPageNo,
    pageSizeDetails,
    labelName,
    pageNo,
    pageSize,
    disableItemPerPage,
    currentPageNumber,
    onPageNumberChange,
    onHandleBlur,
    onUpdateCurrentPage,
    doForceUpdate,
  } = props;

  const pageItems = pageSizeDetails ?? SETTINGS.GRID.PAGINATION.PAGE_SIZES;
  const pageSizes = pageSize ?? SETTINGS.GRID.PAGINATION.PAGE_SIZES[0].value;
  const navDirections = SETTINGS.GRID.PAGINATION.DIRECTIONS;
  const pageNumber = pageNo ?? 0;
  const [currentPageNo, setCurrentPageNo] = useState(pageNumber);
  const [itemPerPage, setItemPerPage] = useState(pageSizes);
  const currentPage = currentPageNumber ?? currentPageNo;
  const currentPageRef = useRef(pageNumber);
  const [, updateState] = useState();
  const forceUpdate = useCallback(() => updateState({}), []);

  const updateCurrentPage = (pageNo) => {
    if (onUpdateCurrentPage) {
      onUpdateCurrentPage(pageNo);
    } else {
      setCurrentPageNo(pageNo);
      currentPageRef.current = pageNo;
    }
  };

  useEffect(() => {
    maxPage.current = Math.ceil(itemCount / itemPerPage);
    doForceUpdate && forceUpdate();
    if ((currentPage === 0 && maxPage.current > 0) || resetPageNo) {
      updateCurrentPage(1);
      onChange(getPaginationObject(itemPerPage, 1));
    }

    if (currentPage > maxPage.current) {
      updateCurrentPage(maxPage.current);
      onChange(getPaginationObject(itemPerPage, maxPage.current));
    }
  }, [itemPerPage, itemCount, resetPageNo, onChange, currentPage]);

  const onNav = (direction) => {
    let page = 0;
    if (direction === navDirections.NEXT) {
      page = currentPage + 1;
    } else {
      page = currentPage - 1;
    }
    updateCurrentPage(page);
    onChange(getPaginationObject(itemPerPage, page));
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const notifyParent = useCallback(
    debounce((itemPerPage, page) => {
      if (
        page <= maxPage.current &&
        page > 0 &&
        currentPageRef.current !== page
      ) {
        currentPageRef.current = page;
        onChange(getPaginationObject(itemPerPage, page));
      }
    }, 750),
    []
  );

  const onPageChange = (e) => {
    const page = +e.target.value;
    if (onPageNumberChange) {
      onPageNumberChange(page);
      notifyParent(itemPerPage, page);
    } else {
      if (page > 0 && REG_EX.NUMBER.test(page)) {
        notifyParent(itemPerPage, page);
        setCurrentPageNo(page);
      } else setCurrentPageNo("");
    }
  };

  const onItemPerPageChange = (e) => {
    let page = currentPage;
    const itemPerPage = e.value;
    maxPage.current = Math.ceil(itemCount / itemPerPage);
    if (page > maxPage.current) {
      page = maxPage.current;
    }
    setItemPerPage(itemPerPage);
    updateCurrentPage(page);
    onChange(getPaginationObject(itemPerPage, page));
  };

  const getPaginationObject = (pageSize, pageNo) => {
    return {
      pageSize: pageSize,
      pageNo: pageNo,
    };
  };

  const handleFocus = (event) => {
    event.target.select();
  };

  const handleBlur = (event) => {
    if (!Boolean(event.target.value)) {
      onHandleBlur ? onHandleBlur() : setCurrentPageNo(currentPageRef.current);
    }
  };

  const renderPageDisplay = () => {
    let secondPart = currentPage * itemPerPage;
    let firstPart = secondPart - itemPerPage + 1;
    if (secondPart > itemCount) {
      secondPart = itemCount;
    }
    if (firstPart < 0) {
      firstPart = 0;
    }
    if (itemCount === 0) {
      firstPart = 0;
      secondPart = 0;
    }

    return (
      <span className={classes.pageDisplay}>
        {firstPart}-{secondPart} / {itemCount}
      </span>
    );
  };

  return (
    <div className={classes.controlContainer}>
      <div>
        <IconButton
          size="small"
          id={`${id}-page-nav-left`}
          variant="outlined"
          disabled={disabled || currentPage <= 1}
          onClick={() => onNav(navDirections.PREV)}
        >
          <ChevronLeft />
        </IconButton>
        {renderPageDisplay()}
        <IconButton
          size="small"
          id={`${id}-page-nav-right`}
          variant="outlined"
          onClick={() => onNav(navDirections.NEXT)}
          disabled={disabled || currentPage === maxPage.current}
        >
          <ChevronRight />
        </IconButton>
      </div>
      <div className={classes.pageWrapper}>
        <Typography variant="body2">
          {t("pages.defect-inspection.controls.page")}
        </Typography>
        <TextField
          id={`${id}-current-page-no`}
          value={currentPage}
          onChange={onPageChange}
          inputProps={{ min: 1, max: maxPage.current }}
          classes={{ root: classes.customInputText }}
          onFocus={handleFocus}
          onBlur={handleBlur}
        />
        <Typography variant="body2">
          {t("pages.defect-inspection.controls.of")}
        </Typography>
        <span className={classes.totalPages}>&nbsp;{maxPage.current}</span>
      </div>
      <div>
        {!disableItemPerPage && (
          <>
            {labelName ?? t("pages.defect-inspection.controls.item-per-page")}
            <SelectField
              id={`${id}-item-per-page`}
              disabled={disabled}
              value={itemPerPage}
              className={classes.select}
              onClick={onItemPerPageChange}
              paperClassName={classes.selectPaper}
              items={pageItems}
            />
          </>
        )}
      </div>
    </div>
  );
};

export default Pagination;

Pagination.propTypes = {
  itemCount: PropTypes.number,
  onChange: PropTypes.func,
  disabled: PropTypes.bool,
  resetPageNo: PropTypes.bool,
  pageSizeDetails: PropTypes.array,
  labelName: PropTypes.string,
  pageNo: PropTypes.number,
  pageSize: PropTypes.number,
  disableItemPerPage: PropTypes.bool,
  currentPageNumber: PropTypes.number,
  onPageNumberChange: PropTypes.func,
};
