import { ClickAwayListener, Paper, Typography } from "@material-ui/core";
import PropTypes from "prop-types";
import { useEffect, useState } from "react";
import { SETTINGS } from "../../../appsettings";
import { Chip } from "../../ui";
import AllFilters from "./allfilters";
import { getChipLabel } from "./helper";
import { useStyles } from "./styles";

const FilterPanel = (props) => {
  const { id, filters, filterLabels, onFilterRemove, clearChipLabel } = props;
  const { CELL, EXCLUDE, INCLUDE } = SETTINGS.GRID.CELL_FILTERS;
  const { filterBy, include, exclude } = filterLabels;

  const [chipData, setChipData] = useState({});
  const [showPanel, setShowPanel] = useState(false);

  const classes = useStyles();

  useEffect(() => {
    const groupFilters = (filters) => {
      const filterTypes = {
        [CELL]: [],
        [EXCLUDE]: [],
        [INCLUDE]: [],
      };
      for (const filter of filters) {
        switch (filter.filter) {
          case CELL:
            filterTypes[CELL] = [...filterTypes[CELL], filter];
            break;
          case EXCLUDE:
            filterTypes[EXCLUDE] = [...filterTypes[EXCLUDE], filter];
            break;
          default:
            filterTypes[INCLUDE] = [...filterTypes[INCLUDE], filter];
            break;
        }
      }
      return filterTypes;
    };

    if (filters.length) {
      setChipData(groupFilters(filters));
    }
  }, [filters]);

  const togglePanel = () => {
    setShowPanel((show) => !show);
  };

  const generateResponse = (currentFilters, removedChip) => {
    const filterObj = {};

    for (const filter in currentFilters) {
      const filters = {};
      currentFilters[filter].forEach((chip) => {
        switch (chip.filter) {
          case CELL:
            filters[chip.column] = true;
            break;
          default:
            if (filters[chip.column])
              filters[chip.column] = [...filters[chip.column], chip.value];
            else filters[chip.column] = [chip.value];
            break;
        }
      });
      filterObj[filter] = filters;
    }
    onFilterRemove(filterObj, removedChip);
  };

  const clearChip = (chip) => {
    let filter = [];
    switch (chip.filter) {
      case CELL:
        filter = chipData[chip.filter].filter(
          (col) => col.column !== chip.column
        );
        break;
      default:
        filter = chipData[chip.filter].filter(
          (col) =>
            col.filter + col.column + col.value !==
            chip.filter + chip.column + chip.value
        );
        break;
    }
    const updatedChips = { ...chipData, [chip.filter]: filter };
    setChipData(updatedChips);
    generateResponse(updatedChips, chip);
  };

  const clearAllChip = (type) => {
    const updatedChips = { ...chipData, [type]: [] };
    setChipData(updatedChips);
    generateResponse(updatedChips, null);
  };

  const renderChips = (key, chips) => {
    return (
      <div className={classes.chipContainer}>
        {chips.map((chip, i) => {
          const label = getChipLabel(chip);
          return (
            <Chip
              id={`${id}_${chip.filter}_${i}`}
              key={label}
              label={label}
              onDelete={() => clearChip(chip)}
            />
          );
        })}

        <Chip
          id={`${id}_close_${key}`}
          main
          onClick={() => clearAllChip(key)}
          label={clearChipLabel}
        />
      </div>
    );
  };

  const renderFilters = (label, content, key) => (
    <div className="child">
      <Typography variant="body2" className={classes.filterTitle}>
        {label}
      </Typography>
      {renderChips(key, content)}
    </div>
  );

  return (
    <>
      <AllFilters
        filters={filters}
        onIconClick={togglePanel}
        label={filterLabels.filters}
        onChipDelete={clearChip}
        id={id}
        showPanel={showPanel}
      />

      {showPanel && (
        <ClickAwayListener onClickAway={togglePanel}>
          <div className={classes.root} id={id}>
            <Paper className={classes.paper} elevation={5}>
              {chipData[CELL]?.length
                ? renderFilters(filterBy, chipData[CELL], CELL)
                : null}

              {chipData[EXCLUDE]?.length
                ? renderFilters(exclude, chipData[EXCLUDE], EXCLUDE)
                : null}

              {chipData[INCLUDE]?.length
                ? renderFilters(include, chipData[INCLUDE], INCLUDE)
                : null}
            </Paper>
          </div>
        </ClickAwayListener>
      )}
    </>
  );
};

export default FilterPanel;

FilterPanel.propTypes = {
  id: PropTypes.string.isRequired,
  filters: PropTypes.array,
  filterLabels: PropTypes.exact({
    filters: PropTypes.string,
    filterBy: PropTypes.string,
    include: PropTypes.string,
    exclude: PropTypes.string,
  }),
  onFilterRemove: PropTypes.func.isRequired,
  clearChipLabel: PropTypes.string.isRequired,
};
