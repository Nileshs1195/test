import {
  MenuItem,
  Popover,
  Table as MuiTable,
  TableBody as MuiTableBody,
  TableCell,
  TableContainer,
  TableHead as MuiTableHead,
  TableRow,
  Typography,
} from "@material-ui/core";
import { ArrowDropDown, ErrorOutline } from "@material-ui/icons";
import clsx from "clsx";
import { useCallback, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { SETTINGS } from "../../appsettings";
import { Checkbox, Loader } from "../../components/ui";
import { convertUTCDateToLocalDate } from "../../utils/dateformatter";
import { commaSeparateNumber } from "../../utils/numberformatter";
import { useStyles } from "./style";
import TableFilter from "./tablefilter";

const { MIN_COL_WIDTH } = SETTINGS.GRID;

const setRowStyle = (row) => {
  const cells = row.querySelectorAll("[data-sticky='true']");
  let width = 0;
  cells.forEach((cell) => {
    cell.style.left = `${width}px`;
    const rect = cell.getBoundingClientRect();
    width += rect.width;
  });
};

export const Table = (props) => {
  const classes = useStyles();
  const containerRef = useRef();
  const { t } = useTranslation();
  const { loading, className, hideNoContent } = props;

  const setFixedWrapperStyle = () => {
    const container = containerRef.current;
    const tBody = container.getElementsByTagName("tbody")[0];
    const tHead = container.getElementsByTagName("thead")[0];
    const fixedContent = container.querySelectorAll("[data-fixed='true']")[0];
    const tHeadRect = tHead.getBoundingClientRect();
    const tBodyRect = tBody.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();

    const contentStyle = fixedContent.style;
    contentStyle.top = `${tBodyRect.top}px`;
    contentStyle.width = `${containerRect.width}px`;
    contentStyle.height = `${container.clientHeight - tHeadRect.height}px`;
  };

  useEffect(() => {
    setFixedWrapperStyle();
    window.addEventListener("resize", setFixedWrapperStyle);
    return () => {
      window.removeEventListener("resize", setFixedWrapperStyle);
    };
  }, [containerRef, loading]);

  const renderLoader = () => {
    return loading && <Loader size={24} />;
  };

  const renderNoContentLabel = () => {
    return (
      !loading && (
        <div className={classes.noContent}>
          <span>
            <ErrorOutline fontSize="large" className={classes.warningIcon} />
          </span>
          <span className={classes.noContentLabel}>
            {t("components.basic-table.no-content")}
          </span>
        </div>
      )
    );
  };

  const showFixedWrapper = () => {
    if (containerRef.current) {
      const container = containerRef.current;
      const tBody = container.getElementsByTagName("tbody")[0];
      return loading || tBody.children.length === 0;
    }

    return false;
  };

  return (
    <TableContainer ref={containerRef} className={className}>
      <div
        data-fixed={true}
        className={clsx(
          (hideNoContent || !showFixedWrapper()) && classes.displayNone,
          classes.fixedWrapper
        )}
      >
        {renderLoader()}
        {renderNoContentLabel()}
      </div>
      <MuiTable className={classes.table}>{props.children}</MuiTable>
    </TableContainer>
  );
};

export const Tr = ({ children, ...props }) => (
  <TableRow {...props}>{children}</TableRow>
);

export const Td = ({ children, className, ...props }) => {
  const classes = useStyles();
  return (
    <TableCell {...props} className={clsx(classes.tableBodyCell, className)}>
      {children}
    </TableCell>
  );
};

export const EmptyColumn = ({ totalColumns, minColLength = 15 }) => {
  if (totalColumns < minColLength) {
    return <Td style={{ width: "100%" }} />;
  }
  return null;
};

export const BodyCellContent = ({
  content,
  onDropdownClick,
  columnId,
  filterCells,
  type,
  headCell,
  className,
  ...props
}) => {
  const classes = useStyles();

  const handleDropdown = (event) => {
    onDropdownClick(event.currentTarget, content, columnId);
  };

  let columnContent = "";

  switch (type) {
    case "number":
      columnContent = headCell.excludeFormatting
        ? content
        : commaSeparateNumber(content ?? "");
      break;
    case "date":
      columnContent = convertUTCDateToLocalDate(content);
      break;
    case "boolean":
      columnContent = headCell.customLabel
        ? headCell.customLabel[content].label
        : content;
      break;
    default:
      columnContent = content;
  }

  return (
    <div className={classes.cellWrapper}>
      <Typography
        {...props}
        noWrap
        variant="body2"
        className={clsx(classes.tablebodyContent, className)}
      >
        {columnContent}
      </Typography>
      {filterCells && (
        <ArrowDropDown
          fontSize="small"
          className={classes.dropIcon}
          onClick={handleDropdown}
        />
      )}
    </div>
  );
};

export const CellFilterMenu = ({ anchorEl, onItemClick, ...props }) => {
  return (
    <Popover
      {...props}
      open={Boolean(anchorEl)}
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "right",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      PaperProps={{
        elevation: 2,
      }}
    >
      <MenuItem onClick={() => onItemClick("include")}>Exclude Others</MenuItem>
      <MenuItem onClick={() => onItemClick("exclude")}>Exclude this</MenuItem>
    </Popover>
  );
};

export const TableHead = (props) => {
  const { t } = useTranslation();
  const classes = useStyles();
  const columnWidth = useRef({});
  let pageX, curCol, curColWidth;
  const headRowRef = useRef(null);
  const {
    id,
    headerData,
    rowCount,
    onAllRowSelected,
    selectedRowCount,
    onFilterApplyClick,
    filters,
    sort,
    hideFilter,
    resize,
    onInteraction,
    colWidth,
    noEmptyColumn,
  } = props;

  useEffect(() => {
    setRowStyle(headRowRef.current);
    if (resize) {
      const columns = headRowRef.current.querySelectorAll("th");
      if (columns.length && colWidth) {
        for (let i = 0; i < headerData.length; i++) {
          if (!headerData[i].isSticky) {
            let width = null;
            width = colWidth[headerData[i].key] ?? MIN_COL_WIDTH;
            const padding = paddingDiff(headRowRef.current.children[i]);
            const paddingDiffWidth = width - padding;
            headRowRef.current.children[
              i
            ].children[1].style.width = `${paddingDiffWidth}px`;
            //setting style for headers
            columnWidth.current[headerData[i].key] = width;
            const rows =
              headRowRef.current.parentNode.nextSibling.querySelectorAll("tr");
            for (let j = 0; j < rows.length; j++) {
              if (rows[j] && rows[j].children) {
                rows[j].children[
                  i
                ].children[0].style.width = `${paddingDiffWidth}px`;
              }
            }
          }
        }
      }
    }
  }, [headerData, colWidth]);

  const renderHeaderCell = (headCell, filter) => {
    return (
      <div className={classes.headerContainer}>
        <div className={classes.textStyle} id={`${id}-${headCell.key}`}>
          {t(headCell.text)}
        </div>
        <div
          className={clsx(classes.filterWrapper, hideFilter && classes.hidden)}
        >
          {!hideFilter && (
            <TableFilter
              id={id}
              columnDefnition={headCell}
              filter={filter}
              onFilterApplyClick={onFilterApplyClick}
              sortPriority={
                sort
                  ? sort.findIndex(
                      (item) =>
                        item.isColumnLocked && item.field === headCell.key
                    ) + 1
                  : 0
              }
              sortOrder={
                sort !== undefined &&
                sort.find((item) => item.field === headCell.key) !== undefined
                  ? sort.find((item) => item.field === headCell.key).asc
                  : undefined
              }
              lock={
                sort
                  ? sort.some(
                      (item) =>
                        item.isColumnLocked && item.field === headCell.key
                    )
                  : false
              }
            />
          )}
        </div>
      </div>
    );
  };

  const renderHandle = () => (
    <div className={classes.resizeWrapper} onMouseDown={handleMouseDown}>
      <div className={classes.resizer} />
    </div>
  );

  const handleMouseDown = (e) => {
    curCol = e.target.parentElement;
    pageX = e.pageX;
    curColWidth = curCol.offsetWidth;
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
  };

  const handleMouseMove = (e) => {
    if (curCol) {
      let diffX = e.pageX - pageX;
      const currentColumn = headerData[curCol.cellIndex].key;
      const newWidth = Math.max(MIN_COL_WIDTH, curColWidth + diffX);
      const paddingDiffWidth = newWidth - paddingDiff(curCol);
      curCol.children[1].style.width = `${paddingDiffWidth}px`;
      const rows =
        headRowRef.current.parentNode.nextSibling.querySelectorAll("tr");
      for (let i = 0; i < rows.length; i++) {
        if (rows[i] && rows[i].children) {
          rows[i].children[
            curCol.cellIndex
          ].children[0].style.width = `${paddingDiffWidth}px`;
        }
      }
      columnWidth.current[currentColumn] = newWidth;
    }
  };

  const handleMouseUp = (e) => {
    const currentColumn = headerData[curCol.cellIndex].key;
    onInteraction && onInteraction(currentColumn, columnWidth.current);
    curCol = undefined;
    pageX = undefined;
    curColWidth = undefined;
    window.removeEventListener("mousemove", handleMouseMove);
    window.removeEventListener("mouseup", handleMouseUp);
  };

  const paddingDiff = (col) => {
    let padLeft = getStyleVal(col, "padding-left");
    let padRight = getStyleVal(col, "padding-right");
    return parseFloat(padLeft) + parseFloat(padRight);
  };

  const getStyleVal = (elm, css) => {
    return window.getComputedStyle(elm, null).getPropertyValue(css);
  };

  return (
    <MuiTableHead>
      <TableRow ref={headRowRef}>
        {headerData.map((headCell) => {
          let toRender = null;
          switch (headCell.type) {
            case "checkbox":
              toRender = (
                <Checkbox
                  id={`${id}-select-all`}
                  color="primary"
                  checked={rowCount > 0 && selectedRowCount === rowCount}
                  onChange={onAllRowSelected}
                  classes={{ root: classes.checkbox }}
                />
              );
              break;
            default:
              toRender = renderHeaderCell(
                headCell,
                filters !== undefined
                  ? filters.find((item) => item.field === headCell.key)
                  : null
              );
              break;
          }
          return (
            <TableCell
              className={clsx(headCell.isSticky && classes.stickyHeader)}
              data-sticky={headCell.isSticky}
              key={headCell.key}
            >
              {resize && !headCell.isSticky && renderHandle()}
              {toRender}
            </TableCell>
          );
        })}
        {!noEmptyColumn && <EmptyColumn totalColumns={headerData.length} />}
      </TableRow>
    </MuiTableHead>
  );
};

export const TableBody = (props) => {
  const classes = useStyles();
  const tbodyRef = useRef();
  const {
    headerData,
    bodyData,
    onRowSelect,
    customRows,
    filterCells,
    onCellFilter,
    noEmptyColumn,
    id,
  } = props;
  const [anchorEl, setAnchorEl] = useState(null);
  const columnToFilter = useRef();

  useEffect(() => {
    const dataRows = tbodyRef.current.querySelectorAll("tr");
    dataRows.forEach((row) => {
      setRowStyle(row);
    });
  }, [bodyData, bodyData?.length]);

  const handleDropdown = useCallback((element, value, field) => {
    setAnchorEl(element);
    columnToFilter.current = { value, field };
  }, []);

  const onCellFilterItemClick = (filterType) => {
    onCellFilter(filterType, columnToFilter.current);
    setAnchorEl(null);
  };

  const handleClose = () => setAnchorEl(null);

  return (
    <MuiTableBody ref={tbodyRef}>
      {anchorEl && (
        <CellFilterMenu
          anchorEl={anchorEl}
          onClose={handleClose}
          onItemClick={onCellFilterItemClick}
        />
      )}
      {customRows?.length
        ? customRows
        : bodyData?.map((row, index) => {
            const labelId = `enhanced-table-checkbox-${index}`;
            return (
              <TableRow
                hover
                role="checkbox"
                tabIndex={-1}
                key={row._id}
                aria-checked={row.selected}
                selected={row.selected}
              >
                {headerData.map((headCell) => {
                  let toRender = null;
                  switch (headCell.type) {
                    case "checkbox":
                      toRender = (
                        <Checkbox
                          color="primary"
                          checked={row.selected}
                          onChange={(event) => onRowSelect(event, row._id)}
                          inputProps={{ "aria-labelledby": labelId }}
                          classes={{ root: classes.checkbox }}
                        />
                      );
                      break;
                    case "date":
                      toRender = (
                        <BodyCellContent
                          type="date"
                          filterCells={filterCells}
                          columnId={headCell.key}
                          content={row[headCell.key]}
                          onDropdownClick={handleDropdown}
                        />
                      );
                      break;
                    case "number":
                      toRender = (
                        <BodyCellContent
                          type="number"
                          headCell={headCell}
                          filterCells={filterCells}
                          columnId={headCell.key}
                          content={row[headCell.key]}
                          onDropdownClick={handleDropdown}
                        />
                      );
                      break;
                    case "boolean":
                      toRender = (
                        <BodyCellContent
                          type="boolean"
                          headCell={headCell}
                          filterCells={filterCells}
                          columnId={headCell.key}
                          content={row[headCell.key]}
                          onDropdownClick={handleDropdown}
                        />
                      );
                      break;
                    default:
                      toRender = (
                        <BodyCellContent
                          filterCells={filterCells}
                          columnId={headCell.key}
                          content={row[headCell.key]}
                          onDropdownClick={handleDropdown}
                        />
                      );
                      break;
                  }

                  return (
                    <Td
                      data-sticky={headCell.isSticky}
                      className={clsx(headCell.isSticky && classes.stickyCell)}
                      key={`${row._id}-${headCell.key}`}
                    >
                      {toRender}
                    </Td>
                  );
                })}
                {!noEmptyColumn && (
                  <EmptyColumn totalColumns={headerData.length} />
                )}
              </TableRow>
            );
          })}
    </MuiTableBody>
  );
};
