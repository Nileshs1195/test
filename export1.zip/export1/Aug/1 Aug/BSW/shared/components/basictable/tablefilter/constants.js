export const FILTER_DEFAULT_VALUE = {
  exclude: false,
  field: "",
  operator: "",
  valueFirst: "",
  valueSecond: "",
  saveFilter: false,
};
export const FIELD_TYPE = {
  BOOLEAN: "boolean",
  DATE: "date",
  NUMBER: "number",
};

export const FILTER_OPERATOR = {
  BETWEEN: "between",
};

export const DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

export const INITIAL_BOOL_STATE = {
  trueValue: false,
  falseValue: false,
};
