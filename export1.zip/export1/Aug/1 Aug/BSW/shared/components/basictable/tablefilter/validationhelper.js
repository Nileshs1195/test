import { FIELD_TYPE, FILTER_OPERATOR, INITIAL_BOOL_STATE } from "./constants";

export const validate = (columnDefnition, values) => {
  const IS_NUMERIC_REGEX = /^[0-9]\d*\.?\d*$/;
  let validationResults = {
    exclude: false,
    field: true,
    operator: true,
    valueFirst: true,
    valueSecond: true,
    valueDate: true,
  };
  if (values.operator !== "") {
    if (columnDefnition.type === FIELD_TYPE.NUMBER) {
      if (values.operator === FILTER_OPERATOR.BETWEEN) {
        if (
          values.valueFirst !== "" &&
          !IS_NUMERIC_REGEX.test(values.valueFirst)
        ) {
          validationResults.valueFirst = false;
        }
        if (
          values.valueSecond !== "" &&
          !IS_NUMERIC_REGEX.test(values.valueSecond)
        ) {
          validationResults.valueSecond = false;
        } else if (Number(values.valueFirst) >= Number(values.valueSecond)) {
          validationResults.valueSecond = false;
        }
        if (values.valueSecond === "") {
          validationResults.valueSecond = false;
        }
      }
      if (
        values.valueFirst === "" ||
        !IS_NUMERIC_REGEX.test(values.valueFirst)
      ) {
        validationResults.valueFirst = false;
      }
    } else if (columnDefnition.type === FIELD_TYPE.DATE) {
      if (
        values.operator === FILTER_OPERATOR.BETWEEN &&
        values.valueFirst > values.valueSecond
      ) {
        validationResults.valueDate = false;
      }
    } else {
      if (values.valueFirst === "") {
        validationResults.valueFirst = false;
      }
    }
  } else {
    if (values.valueFirst !== "") {
      validationResults.operator = false;
    }
  }
  return validationResults;
};

export const checkBoolean = (filter, colDef) => {
  let response = INITIAL_BOOL_STATE;
  if (!Boolean(filter.operator)) return response;

  if (colDef.customLabel?.[filter.valueFirst].value) {
    response = { ...response, trueValue: true };
  } else response = { ...response, falseValue: true };
  return response;
};
