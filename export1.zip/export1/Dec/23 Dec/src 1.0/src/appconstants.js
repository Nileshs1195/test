export const APP_ROUTES = {
  ROOT: "/",
  IMAGE_MANAGEMENT: "/imagemanagement",
  SIGN_IN: "/signIn",
  IMAGE_MANAGEMENT_PAGES: {
    IMAGE_GROUP_LIST: "/imagemanagement/imagegrouplist",
    IMAGE_LIST: "/imagemanagement/imagelist"
  },
  TRAINING_MANAGEMENT_PAGES: {
    TRAINING: "/training",
    SELECTED_TRAINING: "/training/:seqNo?",
    TRAINING_PARAMETER_SETTING: "/training/trainingparametersetting/:id",
    TRAINING_PARAMETER_SETTING_AUGMENTATION: "/training/trainingparametersetting/:id/augmentation",
    TRAINING_PARAMETER_SETTING_SEARCH: "/training/trainingparametersetting/:id/search",
    TRAINING_PARAMETER_SETTING_VIEW_PARAMETER: "/training/trainingparametersetting/:id/view-parameter",
    AUTOMATIC_PARAMETER_SEARCH: "/training/trainingparametersetting/:id/train-parameter-search/:seqNo?",
    AUTOMATIC_PARAMETER_SEARCH_VIEW: "/training/trainingparametersetting/:id/view-parameter-search/:seqNo?",
    IMAGE_LIST: "/training/trainingparametersetting/:id/image-list/:classes?",
    IMAGELIST: "/training/trainingparametersetting/:id/image-list/:classes?",
    MASKINGLIST: "/training/trainingparametersetting/:id/masking-list/:classes",
    PARAMETER_IMAGE_LIST: "/training/trainingparametersetting/:id/view-parameter/image-list/:classes",
    SUB_CLASIFICATION: "/training/trainingparametersetting/:id/subclasification/:classes?",
    SUB_CLASIFICATION_EXECUTION: "/training/trainingparametersetting/:id/subclasification-execution-log/:seqNo?",
    MASKING_EXECUTION: "/training/trainingparametersetting/:id/masking-execution-log/:seqNo/:classes?",
    TRAIN_PARAMETER_EXECUTION_LOG: "/training/trainingparametersetting/:id/train-parameter/execution-log/:seqNo?",
    SUGGESTION_RESULT_DISPLAY_AND_FIX: "/training/trainingparametersetting/:id/subclasification-suggestion-result/:batchNo/:classes?",
    SUGGESTION_RESULT_FIX: "/training/trainingparametersetting/:id/suggestion-fix/:batchNo",
    CORRECTION_RESULT_DISPLAY: "/training/trainingparametersetting/:id/:seqNo/correction-result/:classes",
    ADVISOR: "/training/trainingparametersetting/:id/advisor/:seqNo",
    MASKINGLIST: "/training/trainingparametersetting/:id/masking-list/:classes",
    DEFECT_MASK_CONFIRMATION: "/training/trainingparametersetting/:id/defect-mask-confirmation/:batchSeqNo/:classes"
  },
  CLASSIFICATION_MANAGEMENT_PAGES: {
    CLASSIFICATION_TEST: "/classification-test",
    TESTING_SETTINGS: "/classification-test/testing-settings/:id",
    CONFUSION_MATRIX: "/classification-test/:id/confusion-matrix/:batchSeqNo",
    TESTING_EXECUTION: "/classification-test/testing-settings/:id/testing-execution-log/:seqNo",
    CLASSIFICATION_TEST_IMAGES: "/classification-test/confusion-matrix/:id/image-list/:seqNo?",
    DISPLAY_ADVISOR: "/classification-test/confusion-matrix/:id/:batchSeqNo/advisor"
  }
};

export const IMAGE_MANAGEMENT_TABS = {
  IMAGE_GROUP: 0,
  IMAGE_LIST: 1
};

export const API_URL = {
  IMAGE_GROUP_DATA: "api/image-group",
  FILTER_PREFERENCEDATA: "api/user/preference",
  USER_COLUMN_PREFERENCE: "api/user/preference/",
  EDIT_GROUP_NAME: "api/image-group/{id}",
  GROUP_RECORD: "api/image-group",
  IMAGE_RECORD: "api/image-collection",
  CREATE_DATASET: "api/training/dataset",
  DATASET_LIST: "api/training/{id}/dataset",
  DATASET_LIST_WITH_TRAINING: "api/training/{id}/training-dataset",
  EDIT_DATASET: "api/training/{tId}/dataset",
  UPDATE_DATASET_PERCENTAGES: "api/training/{tId}/update-trainpercentage",
  TRAINING_LIST_DATA: "api/training/list",
  IMAGE_DETAILS: "api/image-group/imagelist/{id}",
  EDIT_TRAINING_RECORD: "/api/training/list/{id}",
  TRAIN_PARAMS: "api/training/{id}/params",
  TRAIN_PARAMS_DEVELOPER: "api/training/{id}/developermode",
  SAVE_IMAGE_DETAILS: "api/training/{id}/image/upload",
  DELETE_DATASET_IMAGES: "/api/training/{tid}/dataset/{seqNo}/image",
  GET_IMAGES_FOR_DATASET: "api/training/{id}/dataset/{seqNo}/image",
  CONVERT_IMAGES: "api/training/{id}/image/{type}",
  DELETE_DATASET: "api/training/{tid}/dataset",
  MASKING_STATUS: "/api/training/{id}/masked-status",
  COPY_PAST_MODAL_DATA: "api/training/{tId}/dataset",
  // GET_PAST_MODAL_LIST: "api/training/list",
  TEMP_CHANGE_TRAINING_STATUS: "api/training/{id}/mode/{mode}",
  AUGMENTATION_MODE: "api/training/{id}/augmentation",
  STOP_EXECUTION: "api/training/{id}/stop-request/{seqNo}",
  GET_BATCH: "api/training/{id}/batch/{seqNo}",
  START_EXECUTION: "api/training/{id}/execute/{mode}",
  EDIT_SUBCLASS_PARAMETER: "api/training/{id}/invariant",
  TRAIN_EXECUTION_LOG: "api/training/{id}/batch/{seqNo}/trainlog",
  SUBCLASSIFICATION_EXECUTION_RESULT: "api/training/{id}/batch/{seqNo}/suggestion-result",
  TRAINING_CLONE: "api/training/{id}/clone",
  DELETE_TRAININGLIST: "api/training/list/{id}",
  DELETE_MULTIPLE_TRAININGLIST: "api/training/list",
  LISTING_EXISTING_MODAL: "api/training/executed/list",
  EXECUTED_DATASET_CLONE: "/api/training/dataset/clone",
  SUGGESTION_RESULT: "api/training/{id}/batch/{seqNo}/suggestion-result",
  SUGESSTION_IMAGES: "api/training/{id}/dataset/{seqNo}/suggestion-images",
  CORRECTION_IMAGES: "api/training/{id}/dataset/{seqNo}/correction-images",
  SUGGESTION_CLASS_UPDATE: "api/training/{id}/dataset/{seqNo}/class-update",
  DATASET_CLASS_CREATE: "api/training/{id}/dataset/class-create",
  SUGGESTION_RESULT_CLASS_CREATE: "api/training/{id}/classification/class-create",
  SUGGESTION_CLASS_GRAPH_DATA: "api/training/{id}/dataset/{seqNo}/graph-details",
  SUGGESTION_RESULT_FIX_SUBMIT: "api/training/{id}/{seqNo}/suggestion-submit",
  CLASSIFICATION_DATASET: "api/training/{id}/classification-dataset/{seqNo}",
  GET_SUGGESTION_RESULT_PROBABILITY_GRAPH: "api/training/{id}/dataset/{seqNo}/graph-details",
  SUGGESTION_RESULT_IMAGE_MOVE: "api/training/{id}/image-move",
  TESTING_LIST: "/api/testing/list",
  EDIT_DELETE_TESTINGLIST: "/api/testing/list/{id}",
  COPY_AND_REEXECUTE_TEST: "api/testing/{id}/testing-copy-execute",
  EDIT_DELETE_MULTIPLE_TESTINGLIST: "/api/testing/list",
  TEST_DATASET: "api/testing/{id}/dataset",
  SAVE_TEST_IMAGE_DETAILS: "api/testing/{id}/image/upload",
  DISPLAY_ADVISOR: "/api/training/{id}/advisor/{seqNo}",
  LOG_IMAGE_URL: "api/batch/{seqNo}/train-log/{fileName}",
  CONFUSION_MATRIX: "api/testing/{id}/confussion-matrix/list",
  CONFUSION_MATRIX_IMAGE_LIST: "api/testing/{id}/confussion-matrix",
  GET_TESTING_BATCH: "api/testing/{id}/batch/{seqNo}",
  ACCURACY_LOSS_IMAGES: "api/batch/{seqNo}/train-log/100_accuracy.png",
  EXECUTE_MODE: "/api/testing/{id}/execute/testing",
  SAVE_TEST_MODEL: "/api/testing/{id}/pre-model-update",
  SET_CONFUSION_MATRIX_NEW_CLASS: "/api/testing/{id}/move-images-to-class",
  HEATMAP_IMAGE: "api/testing/{id}/batch/{seqNo}/heat-map-image/{fileName}",
  UPDATE_MASKING: "api/training/{id}/coordinates",
  EXECUTE_MASKING: "api/training/{id}/execute/masking",
  MASKING_RESULT: "api/training/{id}/{seqNo}/masking-images",
  MASKING_AI_IMAGE: "api/training/{id}/{bacthSeqNo}/{className}/masked-image/{fileName}",
  STOP_TESTING_EXECUTION: "/api/testing/{id}/stop-request/{seqNo}"
};

export const IMAGE_GROUP_LIST = {
  PAGINATION: {
    // total space is 12. so to get columns divide 12
    // eg - 12/4 = 3 columns
    PAGE_SIZES: [
      { value: 8, label: 2, gridSize: 6, waferSize: 450 },
      { value: 12, label: 3, gridSize: 4, waferSize: 330 },
      { value: 16, label: 4, gridSize: 3, waferSize: 270 }
    ],
    DEFAULT: { value: 12, label: 3, gridSize: 4, waferSize: 330 }
  },
  SORT_DIRECTION: {
    ASCENDING: "Ascending",
    DESCENDING: "Descending"
  }
};

export const WAFER = {
  DEFAULT_SIZE: 340,
  EDGE_MARGIN: 0,
  NOTCH_SIZE: 0,
  ZOOM_FACTOR: 0.5,
  DEFECT_SIZE_SCALE: 2,
  SELECTED_DEFECT_OFFSET: 2,
  WAFER_SCRIBE_LINE_OPACITY: 0.3,
  SELECTED_DEFECT_COLOR: 0xff4040,
  SELECTED_DEFECT_OUTLINE_COLOR: 0x5c5cfc,
  DIE_FILL_COLOR: 0xffffff,
  ZOOM_SCALE: {
    IN: 1.6,
    OUT: 0.6
  },
  MAX_SCALE: 64,
  MIN_SCALE: 2,
  SELECTION_RECT_BORDER: 0xff0000
};

export const GRAPH = {
  AXIS_LINE_COLOR: "#0000001f",
  AXIS_LINE_WIDTH: 1
};

export const API_RESPONSE = {
  SUCCESS_STATUS_CODE: 200
};

//application menu list
export const APPMENULIST = [
  {
    title: "Training",
    shortName: "TR",
    url: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING
  },
  {
    title: "Classification Test",
    shortName: "CT",
    url: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST
  }
];
