import { WAFER } from "./appconstants";

const API_URL = window._env_.API_URL; //this will be invoked from external config

export const SETTINGS = {
    I18N: {
        LANGUAGES: {
            EN: "en",
            JP: "jp",
        },
        DEFAULT_LANG: "en",
    },
    DATE_TIME_FORMAT: "yyyy/MM/dd HH:mm:ss",
    BASE_API_URL: API_URL,
    IMAGE_THUMBNAIL_URL: API_URL + "api/image/",
    IMAGE_FULL_URL: API_URL + "api/image/full-view/",
    SOCKET_URL: API_URL,
    API_CONFIG: {
        TIMEOUT: 0,
    },
    EXECUTION_TIMEOUT: window._env_.EXEC_TIMEOUT || (1000 * 60 * 60),
    INSPECTION_GRID: {
        DATE_OFFSET: 30,
    },
    GRID: {
        PAGINATION: {
            DIRECTIONS: {
                PREV: "prev",
                NEXT: "next",
            },
            PAGE_SIZES: [
                { value: 25, label: 25 },
                { value: 50, label: 50 },
                { value: 75, label: 75 },
                { value: 100, label: 100 },
            ],
        },
    },
    DEFECT_IMAGE_INDEX: 1,
    LOCAL_STORAGE_KEYS: {
        I18N: "i18nextLng",
        INSPECTION_LIST_SORT_DATA: "inspectionGridSortData",
        SHOW_WAFER_SCALE: "showWaferScale",
    },
    IMAGE_LIST: {
        ITEM_PER_PAGE: 12,
    },
};