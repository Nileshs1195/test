import { APP_ROUTES } from "../appconstants";
import { Switch, Route } from "react-router-dom";
import TrainingList from "../pages/training/traininglist";
import TrainingParameterSetting from "../pages/training/training-parameter-setting";
import SignIn from "../shared/pages/signIn";
import AutomaticParameterSearch from "../pages/training/training-parameter-setting/train-parameter/train-parameter-search/AutomaticParameterSearch";
import ExecutionLog from "../pages/training/training-parameter-setting/train-parameter/train-execution-log/ExecutionLog";
import SuggestionResultDisplayAndFix from "../pages/training/suggestionresultdisplayfix/suggestionresultdisplayfix";
import SuggestionResultFix from "../pages/training/suggestion-fix";
import CorrectionResultDisplay from "../pages/training/correctionresultdisplay";
import Advisor from "../pages/training/training-parameter-setting/train-parameter/display-advisor";
import TestingList from "../pages/classificationtest/testingList";
import TestingSettings from "../pages/classificationtest/testingsettings/testingsettings";
import ProgressBarTest from "../pages/classificationtest/testingsettings/executeTest/progressBarTest";
import ConfusionMatrix from "../pages/classificationtest/confusionMatrixComponent/confusionMatrixComponent";
import ClassificationTestImages from "../pages/classificationtest/images/ClassificationTestImages";
import Masking from "../pages/training/training-parameter-setting/masking";
import DefectMaskConfirmation from "../pages/training/training-parameter-setting/defectMaskConfirmation/defectMaskConfirmation";
import DisplayAdvisor from "../pages/classificationtest/confusionMatrixComponent/display-advisor";
import MaskingProgressBar from "../pages/training/training-parameter-setting/masking/executionLog/progressBar";
const Routes = () => {
  return (
    <Switch>
      {/* TRAINIG ROUTES */}
      <Route exact path="/" component={TrainingList} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING} component={TrainingList} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SELECTED_TRAINING} component={TrainingList} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH} component={AutomaticParameterSearch} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH_VIEW} component={AutomaticParameterSearch} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_AUGMENTATION} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_SEARCH} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.SIGN_IN} component={SignIn} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST} component={TrainingParameterSetting} />
      {/* <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGELIST} component={TrainingParameterSetting} /> */}
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.PARAMETER_IMAGE_LIST} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION} component={TrainingParameterSetting} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG} component={ExecutionLog} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX} component={SuggestionResultDisplayAndFix} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_FIX} component={SuggestionResultFix} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.CORRECTION_RESULT_DISPLAY} component={CorrectionResultDisplay} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.ADVISOR} component={Advisor} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKINGLIST} component={Masking} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.DEFECT_MASK_CONFIRMATION} component={DefectMaskConfirmation} />
      <Route exact path={APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKING_EXECUTION} component={MaskingProgressBar} />
      {/* CLASSIFICATION TEST ROUTES */}
      <Route exact path={APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST} component={TestingList} />
      <Route exact path={APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS} component={TestingSettings} />
      <Route exact path={APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CONFUSION_MATRIX} component={ConfusionMatrix} />
      <Route exact path={APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_EXECUTION} component={ProgressBarTest} />
      <Route exact path={APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST_IMAGES} component={ClassificationTestImages} />
      <Route exact path={APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.DISPLAY_ADVISOR} component={DisplayAdvisor}/>
    </Switch>
  );
};

export default Routes;
