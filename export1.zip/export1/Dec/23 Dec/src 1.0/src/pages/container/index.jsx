import { Observer, observer } from "mobx-react-lite";
import { useContext, useState, useEffect } from "react";
import { CssBaseline, Container } from "@material-ui/core";
import SignIn from "../../shared/pages/signIn";
import Routes from "../../routes";
import { useStyles } from "./style";
import UserStore from "../../shared/stores/userstore";
import TrainingManagementStore from "../../stores/trainingmanagementstore";
import AppBarSection from "../../shared/components/appbar";
import AppDrawerSection from "../../components/drawer";
import CustomSnackBar from "../../components/snackbar";
import appstore from "../../stores/appstore";
import ImageUploader from "../../components/imageuploader";
import Loader from "../../components/loader";
import ImageManagementStore from "../../stores/imagemanagementstore";

const AppContainer = observer(() => {
  const classes = useStyles();
  const userStore = useContext(UserStore);
  const appStore = useContext(appstore);
  const { snapbarMessage, loader, loaderMessage } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { uploaderAction, setUploaderAction } = imageManagementStore;
  const [open, setOpen] = useState(true);
  const handleDrawerToggle = () => setOpen(prevState => !prevState);

  const handleFileUploadClose = () => {
    setUploaderAction({ uploaderType: "", isOpen: false, className: "", id: "" });
  };

  return (
    <Observer>
      {() => (
        <div className={classes.root}>
          <CssBaseline />
          <AppBarSection handleDrawerToggle={handleDrawerToggle} open={open} />
          <AppDrawerSection open={open} />

          <main className={classes.content}>
            <div className={classes.appBarSpacer} />
            <Container
              maxWidth="xl"
              classes={{
                root: classes.container,
                maxWidthXl: classes.containerMaxWidth
              }}
            >
              {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
              {loader && <Loader message={loaderMessage} size={24} />}
              <ImageUploader
                reloadCurrentList={() => {
                }}
                isActionDisabled={false}
                uploaderAction={uploaderAction}
                className={uploaderAction?.className}
                handleFileUploadClose={handleFileUploadClose}
              />
              {userStore.currentUser ? <Routes /> : <SignIn />}
            </Container>
          </main>
        </div>
      )}
    </Observer>
  );
});

export default AppContainer;
