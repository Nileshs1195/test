import { Paper, Divider, Button, } from "@material-ui/core";
import { useEffect, useContext, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Observer } from "mobx-react-lite";
import { useStyles } from "./style";
import AppStore from "../../../stores/appstore";
import ImageLists from "../../../components/image-list";
import { API_URL, APP_ROUTES } from "../../../appconstants";
import Pagination from "../../../shared/components/basictable/pagination";
import { arrayMultiSplit } from "../../../helpers/arrayutils";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import BackButton from "../../../components/backbutton";
import { useTranslation } from "react-i18next";
import TestManagementStore from "../../../stores/testManagementStore";

const ClassificationTestImages = () => {
  const history = useHistory();
  const classes = useStyles();
  const params = useParams();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const testManagementStore = useContext(TestManagementStore);
  const [currentClasses, setCurrentClasses] = useState([]);
  const [totalClasses, setTotalClasses] = useState([]);
  const [page, setPage] = useState({
    pageSize: 5,
    pageNo: 1
  });

  useEffect(() => {
    appStore.removeAllBreadcrumbs();
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
      label: "pages.classification-test.testing-list.confusion-matrix.title"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST_IMAGES,
      label: 'pages.classification-test.testing-list.confusion-matrix.image-view.title'
    });
  }, []);

  useEffect(() => {
    getSelectedClasses();
    splitClasses(page);
  }, []);

  const splitClasses = (obj) => {
    if (testManagementStore?.selectedClasses?.length > 0) {
      let pageNo = obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo;
      let selectedClass = arrayMultiSplit(JSON.parse(JSON.stringify(testManagementStore.selectedClasses)), obj?.pageSize);
      setTotalClasses(JSON.parse(JSON.stringify(testManagementStore.selectedClasses)));
      selectedClass?.length > 0 && setCurrentClasses(selectedClass[pageNo]);
    }
  }

  const onPagination = (obj) => {
    setPage(obj);
    splitClasses(obj);
  }

  const getSelectedClasses = () => {
    const selectedData = (JSON.parse(localStorage.getItem("selectedConfusionMatrixClasses")))
    let classes = selectedData.reduce((classList, item) => {
      if (!classList[item.setClassName]) {
        classList[item.setClassName] = [];
      }
      classList[item.setClassName].push(item.actualClassName);
      return classList;
    }, {});
    let tempArray = [];
    for (let x in classes) {
      tempArray.push({ setClass: x, classifiedClasses: classes[x] });
    }
    testManagementStore.setSelectedClasses(tempArray);
  }

  const handleBackButton = () => {
    history.goBack();
  };

  const goToTestResult = () => {
    history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CONFUSION_MATRIX.replace(":id", params.id).replace(":batchSeqNo", params.seqNo));
  }

  return (
    <Observer>
      {() => (
        <Paper className={classes.pageContent}>
          <div className={classes.top}>
            <div className={classes.breadcrumbWraper}>
              <BackButton handleBackButton={handleBackButton} />
              <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
            </div>
            <div className={classes.buttonWrapper}>
              <Button color="primary" variant="contained" onClick={goToTestResult}>
                {t("pages.classification-test.classification-images.controls.back")}
              </Button>
            </div>
          </div>
          <Divider className={classes.divider} />
          <div className={classes.mTop}>
            <Pagination
              onChange={onPagination}
              itemCount={totalClasses.length}
              pageNo={page.pageNo + 1}
              pageSize={page.pageSize}
              disableItemPerPage={true}
              disabled={false}
            />
          </div>
          {
            currentClasses?.length > 0 && currentClasses.map((item, index) => {
              return <ImageLists
                url={API_URL.CONFUSION_MATRIX_IMAGE_LIST}
                key={"image-" + index}
                classData={item}
                expand={false}
                order={{ asc: "probability" }}
                imageSelection={false}
                imageType={"all"}
                showAddImage={false}
                showDeleteImage={false}
                showEditClass={false}
                carouselView={true}
                dropdown={true}
                classificationTest={true}
              />
            })
          }
        </Paper>
      )}
    </Observer>
  );
}

export default ClassificationTestImages;