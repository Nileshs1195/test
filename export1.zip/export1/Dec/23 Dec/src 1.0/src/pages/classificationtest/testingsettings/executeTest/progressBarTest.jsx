import React from "react";
import { useEffect, useContext, useState, useCallback } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Grid, Typography, CircularProgress } from "@material-ui/core";
import BackButton from "../../../../../src/components/backbutton";
import { useStyles } from "./style";
import AppStore from "../../../../../src/stores/appstore";
import { API_RESPONSE, APP_ROUTES } from "../../../../../src/appconstants";
import Breadcrumb from "../../../../../src/shared/components/ui/breadcrumb";
import LinearProgressBar from "../../../../../src/components/linearprogressbar";
import { useTranslation } from "react-i18next";
import TestManagementStore from "../../../../../src/stores/testManagementStore";
import { useParams, useHistory } from "react-router-dom";
import CustomSnackBar from "../../../../components/snackbar";
import CustomConfirmation from "../../../../components/modal/CustomConfirmation";
import { Loader } from "../../../../shared/components/ui";

const ProgressBarTest = () => {
  const classes = useStyles();
  const { t } = useTranslation();
  const history = useHistory();
  const params = useParams();
  const appStore = useContext(AppStore);
  const testManagementStore = useContext(TestManagementStore);
  const [loading, setLoading] = useState(false);
  const { addBreadcrumb, removeLastBreadcrumb } = appStore;
  const [isResultSetVisible, setResultSetVisibility] = useState(false);
  const [batchData, setBatchData] = useState({});
  const [startExecution, setStartExecution] = useState(false);
  const [stopExecution, setStopExecution] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [openModal, setOpenModal] = useState(false);
  const [resultSet, setResultSet] = useState({
    pgr: 0,
    Rate: 0,
    Ploss: 0,
    Closs: 0,
    elptime: 0,
    modelName: "",
    noOfFeatures: 0
  });

  useEffect(() => {
    breadCrumb();
  }, [appStore.addBreadcrumb]);

  useEffect(() => {
    setLoading(true);
    testManagementStore
      .getBatch(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setBatchData(response.data);
          if (response?.data?.mode === "testing") {
            if (response.data.status === "Stop" || response.data.status === "Stopping" || response.data.status === "Stopped") {
              setsnapbarMessage({
                message: t("pages.classification-test.errors.testing-list.execution-cancelled", {
                  type: t("pages.classification-test.errors.testing-list.testing-execution")
                }),
                timeout: 100000
              });
            } else {
              setResultSet({
                baseMode: 2,
                elapsedTime: response?.data?.elapsedTime,
                mode: 2,
                progress: response?.data?.progress,
                status: response?.data?.status === "Ok" ? 7 : response?.data?.status
              });
              setStartExecution(true);
            }
          } else {
            setsnapbarMessage({ message: t("pages.classification-test.errors.testing-list.invalid-execution") });
            setStartExecution(false);
          }
        } else {
          setStartExecution(false);
          setsnapbarMessage({ message: t("pages.classification-test.errors.testing-list.execution-failed") });
        }
      })
      .catch((xhr) => {
        setLoading(false);
        setsnapbarMessage({ message: t("pages.classification-test.errors.testing-list.execution-failed") });
      });
  }, []);

  const breadCrumb = () => {
    appStore.removeAllBreadcrumbs();
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
      label: "pages.classification-test.testing-list.title"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS.replace(":id", params.id),
      label: "pages.classification-test.testing-settings.title"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_EXECUTION,
      label: "pages.classification-test.testing-list.execute-test.title"
    });
  };

  const displayData = () => {
    setResultSetVisibility(true);
    setStartExecution(false);
  };

  const loadConfusionMatrix = () => {
    history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CONFUSION_MATRIX.replace(":id", params.id).replace(":batchSeqNo", params.seqNo))
  };

  const handleBackButton = () => {
    startExecution ? setOpenModal(true) : history.goBack();
  };

  const cancelExecutionLog = async () => {
    setOpenModal(false);
    setLoading(true);
    await testManagementStore
      .stopExecutionLog(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setStopExecution(true);
          history.replace();
          history.goBack();
        } else {
          setsnapbarMessage({
            message: t("pages.classification-test.errors.testing-list.exec-cancel-failed")
          })
        }
      })
      .catch((xhr) => {
        setLoading(false);
        setsnapbarMessage({
          message: t("pages.classification-test.errors.testing-list.exec-cancel-failed")
        })
      });
  };

  return (
    <Observer>
      {() => (
        <div>
          <Paper className={classes.pageContent}>
            {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={!isResultSetVisible || resultSet?.progress < 100 || resultSet?.status !== 7}
                  onClick={loadConfusionMatrix}
                >
                  {resultSet?.progress === 100 && resultSet?.status !== 7 && <><CircularProgress size={18} />&nbsp;</>}
                  {t("pages.training.training-parameter.dataset-mode.controls.confusion-matrix")}
                </Button>
                <Button color="primary" variant="contained" disabled={resultSet?.progress >= 100} onClick={handleBackButton}>
                  {t("pages.training.training-parameter.dataset-mode.controls.cancel")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.mtop}>
              {batchData?.seqNo && (
                <LinearProgressBar
                  setResultSet={setResultSet}
                  stopExecution={stopExecution}
                  displayData={displayData}
                  batchData={batchData}
                  loadingAction={true}
                  method="testing"
                  executionType="testing"
                />
              )}
            </div>

            <CustomConfirmation
              open={openModal}
              onClose={() => setOpenModal(false)}
              onSubmit={cancelExecutionLog}
              title={t("pages.training.input-parameter.modal.confirm-cancel-execution.title")}
              message={t("pages.training.input-parameter.modal.confirm-cancel-execution.text")}
              primary={"pages.training.input-parameter.controls.ok"}
              secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
            />

            {isResultSetVisible && (
              <div>
                <Box m={1} p={1} bgcolor="background.paper" className={classes.resultBox}>
                  <Box p={1} className={classes.boxwidth}>
                    <Paper variant="outlined" className={classes.paperPadd}>
                      {/* <Grid container spacing={1}>
                        <Grid item xs={12} className={classes.textCenter}>
                          <Typography variant="h6" gutterBottom>
                            {t("pages.training.training-parameter.dataset-mode.auto-param-search.result")}
                          </Typography>
                          <Divider />
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t("pages.training.training-parameter.dataset-mode.auto-param-search.num-of-features")}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.noOfFeatures}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>{t("pages.training.training-parameter.dataset-mode.auto-param-search.rate")}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Rate}</div>
                        </Grid>{" "}
                        <Grid item xs={6}>
                          <div className={classes.textRight}>{t("pages.training.training-parameter.dataset-mode.auto-param-search.closs")}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Closs}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>{t("pages.training.training-parameter.dataset-mode.auto-param-search.ploss")}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Ploss}</div>
                        </Grid>
                        <Grid item xs={6} className={classes.space}>
                          <div className={classes.textRight}>{t("pages.training.training-parameter.dataset-mode.auto-param-search.model")}</div>
                        </Grid>
                        <Grid item xs={6} className={classes.space}>
                          <div>: {resultSet.modelName}</div>
                        </Grid>
                        <Grid item xs={12} className={classes.buttonWrapper}>
                          <Button color="primary" variant="contained">
                            {t("pages.training.training-parameter.dataset-mode.controls.run-training")}
                          </Button>
                          <Button color="primary" variant="contained">
                            {t("pages.training.training-parameter.dataset-mode.controls.img-group")}
                          </Button>
                        </Grid>
                      </Grid> */}
                    </Paper>
                  </Box>
                </Box>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default ProgressBarTest;
