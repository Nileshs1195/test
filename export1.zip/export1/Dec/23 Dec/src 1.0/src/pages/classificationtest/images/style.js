import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    minHeight: "calc(100vh - 82px)",
    maxHeight: "auto",
    position: "relative",
    paddingBottom: "68px"
  },
  top: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between"
  },
  breadcrumbWraper: {
    display: "flex"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  mTop: {
    marginTop: theme.spacing(2)
  }
}));
