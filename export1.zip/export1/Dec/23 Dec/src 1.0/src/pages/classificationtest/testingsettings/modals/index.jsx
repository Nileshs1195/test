import React, { useState, useEffect, useContext } from "react";
import { useTranslation } from "react-i18next";
import { useStyles } from "./style";
import { TextField, FormControl } from "@material-ui/core";
import GridMaterial from "@material-ui/core/Grid";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import { validateModalForm, validateString, validateDigits } from "../../../../helpers/CommonMethods";
import CustomConfirmation from "../../../../components/modal/CustomConfirmation";
import TestManagementStore from "./../../../../stores/testManagementStore";

const ModalComponent = (props) => {
  const { action, setModalActive, handleAPICall, disableAddButton, handleFileUploadOpen } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const testManagementStore = useContext(TestManagementStore);
  const [isDataSetModalOpen, toggoleDataSetModal] = useState(false);
  const [modal_title, setModalTitle] = useState("");
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [buttonKeys, setButtonKeys] = useState({
    primaryButtonText: "",
    secondaryButtonText: "pages.training.training-parameter.dataset-mode.controls.cancel"
  });
  const [datasetRecord, setDatasetRecord] = useState({
    className: ""
  });

  useEffect(() => {
    if (action.isOpen) {
      handleDataSetModal(action.actionName);
    }
  }, [action]);

  const handleDataSetModal = (actionParam) => {
    switch (actionParam) {
      case "EDIT":
        if (testManagementStore.selectedTestDataset?.[0]) {
          setModalFormErrors({});
          const editData = {
            className: testManagementStore.selectedTestDataset[0].className
          };
          setDatasetRecord(editData);
          setModalDetails(
            t("pages.training.training-parameter.dataset-mode.modal.edit"),
            "pages.training.training-parameter.dataset-mode.controls.save"
          );
        }
        break;
      case "DELETE":
        setModalDetails(
          t("pages.training.training-parameter.dataset-mode.modal.delete"),
          "pages.training.training-parameter.dataset-mode.controls.delete"
        );
        break;
      case "CLOSE":
        setModalActive();
        // disableAddButton(false);
        trainingManagementStore.clearSelectedTrainingDataset();
        toggoleDataSetModal((isOpen) => !isOpen);
        break;
      case "PAST-MODEL":
        setModalDetails(
          "Select Past Execution Model",
          "OK"
        );
        break;
      default:
    }
  };

  const setModalDetails = (title, primaryText) => {
    setModalTitle(title);
    setButtonKeys((prevState) => ({
      ...prevState,
      primaryButtonText: primaryText
    }));
    toggoleDataSetModal((isOpen) => !isOpen);
  };

  const renderEditDataset = () => {
    return (
      <form autoComplete="off">
        <GridMaterial container spacing={2}>
          <GridMaterial item xs={12}>
            <FormControl className={classes.formControl} margin="none">
              <TextField
                id="className"
                name="className"
                label={t("pages.training.training-parameter.dataset-mode.modal.className")}
                value={datasetRecord.className} autoFocus
                onChange={onChangeFieldData}
                error={modalFormErrors["className"]}
                helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
              />
            </FormControl>
          </GridMaterial>
        </GridMaterial>
      </form>
    );
  };

  const renderDeleteDataset = () => {
    return <div className={classes.fontsize}>{t("pages.training.training-parameter.dataset-mode.modal.deleteMsg")}</div>;
  };

  const onChangeFieldData = (event) => {
    const { name, value } = event.target;
    const fieldName = name;
    const fieldError = `${name}ErrorMsg`;
    let isValidDigit = validateDigits(value);
    let isValidString = validateString(value);

    handleDataset(fieldName, value);

    if (value.length > 0) {
      if (fieldName === "className" && isValidString) {
        handleModalFormErrors({
          [fieldName]: false,
          [fieldError]: ""
        });
      } else {
        handleModalFormErrors({
          [fieldName]: true,
          [fieldError]: t("pages.training.errors.modal-errors.alphanumeric")
        });
      }
    } else {
      handleModalFormErrors({
        [fieldName]: false,
        [fieldError]: ""
      });
    }
  };

  const handleDataset = (name, value) => {
    setDatasetRecord((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleModalFormErrors = (data) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, data));
  };

  const editDatasetRecord = () => {
    var data = {
      className: datasetRecord.className
    };

    let isValid = handleValidation(data);
    if (testManagementStore.testDataset && data.className) {
      let duplicateClass = false;
      testManagementStore.testDataset.forEach((testDataset) => {
        if (testDataset.className === data.className) {
          duplicateClass = true;
        }
      });
      if (duplicateClass) {
        setModalFormErrors({
          className: true,
          classNameErrorMsg: "Class name already exist, please try another"
        });
        isValid = false;
      }
    }
    if (isValid) {
      handleAPICall(action.actionName, data);
    } else {
      toggoleDataSetModal((isOpen) => !isOpen);
    }
  };

  const handleValidation = (data) => {
    let errorMessage = t("pages.training.training-list.modal.error-text");
    console.log("data ===>", data, modalFormErrors, errorMessage);
    let status = validateModalForm(data, modalFormErrors, errorMessage, handleModalFormErrors);
    return status;
  };

  const renderData = () => {
    let data;
    switch (action.actionName) {
      case "EDIT":
        data = renderEditDataset();
        break;
      case "DELETE":
        data = renderDeleteDataset();
        break;
      default:
        break;
    }
    return data;
  };

  const handleSubmitActions = (actionParam) => {
    switch (actionParam) {
      case "EDIT":
        editDatasetRecord();
        break;
      case "DELETE":
        handleAPICall(action.actionName);
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CustomConfirmation
        showControls
        widthClass={classes.confirmationModalWidth}
        open={isDataSetModalOpen}
        onClose={() => handleDataSetModal("CLOSE")}
        onSubmit={() => handleSubmitActions(action.actionName)}
        primary={buttonKeys.primaryButtonText}
        secondary={buttonKeys.secondaryButtonText}
        title={modal_title}
        message={renderData()}
      />
    </div>
  );
};

export default ModalComponent;
