import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%"
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  controlContainer: {
    display: "flex",
    alignItems: "center",
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2)
  },
  formControl: {
    display:'flex',
    marginTop:-32,
    width: "200px",
    // marginLeft: "350px",
  },
  tableContainer: {
    height: "calc(100vh - 237px)"
  },
  tableContainerFooter: {
    height: "calc(100vh - 286px)"
  },
  footerContainer: {
    justifyContent: "space-between",
    backgroundColor: theme.palette.primary.main,
    display: "flex",
    paddingTop: 3,
    paddingBottom: 3,
    maxHeight: 55,
    padding: "0px 5px"
  },
  buttonGroup: {
    display: "flex",
    alignSelf: "center",
    "& > *": {
      margin: theme.spacing(0.75)
    }
  },
  buttons: {
    color: "#fff",
    borderColor: "white",
    "&:disabled": {
      color: "rgba(255, 255, 255, .35)",
      borderColor: "rgba(255, 255, 255, .35)"
    }
  },
  noOfDevicesWrapper: {
    color: "#fff",
    alignSelf: "center"
  },
  breadcrumbWraper: {
    display: "flex"
  }
}));
