export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true
  },
  {
    key: "updatedAt",
    text: "pages.classification-test.testing-settings.grid.update-date-time",
    type: "date",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "className",
    text: "pages.classification-test.testing-settings.grid.class-name",
    type: "string",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "imgCount",
    text: "pages.classification-test.testing-settings.grid.no-of-images",
    type: "string",
    validation: { required: true, pattern: "//" }
  }
];
