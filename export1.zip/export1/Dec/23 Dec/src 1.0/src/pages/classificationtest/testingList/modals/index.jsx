import React from "react";
import { useStyles } from "./style";
import Modal from "../../../../shared/components/ui/modal";
import { useTranslation } from "react-i18next";

const Modals = (props) => {
  const { type, open, onClose, deleted } = props;
  const classes = useStyles();
  const { t } = useTranslation();

  switch (type) {
    case "DELETE":
      return (
        <Modal
          open={open}
          onClose={onClose}
          onSubmit={deleted}
          widthClass={classes.modalWidth}
          showControls
          primaryButtonTextKey={"pages.training.suggestion-result.controls.ok-btn"}
          secondaryButtonTextKey={"pages.training.suggestion-result.controls.cancel-btn"}
        >
          <div className={classes.modalTextPadding}>
            <h3 className={classes.modalTitle}>{t("pages.classification-test.testing-list.modal.delete-testing")}</h3>
            <div className={classes.mT1}>
              <label className={classes.fontSize}>{t("pages.training.training-parameter.dataset-mode.modal.deleteMsg")}</label>
            </div>
          </div>
        </Modal>
      );
      break;
  }
  return <div></div>;
};
export default Modals;
