import React from "react";
import { useEffect, useContext, useState, useCallback } from "react";
import { Observer } from "mobx-react-lite";
import { Accordion, AccordionSummary, AccordionDetails } from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import TestManagementStore from "../../../../stores/testManagementStore";
import Pagination from "../../../../shared/components/basictable/pagination";
import ImageListGrid from "./imagelistgrid/imageListGrid";
import { useParams } from "react-router-dom";
import { API_RESPONSE } from "../../../../appconstants";
import DragIndicatorIcon from '@material-ui/icons/DragIndicator';
import ResizablePanel from '../../../../components/resizable';

const ImageList = ({ drag, probabilityThreshold, selectedConfusionMatrixClassesCount }) => {
  const classes = useStyles({ height: 20 });
  const { t } = useTranslation();
  const params = useParams();
  const testManagementStore = useContext(TestManagementStore);
  const [loading, setLoading] = useState(false);
  const [totalImageCount, setTotalImageCount] = useState(0);
  const [pageNo, setPageNo] = useState(1);
  const [imageListData, setImageListData] = useState([]);
  const [resizeDrag, setResizeDrag] = useState(false);

  useEffect(() => {
    getImageList();
  }, [selectedConfusionMatrixClassesCount, probabilityThreshold, pageNo]);

  const getImageList = useCallback(async () => {
    setLoading(true);
    const selectedData = JSON.parse(JSON.stringify(testManagementStore.selectedConfusionMatrixClasses));
    let classes = selectedData.reduce((classList, item) => {
      if (!classList[item.setClassName]) {
        classList[item.setClassName] = [];
      }
      classList[item.setClassName].push(item.actualClassName);
      return classList;
    }, {});
    const pageNumber = (pageNo > 0 ? pageNo - 1 : pageNo) * 10;
    let payload = { probability: probabilityThreshold, classes: classes, from_index: pageNumber, end_index: pageNumber + 10, asc: "seqNo" };
    await testManagementStore
      .fetchConfusionMatrixImageListData(params.id, payload)
      .then((response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          let imageLists = [];
          if (response?.data?.length > 0) {
            imageLists = response?.data?.map(image => {
              if (image?.probability?.length > 0) {
                let probabilities = image?.probability.map(probability => probability.toFixed(8)); //?.join("\\n");
                // let probabilityData = "";
                // probabilities.forEach((probability, key) => {
                //   if (key % 3 === 1) {
                //     probabilityData += probability + "<br />";
                //   } else {
                //     probabilityData += probability + ", ";
                //   }

                // })
                // ?.map(probability => {
                //   return probability?.toFixed(8);
                // });
                image.probability = probabilities;
              }
              return image;
            });
          }
          setImageListData(imageLists);
          setTotalImageCount(response?.count);
        }
      })
      .catch((error) => {
        setLoading(false);
        setImageListData([]);
      });
    setLoading(false);
  });

  const onPagination = (options) => {
    setPageNo(options.pageNo);
  };
  const handleAccordionChange = (ev, isExpanded) => {
    setResizeDrag(isExpanded)
  }

  return (
    <Observer>
      {() => (
        <ResizablePanel hideDrag={resizeDrag}>
          <Accordion height="20" defaultExpanded={false} className={classes.accMarginTop} onChange={handleAccordionChange} >
            <AccordionSummary className={classes.accSummary} expandIcon={<ExpandMoreIcon />} aria-controls="panel1bh-content" id="panel1bh-header">
              <div {...drag}>
                <DragIndicatorIcon />
              </div>
              <label className={classes.accSummaryLabel} >{t("pages.classification-test.testing-list.grid.image-list")}</label>
            </AccordionSummary>
            <AccordionDetails className={classes.accDetails}>
              <div className={classes.pagination}>
                <Pagination
                  disabled={false}
                  onChange={onPagination}
                  itemCount={totalImageCount}
                  pageNo={pageNo}
                  pageSize={10}
                  disableItemPerPage={true}
                  disablePageNumber={true}
                />
              </div>
              <ImageListGrid
                loading={loading}
                records={imageListData}
                selectedImagesCount={testManagementStore.selectedconfusionMatrixImages?.length}
                containerClassName={classes.tableContainer}
              />
            </AccordionDetails>
          </Accordion>
        </ResizablePanel>
      )}
    </Observer>
  );
};

export default ImageList;
