export const columnDefinition = [
  {
    key: 'checkbox',
    type: 'checkbox',
    isSticky: true,
  },
  {
    key: 'updatedAt',
    text: 'pages.classification-test.testing-list.grid.update-date-time',
    type: 'date',
    validation: { required: true, pattern: '//' },
  },
  // {
  //   key: 'user',
  //   text: 'pages.classification-test.testing-list.grid.create-user',
  //   type: 'string',
  //   validation: { required: true, pattern: '//' },
  // },
  {
    key: 'title',
    text: 'pages.classification-test.testing-list.grid.title',
    type: 'string',
    validation: { required: true, pattern: '//' },
  },
  {
    key: 'comment',
    text: 'pages.classification-test.testing-list.grid.comment',
    type: 'string',
    validation: { required: true, pattern: '//' }
  },
  {
    key: 'statusString',
    text: 'pages.classification-test.testing-list.grid.status',
    type: 'string',
    validation: { required: true, pattern: '//' }
  },
  {
    key: 'classesUsed',
    text: 'pages.classification-test.testing-list.grid.classes-used',
    type: 'string',
    hover: true,
    validation: { required: true, pattern: '//' }
  },
  {
    key: 'datasetMode',
    text: 'pages.classification-test.testing-list.grid.mode',
    type: 'string',
    validation: { required: true, pattern: '//' }
  },
  {
    key: 'modelName',
    text: 'pages.classification-test.testing-list.grid.model-used',
    type: 'string',
    validation: { required: true, pattern: '//' }
  },
  {
    key:"classifiedImagesCount",
    text: "pages.classification-test.testing-list.grid.classified-images",
    type: 'string',
    validation: { required: true, pattern: '//' }
  }
]
