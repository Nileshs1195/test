import { useContext, useEffect } from "react";
import { Table, TableHead } from "../../../../../shared/components/basictable";
import { TableBody as MuiTableBody } from "@material-ui/core";
import CustomTable from "../../../../../components/customtable";
import TestManagementStore from "../../../../../stores/testManagementStore";

const ConfusionMatrixGrid = ({ loading, records, containerClassName, selectedRecordsCount,disableAdvisorButton, columnDefinition }) => {
  const testManagementStore = useContext(TestManagementStore);
  let selectedRowCount = 0;
  useEffect(() => {
    init();
    advisor();
  }, [records]);

  const init = () => {
    let classPairs = [];
    testManagementStore.clearConfusionMatrixClass();
    if (testManagementStore?.selectedConfusionMatrixClasses?.length > 0) {
      classPairs = testManagementStore?.selectedConfusionMatrixClasses;
    } else {
      records.forEach((item) => {
        const actualClasses = Object.keys(item.imgCount);
        actualClasses.forEach((element) => {
          classPairs.push({ setClassName: item.className, actualClassName: element });
        });
      });
    }
    testManagementStore.addConfusionMatrixClass(classPairs);
  };

  const isSelected = (setClassName, actualClassName) => {
    return (
      testManagementStore.selectedConfusionMatrixClasses.filter(
        (item) => item.setClassName === setClassName && item.actualClassName === actualClassName
      ).length > 0
    );
  };

  const getBodyData = (data) => {
    data = JSON.parse(JSON.stringify(data));
    data.forEach((element) => {
      let isRowSelected = true;
      element._id = element.className;
      const imageCountData = Object.entries(element.imgCount);
      imageCountData.forEach((item) => {
        const isItemSelected = isSelected(element.className, item[0]);
        isRowSelected = isItemSelected ? isRowSelected : isItemSelected;
        element[item[0]] = { value: item[1], selected: isItemSelected };
      });
      element.selected = isRowSelected;
      if (isRowSelected) {
        selectedRowCount++;
      }
    });
    return data;
  };

  const handleSelectAllClick = (event) => {
    const { checked } = event.target;
    testManagementStore.clearConfusionMatrixClass();
    if (checked) {
      init();
    }
  };

  const onRowSelect = (event, setClassName) => {
    const { checked } = event.target;
    testManagementStore.removeConfusionMatrixClass(setClassName);
    if (checked) {
      const selectedData = records.filter((item) => item.className === setClassName);
      const actualClasses = Object.keys(selectedData[0]?.imgCount);
      let classPairs = [];
      actualClasses.forEach((element) => {
        classPairs.push({ setClassName: setClassName, actualClassName: element });
      });
      testManagementStore.addConfusionMatrixClass(classPairs);
    }
  };

  const onClassSelect = (event, actualClassName, setClassName) => {
    const { checked } = event.target;
    if (checked) {
      testManagementStore.addConfusionMatrixClass([{ actualClassName: actualClassName, setClassName: setClassName }]);
    } else {
      testManagementStore.removeConfusionMatrixClass(setClassName, actualClassName);
    }
  };

  const advisor = () => {
    disableAdvisorButton(true);
    data.forEach((record,i)=>{
      let selectedClass = testManagementStore.testDataset.filter(dataset=>dataset.className === record.className);
      if(record?.imgCount) {
        Object.keys(record.imgCount).forEach(classname=>{
          if(record?.imgCount?.[classname]!==selectedClass?.[0]?.imgCount && classname === selectedClass?.[0]?.className){
            disableAdvisorButton(false);
            return;
          }   
          if(record?.imgCount?.[classname]!==0 && classname !== selectedClass?.[0]?.className){
            disableAdvisorButton(false);
            return;
          }
        })
      }
    });
  }
  
  const data = getBodyData(records);
  return (
    <Table loading={loading} className={containerClassName}>
      <TableHead
        rowCount={records?.length}
        headerData={columnDefinition}
        onAllRowSelected={handleSelectAllClick}
        hideFilter={true}
        noEmptyColumn={true}
        selectedRowCount={selectedRowCount}
      />
      <MuiTableBody>
        <CustomTable onRowSelect={onRowSelect} bodyData={data} headerData={columnDefinition} onCheckboxClick={onClassSelect} />
      </MuiTableBody>
    </Table>
  );
};

export default ConfusionMatrixGrid;
