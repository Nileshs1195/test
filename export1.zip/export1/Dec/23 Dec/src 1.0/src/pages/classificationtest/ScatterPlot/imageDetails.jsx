import { Grid, Typography, Button } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useStyles } from './styles';
import { SETTINGS } from "../../../appsettings";
// import CompareImage from './compareImage';

const ImageDetails = ({ selectedPlotData }) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const [showHeatImage, disableHeatImage] = useState(false);
  // const [imageData,setImageData] = useState([]);
  const imageThumbnailURL = SETTINGS.IMAGE_FULL_URL;
  useEffect(()=>{
    disableHeatImage(false);
  },[selectedPlotData]);

  const onButtonClick = () =>{
    disableHeatImage((isOpen) => !isOpen)
    // setImageData()
  }
  return (
    <Grid xs={12} sm={12} lg={6} item spacing={2} className={classes.imageBox}>
      <Grid item xs={6} className={classes.container} >
      {/* {imageThumbnailURL+selectedPlotData.fileName} */}
        {selectedPlotData?.fileName && (<>
          <img
            src={imageThumbnailURL+selectedPlotData.fileName}
            className={classes.leftimageCenter}
            alt={selectedPlotData.fileName}
          />
        <div className={classes.displayText}>
          <span>
            <Typography className={classes.textOverflow}>
              {t('pages.classification-test.testing-list.grid.img-file-name')}:{' '}
              {selectedPlotData?.fileName}
              {t('pages.classification-test.testing-list.grid.probability')}:
              {selectedPlotData.probability}
     
              {t('pages.classification-test.testing-list.grid.set-class')}:
              {selectedPlotData.setClassName}
            </Typography>
            <Typography className={classes.textOverflow}>
              {t('pages.classification-test.testing-list.grid.actual')}:
              {selectedPlotData.actualClassName}
            </Typography>
          </span>
        </div>
        </>
        )}

        {selectedPlotData?.heatmapFileName && (
          <Button
            variant="outlined"
            className={classes.buttons}
            onClick={onButtonClick}
          >
            Heat Map
          </Button>
        )}
      </Grid>
      <Grid item xs={6} className={classes.container}>
      {/* {imageThumbnailURL+selectedPlotData.heatmapFileName} */}
        {showHeatImage && (
          <img
            className={classes.rightimageCenter}
            src={imageThumbnailURL+selectedPlotData.heatmapFileName}
            alt={selectedPlotData.heatmapFileName}
          />
        )}
        {/* <CompareImage open={showHeatImage} onClose={()=>disableHeatImage((isOpen)=>!isOpen)} imageData={selectedPlotData}/> */}
      </Grid>
    </Grid>
  )
}
export default ImageDetails
