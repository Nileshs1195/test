import React from "react";
import { useEffect, useContext, useState, useCallback } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button } from "@material-ui/core";
import { useStyles } from "./style";
import AppStore from "../../../stores/appstore";
import TestManagementStore from "../../../stores/testManagementStore";
import { API_RESPONSE, APP_ROUTES } from "../../../appconstants";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import { useTranslation } from "react-i18next";
import ConfusionMatrix from "./confusionMatrix/confusionMatrix";
import ImageList from "./imageList/imageList";
import ScatterGraph from "../ScatterPlot";
import { useHistory, useParams } from "react-router";
import BackButton from "../../../components/backbutton";
import AddNewClass from "../../../components/add-class";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
// import { API_RESPONSE } from "../../../../appconstants";

const ConfusionMatrixComponent = () => {
  const classes = useStyles();
  const history = useHistory();
  const params = useParams();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const testManagementStore = useContext(TestManagementStore);
  const [probabilityThreshold, setProbabilityThreshold] = useState(0.8);
  const [addClass, setAddClass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [confusionMatrixData, setConfusionMatrixData] = useState([]);
  const [setClasses, setSetClasses] = useState([]);
  const [isAdvisorButton, disableAdvisorButton] = useState(true);
  const [dragOrder, setDragOrder] = useState([
    { id: "1", componentName: "matrix" },
    { id: "2", componentName: "list" },
    { id: "3", componentName: "graph" }
  ]);

  useEffect(() => {
    breadCrumb();
    getTestingList();
    if (localStorage.getItem("updatedDragOrder")) {
      let neworder = JSON.parse(localStorage.getItem("updatedDragOrder"));
      setDragOrder(neworder);
    }
  }, [appStore.addBreadcrumb]);

  useEffect(() => {
    localStorage.setItem("confusionMatrixThreshold", probabilityThreshold);
    getConfusionMatrixData();
  }, [probabilityThreshold]);

  const breadCrumb = () => {
    appStore.removeAllBreadcrumbs();
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
      label: "pages.classification-test.testing-list.confusion-matrix.title"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
      label: "pages.classification-test.testing-list.title"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS.replace(":id", params.id),
      label: "pages.classification-test.testing-settings.title"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CONFUSION_MATRIX.replace(":id", params.id),
      label: "pages.classification-test.confusion-matrix.title"
    });
  };

  const getTestingList = useCallback(async () => {
    await testManagementStore.fetchTestingList();
  });

  const getConfusionMatrixData = useCallback(async () => {
    setLoading(true);
    let payload = { probability: probabilityThreshold };
    await testManagementStore
      .fetchConfusionMatrixData(params.id, payload)
      .then((response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setConfusionMatrixData(response?.data);
          const setClassList = JSON.parse(JSON.stringify(response.column));
          setClassList.push(setClassList.splice(setClassList.indexOf(t("pages.classification-test.testing-list.grid.unknown-class")), 1)[0]);
          const setClassCollection = setClassList.map((item) => {
            return { className: item };
          });
          setSetClasses(setClassCollection);
        } else {
          alert("Failed to fetch data. Please reload the page");
        }
      })
      .catch((error) => {
        alert("Failed to fetch data. Please reload the page");
        setLoading(false);
        setConfusionMatrixData([]);
      });
    setLoading(false);
  });

  const handleProbabilityChange = (value) => {
    setProbabilityThreshold(value);
  };

  const handleBackButton = (to = "") => {
    if (to == "settings") {
      history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS.replace(":id", params.id));
    } else {
      history.goBack();
    }
  };

  const goToViewImages = () => {
    testManagementStore.updateClassificationData({ isListUpdated: false, updatedList: [] });
    localStorage.setItem("selectedConfusionMatrixClasses", JSON.stringify(testManagementStore.selectedConfusionMatrixClasses));
    history.push(
      APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST_IMAGES.replace(":id", params.id).replace(":seqNo", params.batchSeqNo)
    );
  };

  const createClass = (id, newClassName) => {
    const selectedImages = testManagementStore.selectedconfusionMatrixImages.reduce((result, element) => {
      result.push(element.imageSeqNo);
      return result;
    }, []);

    testManagementStore
      .setConfusionMatrixNewClass(id, { className: newClassName, imgSeqno: selectedImages })
      .then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE && response?.data) {
          getConfusionMatrixData();
          testManagementStore.clearConfusionMatrixImages();
        } else {
          alert("Failed to save data.");
        }
      })
      .catch((error) => {
        alert("Failed to save data.");
        console.log(error);
      });
  };

  const onDragEnd = (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) {
      return;
    }
    if (destination.droppableId === source.droppableId && destination.index === source.index) {
      return;
    }
    const order = dragOrder;
    const record = order.splice(source.index, 1)[0];
    order.splice(destination.index, 0, record);
    setDragOrder(order);
    localStorage.setItem("updatedDragOrder", JSON.stringify(order));
  };

  const goToAdvisor = () => {
    history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.DISPLAY_ADVISOR.replace(":id", params.id).replace(":batchSeqNo", params.batchSeqNo));
  };

  return (
    <Observer>
      {() => (
        <div>
          <Paper className={classes.pageContent}>
            <AddNewClass open={addClass} dataset={setClasses} setAddClass={setAddClass} handleCreateClass={createClass} />
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={testManagementStore.selectedconfusionMatrixImages?.length === 0}
                  onClick={() => setAddClass(true)}
                >
                  {t("pages.classification-test.testing-list.confusion-matrix.controls.set-class-name")}
                </Button>
                <Button color="primary" variant="contained" onClick={goToAdvisor} disabled={isAdvisorButton}>
                  {t("pages.classification-test.testing-list.confusion-matrix.controls.advisor")}
                </Button>
                {/* <Button color="primary" variant="contained">
                  {t("pages.classification-test.testing-list.confusion-matrix.controls.scatter-plot")}
                </Button> */}
                <Button
                  color="primary"
                  variant="contained"
                  onClick={goToViewImages}
                  disabled={testManagementStore.selectedConfusionMatrixClasses?.length > 0 ? false : true}
                >
                  {t("pages.classification-test.testing-list.confusion-matrix.controls.view-img")}
                </Button>
                {/* <Button color="primary" variant="contained">
                  {t("pages.classification-test.testing-list.confusion-matrix.controls.img-list")}
                </Button>
                <Button color="primary" variant="contained">
                  {t("pages.classification-test.testing-list.confusion-matrix.controls.cancel")}
                </Button> */}
                <Button
                  color="primary"
                  onClick={() => {
                    handleBackButton("settings");
                  }}
                  variant="contained"
                >
                  {t("pages.classification-test.confusion-matrix.controls.back")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="drag-12">
                {(provided) => (
                  <div ref={provided.innerRef} {...provided.droppableProps}>
                    {dragOrder.map((item, index) => (
                      <div>
                        <Draggable key={item.id} draggableId={item.id} index={index}>
                          {(provided) => (
                            <div {...provided.draggableProps} ref={provided.innerRef}>
                              {item.componentName === "matrix" && (
                                <ConfusionMatrix
                                  drag={provided.dragHandleProps}
                                  loading={loading}
                                  confusionMatrixData={confusionMatrixData}
                                  selectedConfusionMatrixClassesCount={testManagementStore.selectedConfusionMatrixClasses?.length}
                                  setProbabilityThreshold={handleProbabilityChange}
                                  testList={testManagementStore.testingList}
                                  setClasses={setClasses}
                                  disableAdvisorButton={disableAdvisorButton}
                                />
                              )}
                              {item.componentName === "list" && (
                                <ImageList
                                  drag={provided.dragHandleProps}
                                  probabilityThreshold={probabilityThreshold}
                                  selectedConfusionMatrixClassesCount={testManagementStore.selectedConfusionMatrixClasses?.length}
                                />
                              )}
                              {item.componentName === "graph" && (
                                <ScatterGraph
                                  probabilityThreshold={probabilityThreshold}
                                  drag={provided.dragHandleProps}
                                  graphData={testManagementStore.confusionMatrixImageListData}
                                />
                              )}
                            </div>
                          )}
                        </Draggable>
                      </div>
                    ))}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default ConfusionMatrixComponent;
