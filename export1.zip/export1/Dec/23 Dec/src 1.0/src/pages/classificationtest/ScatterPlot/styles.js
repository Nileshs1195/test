import { makeStyles } from '@material-ui/core'

export const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    background: '#fff',
    padding: theme.spacing(1.5),
  },
  scatterGraph:{
    '& .modebar':{
      display:'none !important'
    }
  },
  radioWrapper: {
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'unset',
    // marginTop:'-18px',
    zIndex:1
  },
  box:{
    // position: 'absolute',
    // left:"calc(100% - 80% )",
    // margin:'auto',
    // textAlign:'center',
    // top:-100,
    // zIndex: 1,
    marginTop:18
  },
  leftButtonContainer: {
    display: 'grid',
    alignItems: 'center',
    position: 'absolute',
    left: theme.spacing(3),
    overflow:'hidden',
    zIndex: 1,
    textAlign: 'end',
    '& > *': {
      marginTop: theme.spacing(1.5),
    },
  },
  modebar: {
    display: 'none!important'
 },
  iconColor: {
    color: '#000',
  },
  iconButton:{
   background: "rgba(58, 95, 170, 0.13)"
  },
  imageBox: {
    display:'flex',
    // borderLeft:'1px solid rgb(203, 203, 203,1)'
    // margin:'auto',
  },
  container:{
    height:'100%',
    textAlign:'center'
  },
  leftimageCenter: {
    position: 'relative',
    // marginTop:'30px',
    border: '1px solid rgb(203, 203, 203,1)',
    borderRadius: 3,
    maxWidth: '300px',
    minWidth: '400px',
    minHeight: '400px',
    objectFit: 'contain',
    overflow: 'hidden',
    margin: 'auto'
  },
  rightimageCenter: {
    position: 'relative',
    // marginTop:'30px',
    border: '1px solid rgb(203, 203, 203,1)',
    borderRadius: 3,
    maxWidth: '300px',
    minWidth: '400px',
    minHeight: '400px',
    objectFit: 'contain',
    overflow: 'hidden',
    margin: 'auto'
  },
  displayText: {
    // display: "flex",
    // textAlign:'center',
    // margin: 0
  },
  textOverflow: {
    fontSize: theme.typography.fontSize,
    fontWeight: theme.typography.fontWeightLight,
    textOverflow: "ellipsis",
    textAlign:'center',
    overflow: "hidden",
    whiteSpace: "nowrap",
    margin:'auto',
    width: '100%',
    // height:'160px'
    // "&:hover": {
    //   overflow: "visible",
    // },
  },
  imageDetialsBox:{
      marginTop:'auto',
      marginBottom: 'auto',
      padding: theme.spacing(2),
      width:'100%',
  },
  accMarginTop:{
    // marginTop: theme.spacing(2),
    '&.MuiAccordion-root':{
      transition: 'none !important'
    }
  },
  accSummaryLabel:{
    marginTop:4, 
    marginLeft:4
  },
  accSummary: {
    "&.MuiAccordion-root":{
      transition: 'none'
    },
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      // minHeight: "48px !important",
      // marginTop: theme.spacing(2),
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      // marginTop: theme.spacing(2)
    }
  },
  accDetails: {
    padding: "10px",
    border: "1px solid rgba(0, 0, 0, .125)",
    display: "block",
  },
}))
