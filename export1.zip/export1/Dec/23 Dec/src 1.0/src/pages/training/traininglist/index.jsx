import { Button, Divider, Paper } from '@material-ui/core';
import { Observer } from 'mobx-react-lite';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router-dom';
import { APP_ROUTES, IMAGE_GROUP_LIST } from '../../../appconstants';
import Pagination from '../../../shared/components/basictable/pagination';
import Breadcrumb from '../../../shared/components/ui/breadcrumb';
import Modal from '../../../shared/components/ui/modal';
import AppStore from '../../../stores/appstore';
import TrainingManagementStore from './../../../stores/trainingmanagementstore';
import { columnDefinitions } from './grid/columndefinitions';
import Grid from './grid';
import { useStyles } from './style';
import { useCallback, useContext, useEffect, useState } from 'react';
import { API_RESPONSE } from '../../../appconstants';
import CustomSnackBar from '../../../components/snackbar';
import CustomConfirmation from '../../../components/modal/CustomConfirmation';
import AddTraining from '../../../components/training-forms/AddTraining';
import EditTraining from '../../../components/training-forms/EditTraining';
import CopyTraining from '../../../components/training-forms/CopyTraining';
import AddClassificationTest from '../../../components/add-test';

const TrainingList = () => {
  const classes = useStyles();
  const history = useHistory();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { trainingListData, fetchTrainingListData } = trainingManagementStore;
  const { addBreadcrumb, removeAllBreadcrumbs } = appStore;
  const [loading, setLoading] = useState(false);
  const [confirm, setConfirm] = useState({ mode: "", status: "", open: false });
  const [modalTitle, setModalTitle] = useState('');
  const [trainings, setTrainings] = useState([]);
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [isEditAndNextDisabled, disableEditButton] = useState(false);
  const [isDeleteDisabled, disableDeleteButton] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: '' });
  const [isModalOpen, setModalOpen] = useState(false);
  const [addTraining, setAddTraining] = useState(false);
  const [editTraining, setEditTraining] = useState(false);
  const [copyTraining, setCopyTraining] = useState(false);
  const [addTest, setAddTest] = useState(false);
  const [trainingData, setTrainingData] = useState({ modelName: "", comment: "", status: 0 });

  useEffect(() => {
    trainingManagementStore.setImageGroupGridSortParams(
      "sortOrder",
      IMAGE_GROUP_LIST.SORT_DIRECTION.ASCENDING,
    );
    if (trainingManagementStore?.selectedTrainingListData?.length > 0) {
      trainingManagementStore.clearSelectedTrainingListData();
      disableAddButton(false);
    }
    trainingManagementStore.clearTrainingListData();
  }, []);

  useEffect(() => {
    let data = trainingManagementStore?.trainingListData;
    setTrainings(data);
  }, [trainingManagementStore?.trainingListData]);

  useEffect(() => {
    const breadcrumb = {
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-list.title",
    };
    removeAllBreadcrumbs();
    addBreadcrumb(breadcrumb);
    trainingManagementStore.clearSelectedTrainingDataset();
    trainingManagementStore.setViewParameter(false);
  }, [addBreadcrumb]);

  // get traininglist
  const getTrainingListData = useCallback(async () => {
    setLoading(true);
    appStore.addInspectionGridColumnPreference(columnDefinitions);
    await fetchTrainingListData();
    setLoading(false);
  });

  const handleTrainingListModal = (label, apply = false) => {
    switch (label) {
      case "COPY-TO-NEW":
        setTrainingData((prev) => ({
          ...trainingManagementStore.selectedTrainingListData[0],
          ["modelName"]: 'Copy_' + trainingManagementStore.selectedTrainingListData[0].modelName,
          ["comment"]: trainingManagementStore.selectedTrainingListData[0].comment,
          ["Status"]: 'Ready'
        }));
        setCopyTraining(true);
        break;
      case 'DELETE':
        setModalDetails("DELETE");
        disableAddButton(false);
        break
      case 'NEXT':
        if (trainingManagementStore?.selectedTrainingListData?.[0]?._id) {
          gotoTrainParameterSetting(trainingManagementStore.selectedTrainingListData[0]._id);
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.selected-id-unavailable") });
        }
        break;
      case "VIEW-PARAMETER":
        if (trainingManagementStore?.selectedTrainingListData?.[0]?._id) {
          trainingManagementStore.setTabIndex(0);
          trainingManagementStore.clearTrainingDataset();
          trainingManagementStore.setViewParameter(true);
          history.push(
            APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER.replace(
              ":id",
              trainingManagementStore.selectedTrainingListData[0]._id,
            ),
          );
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.selected-id-unavailable") });
        }
        break;
      case "RE-EXECUTE":
        if (trainingManagementStore?.selectedTrainingListData?.[0]?._id) {
          let selectedTraining = Object.assign({}, trainingManagementStore?.selectedTrainingListData?.[0]);
          if (selectedTraining?.status === 7 || selectedTraining?.status === "Ok" || selectedTraining?.status === "Executed" || selectedTraining?.status === "Stop" || selectedTraining?.status === "Stopping" || selectedTraining?.status === "Stopped" || !selectedTraining.batchSeqNo || selectedTraining.statusString === "Not Running") {
            if (selectedTraining?.status === "Ok") {
              trainingManagementStore.startExecution(trainingManagementStore?.selectedTrainingListData?.[0]?._id, "none", {}).then(res => {
                if (res?.status === 200 && res?.data?.seqNo && res?.data?.mode === "none") {
                  gotoTrainParameterSetting(selectedTraining._id);
                } else {
                  console.log("Mode", res?.data?.mode);
                }
              }).catch(error => {
                console.log(error);
              });
            } else {
              gotoTrainParameterSetting(selectedTraining._id);
            }
          } else {
            setConfirm({
              mode: selectedTraining.mode,
              status: selectedTraining.status,
              open: true,
              submit: () => redirectToExecution(selectedTraining),
              title: t("pages.training.errors.training-list.execution-failed-title"),
              message: t("pages.training.errors.training-list.execution-failed-training-reexecute"),
              primary: "pages.training.errors.training-list.fail-redirect",
              secondary: "pages.training.input-parameter.grid.cutomization.modal.cancel-btn"
            });
          }
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.selected-id-unavailable") });
        }
        break;
      case "CLOSE":
        setModalOpen((isOpen) => !isOpen);
        trainingManagementStore.clearSelectedTrainingListData();
        disableAddButton(false);
        break;
      default:
    }
  }

  const redirectToExecution = (selectedTraining) => {
    if (selectedTraining?.mode === "subclassification") {
      history.push(
        APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION.replace(
          ':id',
          selectedTraining._id,
        ).replace(
          ':seqNo',
          selectedTraining.batchSeqNo,
        )
      )
    } else if (selectedTraining?.mode === "training") {
      history.push(
        APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(
          ':id',
          selectedTraining._id,
        ).replace(
          ':seqNo',
          selectedTraining.batchSeqNo,
        )
      )
    } else if (selectedTraining?.mode === "parameterSearch") {
      history.push(
        APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH.replace(
          ':id',
          selectedTraining._id,
        ).replace(
          ':seqNo',
          selectedTraining.batchSeqNo,
        )
      )
    } else {

    }
  }

  const setModalDetails = (title) => {
    setModalOpen((isOpen) => !isOpen);
    setModalTitle(title);
  }

  const gotoTrainParameterSetting = (trainingId) => {
    trainingManagementStore.clearTrainingDataset();
    trainingManagementStore.setTabIndex(0);
    history.push(
      APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(
        ':id',
        trainingId,
      ),
    );
  }

  const handleDeleteTrainingListRecord = () => {
    var idArray = { id: [] }
    trainingManagementStore.selectedTrainingListData.map(function (v) {
      idArray.id.push(v._id);
    })
    console.log(idArray);
    trainingManagementStore
      .deleteMultipleTrainingListRecords(idArray)
      .then((response) => {
        if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          getTrainingListData();
          setsnapbarMessage({ message: t("pages.training.success.training-list.deleted") });
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.delete-failed") });
        }
      })
      .catch((err) => {
        console.log("error", err);
      })
  }

  const onPagination = (options) => {
    appStore.updateInspectionGridPageNo((options.pageNo > 0 ? options.pageNo - 1 : options.pageNo) * options.pageSize);
    getTrainingListData();
  }

  const delteTrainingModal = () => {
    return <Modal
      open={isModalOpen}
      onClose={() => handleTrainingListModal('CLOSE')}
      onSubmit={() => {
        handleDeleteTrainingListRecord();
        trainingManagementStore.clearSelectedTrainingListData();
      }}
      widthClass={classes.modalWidth}
      showControls
      primaryButtonTextKey={'pages.training.training-list.controls.delete'}
      secondaryButtonTextKey={'pages.training.training-list.controls.cancel-btn'}
    >
      <div className={classes.modalTextPadding}>
        <h3 className={classes.modalTitle}>{t("pages.training.training-parameter.dataset-mode.modal.delete")}</h3>
        <div className={classes.mT1}>{t("pages.training.training-parameter.dataset-mode.modal.deleteMsg")}</div>
      </div>
    </Modal>
  }

  return (
    <Observer>
      {() => (
        <div>
          {addTest && <AddClassificationTest open={addTest} setOpen={setAddTest} id={trainingManagementStore.selectedTrainingListData[0]?._id} askTrainingModel={true} />}
          <AddTraining open={addTraining} setOpen={setAddTraining} setSnapbar={setsnapbarMessage} />
          {editTraining && <EditTraining training={trainingManagementStore?.selectedTrainingListData?.[0]} open={editTraining} callBack={getTrainingListData} setOpen={setEditTraining} setSnapbar={setsnapbarMessage} disableAddButton={disableAddButton}/>}
          {copyTraining && <CopyTraining training={trainingData} open={copyTraining} callBack={getTrainingListData} setOpen={setCopyTraining} setSnapbar={setsnapbarMessage} />}
          {isModalOpen && modalTitle === "DELETE" && delteTrainingModal()}
          <Paper className={classes.pageContent}>
            {snapbarMessage?.message && (
              <CustomSnackBar snapbarMessage={snapbarMessage} />
            )}
            <div className={classes.top}>
              <Breadcrumb
                breadcrumbs={appStore.breadcrumbs}
                removeBreadcrumb={appStore.removeBreadcrumb}
              />
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={isAddButtonDisabled}
                  onClick={() => { setAddTraining(true); }}
                >
                  {t('pages.training.training-list.controls.add-btn')}
                </Button>

                {/* t("pages.training.training-parameter.dataset-mode.modal.deleteMsg") */}
                {/* <Button
                  color="primary"
                  variant="contained"
                  onClick={handleFilterPreference}
                >
                  {t(
                    "pages.training.training-list.controls.apply-default-filter-btn"
                  )}
                </Button> */}
                {/* <Button
                  variant="contained"
                  color="primary"
                  onClick={handleCustomizeModal}
                >
                  {t("pages.training.training-list.controls.customize-btn")}
                </Button> */}
              </div>
            </div>
            <CustomConfirmation
              open={confirm.open} 
              onClose={() => {
                setConfirm({
                  open: false
                });
              }}
              onSubmit={confirm.submit}
              primary={confirm.primary}
              secondary={confirm.secondary}
              title={confirm.title}
              message={confirm.message}
            />
            <Divider className={classes.divider} />
            <div className={classes.controlContainer}>
              <Pagination
                disabled={false}
                onChange={onPagination}
                itemCount={trainingListData.length}
                pageNo={appStore.inspectionSearchFilter.pageNo + 1}
                pageSize={appStore.inspectionSearchFilter.pageSize}
              />
            </div>
            <Grid
              loading={loading}
              records={trainingListData}
              containerClassName={
                trainingManagementStore.selectedTrainingListDataCount > 0
                  ? classes.tableContainerFooter
                  : classes.tableContainer
              }
              columnDefinitions={appStore.inspectionGridColumnPreference}
              disableAddButton={disableAddButton}
              disableEditButton={disableEditButton}
              disableDeleteButton={disableDeleteButton}
            />
            {trainingManagementStore.selectedTrainingListDataCount > 0 && (
              <div className={classes.footerContainer}>
                <div className={classes.buttonGroup}>
                  <span className={classes.noOfDevicesWrapper}>
                    {t('pages.training.training-list.controls.selected')}
                    {' : '}
                    {trainingManagementStore.selectedTrainingListDataCount}
                  </span>
                </div>

                <div className={classes.buttonGroup}>
                  <Button 
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={()=>setAddTest(true)}
                    disabled={
                      !((trainingManagementStore.selectedTrainingListData[0]?.statusString === 'Executed') 
                      && 
                      trainingManagementStore.selectedTrainingListDataCount === 1
                      ) }
                  >
                  {t("pages.training.training-list.controls.test-execute")}
                  </Button>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('COPY-TO-NEW')}
                  >
                    {t('pages.training.training-list.controls.copy-to-new')}
                  </Button>
                  {/* Only needed for release 0.2  */}
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    disabled={isDeleteDisabled}
                    onClick={() => handleTrainingListModal('DELETE')}
                  >
                    {t('pages.training.training-list.controls.delete')}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => { setEditTraining(true); }}
                  >
                    {t('pages.training.training-list.controls.edit')}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('VIEW-PARAMETER')}
                  >
                    {t('pages.training.training-list.controls.view-params')}
                  </Button>
                  {/* Only needed for release 0.2 */}
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleTrainingListModal('RE-EXECUTE')}
                  >
                    {t('pages.training.training-list.controls.re-execute')}
                  </Button>
                </div>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  )
}

export default TrainingList
