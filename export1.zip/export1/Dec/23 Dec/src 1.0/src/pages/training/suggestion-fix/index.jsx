import { Button, Divider, FormControlLabel, Paper, Switch } from "@material-ui/core";
import { Observer, observer } from "mobx-react-lite";
import { useCallback, useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import { useHistory } from "react-router-dom";
import Breadcrumb from "../../../shared/components/ui/breadcrumb"; import AppStore from "../../../stores/appstore";
import TrainingManagementStore from "./../../../stores/trainingmanagementstore";
import { useStyles } from "./style";
import { API_RESPONSE, API_URL, APP_ROUTES } from "../../../appconstants";
import BackButton from "../../../components/backbutton";
import CustomConfirmation from "../../../components/modal/CustomConfirmation";
import { arrayMultiSplit } from "../../../helpers/arrayutils";
import Pagination from "../../../shared/components/basictable/pagination";
import ThresholdSlider from "../../../components/threshold-slider";
import SuggestionList from "../../../components/image-list/SuggestionList";
import AddNewClass from "../../../components/add-class";

const SuggestionResultFix = observer((props) => {
    const initialProbabilityTreshold = 0.8;
    const classes = useStyles();
    const params = useParams();
    const history = useHistory();
    const { t } = useTranslation();

    const trainingManagementStore = useContext(TrainingManagementStore);
    const { fetchSuggestionResult } = trainingManagementStore

    const appStore = useContext(AppStore);
    const { addBreadcrumb, updateLastBreadcrumb, removeLastBreadcrumb, setLoader } = appStore;

    const [selectedClasses, setSelectedClasses] = useState([]);
    const [checkedClasses, setCheckedClasses] = useState([]);
    const [selectedClassesData, setSelectedClassesData] = useState([]);
    const [actualClasses, setActualClasses] = useState([]);
    const [currentClasses, setCurrentClasses] = useState([]);
    const [totalClasses, setTotalClasses] = useState([]);
    const [classCount, setClassCount] = useState(0);
    const [showGraph, setShowGraph] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const [probabilityTreshold, setProbabilityTreshold] = useState(initialProbabilityTreshold);
    const [showTransferedImagesOnly, setShowTransferedImagesOnly] = useState(false);
    const [training, setTraining] = useState({});
    const [addClass, setAddClass] = useState(false);

    const [page, setPage] = useState({
        pageSize: 5,
        pageNo: 1
    });

    const setBreadCrumbs = () => {
        removeLastBreadcrumb();
        updateLastBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
            label: "pages.training.training-parameter.breadcrumb.training"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
            label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", actualClasses.join(",")),
            label: "pages.training.training-parameter.breadcrumb.subclassification"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX,
            label: "pages.training.training-parameter.breadcrumb.suggestionResultDisplay"
        });
    };

    useEffect(() => {
        setBreadCrumbs();
        getClassList();
    }, []);

    useEffect(() => {
        splitClasses(page);
    }, [selectedClasses]);

    const splitClasses = (obj) => {
        let pageNo = obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo;
        let selectedClass = arrayMultiSplit(selectedClasses, obj?.pageSize);
        setTotalClasses(selectedClasses);
        selectedClass?.length > 0 && setCurrentClasses(selectedClass[pageNo]);
    }

    const onPagination = (obj) => {
        setPage(obj);
        splitClasses(obj);
    }

    const handleShowGraphToggle = () => {
        setShowGraph((prevOpen) => !prevOpen);
    };

    const getClassList = async () => {
        if (params?.id) {
            setLoader(true);
            let response = await fetchSuggestionResult(params.id, params.batchNo);
            if (response?.status == 200 && response?.data) {
                setLoader(false);
                if (response?.training) {
                    setTraining(response?.data?.training);
                }
                setClassCount(response?.count);
                setSelectedClassesData(response?.data);
                let seqNos = response?.data.map((res) => res.seqNo);
                let actualClass = [];
                response?.data?.filter(res => res?.isSubClass && actualClass.push(res.seqNo));
                setActualClasses(actualClass);
                setSelectedClasses(seqNos);
                setCheckedClasses(seqNos);
            } else {
                setLoader(false);
            }
        }
    }

    const handleBackButton = () => {
        history.goBack();
    }

    const handleTresholdChangeCommit = (tresholdValue) => {
        setProbabilityTreshold(tresholdValue);
    };

    const createClass = (id, className) => {
        setLoader(true);
        trainingManagementStore
            .suggestionResultCreateClass(params.id, { className, seqNo: parseInt(params.batchNo) })
            .then((response) => {
                setLoader(false);
                if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                    // updateClassData(response.data);
                    setClassCount(classCount + 1);
                    let selectedClass = arrayMultiSplit(selectedClassesData, page?.pageSize)
                    selectedClass[page?.pageNo - 1].unshift(response?.data)
                    selectedClass = [].concat.apply([], selectedClass);
                    console.log("selectedClass", selectedClass);
                    // selectedClassesData.unshift(response?.data);
                    setSelectedClassesData(selectedClass);
                    let seqNos = selectedClass.map((res) => res.seqNo);
                    let actualClass = [];
                    selectedClass?.filter(res => res?.isSubClass && actualClass.push(res.seqNo));
                    setActualClasses(actualClass);
                    setSelectedClasses(seqNos)
                    // setCurrentClasses(currentClass);
                    setCheckedClasses(seqNos);
                }
            })
            .catch((erro) => {
                // t("pages.training.input-parameter.modal.already-exist")
                setLoader(false);
            });
    }

    return (
        <Observer>
            {() => (
                <div>
                    <Paper className={classes.pageContent}>
                        <AddNewClass
                            open={addClass}
                            dataset={selectedClassesData}
                            setAddClass={setAddClass}
                            handleCreateClass={createClass}
                        />
                        <div className={classes.top}>
                            <div className={classes.wrapContent}>
                                <BackButton handleBackButton={handleBackButton} />
                                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
                            </div>

                            <div className={classes.buttonWrapper}>
                                <Button color="primary" variant="contained" onClick={() => setExpanded(!expanded)}>
                                    {expanded ? t("pages.training.manageImages.controls.expandAll") : t("pages.training.manageImages.controls.collapseAll")}
                                </Button>
                                <Button color="primary" onClick={() => {
                                    setAddClass(true)
                                }} variant="contained">
                                    {t("pages.training.suggestion-result.controls.add-class")}
                                </Button>
                            </div>
                        </div>
                        <Divider className={classes.divider} />
                        <br />
                        <div>
                            <hr className={classes.imageLegendAuto} />
                            <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.autoLegend")}</div>
                            <hr className={classes.imageLegendManual} />
                            <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.manualLegend")}</div>
                            <hr className={classes.imageLegendNone} />
                            <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.noneLegend")}</div>
                        </div>
                        <div className={classes.controlContainer}>
                            <Pagination
                                disabled={false}
                                disableItemPerPage={true}
                                itemCount={classCount}
                                onChange={onPagination}
                                pageNo={page.pageNo}
                                pageSize={page.pageSize}
                            />
                            <FormControlLabel
                                control={<Switch checked={showGraph} onChange={handleShowGraphToggle} name="showGraph" color="primary" />}
                                label={t("pages.training.suggestion-result.controls.show-graph")}
                                labelPlacement="start"
                            />
                            <ThresholdSlider
                                onThresholdChange={handleTresholdChangeCommit}
                                disabled={false}
                                initialProbabilityTreshold={initialProbabilityTreshold}
                                decimalPoints={4}
                            />
                        </div>
                        {
                            currentClasses?.length > 0 && currentClasses.map((seqNo) => {
                                return <SuggestionList showTransferedImagesOnly={showTransferedImagesOnly} probabilityTreshold={probabilityTreshold} url={API_URL.CORRECTION_IMAGES} seqNo={seqNo} trainingDetails={training} order={{ desc: "updatedAt" }} key={"image-" + seqNo} expand={expanded} imageType={"all"} showAddImage={false} trainingClasses={selectedClassesData} showEditClassName showDeleteImage={false} pageSize={5}
                                    paginationPosition="topRight" imageSelection showEditClass carouselView={false} />;
                            })
                        }
                        <div className={classes.bottom}>
                            <div className={classes.buttonWrapper}>

                            </div>
                        </div>
                    </Paper>
                </div>
            )}
        </Observer>
    );
});

export default SuggestionResultFix;
