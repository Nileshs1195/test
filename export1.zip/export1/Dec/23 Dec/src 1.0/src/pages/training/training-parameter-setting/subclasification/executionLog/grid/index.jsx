import { useContext } from "react";
import { Table, TableBody, TableHead } from "../../../../../../shared/components/basictable";
import AppStore from "./../../../../../../stores/appstore";

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions
}) => {
  const appStore = useContext(AppStore);
  const onRowSelect = () => {}

  return (
    <Table loading={loading} className={containerClassName}>
      <TableHead
        rowCount={records.length}
        headerData={columnDefinitions}
        filters={appStore.inspectionSearchFilter.filter}
        noEmptyColumn={true}
        sort={appStore.inspectionSearchFilter.sort}
      />
      <TableBody
        bodyData={records}
        noEmptyColumn={true}
        headerData={columnDefinitions}
        onRowSelect={onRowSelect}
      />
    </Table>
  );
};

export default Grid;
