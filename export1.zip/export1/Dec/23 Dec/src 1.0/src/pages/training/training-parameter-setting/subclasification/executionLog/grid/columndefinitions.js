export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true,
  },
  {
    key: "iteration",
    text: "pages.training.subclassification-execution-log.grid.iteration",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainLoss",
    text: "pages.training.subclassification-execution-log.grid.main-loss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainAccuracy",
    text: "pages.training.subclassification-execution-log.grid.main-accuracy",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
];
