import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  thumbItem: {
    position: "relative",
    "&:hover $thumbCheckbox": {
      display: "flex",
      backgroundColor: "white"
    },
    "@media (min-width: 960px)": {
      maxWidth: "20%"
    }
  },
  thumbCheckbox: {
    display: "none",
    position: "absolute",
    zIndex: 5,
    right: 12,
    top: 4,
    width: "16px",
    height: "16px",
    backgroundColor: "white",
    "&.Mui-checked": {
      display: "flex",
      backgroundColor: "white"
    }
  },
  transferedAndMovedThumbImg: {
    width: "100%",
    height: "130px",
    borderBottom: "3px solid #3a5faa"
    // boxShadow: "0px 2px 0px #3a5faa, 0px -2px 0px #dd0a55"
  },
  transferedThumbImg: {
    width: "100%",
    height: "130px",
    // boxShadow: "0px 2px 0px #3a5faa"
    borderBottom: "3px solid #3a5faa"
  },
  movedThumbImg: {
    width: "100%",
    height: "130px",
    borderTop: "3px solid #dd0a55"
    // boxShadow: "0px -2px 0px #dd0a55"
  },
  thumbImg: {
    width: "100%",
    height: "130px"
  },
  popover: {
    pointerEvents: "none"
  },
  popover_paper: {
    padding: theme.spacing(2)
  },
  imageCenter: {
    position: "relative",
    width: "100%",
    height: "100%",
    objectFit: "cover",
    overflow: "hidden",
  }
}));
