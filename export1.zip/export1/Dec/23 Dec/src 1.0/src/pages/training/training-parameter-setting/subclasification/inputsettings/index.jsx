import React, { useContext, useEffect, useState } from "react";
import { Button, Divider, Paper } from "@material-ui/core";
import { Observer } from "mobx-react-lite";
import { useTranslation } from "react-i18next";
import { columnDefinitions } from "../grid/columndefinitions";
import TrainingManagementStore from "../../../../../stores/trainingmanagementstore";
import Grid from "../grid";
import { useStyles } from "./style";
import ImageManagementStore from "./../../../../../stores/imagemanagementstore";

const InputSetting = props => {
  const {
    loading,
    isEditAndNextDisabled,
    disableAddButton,
    disableEditButton,
    handleNewInputParameterModal,
    disableMaskingButton
  } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const [datasets, setDatasets] = useState([]);
  const [isMasking, setMasking] = useState(false);
  const {
    selectedInputParameterCount,
    TrainingInputparameter
  } = trainingManagementStore;

  useEffect(() => {
    setDatasets([]);
    if (TrainingInputparameter?.length > 0) {
      setDatasets([...TrainingInputparameter]);
    }
  }, [TrainingInputparameter])

  return (
    <Observer>
      {() => (
        <>
          <Paper variant="outlined" className={classes.paperCustom}>
            <div className={classes.paperTitle}>
              {t("pages.training.input-parameter.input-settings")}{" "}
            </div>
            <Divider className={classes.divider} />
            <Grid
              loading={loading}
              records={datasets}
              containerClassName={
                selectedInputParameterCount > 0
                  ? classes.tableContainerFooter
                  : classes.tableContainer
              }
              columnDefinitions={columnDefinitions}
              disableAddButton={disableAddButton}
              disableEditButton={disableEditButton}
              disableMasking={disableMaskingButton}
              disableCheckBox={(imageManagementStore.imageUploadStatus === 'in-progress')}
            />

            {selectedInputParameterCount > 0 && (
              <div className={classes.footerContainer}>
                <div className={classes.buttonGroup}>
                  <span className={classes.noOfDevicesWrapper}>
                    {t("pages.training.input-parameter.controls.selected")}
                    {" : "}
                    {trainingManagementStore.selectedInputParameterCount}
                  </span>
                </div>
                <div className={classes.buttonGroup}>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleNewInputParameterModal("DELETE")}
                  >
                    {t("pages.training.input-parameter.controls.delete")}
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    className={classes.buttons}
                    disabled={isEditAndNextDisabled}
                    onClick={() => handleNewInputParameterModal("EDIT")}
                  >
                    {t("pages.training.input-parameter.controls.edit-class")}
                  </Button>
                  {/* <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    disabled={isMasking}
                    onClick={() => handleNewInputParameterModal("MASKING")}
                  >
                    {t("pages.training.input-parameter.controls.masking")}
                  </Button> */}
                  {/* <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleNewInputParameterModal("EXECUTE")}
                  >
                    {t("pages.training.input-parameter.controls.execute")}
                  </Button> */}
                </div>
              </div>
            )}
          </Paper>
        </>
      )}
    </Observer>
  );
};

export default InputSetting;
