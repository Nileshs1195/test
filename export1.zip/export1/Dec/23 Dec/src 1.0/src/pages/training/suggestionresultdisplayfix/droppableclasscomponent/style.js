import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    paddingBottom: "8px",
    padding: "0px 8px",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  thumbWrap: {
    margin: "8px 0px 0px 0px"
  },
  thumbItem: {
    position: "relative",
    "&:hover $thumbCheckbox": {
      display: "flex",
      backgroundColor: "white"
    },
    "@media (min-width: 960px)": {
      maxWidth: "11.11%"
    }
  },
  thumbCheckbox: {
    display: "none",
    position: "absolute",
    zIndex: 5,
    right: 12,
    top: 12,
    width: "16px",
    height: "16px",
    backgroundColor: "white",
    "&.Mui-checked": {
      display: "flex",
      backgroundColor: "white"
    }
  },
  noContentLabel: {
    marginTop: "-.5em",
  },
  noContent: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
  },
  warningIcon: {
    fontSize: "4rem",
    color: "#00000020",
  },
  trainingThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #3a5faa"
  },
  validationThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #dd0a55"
  },
  popover: {
    pointerEvents: "none"
  },
  popover_paper: {
    padding: theme.spacing(2)
  },
  bottom: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    paddingBottom: "16px",
    padding: "0px 16px",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  buttonWrapper: {
    display: "flex",
    alignSelf: "center"
  },
  accMarginTop: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2)
  },
  accSummary: {
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      minHeight: "48px !important",
      padding: "8px 16px"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  accDetails: {
    padding: 0,
    display: "block"
  },
  fileUpload: {
    display: "none"
  },
  modalTextPadding: {
    paddingBottom: "16px"
  },
  confirmationModalPadding: {
    paddingTop: theme.spacing(2)
  },
  confirmationModalWidth: {
    minWidth: "25%",
    maxWidth: "25%",
    minHeight: "auto"
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: 18,
    fontWeight: "normal",
    height: "42px",
    margin: "-16px -16px 0px -16px",
    padding: "8px 16px",
    borderRadius: "4px 4px 0 0"
  },
  formControl: {
    minWidth: "100%"
  },
  leftImageSection: { display: "flex", flexDirection: "row", justifyContent: "flex-end" },
  rightImageSection: { display: "flex", flexDirection: "row", justifyContent: "flex-start" },
  button: {
    marginLeft: theme.spacing(2)
  },
  left: {
    position: "relative",
    width: "55.55%",
    flexBasis: "55.5%",
    maxWidth: "55.5%",
    margin: "8px 0px",
    borderRight: "solid 2px red",
    // zIndex: 0,
    "& .MuiGrid-item": {
      padding: "0px 8px",
      flexBasis: "inherit",
      maxWidth: "20%"
    }
  },
  navL: {
    position: "absolute",
    right: "0px",
    top: "-68px",
    // zIndex: "5",
    padding: "2px",
    "& div[class*='makeStyles-controlContainer-'] div:not(:first-of-type)": {
      display: "none"
    }
  },
  right: {
    position: "relative",
    width: "44.44%",
    flexBasis: "44.4%",
    maxWidth: "44.4%",
    margin: "8px 0px",
    // zIndex: 0,
    "& .MuiGrid-item": {
      padding: "0px 8px",
      flexBasis: "inherit",
      maxWidth: "25%"
    }
  },
  navR: {
    position: "absolute",
    right: "48px",
    top: "-68px",
    // zIndex: "5",
    padding: "2px",
    "& div[class*='makeStyles-controlContainer-'] div:not(:first-of-type)": {
      display: "none"
    }
  },
  classCheckboxWrap: {
    maxWidth: "calc(57% - 146px)",
    overflow: "hidden",
    whiteSpace: "nowrap",
    textOverflow: "ellipsis",
    display: "block"
  }
}));
