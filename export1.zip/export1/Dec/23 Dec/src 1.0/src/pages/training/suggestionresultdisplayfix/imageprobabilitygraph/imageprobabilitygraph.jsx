import { Observer } from "mobx-react-lite";
import { Grid } from "@material-ui/core";
import { useState, useContext, useEffect } from "react";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import { Loader } from "../../../../shared/components/ui";
import { API_RESPONSE } from "../../../../appconstants";
import RangeSelector, { Scale, Label, SliderMarker, Margin, Export } from "devextreme-react/range-selector";
import {
  Chart,
  Series,
  ArgumentAxis,
  CommonSeriesSettings,
  CommonAxisSettings,
  // Grid,
  // Export,
  Legend,
  // Margin,
  Tooltip,
  // Label,
  Format,
  VisualRange,
  ValueAxis
} from "devextreme-react/chart";
import { useStyles } from "./style";
import "./style.css";
import ImageManagementStore from "../../../../stores/imagemanagementstore";
import { useTranslation } from "react-i18next";

const ImageProbabilityGraph = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const { trainingId, classSeqNo, setGraphData, onRangeChange, onPointClick, probabilityTreshold } = props;
  const xAxisData = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { selectedClassImages } = imageManagementStore;
  const [graphLoader, setGraphLoader] = useState(false);
  const [totalImages, setTotalImages] = useState(0);
  const [graphDetails, setGraphDetails] = useState([]);
  const [graphRawData, setGraphRawData] = useState([]);

  useEffect(() => {
    getGraphData();
  }, [trainingId, classSeqNo, trainingManagementStore.suggestionResultData]);

  const getGraphData = async () => {
    setGraphLoader(true);
    let graphDataList = await trainingManagementStore.getSuggestionResultProbabilityGraphDetails(trainingId, classSeqNo, { probability: probabilityTreshold });
    if (graphDataList?.status === API_RESPONSE.SUCCESS_STATUS_CODE && graphDataList?.data?.length > 0) {
      setGraphRawData(graphDataList.data);
      let graphData = [];

      graphDataList?.data.sort((a, b) => (a.probability > b.probability) ? 1 : ((b.probability > a.probability) ? -1 : 0)).reverse();

      graphDataList?.data?.forEach((item, key) => {
        let probability = Number(parseFloat(item?.probability).toFixed(4));
        let probabilityPoints = Number(parseFloat(item?.probability).toFixed(4));
        // const index = graphData.findIndex((x) => x.probability === probability);
        // if (index >= 0) {
        //   // graphData[index].imageCount++;
        // } else {
        // }
        graphData.push({ probability: probability, prob: probabilityPoints, seqNo: item.seqNo, itemKey: key + 1 });
      });
      // console.log("graphData", graphData);
      setGraphData(graphData);
      setTotalImages(graphData?.length);
      setGraphDetails(graphData);
    }
    setGraphLoader(false);
  };

  const customizePoint = (value) => {
    let selectedImages = JSON.parse(JSON.stringify(imageManagementStore?.selectedClassImages));
    let result = { color: t("pages.training.suggestion-result.graph.point-color"), visible: true };
    selectedImages.forEach((img) => {
      if (value?.data?.seqNo === img.imageSeqNo) {
        result = { color: t("pages.training.suggestion-result.graph.selected-point-color"), visible: true };
      }
    });

    return result;
  }

  return (
    <Observer>
      {() =>
        graphLoader ? (
          <Loader size={24} />
        ) : graphDetails.length > 0 ? (
          <Grid container spacing={0}>
            {/* <Grid item className={classes.axisLabels}>
              <div className={classes.labels}>
                {xAxisData.map(data => <div className={classes.label1}>{data}</div>)}
              </div>
            </Grid> */}
            <Grid item xs className={classes.graphItem}>
              {/* <RangeSelector
                id="range-selector"
                dataSource={graphDetails}
                onValueChanged={(value) => onRangeChange(value, graphRawData, totalImages)}
                defaultValue={[0.0, totalImages]}
              >
                <Margin left={20} />
                <Scale tickInterval={5} showCustomBoundaryTicks={false} minorTickInterval={1} startValue={1} endValue={totalImages}>
                  <Label>
                    <Format type="decimal" />
                  </Label>
                </Scale>
                <SliderMarker visible={true} /> */}
              <Chart id="range-selector"
                pointSelectionMode="multiple"
                point={{
                  color: "#f00"
                }}
                customizePoint={customizePoint}
                onPointClick={(event) => onPointClick(event, graphDetails)}
                dataSource={graphDetails}>
                {/* <CommonSeriesSettings
                  argumentField="itemKey"
                  valueField="probability"
                  type={"fullstackedspline"}
                />
                <CommonAxisSettings

                  // wholeRange={{
                  //   startValue: 0,
                  //   endValue: 100,
                  //   length: 10
                  // }}
                >
                  <Grid visible={false} />
                </CommonAxisSettings> */}


                <CommonSeriesSettings
                  argumentField="itemKey"
                  type="fullstackedspline"
                />
                <CommonAxisSettings>
                  <Grid visible={false} />
                </CommonAxisSettings>

                <Series type="spline" valueField="probability" name="Probability" color={t("pages.training.suggestion-result.graph.line-color")} />
                {/* <Series argumentField="prob" type="spline" name="" color="#ffffff" /> */}
                <Margin bottom={20} />
                <ArgumentAxis
                  allowDecimals={false}
                  axisDivisionFactor={2}
                >
                  <Label>
                    <Format type="decimal" />
                  </Label>
                </ArgumentAxis>

                <ValueAxis
                  tickInterval={0.2}
                  valueMarginsEnabled={false}
                >
                  <VisualRange
                    startValue={0.0}
                    endValue={1.0}
                  />
                  <Label>
                    <Format
                      precision={0}
                    />
                  </Label>
                </ValueAxis>
                {/* <Export enabled={true} /> */}
                <Tooltip enabled={true} />
                {/* <ArgumentAxis allowDecimals={false} axisDivisionFactor={60}>
                  <Grid visible={false} />
                  <Label>
                    <Format type="decimal" />
                  </Label>
                </ArgumentAxis> */}

                {/* <ValueAxis wholeRange={{
                  startValue: 0,
                  endValue: 100
                }} allowDecimals={false} axisDivisionFactor={10} name="percentageAxis">
                  <Label
                    staggeringSpacing={10}
                    displayMode="stagger"
                  />
                  <Grid visible={false} />
                </ValueAxis> */}
                {/* <ValueAxis categories={[1, totalImages]} argumentField="itemKey" name="itemKey" title="Count">
                    <Grid visible={true} />
                  </ValueAxis>
                  <ValueAxis name="probability" position="left" valueField="probability" title="Probability">
                    <Grid visible={true} />
                  </ValueAxis> */}
              </Chart>
              {/* </RangeSelector> */}
            </Grid>
          </Grid>
        ) : null
      }
    </Observer>
  );
};
export default ImageProbabilityGraph;
