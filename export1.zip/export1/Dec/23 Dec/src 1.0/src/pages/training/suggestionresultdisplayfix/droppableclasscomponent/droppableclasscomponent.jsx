import { Observer } from "mobx-react-lite";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { Droppable } from "react-beautiful-dnd";
import { useStyles } from "./style";
import { useState, useRef, useContext, useEffect } from "react";
import { useTranslation } from "react-i18next";
import {
  Grid,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Checkbox,
  FormControlLabel,
  Button,
  FormControl,
  TextField
} from "@material-ui/core";
import ImageManagementStore from "../../../../stores/imagemanagementstore";
import DatasetClassImage from "../datasetclassimage/datasetclassimage";
import Pagination from "../../../../shared/components/basictable/pagination";
import CustomSnackBar from "../../../../components/snackbar";
import { Autocomplete } from "@material-ui/lab";
import Modal from "../../../../shared/components/ui/modal";
import Modals from "../modals/modal";
import * as CommonMethod from "../commonMethods";
import ImageProbabilityGraph from "./../imageprobabilitygraph/imageprobabilitygraph";
import { useParams } from "react-router-dom";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import { API_RESPONSE } from "../../../../appconstants";
import { ErrorOutline } from "@material-ui/icons";
import { Loader } from "../../../../shared/components/ui";
import AppStore from "../../../../stores/appstore";

const ClassComponent = (props) => {
  const {
    classData,
    key,
    classesAvailable,
    showGraph,
    suggestionList,
    showTransferedImagesOnly,
    probabilityTreshold,
    imageClassEditAction,
    updateClassName,
    selectedClass,
    selectedSeqNos
  } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [alertSnackBar, toggleAlertSnackBar] = useState(false);
  const [higherPagination, setHigherPagination] = useState(0);
  const [lowerPagination, setLowerPagination] = useState(0);
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [imageClassModal, toggleImageClassModal] = useState(false);
  const [asideLoader, setAsideLoader] = useState([]);
  const [isEditClassButton, setIsEditClassButton] = useState(false);
  const [totalImages, setTotalImages] = useState(false);
  const imageManagementStore = useContext(ImageManagementStore);
  const [imageArray, setImageArray] = useState([]);
  const [currentClassData, setCurrentClassData] = useState(classData);
  const [graphData, setGraphData] = useState([]);
  const [probabilityTresholdValue, setProbabilityTresholdValue] = useState(0);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const appStore = useContext(AppStore);
  let selectedImageClass;
  const classNameList = classesAvailable.filter((item, index, inputArray) => item.label !== classData.className);

  useEffect(() => {
    if (classData.selected) {
      setProbabilityTresholdValue(probabilityTreshold);
    }
  }, [probabilityTreshold]);

  useEffect(() => {
    getImagesList();
  }, [
    showTransferedImagesOnly,
    appStore.selectedSuggestionResultClass.length,
    probabilityTresholdValue,
    higherPagination,
    lowerPagination,
    suggestionList,
    trainingManagementStore.suggestionResultData
  ]);

  useEffect(() => {
    selectedClass(classData);
  }, []);

  useEffect(() => {
    let index = trainingManagementStore.suggestionResultData.findIndex((e) => e.seqNo === classData.seqNo);
    const suggestionData = JSON.parse(JSON.stringify(trainingManagementStore.suggestionResultData));
    const imageData = suggestionData[index]?.list;
    if (imageData) {
      setImageArray({
        imageLeft: imageData.imageLeft,
        imageRight: imageData.imageRight,
        imageLeftCount: imageData.imageLeft ? imageData.imageLeft.length : 0,
        imageRightCount: imageData.imageRight ? imageData.imageRight.length : 0
      });
    }
  }, [trainingManagementStore.suggestionResultData, classData]);

  const getImagesList = () => {
    let isExist = selectedSeqNos.map((e) => Number(e)).indexOf(classData.seqNo);
    if (isExist !== -1) {
      let paginationData = {
        left: {
          from_index: higherPagination,
          end_index: higherPagination + 5
        },
        right: {
          from_index: lowerPagination,
          end_index: lowerPagination + 4
        }
      };
      let data = {
        probability: probabilityTresholdValue,
        conditions: [
          {
            column: "modeOfChange",
            case: "lte",
            value: 2
          }
        ],
        desc: "probabilityValue",
        paginationData
      };
      if (showTransferedImagesOnly) {
        setAsideLoader("");
        data = {
          ...data,
          conditions: [
            {
              column: "modeOfChange",
              case: "ne",
              value: 0
            }
          ],
          desc: "probability"
        };
      }
      trainingManagementStore
        .subclassificationSuggestionImages(params.id, classData.seqNo, data)
        .then((res) => {
          setAsideLoader("");
          if (res.status === 200) {
            let index = trainingManagementStore.suggestionResultData.findIndex((e) => e.seqNo === classData.seqNo);
            trainingManagementStore.suggestionResultData[index].list = {
              imageLeft: res.data.imageLeft,
              imageRight: res.data.imageRight
            };
            let leftImages = res.data.imageLeft
              // .sort((a, b) => (a.probability > b.probability ? 1 : b.probability > a.probability ? -1 : 0))
              // .reverse();

            let rightImages = res.data.imageRight
              // .sort((a, b) => (a.probability > b.probability ? 1 : b.probability > a.probability ? -1 : 0))
              // .reverse();
            setImageArray({
              imageLeft: leftImages,
              imageRight: rightImages,
              imageLeftCount: res.data.imageLeftCount,
              imageRightCount: res.data.imageRightCount
            });
            let images = trainingManagementStore.subclassificationImages;
            if (res?.data?.imageLeft?.length > 0) {
              res?.data?.imageLeft.forEach((image) => {
                if (!images.includes(image)) {
                  images.push(image);
                }
              });
            }
            if (res?.data?.imageRight?.length > 0) {
              res?.data?.imageRight.forEach((image) => {
                if (!images.includes(image)) {
                  images.push(image);
                }
              });
            }
            setTotalImages(res?.data?.imageLeftCount + res?.data?.imageRightCount);
            trainingManagementStore.setSubclassificationImages(images);
          }
        })
        .catch((error) => {
          setAsideLoader("");
        });
    }
  };

  const onHigherPagination = async (indexObj) => {
    // if(!showTransferedImagesOnly) {
    //   setAsideLoader("left");
    // }
    setHigherPagination((indexObj.pageNo > 0 ? indexObj.pageNo - 1 : indexObj.pageNo) * indexObj.pageSize);
  };

  const onLowerPagination = (indexObj) => {
    // if(!showTransferedImagesOnly) {
    //   setAsideLoader("right");
    // }
    setLowerPagination((indexObj.pageNo > 0 ? indexObj.pageNo - 1 : indexObj.pageNo) * indexObj.pageSize);
  };

  const setChangeImageClassModel = () => {
    toggleImageClassModal((isOpen) => !isOpen);
  };

  const isSelected = (seqNo) => {
    const selected = imageManagementStore.selectedClassImages.filter((item) => item.imageSeqNo === seqNo && item.classSeqNo === classData.seqNo);
    return selected.length > 0;
  };

  const onImageSelect = (event, seqNo) => {
    const selected = isSelected(seqNo);
    if (selected) {
      imageManagementStore.removeSelectedClassImage([seqNo], classData.seqNo);
    } else {
      imageManagementStore.setSelectedClassImage([seqNo], classData);
    }
  };

  const emptyColumn = () => {
    return (
      <div className={classes.noContent}>
        <span>
          <ErrorOutline fontSize="large" className={classes.warningIcon} />
        </span>
        <span className={classes.noContentLabel}>{t("components.basic-table.no-content")}</span>
      </div>
    );
  };

  const renderImages = (images, imageClass, count) => {
    return images?.length > 0 && <Grid container spacing={0}  className={imageClass}>
      {images.map((image, key) => key < count && <DatasetClassImage suggestionList={suggestionList} imageData={image} index={image.seqNo} onImageSelect={onImageSelect} classSeqNo={classData.seqNo} />)}
    </Grid> 
  }

  const renderClassImages = () => {
    return (
      <Droppable direction={"horizontal"} droppableId={classData.seqNo.toString()}>
        {(provided) => (
          <div {...provided.droppableProps} ref={provided.innerRef}>
            <div className={classes.container}>
              <div className={classes.thumbWrap}>
                <Grid container spacing={0} key={key}>
                  <Grid item xs={7} md={6} className={classes.left}>
                    <div className={classes.navL}>
                      <Pagination
                        onChange={onHigherPagination}
                        itemCount={imageArray?.imageLeftCount}
                        pageNo={higherPagination + 1}
                        pageSize={5}
                        disableItemPerPage={true}
                        disabled={false}
                      />
                    </div>
                    {asideLoader === "left" && <Loader style={{ zIndex: 99 }} size={24} />}
                    {renderImages(imageArray?.imageLeft, classes.leftImageSection, 5)}
                  </Grid>
                  <Grid item xs={5} md={6} className={classes.right}>
                    <div className={classes.navR}>
                      <Pagination
                        onChange={onLowerPagination}
                        itemCount={imageArray?.imageRightCount}
                        pageNo={lowerPagination + 1}
                        pageSize={4}
                        disableItemPerPage={true}
                        disabled={false}
                      />
                    </div>
                    {asideLoader === "right" && <Loader style={{ zIndex: 99 }} size={24} />}
                    {renderImages(imageArray?.imageRight, classes.rightImageSection, 4)}
                  </Grid>
                </Grid>
              </div>
            </div>
          </div>
        )}
      </Droppable>
    );
  };

  const setAlertMessage = () => {
    toggleAlertSnackBar((isOpen) => !isOpen);
  };

  const handleOnClick = (event) => {
    selectedClass(classData);
    event.stopPropagation();
  };

  const changeSelectedImageClass = () => {
    setModalFormErrors({});
    setChangeImageClassModel();
  };

  // validate each field
  const validateField = (errorObj, fieldName, fieldNameError) => {
    errorObj.isFormValid = false;
    errorObj.modalFormErrors[fieldName] = true;
    errorObj.modalFormErrors[fieldNameError] = t("pages.image-management.image-group-list.modal.error-text");
    return errorObj;
  };

  const validateModalForm = () => {
    let errorObj = {
      isFormValid: true,
      modalFormErrors: {}
    };

    if (!selectedImageClass || selectedImageClass === "" || selectedImageClass === null) {
      errorObj = validateField(errorObj, "className", "classNameErrorMsg");
    }

    setModalFormErrors(errorObj.modalFormErrors);
    return errorObj.isFormValid;
  };

  const handleImageClassEdit = async () => {
    const selectedImages = imageManagementStore.selectedClassImages
      .filter((item) => item.classSeqNo === classData.seqNo)
      .map((element) => element.imageSeqNo);

    const saveImageData = {
      src_seqNo: classData.seqNo,
      dst_seqNo: selectedImageClass.value,
      seqNos: selectedImages
    };
    setAsideLoader("");

    await trainingManagementStore.suggestionResultImageMove(params.id, saveImageData).then((response) => {
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        const newMessageObj = {
          message: t("pages.training.manageImages.messages.imageRecordUpdated")
        };
        setAlertMessage();
        setsnapbarMessage(newMessageObj);
        imageManagementStore.removeSelectedClassImage(selectedImages, classData.seqNo);
        imageClassEditAction(classData.seqNo, selectedImageClass.value, selectedImages);
        imageManagementStore.setUpdateImageListForClass(true);
        console.log("Image group record modified successfully");
      } else {
        console.log("Error occurred while saving image group record");
      }
    });
  };

  const confirmChangeImageClass = () => {
    let isValid = validateModalForm();
    if (isValid) {
      handleImageClassEdit();
    } else {
      // if the modal form fields are empty, the modal will be opened up using below function
      setChangeImageClassModel();
    }
  };

  const onSelectImageClass = (event, value) => {
    selectedImageClass = value;
  };
  const checkClassName = (name) => {
    if (trainingManagementStore.suggestionResultData.length > 0) {
      return trainingManagementStore.suggestionResultData.some((item) => item.className.toLowerCase() === name.toLowerCase());
    }
    return false;
  };
  const handleModalFormErrors = (errorData) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, errorData));
  };
  const handleClassData = (name, value) => {
    setCurrentClassData((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };
  const onChangeFieldData = (event) => {
    let errMsg = [];
    errMsg["errExist"] = t("pages.training.input-parameter.modal.already-exist");
    errMsg["errAlphanumeric"] = t("pages.training.input-parameter.modal.alphanumeric");
    CommonMethod.onChangeDataSetting(event, handleClassData, handleModalFormErrors, checkClassName, errMsg);
  };

  const handleEditClass = () => {
    const index = trainingManagementStore.suggestionResultData.findIndex((element) => element.seqNo === classData.seqNo);
    trainingManagementStore.suggestionResultData[index] = currentClassData;
    let data = {
      className: currentClassData.className,
      batchSeqNo : params.batchNo
    };
    trainingManagementStore.suggestionResultClassUpdate(params.id, classData.seqNo, data).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        updateClassName(response?.data);
      }
    });
  };

  const showSelectedImage = (seqNo) => {
    // Left Side & Right Side Images
    let leftImages = graphData.filter((item) => item.probability >= probabilityTresholdValue);
    let rightImages = graphData.filter((item) => item.probability < probabilityTresholdValue);

    // Finding Index of Image
    let leftIndex = leftImages.findIndex((item) => item.seqNo === seqNo) + 1;
    let rightIndex = rightImages.findIndex((item) => item.seqNo === seqNo) + 1;

    // Logic
    if (leftIndex !== 0) {
      onHigherPagination({
        pageSize: 5,
        pageNo: Math.ceil(leftIndex / 5)
      });
    } else if (rightIndex !== 0) {
      onLowerPagination({
        pageSize: 4,
        pageNo: Math.ceil(rightIndex / 4)
      });
    }
  };
  const onPointClick = (event, graphDetails) => {
    let index = event?.target?.index;
    if (index >= 0) {
      let selectedImage = graphDetails[index];
      // console.log(selectedImage);
      // let pageCount = 5;
      // let pageType = "left";
      // let images = imageArray.imageRightCount;
      // if (probabilityTresholdValue >= selectedImage.prob) {
      //   pageCount = 4;
      //   pageType = "right";
      //   images = imageArray.imageLeftCount;
      // }
      // let page = 0;
      let selectedClassImages = JSON.parse(JSON.stringify(imageManagementStore?.selectedClassImages));
      if (selectedClassImages?.filter((image) => image.imageSeqNo === selectedImage.seqNo).length > 0) {
        imageManagementStore.removeSelectedClassImage([selectedImage.seqNo], classData.seqNo);
      } else {
        showSelectedImage(selectedImage.seqNo);
        imageManagementStore.setSelectedClassImage([selectedImage.seqNo], classData);
      }
    }
  };

  const onRangeChange = (rangeValue, graphDetails, totalImages) => {
    const selectedImageSeqNos = graphDetails
      .filter((item, key) => key + 1 >= rangeValue?.value[0] && key + 1 <= rangeValue?.value[1])
      .map((element) => element.seqNo);
    toggleAlertSnackBar(false);
    setAsideLoader("");
    imageManagementStore.clearClassSpecificImageSelection(classData.seqNo);
    if (rangeValue?.value?.[0] > 0 || rangeValue?.value?.[1] < totalImages) {
      imageManagementStore.setSelectedClassImage(selectedImageSeqNos, classData);
      if (selectedImageSeqNos?.length > 0) {
        toggleAlertSnackBar(true);
        setsnapbarMessage({
          message: t("pages.training.suggestion-result.modal.messages.selected-image-count", { total: selectedImageSeqNos?.length })
        });
      }
    }
  };

  const onOpen = () => {
    setIsEditClassButton((isOpen) => !isOpen)
    setCurrentClassData(classData)
  }

  const onClose = () => {
    setIsEditClassButton((isOpen) => !isOpen)
    handleClassData("className", "")
  }

  return (
    <Observer>
      {() => (
        <>
          {alertSnackBar ? <CustomSnackBar snapbarMessage={snapbarMessage} /> : null}
          <Modals
            modalType="EDIT-CLASS"
            open={isEditClassButton}
            onClose={onClose}
            onSubmit={handleEditClass}
            inputParameter={currentClassData}
            modalFormErrors={modalFormErrors}
            title={"pages.training.suggestion-result.modal.edit-class"}
            onChangeFieldData={onChangeFieldData}
          />
          <div className={classes.accMarginTop}>
            <Modal
              widthClass={classes.confirmationModalWidth}
              open={imageClassModal}
              onClose={setChangeImageClassModel}
              onSubmit={confirmChangeImageClass}
              showControls
              primaryButtonTextKey={"pages.training.manageImages.modal.ok-btn"}
              secondaryButtonTextKey={"pages.training.manageImages.modal.cancel-btn"}
            >
              <div className={classes.modalTextPadding}>
                <h3 className={classes.modalTitle}>{t("pages.training.manageImages.modal.editImageClassTitle")}</h3>
                <div className={classes.confirmationModalPadding}>
                  <label htmlFor="">{t("pages.training.manageImages.modal.editImageClassMessage")}</label>
                  <br />
                  <form autoComplete="off">
                    <FormControl className={classes.formControl}>
                      <Autocomplete
                        id="combo-box"
                        clearOnEscape
                        options={classNameList}
                        getOptionLabel={(option) => option.label}
                        onChange={(event, value) => onSelectImageClass(event, value)}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Class Name"
                            id="className"
                            name="className"
                            margin="normal"
                            error={modalFormErrors["className"]}
                            helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
                          />
                        )}
                      />
                    </FormControl>
                  </form>
                </div>
              </div>
            </Modal>
            <Accordion defaultExpanded={true} className={classes.accMarginTop}>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
                className={classes.accSummary}
              >
                <Grid container>
                  <FormControlLabel
                    control={
                      <Checkbox
                        // className={classes.thumbCheckbox}
                        color="primary"
                        checked={classData.selected}
                        id={classData.className}
                        name={classData.className}
                        onClick={(event) => handleOnClick(event)}
                      />
                    }
                    onClick={(event) => {
                      handleOnClick(event);
                    }}
                    label={classData.className}
                    className={classes.classCheckboxWrap}
                  />
                </Grid>
              </AccordionSummary>
              <AccordionDetails className={classes.accDetails}>
                {/* {loader && <Loader size={24} />} */}
                {renderClassImages()}
                <div className={classes.bottom}>
                  <div className={classes.buttonWrapper}>
                    <Button
                      color="primary"
                      disabled={classesAvailable.length < 2 || imageManagementStore.getSelectedClassImagesCount(classData.seqNo) === 0}
                      className={classes.button}
                      variant="contained"
                      onClick={() => changeSelectedImageClass()}
                    >
                      {t("pages.training.manageImages.controls.editImageClass")}
                    </Button>
                    <Button
                      color="primary"
                      onClick={onOpen}
                      className={classes.button}
                      variant="contained"
                    >
                      {t("pages.training.manageImages.controls.editClass")}
                    </Button>
                  </div>
                </div>
                {showGraph && totalImages > 0 ? (
                  <ImageProbabilityGraph
                    setGraphData={setGraphData}
                    probabilityTreshold={probabilityTresholdValue}
                    onPointClick={onPointClick}
                    trainingId={params.id}
                    classSeqNo={classData.seqNo}
                    onRangeChange={onRangeChange}
                  />
                ) : null}
              </AccordionDetails>
            </Accordion>
          </div>
        </>
      )}
    </Observer>
  );
};

export default ClassComponent;
