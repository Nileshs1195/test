export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true,
  },
  {
    key: "iteration",
    text: "pages.training.training-execution-log.grid.iteration",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainAccuracy",
    text: "pages.training.training-execution-log.grid.main-accuracy",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validationMainAccuracy",
    text: "pages.training.training-execution-log.grid.validation-main-accuracy",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainLoss",
    text: "pages.training.training-execution-log.grid.main-loss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainEloss",
    text: "pages.training.training-execution-log.grid.main-eloss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validationMainELoss",
    text: "pages.training.training-execution-log.grid.validation-main-eloss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainCloss",
    text: "pages.training.training-execution-log.grid.main-closs",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "mainPloss",
    text: "pages.training.training-execution-log.grid.main-ploss",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  // {
  //   key: "validationMainLoss",
  //   text: "pages.training.training-execution-log.grid.validation-main-loss",
  //   type: "number",
  //   validation: { required: true, pattern: "//" }
  // },
  // {
  //   key: "validationMainCLoss",
  //   text: "pages.training.training-execution-log.grid.validation-main-closs",
  //   type: "number",
  //   validation: { required: true, pattern: "//" }
  // },
  // {
  //   key: "validationMainPLoss",
  //   text: "pages.training.training-execution-log.grid.validation-main-ploss",
  //   type: "number",
  //   validation: { required: true, pattern: "//" }
  // },
  {
    key: "elpasedTime",
    text: "pages.training.training-execution-log.grid.passed-time",
    type: "number",
    validation: { required: true, pattern: "//" }
  }
];
