import { makeStyles, withStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    minHeight: "calc(100vh - 82px)",
    maxHeight: "auto",
    position: "relative",
    paddingBottom: "68px"
  },
  paper: {
    maxHeight: "35%"
  },
  pageHeader: {
    display: "flex"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  mTop: {
    marginTop: "16px"
  },
  top: {
    marginTop: theme.spacing(2),
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  btnBottom: {
    position: "absolute",
    right: "16px",
    bottom: "16px",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2),
    }
  }
}));
