import React, { useState, useContext, useEffect } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button } from "@material-ui/core";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import AppStore from "../../../stores/appstore";
import { API_URL, APP_ROUTES } from "../../../appconstants";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import { useHistory, useParams } from "react-router-dom";
import TrainingManagementStore from "../../../stores/trainingmanagementstore";
import BackButton from "../../../components/backbutton";
import ImageManagementStore from "../../../stores/imagemanagementstore";
import Pagination from "../../../shared/components/basictable/pagination";
import { Loader } from "../../../shared/components/ui";
import { arrayMultiSplit } from "../../../helpers/arrayutils";
import ImageLists from "../../../components/image-list";

const CorrectionResultDisplay = () => {
  const params = useParams();
  const classes = useStyles();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb } = appStore;
  const history = useHistory();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { fetchSuggestionClassList } = trainingManagementStore;
  const [totalClasses, setTotalClasses] = useState([]);
  const [currentClasses, setCurrentClasses] = useState([]);
  const [imageType, setImageType] = useState("all");
  const [loader, setLoader] = useState(false);
  const [selectedClasses, setSelectedClasses] = useState(params.classes);
  const [suggestionClassData, setSuggestionClassData] = useState([]);
  const [expanded, setExpanded] = useState(false);
  const [page, setPage] = useState({
    pageSize: 5,
    pageNo: 1
  });
  const seqNoList = (JSON.parse(localStorage.getItem("selectedTrainingDatasets")))

  useEffect(() => {
    removeLastBreadcrumb();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", seqNoList),
      label: "pages.training.training-parameter.breadcrumb.subclassification"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX.replace(":id", params.id).replace(":batchNo", params.seqNo).replace(":classes", params.classes),
      label: "pages.training.training-parameter.breadcrumb.suggestionResultDisplay"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.CORRECTION_RESULT_DISPLAY,
      label: "pages.training.training-parameter.breadcrumb.correctionResult"
    });
  }, [addBreadcrumb]);

  useEffect(() => {
    splitClasses(page);
  }, [selectedClasses]);

  const splitClasses = (obj) => {
    let pageNo = obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo;
    let selectedClass = arrayMultiSplit(selectedClasses?.split(","), obj?.pageSize);
    setTotalClasses(selectedClasses?.split(","));
    selectedClass?.length > 0 && setCurrentClasses(selectedClass[pageNo]);
  }

  const getImageList = async () => {
    const suggestionClasses = await getSlectedClasses();
    setSuggestionClassData(suggestionClasses);
  };

  const onPagination = (obj) => {
    setPage(obj);
    splitClasses(obj);
  }

  const getSlectedClasses = () => {
    const selectedClassSeqNos = params.classes.split(",").map(Number);
    const classList = JSON.parse(
      JSON.stringify(trainingManagementStore.suggestionClassList?.length > 0 ? trainingManagementStore.suggestionClassList.filter((item) => selectedClassSeqNos.includes(item.seqNo)) : [])
    );
    return classList;
  };

  const handleBackButton = () => {
    history.goBack();
  };

  const gotoTrainParameterSetting = () => {
    setLoader(true);
    trainingManagementStore.storeCorrectionFixData(params.id, params.seqNo).then((response) => {
      setLoader(false);
      if (response.status === 200) {
        trainingManagementStore.setTabIndex(0);
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
      }
    }).catch(error => {
      setLoader(false);
    })

  };

  return (
    <Observer>
      {() => (
        <React.Fragment>
          <div>
            {loader && <Loader size={24} />}
            <Paper className={classes.pageContent}>
              <div className={classes.pageHeader}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <Divider className={classes.divider} />
              <div className={classes.top}>
                <div>
                </div>
                <div className={classes.buttonWrapper}>
                  <Button color="primary" variant="contained" onClick={() => setExpanded(!expanded)}>
                    {expanded ? t("pages.training.manageImages.controls.expandAll") : t("pages.training.manageImages.controls.collapseAll")}
                  </Button>
                </div>
              </div>
              <div className={classes.mTop}>
                <Pagination
                  onChange={onPagination}
                  itemCount={totalClasses.length}
                  pageNo={imageManagementStore.classPaginationStartIndex + 1}
                  pageSize={page.pageSize}
                  disableItemPerPage={true}
                  disabled={false}
                />
              </div>
              {
                currentClasses?.length > 0 && currentClasses.map((seqNo) => {
                  return <ImageLists
                    url={API_URL.CORRECTION_IMAGES}
                    seqNo={seqNo}
                    key={"image-" + seqNo} expand={expanded} order={{ asc: "probabilityValue" }} imageSelection={false} imageType={imageType} showAddImage={false} showDeleteImage={false} showEditClass={false} carouselView={false} />;
                })
              }
              <div className={classes.btnBottom}>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={handleBackButton}
                >
                  {t("pages.training.correction-result.controls.back")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={gotoTrainParameterSetting}
                >
                  {t("pages.training.correction-result.controls.train-data")}
                </Button>
              </div>
            </Paper>
          </div>
        </React.Fragment>
      )}
    </Observer>
  );
};

export default CorrectionResultDisplay;
