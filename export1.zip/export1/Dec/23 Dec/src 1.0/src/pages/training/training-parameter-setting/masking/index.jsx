import { Divider, Paper, Button } from '@material-ui/core';
import { Observer } from 'mobx-react-lite';
import React,{ useState, useContext, useEffect } from 'react'
import BackButton from '../../../../components/backbutton';
import { Breadcrumb } from '../../../../shared/components/ui';
import { useStyles } from './style';
import { useTranslation } from "react-i18next";
import AppStore from "../../../../stores/appstore";
import { API_RESPONSE, API_URL, APP_ROUTES } from "../../../../appconstants";
import { useHistory, useParams } from "react-router-dom";
import Pagination from '../../../../shared/components/basictable/pagination';
import ImageLists from '../../../../components/image-list';
import { arrayMultiSplit, arrayUnique } from '../../../../helpers/arrayutils';
import trainingmanagementstore from '../../../../stores/trainingmanagementstore';
import imagemanagementstore from '../../../../stores/imagemanagementstore';

const Masking = (props) => {
    const params = useParams();
    const classes = useStyles();
    const { t } = useTranslation();
    const history = useHistory();
    const appStore = useContext(AppStore);
    const trainingManagementStore = useContext(trainingmanagementstore);
    const imageManagementStore = useContext(imagemanagementstore);
    const { addBreadcrumb, removeLastBreadcrumb, setsnapbarMessage } = appStore;
    const [selectedClasses, setSelectedClasses] = useState(params.classes);
    const [totalClasses, setTotalClasses] = useState([]);
    const [currentClasses, setCurrentClasses] = useState([]);
    const [expanded, setExpanded] = useState(false);
    const [trainingDetails, setTrainingDetails] = useState([]);
    const [imageType, setImageType] = useState("all");
    const [page, setPage] = useState({
        pageSize: 5,
        pageNo: 1
    });

    const breadCurmbs = () => {
        localStorage.setItem("maskingSeqnos",params.classes);
        removeLastBreadcrumb();
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
            label: "pages.training.training-parameter.breadcrumb.training"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
            label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", params.classes),
            label: "pages.training.training-parameter.breadcrumb.subclassification"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKINGLIST.replace(":id", params.id).replace(":classes", params.classes),
            label: "pages.training.training-parameter.breadcrumb.masking-list"
        });
    };

    useEffect(async()=>{
        breadCurmbs();
        await trainingManagementStore.fetchTrainingDatasetWithTraining(params.id);

        let trainingList = JSON.parse(JSON.stringify(trainingManagementStore.selectedTrainingListData));
        setTrainingDetails(trainingList?.[0]);
    },[]);

    useEffect(() => {
        splitClasses(page);
    }, [selectedClasses]);

    const splitClasses = (obj) => {
        let pageNo = obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo;
        let uniqueClasses = arrayUnique(selectedClasses?.split(","));
        let selectedClass = arrayMultiSplit(uniqueClasses, obj?.pageSize);
        setTotalClasses(uniqueClasses);
        selectedClass?.length > 0 && setCurrentClasses(selectedClass[pageNo]);
    };

    const handleBackButton = ()=>{
        history.goBack();
    }

    const onPagination = (obj) => {
        setPage(obj);
        splitClasses(obj);
    }
 
    const handleExecution = () => {
        const payload = { "seqNos":params.classes.split(",").map(Number) }
        trainingManagementStore.excuteMasking(params.id,payload).then(res=>{
            if(res.status === API_RESPONSE.SUCCESS_STATUS_CODE && res?.data?.seqNo && res?.data?.mode === "masking"){
                history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKING_EXECUTION.replace(":id",params.id).replace(":seqNo",res?.data?.seqNo).replace(":classes",params.classes))
            }else {
                setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
            }
        }).catch((err)=>{
            console.log(err);
        })
    }

    return (
      <Observer>
          {()=>(
              <React.Fragment>
                  <div>
                      <Paper className={classes.pageContent}>
                        <div className={classes.pageHeader}>
                            <BackButton handleBackButton={handleBackButton} />
                            <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
                        </div>
                        <Divider className={classes.divider} />
                        <div className={classes.top}>
                            <div>
                                <hr className={classes.legend} />
                                <div className={classes.legendText}>{t("pages.training.masking.messages.masked-images")}</div>
                            </div>
                            <div className={classes.buttonWrapper}>
                                <Button color="primary" variant="contained" onClick={handleBackButton} >
                                    {t("pages.training.input-parameter.controls.back")}
                                </Button>
                                <Button color="primary" variant="contained" onClick={handleExecution} >
                                    {t("pages.training.input-parameter.controls.execute-masking")}
                                </Button>
                            </div>
                        </div>
                        <div className={classes.mTop}>
                            <Pagination
                                onChange={onPagination}
                                itemCount={totalClasses.length}
                                pageNo={imageManagementStore.classPaginationStartIndex + 1}
                                pageSize={page.pageSize}
                                disableItemPerPage={true}
                                disabled={false}
                            />
                        </div>
                     
                        {currentClasses?.length > 0 &&
                            currentClasses.map((seqNo) => {
                            return (
                                <ImageLists
                                    url={API_URL.GET_IMAGES_FOR_DATASET}
                                    seqNo={seqNo}
                                    trainingDetails={trainingDetails}
                                    order={{ desc: "updatedAt" }}
                                    key={"image-" + seqNo}
                                    expand={expanded}
                                    masking={true}
                                    imageType={imageType}
                                    imageSelection
                                    showEditClass
                                    carouselView
                                    trainingClasses={trainingManagementStore.TrainingDataset} 
                                />
                            );
                            })}
                      </Paper>
                  </div>
              </React.Fragment>
          )}
      </Observer>
    )
}
export default Masking;
