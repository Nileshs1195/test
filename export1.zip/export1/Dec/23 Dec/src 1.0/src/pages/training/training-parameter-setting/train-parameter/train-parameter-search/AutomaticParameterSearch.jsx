import React from "react";
import { useEffect, useContext, useState } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Grid, Typography } from "@material-ui/core";
import { useStyles } from "./style";
import AppStore from "../../../../../stores/appstore";
import { API_RESPONSE, APP_ROUTES } from "../../../../../appconstants";
import Breadcrumb from "../../../../../shared/components/ui/breadcrumb";
import LinearProgressBar from "../../../../../components/linearprogressbar";
import { useTranslation } from "react-i18next";
import { useParams, useHistory } from "react-router-dom";
import BackButton from "../../../../../components/backbutton";
import trainingmanagementstore from "../../../../../stores/trainingmanagementstore";
import CustomSnackBar from "../../../../../components/snackbar";
import CustomConfirmation from "../../../../../components/modal/CustomConfirmation";
import { Loader } from "../../../../../shared/components/ui";

const AutomaticParameterSearch = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const trainingManagementStore = useContext(trainingmanagementstore);
  const { addBreadcrumb, removeLastBreadcrumb, breadcrumbs } = appStore;
  const [isResultSetVisible, setResultSetVisibility] = useState(true);
  const [openModal, setOpenModal] = useState(false);
  const [batchData, setBatchData] = useState({});
  const [loading, setLoading] = useState(false);
  const [viewOnly, setViewOnly] = useState(false);
  const [startExecution, setStartExecution] = useState(false);
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [resultSet, setResultSet] = useState({
    pgr: 0,
    Rate: 0,
    Ploss: 0,
    Closs: 0,
    elptime: 0,
    modelName: "",
    noOfFeatures: 0
  });

  useEffect(() => {
    removeLastBreadcrumb();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING,
      label: "pages.training.training-parameter.dataset-mode.auto-param-search.title"
    });
    
    if(props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH_VIEW) {
      setViewOnly(true);
    }
  }, [addBreadcrumb]);

  useEffect(() => {
    setLoading(true);
    trainingManagementStore
      .getBatch(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setBatchData(response.data);
          if (response?.data?.mode === "parameterSearch") {
            if (response.data.status === "Stop" || response.data.status === "Stopping" || response.data.status === "Stopped") {
              setsnapbarMessage({
                message: t("pages.training.errors.training-list.execution-cancelled", { "type": t("pages.training.errors.training-list.parameter-search") }),
                timeout: 100000
              })
            } else {
              setStartExecution(true);
            }
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.training-list.invalid-execution") });
            setStartExecution(false);
          }
        } else {
          setStartExecution(false);
          setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
        }
      })
      .catch((xhr) => {
        setLoading(false);
        setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
      });
  }, [])

  const displayData = () => {
    setResultSetVisibility(true);
    setStartExecution(false);
  };

  const gotoTrainParameterSetting = () => {
    if(viewOnly) {
      history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER.replace(":id", params.id));
      return;
    } else if (!startExecution) {
      history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
      return;
    }
    setLoading(true);
    setOpenModal(false);
    trainingManagementStore
      .stopExecution(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          trainingManagementStore.setTabIndex(2);
          setTimeout(() => {
            history.replace();
            history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
          }, 1000);
        } else {
        }
      })
      .catch((xhr) => {
        setLoading(false);
      });
  };

  const handleBackButton = () => {
    startExecution ? setOpenModal(true) : gotoTrainParameterSetting();
  };

  const redirectToProgress = () => {
    switch (snapbarMessage.type) {
      case "parameterSearch":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      case "subclassification":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      case "training":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      default:
        break;
    }
  }

  const showConfirmation = () => {
    return (<CustomConfirmation open={snapbarMessage.open} onClose={() => {
      setsnapbarMessage({ open: false });
    }} onSubmit={redirectToProgress} primary={"pages.training.errors.training-list.fail-redirect"} secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"} title={snapbarMessage.title} message={snapbarMessage.info} />);
  }

  const gotoExecutionLogScreen = () => {
    setsnapbarMessage({ message: "" });
    setLoading(true);
    trainingManagementStore.startExecution(params.id, "training", {}).then(res => {
      setLoading(false);
      if (res?.status === 200 && res?.data?.seqNo && res?.data?.mode === "training") {
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(":id", params.id).replace(":seqNo", res?.data?.seqNo));
      } else {
        if (res?.data?.mode === "subclassification") {
          setsnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-subclassification"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
          setOpenConfirmation(true)
        } else if (res?.data?.mode === "parameterSearch") {
          setsnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-parameter-search"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
          setOpenConfirmation(true)
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
        }
      }
    }).catch(error => {
      setLoading(false);
      setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
    });

  };

  return (
    <Observer>
      {() => (
        <div>
          {loading && <Loader size={24} />}
          {showConfirmation()}
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton
                  handleBackButton={handleBackButton}
                />
                <Breadcrumb
                  breadcrumbs={appStore.breadcrumbs}
                  removeBreadcrumb={appStore.removeBreadcrumb}
                />
              </div>
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={!isResultSetVisible || resultSet?.progress < 100 || viewOnly}
                  onClick={gotoExecutionLogScreen}
                >
                  {t("pages.training.training-parameter.dataset-mode.auto-param-search.run-training")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={!isResultSetVisible}
                  onClick={gotoTrainParameterSetting}
                >
                  {t("pages.training.training-parameter.dataset-mode.auto-param-search.back")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => handleBackButton()}
                  disabled={resultSet?.progress >= 100}
                >
                  {t("pages.training.training-parameter.dataset-mode.auto-param-search.cancel")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.mtop}>
              {batchData?.seqNo && <LinearProgressBar
                setResultSet={setResultSet}
                displayData={displayData}
                batchData={batchData}
                loadingAction={true}
                method="parameterSearch"
                executionType="parameterSearch"
              />}
            </div>

            <CustomConfirmation open={openModal} onClose={() => {
              setOpenModal(false);
            }} onSubmit={gotoTrainParameterSetting} primary={"pages.training.input-parameter.controls.ok"} secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"} title={t("pages.training.input-parameter.modal.confirm-cancel-execution.title")} message={t("pages.training.input-parameter.modal.confirm-cancel-execution.text")} />

            {isResultSetVisible && (
              <div>
                <Box m={1} p={1} bgcolor="background.paper" className={classes.resultBox}>
                  <Box p={1} className={classes.boxwidth}>
                    <Paper variant="outlined" className={classes.paperPadd}>
                      <Grid container spacing={1}>
                        <Grid item xs={12} className={classes.pad8}>
                          <Typography variant="h6" gutterBottom>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.result"
                            )}
                          </Typography>
                          <Divider />
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.num-of-features"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.noOfFeatures}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.rate"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Rate}</div>
                        </Grid>{" "}
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.closs"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Closs}</div>
                        </Grid>
                        <Grid item xs={6}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.ploss"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div>: {resultSet.Ploss}</div>
                        </Grid>
                        <Grid item xs={6} className={classes.space}>
                          <div className={classes.textRight}>
                            {t(
                              "pages.training.training-parameter.dataset-mode.auto-param-search.model"
                            )}
                          </div>
                        </Grid>
                        <Grid item xs={6} className={classes.space}>
                          <div>: {resultSet.modelName}</div>
                        </Grid>
                      </Grid>
                    </Paper>
                  </Box>
                </Box>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default AutomaticParameterSearch;
