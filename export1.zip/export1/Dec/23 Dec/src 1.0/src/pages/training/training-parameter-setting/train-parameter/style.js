import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
    divider: {
        marginTop: theme.spacing(2),
        marginBottom: theme.spacing(2)
    },
    pageContent: {
        minHeight: "calc(100vh - 230px)",
        position: "relative"
    },
    radioGroup: {
        display: "flex",
        justifyContent: "center",
    },
    buttonWrapper: {
        textAlign: "right",
        right: "16px",
        bottom: "16px",
        marginTop: "16px"
    },

    formControl: {
        minWidth: "100%"
    },
    paperTitle: {
        textAlign: "center",
        fontSize: 16,
        fontWeight: "600"
    },
    paddingTop: {
        paddingTop: 16
    },
    border: {
        border: "solid 1px rgb(1 1 1 / 12%)",
        padding: "16px 16px 8px 16px",
        textAlign: "center",
        marginBottom: 16
    },
    trainParameterContainer: {
        minHeight: "calc(100vh - 282px)"
    },
    arrowFlip: {
        transform: "rotate(180deg)"
    },
    timeInfo: {
        "& svg": {
            margin: 0,
            height: 24,
            display: "inline-block",
            verticalAlign: "middle"
        }
    }
}));