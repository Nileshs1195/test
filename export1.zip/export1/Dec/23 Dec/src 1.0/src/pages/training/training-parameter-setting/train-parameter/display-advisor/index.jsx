import React, { useState, useContext, useEffect } from 'react'
import { useStyles } from "./style";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Grid, Typography } from "@material-ui/core";
import BackButton from "../../../../../components/backbutton";
import Breadcrumb from "../../../../../shared/components/ui/breadcrumb";
import AppStore from "../../../../../stores/appstore";
import { API_RESPONSE, API_URL, APP_ROUTES } from "../../../../../appconstants";
import { useParams, useHistory } from "react-router-dom";
import { Warning, ThumbUp, FiberManualRecord } from '@material-ui/icons';
import { useTranslation } from "react-i18next";
import trainingmanagementstore from '../../../../../stores/trainingmanagementstore';
import { SETTINGS } from '../../../../../appsettings';
import AddClassificationTest from '../../../../../components/add-test';
import { Loader } from '../../../../../shared/components/ui';
import { arrayVariance } from '../../../../../helpers/arrayutils';
import GraphImage from '../../../../../components/graph-images';

const Advisor = () => {
    const classes = useStyles();
    const params = useParams();
    const { t } = useTranslation();
    const history = useHistory();
    const appStore = useContext(AppStore);
    const trainingManagementStore = useContext(trainingmanagementstore);
    const { fetchExecutionLogData } = trainingManagementStore;
    const { addBreadcrumb, removeLastBreadcrumb } = appStore;
    const [displayAdvisorData, setDisplayAdvisorData] = useState({});
    const [executionLog, setExecutionLogData] = useState([]);
    const [loader, setLoader] = useState(false);

    const [addTest, setAddTest] = useState(false);
    useEffect(() => {
        removeLastBreadcrumb();
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
            label: "pages.training.training-parameter.breadcrumb.training"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
            label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(":id", params.id).replace(":seqNo", params.seqNo),
            label: "pages.training.training-parameter.breadcrumb.train-param-search.execution-log"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.ADVISOR.replace(":id", params.id).replace(":seqNo", params.seqNo),
            label: "Performance improvement advisor"
        });
        handleDisplayAdvisorData();
    }, [addBreadcrumb]);


    const handleBackButton = () => {
        history.goBack();
    };

    const handleDisplayAdvisorData = () => {
        // trainingManagementStore.displayAdvisor(params.id, params.seqNo).then((response) => {
        //     if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        //         console.log("response", response);
        //         setDisplayAdvisorData(response?.Accuracy);
        //     }
        // })
        setLoader(true);
        fetchExecutionLogData(params.id, params.seqNo)
            .then((response) => {
                setLoader(false);
                if (response?.status === 200) {
                    let executionLogs = response?.data;
                    if (executionLogs?.length > 0) {
                        let advisorData = {
                            accuracyData: {
                                image: executionLogs[executionLogs?.length - 1]?.accuracyImage,
                                data: t("pages.training.training-parameter.train-parameter.graph-data.accuracy-data").split(","),
                                color: t("pages.training.training-parameter.train-parameter.graph-data.accuracy-color").split(",")
                              },
                              lossData: {
                                image: executionLogs[executionLogs?.length - 1]?.lossImage,
                                data: t("pages.training.training-parameter.train-parameter.graph-data.loss-data").split(","),
                                color: t("pages.training.training-parameter.train-parameter.graph-data.loss-color").split(",")
                              }
                        };

                        if (executionLogs[executionLogs?.length - 1]?.mainAccuracy < 0.95) {
                            advisorData.caution = t("pages.training.training-parameter.train-parameter.advisor.cautionData1");
                            advisorData.advices = t("pages.training.training-parameter.train-parameter.advisor.adviceData1").split(",");
                        } else if (executionLogs[executionLogs?.length - 1]?.validationMainAccuracy < 0.90) {
                            advisorData.caution = t("pages.training.training-parameter.train-parameter.advisor.cautionData2");
                            advisorData.advices = t("pages.training.training-parameter.train-parameter.advisor.adviceData2").split(",");
                        } else {
                            let sum = executionLogs.map(log => {
                                return log?.mainAccuracy;
                            });
                            if (arrayVariance(sum) > 0.1) {
                                advisorData.caution = t("pages.training.training-parameter.train-parameter.advisor.cautionData3");
                                advisorData.advices = t("pages.training.training-parameter.train-parameter.advisor.adviceData3").split(",");
                            }
                        }
                        setDisplayAdvisorData(advisorData)
                    }
                    // setExecutionLogData(response.data);
                }
            })
            .catch((err) => {
                setLoader(false);
                console.log("error", err);
            });
    }

    const reExecute = () => {
        trainingManagementStore.startExecution(params.id, "none", {}).then(res => {
            if (res?.status === 200) {
                history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
            } else {
            }
        }).catch(error => {
            console.log(error);
        });
    }

    return (
        <Observer>
            {() => (
                <div>
                    <AddClassificationTest open={addTest} askTrainingModel={true} setOpen={setAddTest} id={params.id} />
                    <Paper className={classes.pageContent}>
                        {loader && <Loader size={24} />}
                        <div className={classes.top}>
                            <div className={classes.breadcrumbWraper}>
                                <BackButton
                                    handleBackButton={handleBackButton}
                                />
                                <Breadcrumb
                                    breadcrumbs={appStore.breadcrumbs}
                                    removeBreadcrumb={appStore.removeBreadcrumb}
                                />
                            </div>

                            <div className={classes.buttonWrapper}>
                                <Button color="primary" variant="contained" onClick={() => {
                                    setAddTest(true);
                                }}>
                                    {t("pages.training.training-parameter.train-parameter.controls.test-model")}
                                </Button> &nbsp; &nbsp;
                                <Button color="primary" variant="contained" onClick={reExecute}>
                                    {t("pages.training.training-parameter.train-parameter.controls.re-execute")}
                                </Button>
                            </div>
                        </div>
                        <Divider className={classes.divider} />
                        {displayAdvisorData?.caution && <Paper variant="outlined" className={classes.paperCustom}>
                            <Grid container spacing={0}>
                                <Grid item xs={12} sm={6}>
                                    <div className={classes.inLine}>
                                        <div>
                                            <Warning className={classes.warningIcon} />
                                        </div>
                                        <div className={classes.textPadding}>
                                            {t("pages.training.training-parameter.train-parameter.advisor.caution")}
                                        </div>
                                    </div>
                                    <div className={classes.inLine} style={{ marginTop: "6px" }}>
                                        <div>
                                            <FiberManualRecord className={classes.iconSize} />
                                        </div>
                                        <div className={classes.text}>
                                            {displayAdvisorData?.caution}
                                        </div>
                                    </div>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <div className={classes.inLine}>
                                        <div>
                                            <ThumbUp className={classes.thumbIcon} />
                                        </div>
                                        <div className={classes.textPadding}>
                                            {t("pages.training.training-parameter.train-parameter.advisor.advice")}
                                        </div>
                                    </div>
                                    {displayAdvisorData?.advices?.length > 0 && displayAdvisorData?.advices?.map(advice => {
                                        return <div className={classes.inLine} style={{ marginTop: "6px" }}>
                                            <div>
                                                <FiberManualRecord className={classes.iconSize} />
                                            </div>
                                            <div className={classes.text}>
                                                {/* {t("pages.training.training-parameter.train-parameter.advisor.trainingCount")} */}
                                                {advice}
                                            </div>
                                        </div>
                                    })}

                                </Grid>
                            </Grid>
                        </Paper>}
                        {
                            displayAdvisorData && <GraphImage graphData={displayAdvisorData} params={params} />
                        }
                    </Paper>
                </div>
            )}
        </Observer>
    )
}

export default Advisor
