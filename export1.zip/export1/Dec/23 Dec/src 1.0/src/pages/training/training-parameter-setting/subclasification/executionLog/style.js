import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    minHeight: "100vh"
  },
  paper: {
    maxHeight: "35%"
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  breadcrumbWraper: {
    display: "flex"
  },
  mtop: {
    marginTop: "16px",
    marginBottom: "16px"
  },
  textRight: {
    textAlign: "right"
  },
  space: {
    margin: "16px 0px"
  },
  accSummary: {
    "&.Mui-expanded": {
      minHeight: "48px !important"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  accDetails: {
    padding: "0px 16px 16px"
  },
  tableContainer: {
    height: "calc(100vh - 357px)",
    "& table thead th:first-child": {
      transform: "translateY(-1px) scaleX(1)"
    }
  },
  accSumTitle: {
    fontWeight: "500"
  },
  accordionContainer: {
    marginTop: "24px"
  },
}));
