import { React, useState, useEffect, useContext } from "react";
import { useParams } from "react-router-dom";
import { Button, Divider, Paper, Box } from "@material-ui/core";
import { Observer, observer } from "mobx-react-lite";
import { useTranslation } from "react-i18next";
import { useStyles } from "./style";
import Checkbox from "../../../../../shared/components/ui/checkbox";
import TrainingManagementStore from "./../../../../../stores/trainingmanagementstore";
import { API_RESPONSE } from "../../../../../appconstants";
import CustomSnackBar from "../../../../../components/snackbar";

const ParameterSetting = observer((props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [parameterState, setParameterState] = useState({
    rotationInvariant: false,
    flippingInvariant: false
  });
  const { setLoading } = props;
  const trainingId = params.id;
  const [initialValue, setInitialValue] = useState(true);

  const handleCheckBoxChange = (fieldName, checked) => {
    parameterState[fieldName] = checked;
    setParameterState({ ...parameterState });
    setInitialValue(false);
    saveParameterData();
  };

  // useEffect(async () => {
  //   await trainingManagementStore.fetchTrainingDatasetWithTraining(trainingId);
  // }, [])

  useEffect(() => {
    let trainingData = JSON.parse(JSON.stringify(trainingManagementStore.selectedTrainingListData));
    let settingdata = {
      rotationInvariant: trainingData?.[0]?.rotationInvariant,
      flippingInvariant: trainingData?.[0]?.flippingInvariant
    };
    setParameterState(settingdata);
  }, [trainingManagementStore?.selectedTrainingListData]);

  // useEffect(() => {
  //   if (!initialValue) {
  //     saveParameterData();
  //   }
  //   setsnapbarMessage({ message: "" });
  // }, [parameterState]);

  const saveParameterData = async () => {
    setLoading(true);
    console.log("state", parameterState);
    await trainingManagementStore
      .saveParameterData(trainingId, parameterState)
      .then(response => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setsnapbarMessage({
            message: t("pages.training.success.params-setting.updated")
          });
          setParameterState({
            rotationInvariant: response?.data?.rotationInvariant,
            flippingInvariant: response?.data?.flippingInvariant
          });
          // trainingManagementStore.fetchTrainingDatasetWithTraining(trainingId);
          trainingManagementStore.setSelectedTrainingDataset(response?.data);
        } else {
          setsnapbarMessage({
            message: t("pages.training.errors.params-setting.update-failed")
          });
        }
      })
      .catch(err => {
        setLoading(false);
        setsnapbarMessage({
          message: t("pages.training.errors.params-setting.update-failed")
        });
      });
  };
  return (
    <Observer>
      {() => (
        <>
          <Paper variant="outlined" className={classes.paperCustom}>
            {snapbarMessage && snapbarMessage.message && (
              <CustomSnackBar snapbarMessage={snapbarMessage} />
            )}
            <div className={classes.paperTitle}>
              {" "}
              {t("pages.training.input-parameter.parametere-sttings")}
            </div>
            <div className={classes.alignCenter}>
              <Divider className={`${classes.divider} ${classes.mB1}`} />
              <Box display="flex" justifyContent="center">
                <Box mr={1}>
                  <Checkbox
                    color="default"
                    checked={parameterState?.rotationInvariant}
                    id="rotationInvariant"
                    name="rotationInvariant"
                    className={classes.checkBox}
                    onChange={event =>
                      handleCheckBoxChange(
                        "rotationInvariant",
                        event.target.checked
                      )
                    }
                  />
                  <span>
                    {t(
                      "pages.training.input-parameter.controls.rotation-invariance"
                    )}
                  </span>
                </Box>
                <Box>
                  <Checkbox
                    color="default"
                    checked={parameterState?.flippingInvariant}
                    id="flippingInvariant"
                    name="flippingInvariant"
                    className={classes.checkBox}
                    onChange={event =>
                      handleCheckBoxChange(
                        "flippingInvariant",
                        event.target.checked
                      )
                    }
                  />
                  <span>
                    {t(
                      "pages.training.input-parameter.controls.flipping-invariance"
                    )}
                  </span>
                </Box>
              </Box>
            </div>
            {/*<Box display="flex" justifyContent="center" className={classes.mT1}>
                <Button color="primary" variant="contained">
                  {t("pages.training.input-parameter.controls.advanced-settings")}
                </Button>
              </Box>
            */}
          </Paper>
        </>
      )}
    </Observer>
  );
});

export default ParameterSetting;
