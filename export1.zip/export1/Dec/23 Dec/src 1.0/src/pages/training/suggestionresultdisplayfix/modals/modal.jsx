import React from 'react'
import { useStyles } from './style'
import Modal from '../../../../shared/components/ui/modal'
import GridMaterial from '@material-ui/core/Grid'
import { useTranslation } from 'react-i18next'
import { FormControl, TextField } from '@material-ui/core'

const Modals = (props) => {
  const classes = useStyles()
  const { t } = useTranslation()
  const {   
    modalType,
    open,
    title,
    onClose,
    onSubmit,
    onChangeFieldData,
    modalFormErrors,
    inputParameter,
  } = props

  switch (modalType) {
    case 'ADD-CLASS':
      return (
        <Modal
          open={open}
          onClose={onClose}
          onSubmit={onSubmit}
          widthClass={classes.modalWidth}
          showControls
          primaryButtonTextKey={
            'pages.training.suggestion-result.controls.ok-btn'}
          secondaryButtonTextKey={
            'pages.training.suggestion-result.controls.cancel-btn'
          }
        >
          <div className={classes.modalTextPadding}>
            <h3 className={classes.modalTitle}>
              {t(title)}
            </h3>
            <form autoComplete="off">
              <GridMaterial container spacing={2} className={classes.mT1}>
                <GridMaterial item xs={12}>
                  <FormControl className={classes.formControl} margin="none">
                    <TextField
                      fullWidth
                      id="className"
                      name="className"
                      label={t(
                        'pages.training.input-parameter.grid.class-name',
                      )}
                      value={inputParameter.className} autoFocus
                      onChange={onChangeFieldData}
                      error={modalFormErrors['className']}
                      helperText={
                        modalFormErrors['classNameErrorMsg'] !== '' &&
                        modalFormErrors['classNameErrorMsg']
                      }
                    />
                  </FormControl>
                </GridMaterial>
              </GridMaterial>
            </form>
          </div>
        </Modal>
      )
      break
    case 'EDIT-CLASS':
      return (
        <Modal
          disableApply={(
            modalFormErrors['classNameErrorMsg'] !== '' &&
            modalFormErrors['classNameErrorMsg'])}
          open={open}
          onClose={onClose}
          onSubmit={onSubmit}
          widthClass={classes.modalWidth}
          showControls
          primaryButtonTextKey={
            'pages.training.suggestion-result.controls.ok-btn'}
          secondaryButtonTextKey={
            'pages.training.suggestion-result.controls.cancel-btn'}
        >
          <div className={classes.modalTextPadding}>
            <h3 className={classes.modalTitle}>
              {t(title)}
            </h3>
            <form autoComplete="off">
              <GridMaterial container spacing={2} className={classes.mT1}>
                <GridMaterial item xs={12}>
                  <FormControl className={classes.formControl} margin="none">
                    <TextField
                      fullWidth
                      id="className"
                      name="className"
                      label={t(
                        'pages.training.input-parameter.grid.class-name',
                      )}
                      value={inputParameter.className}
                      onChange={onChangeFieldData}
                      error={modalFormErrors['className']}
                      helperText={
                        modalFormErrors['classNameErrorMsg'] !== '' &&
                        modalFormErrors['classNameErrorMsg']
                      }
                    />
                  </FormControl>
                </GridMaterial>
              </GridMaterial>
            </form>
          </div>
        </Modal>
      )
  }
  return <div></div>
}

export default Modals
