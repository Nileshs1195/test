import React from "react";
import { useStyles } from "./style";
import Modal from "../../../../../../shared/components/ui/modal";
import { useTranslation } from "react-i18next";
import { FormControl, TextField } from "@material-ui/core";
import GridMaterial from "@material-ui/core/Grid";

const Modals = (props) => {
  const { open, onClose, onChange, inputField, create, modalFormErrors } = props;
  const classes = useStyles();
  const { t } = useTranslation();

  return (
    <Modal
      open={open}
      onClose={onClose}
      onSubmit={create}
      widthClass={classes.modalWidth}
      showControls
      primaryButtonTextKey={"pages.classification-test.testing-list.controls.ok"}
      secondaryButtonTextKey={"pages.classification-test.testing-list.controls.cancel-btn"}
    >
      <div className={classes.modalTextPadding}>
        <h3 className={classes.modalTitle}>{t("pages.classification-test.testing-list.modal.new-testing")}</h3>
        <form autoComplete="off">
          <GridMaterial container spacing={2} className={classes.mT1}>
            <GridMaterial item xs={12}>
              <FormControl className={classes.formControl} margin="none">
                <TextField
                  fullWidth
                  id="title"
                  name="title"
                  label={"Title"}
                  value={inputField.title}
                  onChange={onChange}
                  error={modalFormErrors["title"]}
                  helperText={modalFormErrors["titleErrorMsg"] !== "" && modalFormErrors["titleErrorMsg"]}
                />
              </FormControl>
            </GridMaterial>
            {/* <GridMaterial item xs={6}>
              <FormControl className={classes.formControl} margin="none">
                <TextField
                  fullWidth
                  id="lotId"
                  name="lotId"
                  label={"Lot ID"}
                  value={inputField.lotId}
                  onChange={onChange}
                  disabled={false}
                  error={modalFormErrors["lotId"]}
                  helperText={modalFormErrors["lotIdErrorMsg"] !== "" && modalFormErrors["lotIdErrorMsg"]}
                />
              </FormControl>
            </GridMaterial> */}
            {/* <GridMaterial item xs={6}>
              <FormControl className={classes.formControl} margin="none">
                <TextField
                  fullWidth
                  id="deviceName"
                  name="deviceName"
                  label={"Device Name"}
                  value={inputField.deviceName}
                  onChange={onChange}
                  disabled={false}
                  error={modalFormErrors["deviceName"]}
                  helperText={modalFormErrors["deviceNameErrorMsg"] !== "" && modalFormErrors["deviceNameErrorMsg"]}
                />
              </FormControl>
            </GridMaterial> */}
            {/* <GridMaterial item xs={6}>
              <FormControl className={classes.formControl} margin="none">
                <TextField
                  fullWidth
                  id="designGroup"
                  name="designGroup"
                  label={"Device Design Group"}
                  value={inputField.designGroup}
                  onChange={onChange}
                  disabled={false}
                  error={modalFormErrors["designGroup"]}
                  helperText={modalFormErrors["designGroupErrorMsg"] !== "" && modalFormErrors["designGroupErrorMsg"]}
                />
              </FormControl>
            </GridMaterial> */}
            <GridMaterial item xs={12}>
              <FormControl className={classes.formControl} margin="none">
                <TextField
                  fullWidth
                  id="comment"
                  name="comment"
                  label={"Comment"}
                  value={inputField.comment}
                  onChange={onChange}
                  error={modalFormErrors["comment"]}
                  helperText={modalFormErrors["commentErrorMsg"] !== "" && modalFormErrors["commentErrorMsg"]}
                />
              </FormControl>
            </GridMaterial>
          </GridMaterial>
        </form>
      </div>
    </Modal>
  );
};
export default Modals;
