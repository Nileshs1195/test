import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles((theme)=>({
    paper: {
        maxHeight: "35%"
    },
    pageContent: {
        padding: theme.spacing(2, 2),
        width: "100%",
        minHeight: "calc(100vh - 82px)",
        maxHeight: "auto",
        position: "relative",
        paddingBottom: "68px"
    },
    pageHeader: {
        display: "flex"
    },
    divider: {
        marginTop: theme.spacing(2)
    },
    top: {
        marginTop: theme.spacing(2),
        alignItems: "center",
        display: "flex",
        justifyContent: "space-between"
    },
    legend: {
        display: "inline-block",
        width: "15px",
        height: "4px",
        margin: "8px 8px 8px 0px",
        border:'none',
        backgroundColor: "#dd0a55",
        verticalAlign: "middle"
    },
    legendText: {
        display: "inline-block",
        verticalAlign: "middle",
        marginRight: "16px"
    },
    buttonWrapper: {
        display: "flex",
        alignSelf: "center",
        "& > *": {
          marginLeft: theme.spacing(2)
        },
        zIndex: 1
    },
    mTop: {
        marginTop: theme.spacing(2)
    },
}));