import { observer } from "mobx-react-lite";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useStyles } from "./style";
import { useCallback, useState, useRef, useContext, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Grid, Button, Accordion, AccordionSummary, AccordionDetails, FormControl, TextField, Checkbox, FormControlLabel } from "@material-ui/core";
import ImageManagementStore from "../../stores/imagemanagementstore";
import Pagination from "../../shared/components/basictable/pagination";
import TrainingManagementStore from "../../stores/trainingmanagementstore";
import Loader from "../../shared/components/ui/loader";
import Carousel from "../carousel";
import { ErrorOutline } from "@material-ui/icons";
import { useParams } from "react-router-dom";
import { API_RESPONSE, API_URL } from "../../appconstants";
import ViewImage from "../view-image";
import CustomConfirmation from "../modal/CustomConfirmation";
import AppStore from "../../stores/appstore";
import { Autocomplete } from "@material-ui/lab";

const SuggestionList = observer((props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const appStore = useContext(AppStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { key, imageType, seqNo, expand, trainingDetails, showAddImage, showDeleteImage, showEditClass, carouselView, url, imageSelection, showTransferedImagesOnly, probabilityTreshold, showEditClassName, trainingClasses, paginationPosition } = props;
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [leftImages, setLeftImages] = useState([]);
  const [rightImages, setRightImages] = useState([]);
  const [totalImageCount, setTotalImageCount] = useState(0);
  const [confirmAction, setConfirmAction] = useState("");
  const [pageLeft, setPageLeft] = useState({
    pageNo: 1,
    pageSize: 5
  });
  const [pageRight, setPageRight] = useState({
    pageNo: 1,
    pageSize: 4
  });
  const [leftLoader, setLeftLoader] = useState(false);
  const [rightLoader, setRightLoader] = useState(false);
  const [classList, setClassList] = useState([]);
  const [isImageview, setImageview] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const [expanded, setExpanded] = useState(expand);
  const [classDetails, setClassDetails] = useState({
    selected: true
  });
  const [selectedImages, setSelectedImages] = useState([]);
  const [selectedSeqNo, setSelectedSeqNo] = useState("");
  const [currentClassName, setCurrentClassName] = useState("");
  const { updateDatasetImageCount, destinationClassSeqNo, setDestinationClassSeqNo, viewParameter } = trainingManagementStore;
  const { setsnapbarMessage } = appStore;
  const { getImagesForDataset, deleteImagesForDataset, imageUploadStatus, uploaderAction, setUploaderAction } = imageManagementStore;

  useEffect(() => {
    setExpanded(expand);
  }, [expand]);

  useEffect(() => {
    if (destinationClassSeqNo === classDetails.seqNo) {
      setDestinationClassSeqNo("");
      getImagesLeft(pageLeft);
    }
  }, [destinationClassSeqNo]);

  useEffect(() => {
    imageUploadStatus === "completed" && uploaderAction?.className === classDetails?.className && getImagesLeft(pageLeft);
  }, [imageUploadStatus]);

  const getClassLists = () => {
    let allClasses = trainingClasses?.filter(dataset => dataset?.className !== classDetails?.className);
    setClassList(allClasses)
  };

  const onPaginationLeft = (obj) => {
    setPageLeft(obj);
    getImagesLeft(obj);
  }
  const onPaginationRight = (obj) => {
    setPageRight(obj);
    getImagesRight(obj);
  }

  const getImagesLeft = (obj) => {
    let pageNo = (obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo) * obj.pageSize;
    const paginationData = {
      from_index: pageNo,
      end_index: pageNo + (obj.pageSize || 5)
    };

    let data = {
      probability: probabilityTreshold,
      conditions: [
        {
          column: "modeOfChange",
          case: "lte",
          value: 2
        }
      ],
      desc: "probabilityValue",
      ...paginationData
    };
    if (showTransferedImagesOnly) {
      data = {
        ...data,
        conditions: [
          {
            column: "modeOfChange",
            case: "ne",
            value: 0
          }
        ],
        desc: "probability"
      };
    }
    setLeftLoader(true);
    getImagesForDataset(url, params.id, seqNo, data).then(result => {
      setLeftImages([]);
      setLeftLoader(false);
      if (result?.status === API_RESPONSE.SUCCESS_STATUS_CODE && result?.data) {
        setTotalImageCount(result?.data?.count);
        setLeftImages([...result?.data?.images]);
        setClassDetails({
          ...classDetails,
          seqNo: result?.data?.classSeqNo,
          className: result?.data?.className,
          modelName: result?.data?.modelName,
        });
      }
    }).catch(error => {
      setLeftLoader(false);
      setLeftImages([]);
    });
  }

  const getImagesRight = (obj) => {
    let pageNo = (obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo) * obj.pageSize;
    const paginationData = {
      from_index: pageNo,
      end_index: pageNo + (obj.pageSize || 4),
    };

    let data = {
      probability: probabilityTreshold,
      conditions: [
        {
          column: "modeOfChange",
          case: "lte",
          value: 2
        }
      ],
      desc: "probabilityValue",
      ...paginationData
    };
    // if (showTransferedImagesOnly) {
    //   data = {
    //     ...data,
    //     conditions: [
    //       {
    //         column: "modeOfChange",
    //         case: "ne",
    //         value: 0
    //       }
    //     ],
    //     desc: "probability"
    //   };
    // }
    setRightLoader(true);
    getImagesForDataset(url, params.id, seqNo, data).then(result => {
      setRightImages([]);
      setRightLoader(false);
      if (result?.status === API_RESPONSE.SUCCESS_STATUS_CODE && result?.data) {
        setTotalImageCount(result?.data?.count);
        setRightImages([...result?.data?.images]);
        setClassDetails({
          ...classDetails,
          seqNo: result?.data?.classSeqNo,
          className: result?.data?.className,
          modelName: result?.data?.modelName,
        });
      }
    }).catch(error => {
      setRightLoader(false);
      setRightImages([]);
    });
  }

  const handleViewImage = (index) => {
    setActiveImage(index);
    setImageview((isOpen) => !isOpen);
  }

  const selectImages = (image) => {
    // image = { ...image, selected: !image?.selected };
    let selected = selectedImages;
    if (selected.includes(image?.seqNo)) {
      selected.splice(selected.indexOf(image?.seqNo), 1);
    } else {
      selected.push(image?.seqNo);
    }
    setSelectedImages([...selected]);
  }

  const deleteSelectedImages = () => {
    if (selectedImages?.length > 0 && classDetails?.seqNo) {
      const reqPayload = {
        img_seqNo: selectedImages
      };
      setLeftLoader(true);
      setRightLoader(true);
      deleteImagesForDataset(params.id, classDetails.seqNo, reqPayload)
        .then((response) => {
          if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            setsnapbarMessage({
              message: t("pages.training.manageImages.messages.imageRecordDeleted")
            });
            getImagesLeft(pageLeft);
            setSelectedImages([]);
            updateDatasetImageCount(classDetails.seqNo, response?.data?.length);
            setLeftLoader(false);
            setRightLoader(false);
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.delete-failed") });
          }
        })
        .catch((error) => {
          setLeftLoader(false);
          setRightLoader(false);
          setsnapbarMessage({ message: t("pages.training.errors.delete-failed") });
        });
    }
  }

  const onSelectImageClass = (event, value) => {
    if (value?.value) {
      setSelectedSeqNo(value?.value);
    }
  }

  const moveSelectedImages = () => {
    if (classDetails?.seqNo && selectedSeqNo) {
      let pageUrl = API_URL.GET_IMAGES_FOR_DATASET;
      if (url === API_URL.CORRECTION_IMAGES) {
        pageUrl = API_URL.SUGGESTION_CLASS_UPDATE;
      }
      setLeftLoader(true);
      setRightLoader(true);
      imageManagementStore
        .saveEditImageClassDetails(pageUrl, params.id, classDetails?.seqNo, { img_seqNo: selectedImages, dst_seqNo: selectedSeqNo })
        .then((response) => {
          setLeftLoader(false);
          setRightLoader(false);
          if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            setsnapbarMessage({
              message: t("pages.training.manageImages.messages.imageRecordUpdated")
            });
            setSelectedImages([]);
            setDestinationClassSeqNo(selectedSeqNo);
            getImagesLeft(pageLeft);
          } else {
          }
        })
        .catch((error) => {
          setLeftLoader(false);
          setRightLoader(false);
        });
    }
  }

  const onChangeClassName = (event) => {
    let errMsg = [];
    let value = event.target.value;
    errMsg["errExist"] = t("pages.training.input-parameter.modal.already-exist");
    errMsg["errAlphanumeric"] = t("pages.training.input-parameter.modal.alphanumeric");
    setCurrentClassName(value);
  }

  const renderLeftImages = () => {
    return leftLoader ? <div className={classes.loaderPosition} > <Loader size={24} /></div > : leftImages.length > 0 ? <Grid key={key} container spacing={2}> {reverseImages(leftImages).map((image, key) => {
      return (<ViewImage selectedImages={selectedImages} selectImages={selectImages} imageKey={key} index={"image-" + image.seqNo} imageData={{ ...image, className: classDetails?.className }} handleViewImage={handleViewImage} viewParameter={viewParameter} imageSelection={imageSelection} url={url} />)
    })}</Grid> : !leftLoader && <div className={classes.noContentMiddle}>
      <div className={classes.noContent}>
        <span>
          <ErrorOutline fontSize="large" className={classes.warningIcon} />
        </span>
        <span className={classes.noContentLabel}>{t("components.basic-table.no-content")}</span>
      </div>
    </div>
  }
  const renderRightImages = () => {
    return rightLoader ? <div className={classes.loaderPosition} > <Loader size={24} /></div > : rightImages.length > 0 ? <Grid key={key} container spacing={2}> {reverseImages(rightImages).map((image, key) => {
      return (<ViewImage selectedImages={selectedImages} selectImages={selectImages} imageKey={key} index={"image-" + image.seqNo} imageData={{ ...image, className: classDetails?.className }} handleViewImage={handleViewImage} viewParameter={viewParameter} imageSelection={imageSelection} url={url} />)
    })}</Grid> : !rightLoader && <div className={classes.noContentMiddle}>
      <div className={classes.noContent}>
        <span>
          <ErrorOutline fontSize="large" className={classes.warningIcon} />
        </span>
        <span className={classes.noContentLabel}>{t("components.basic-table.no-content")}</span>
      </div>
    </div>
  }

  const reverseImages = (images) => {
    return images; //!important: In order to avoid array reverse during production build this is required
  }

  const handleClick = (type) => {
    if (viewParameter) {
      return;
    }
    if (type === 0) {
      setUploaderAction({
        isOpen: true,
        uploaderType: "add-images",
        className: classDetails?.className,
        id: params?.id
      });
    } else if (type === 1) {
      setConfirmAction("delete");
    } else if (type === 2) {
      getClassLists();
      setConfirmAction("move");
    } else if (type === 3) {
      setCurrentClassName(classDetails?.className);
      setConfirmAction("edit");
    }
  };

  const handleOnClick = (event) => {
    setClassDetails({
      ...classDetails, selected: !classDetails.selected
    })
    event.stopPropagation();
  };

  return (
    <>
      <Accordion
        key={key}
        expanded={!expanded}
        onChange={() => setExpanded(!expanded)}
        defaultExpanded={true}
        className={classes.accMarginTop}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          className={classes.accSummary}
        >
          {classDetails &&
            <Grid>
              <FormControlLabel
                control={
                  <Checkbox
                    // className={classes.thumbCheckbox}
                    color="primary"
                    checked={classDetails.selected}
                    id={classDetails.className}
                    name={classDetails.className}
                    onClick={(event) => handleOnClick(event)}
                  />
                }
                onClick={(event) => {
                  handleOnClick(event);
                }}
                label={classDetails.className}
                className={classes.classCheckboxWrap}
              />
            </Grid>
          }
        </AccordionSummary>
        <AccordionDetails className={classes.accDetails}>
          <div className={classes.container}>
            <div className={classes.navL}>
              <Pagination
                onChange={onPaginationLeft}
                itemCount={totalImageCount}
                pageNo={pageLeft?.pageNo || 1}
                pageSize={pageLeft?.pageSize || 5}
                disableItemPerPage={true}
                disabled={false}
              />
            </div>
            <div className={classes.navR}>
              <Pagination
                onChange={onPaginationRight}
                itemCount={totalImageCount}
                pageNo={pageRight?.pageNo || 1}
                pageSize={pageRight?.pageSize || 4}
                disableItemPerPage={true}
                disabled={false}
              />
            </div>
            <div className={classes.thumbWrap}>
              {renderLeftImages()}
              {renderRightImages()}
            </div>
            <div className={classes.bottom}>
              <div className={classes.buttonWrapper}>
                {
                  showAddImage && <>
                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.marginLeft20}
                      onClick={() => handleClick(0)}
                      disabled={selectedImages?.length > 0 || viewParameter}
                    >
                      {t("pages.training.manageImages.controls.addImages")}
                    </Button>{" "}
                    &nbsp;&nbsp;
                  </>
                }
                {showDeleteImage && <>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.marginLeft20}
                    onClick={() => handleClick(1)}
                    disabled={selectedImages?.length < 1 || viewParameter}
                  >
                    {t("pages.training.manageImages.controls.deleteImages")}
                  </Button>{" "}
                  &nbsp;&nbsp;
                  <CustomConfirmation
                    open={confirmAction === "delete"}
                    onClose={() => {
                      setConfirmAction("");
                    }}
                    onSubmit={deleteSelectedImages}
                    primary={"pages.training.manageImages.modal.delete-btn"}
                    secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                    title={t("pages.training.manageImages.modal.deleteRecordTitle")}
                    message={t("pages.training.manageImages.modal.deleteRecordMessage")}
                  />
                </>}

                {showEditClass && <>
                  <CustomConfirmation
                    open={confirmAction === "move"}
                    onClose={() => {
                      setConfirmAction("");
                    }}
                    onSubmit={moveSelectedImages}
                    primary={"pages.training.manageImages.modal.ok-btn"}
                    secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                    title={t("pages.training.manageImages.modal.editImageClassTitle")}
                    message={<>
                      <FormControl className={classes.formControl}>
                        <Autocomplete
                          id="combo-box"
                          clearOnEscape
                          options={classList?.map(dataset => {
                            return { label: dataset.className, value: dataset.seqNo };
                          })}
                          getOptionLabel={(option) => option?.label}
                          onChange={(event, value) => onSelectImageClass(event, value)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Class Name"
                              id="className"
                              name="className"
                              margin="normal"
                              error={modalFormErrors["className"]}
                              helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
                            />
                          )}
                        />
                      </FormControl>
                    </>}
                  />
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.marginLeft20}
                    onClick={() => handleClick(2)}
                    disabled={selectedImages?.length < 1 || viewParameter}
                  >
                    {t("pages.training.manageImages.controls.editImageClass")}
                  </Button></>
                }
                {showEditClassName && <>
                  <CustomConfirmation
                    open={confirmAction === "edit"}
                    onClose={() => {
                      setConfirmAction("");
                    }}
                    onSubmit={moveSelectedImages}
                    primary={"pages.training.manageImages.modal.ok-btn"}
                    secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                    title={t('pages.training.manageImages.controls.editClass')}
                    message={<>
                      <FormControl className={classes.formControl}>
                        <TextField
                          fullWidth
                          id="className"
                          name="className"
                          label={t(
                            'pages.training.input-parameter.grid.class-name',
                          )}
                          value={currentClassName}
                          onChange={onChangeClassName}
                          error={modalFormErrors['className']}
                          helperText={
                            modalFormErrors['classNameErrorMsg'] !== '' &&
                            modalFormErrors['classNameErrorMsg']
                          }
                        />
                      </FormControl>
                    </>}
                  />
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.marginLeft20}
                    onClick={() => handleClick(3)}
                    disabled={selectedImages?.length > 0 || viewParameter}
                  >
                    {t("pages.training.manageImages.controls.editClass")}
                  </Button></>
                }
              </div>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      {carouselView && <Carousel open={isImageview} onClose={() => {
        setImageview((isOpen) => !isOpen);
        // reverseImages();
      }} active={activeImage} setActiveImage={setActiveImage} sliderData={reverseImages()} />}
    </>
  );
});

export default SuggestionList;
