import { observer } from "mobx-react-lite";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useStyles } from "./style";
import { useState, useContext, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Grid, Button, Accordion, AccordionSummary, AccordionDetails, FormControl, TextField, Checkbox } from "@material-ui/core";
import ImageManagementStore from "../../stores/imagemanagementstore";
import Pagination from "../../shared/components/basictable/pagination";
import TrainingManagementStore from "../../stores/trainingmanagementstore";
import Loader from "../../shared/components/ui/loader";
import Carousel from "../carousel";
import { ErrorOutline } from "@material-ui/icons";
import { useParams } from "react-router-dom";
import { API_RESPONSE, API_URL } from "../../appconstants";
import ViewImage from "../view-image";
import CustomConfirmation from "../modal/CustomConfirmation";
import AppStore from "../../stores/appstore";
import { Autocomplete } from "@material-ui/lab";
import TestManagementStore from "../../stores/testManagementStore";
import DropDown from "../dropdown";
import EditImageClass from "../imagelist-forms/EditImageClass";
import * as CommonMethod from "../../helpers/CommonMethods";
import CompareImageCarousel from "../compareimagecarousel/compareImageCarousel";
import { convertPixelToPercentage } from "../masking";

const ImageLists = observer((props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const appStore = useContext(AppStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const {
    key,
    imageType,
    masking,
    maskConfirmation,
    seqNo,
    expand,
    trainingDetails,
    showAddImage,
    showDeleteImage,
    showEditClass,
    carouselView,
    url,
    imageSelection,
    order,
    pageSize,
    showEditClassName,
    trainingClasses,
    paginationPosition,
    classData,
    classificationTest,
    dropdown,
    showMoveImages,
    showMaskedImages
  } = props;
  const testManagementStore = useContext(TestManagementStore);
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [images, setImages] = useState([]);
  const [totalImageCount, setTotalImageCount] = useState(0);
  const [confirmAction, setConfirmAction] = useState("");
  const [page, setPage] = useState({
    pageNo: 1,
    pageSize: pageSize || 9
  });
  const [loader, setLoader] = useState(false);
  const [classList, setClassList] = useState([]);
  const [isImageview, setImageview] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const [expanded, setExpanded] = useState(expand);
  const [classDetails, setClassDetails] = useState(expand);
  const [selectedImages, setSelectedImages] = useState([]);
  const [selectedSeqNo, setSelectedSeqNo] = useState("");
  const [currentClassName, setCurrentClassName] = useState("");
  const [classifiedClasses, setClassifiedClasses] = useState([]);
  const [selectedCount, setSelectedCount] = useState(false);
  const [selectedClasses, setSelectedClasses] = useState([]);
  const [selectedClassifiedClasses, setSelectedClassifiedClasses] = useState([]);
  const [editImageClass, setEditImageClass] = useState(false);
  const [maskData, setMaskData] = useState([]);
  const [maskedImageCount, setMaskedImageCount] = useState(0);
  const [unsavedData,setUnsavesData] = useState(false)
  const [disableMoveImageButton, setDisableMoveImageButton] = useState(true);
  const [selectedImageData, setSelectedImageData] = useState({});
  const [imageData, setImageData] = useState({ buttonText: "pages.training.manageImages.controls.moveToTraining", imgType: "" });
  const {
    TrainingDataset,
    updateDatasetImageCount,
    destinationClassSeqNo,
    setDestinationClassSeqNo,
    viewParameter,
    selectedMasks,
    setSelectedMasks
  } = trainingManagementStore;
  const { setsnapbarMessage } = appStore;
  const { getImagesForDataset, deleteImagesForDataset, imageUploadStatus, uploaderAction, setUploaderAction, changeImageType } =
    imageManagementStore;
  const maskingFuncs = {
    unsavedData:unsavedData,
    maskData: maskData,
    imageMasking: masking,
    setUnsavesData: (bool) => {
      setUnsavesData(bool);
    },
    setMaskData: (data) => {
      setMaskData(data);
    },
    updateMasking: (defectData) => {
      updateMasking(defectData);
    }
  };
  useEffect(() => {
    setExpanded(expand);
    if (dropdown) {
      // setInitialDropDownClasses(page);
    }
  }, [expand]);

  useEffect(() => {
    if (destinationClassSeqNo === classDetails.seqNo) {
      setDestinationClassSeqNo("");
      getImages(page);
    }
  }, [destinationClassSeqNo]);

  useEffect(() => {
    if (classificationTest) {
      setExpanded(expand);
      if (dropdown) {
        setInitialDropDownClasses(page);
      }
    }
  }, [classData]);

  useEffect(() => {
    imageUploadStatus === "completed" && uploaderAction?.className === classDetails?.className && getImages(page);
  }, [imageUploadStatus]);

  useEffect(() => {
    const image = reverseImages().filter((obj, index) => index === activeImage);
    setSelectedImageData(...image);
  }, [activeImage]);

  const getClassLists = () => {
    let allClasses = trainingClasses?.filter((dataset) => dataset?.className !== classDetails?.className);
    setClassList(allClasses);
  };

  const onPagination = (obj) => {
    setPage(obj);
    if (!classificationTest) {
      getImages(obj);
    } else {
      changePagination(obj);
    }
  };

  const getImages = (obj) => {
    let pageNo = (obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo) * obj.pageSize;
    console.log("masking", masking);
    const paginationData = {
      from_index: pageNo,
      end_index: pageNo + (pageSize || 9),
      ...order,
      masking: masking || maskConfirmation ? true : false,
      conditions:
        !imageType || imageType === "all" || imageType === ""
          ? [
            {
              case: "ne",
              column: "fileName",
              value: null
            }
          ]
          : [
            {
              case: "equal",
              column: "imageMode",
              value: imageType === "training" || imageType === 1 ? 1 : 2
            },
            {
              case: "ne",
              column: "fileName",
              value: null
            }
          ]
    };
    setLoader(true);
    getImagesForDataset(url, params.id, seqNo, paginationData)
      .then((result) => {
        setImages([]);
        setLoader(false);
        if (result?.status === API_RESPONSE.SUCCESS_STATUS_CODE && result?.data) {
          setTotalImageCount(result?.data?.count);
          setImages([...result?.data?.images.sort((a, b) => b.$date - a.$date)]);
          setClassDetails({
            seqNo: result?.data?.classSeqNo,
            className: result?.data?.className,
            modelName: result?.data?.modelName
          });
          if (maskConfirmation) {
            setMaskedImageCount(result?.data?.maskedCount);
          }
          if (masking || maskConfirmation) {
            getMaskingCoordinates(result?.data);
          }
        }
      })
      .catch((error) => {
        setLoader(false);
        setImages([]);
      });
  };

  const getMaskingCoordinates = (classData) => {
    let exist = selectedMasks.some((obj) => obj.classSeqNo === classData?.classSeqNo);
    let imagesData = [];
    classData?.images.forEach((obj) => {
      let dimentions = {
        dimentionX: obj?.dimentionX,
        dimentionY: obj?.dimentionY
      };
      imagesData.push(
        obj.defectCoordinates.map((coords, i) =>
          Object.assign(
            convertPixelToPercentage(coords, dimentions, "%"), 
            { data: { index: i }, imageSeqNo: obj.seqNo }, 
            dimentions
          )
        )
      );
    });
    if (!exist) {
      setSelectedMasks({
        className: classData?.className,
        classSeqNo: classData?.classSeqNo,
        masks: imagesData.flat()
      });
      setMaskData(imagesData.flat());
      setMaskedImageCount(CommonMethod.getUniqueDataByField(imagesData.flat(), "imageSeqNo").length);
    } else {
      const stored = selectedMasks.filter((obj) => obj.classSeqNo === classData?.classSeqNo)[0]?.masks;
      const compareMasks = new Set(stored.map((obj) => JSON.stringify({ id: obj?.data?.index, seqNo: obj?.imageSeqNo })));
      const unsavedData = imagesData.flat().filter((obj) => !compareMasks.has(JSON.stringify({ id: obj?.data?.index, seqNo: obj?.imageSeqNo })));

      if (unsavedData.length > 0) {
        trainingManagementStore.updateSelectedMasks(classData?.classSeqNo, unsavedData);
        setMaskData((prev) => [...prev, ...unsavedData]);
      } else {
        setMaskData(stored);
      }
      setMaskedImageCount(CommonMethod.getUniqueDataByField(stored, "imageSeqNo").length);
    }
  };
  const setInitialDropDownClasses = (obj) => {
    let classifiedClassList = [];
    let classes = {};
    classData?.classifiedClasses?.length > 0 &&
      classData?.classifiedClasses.forEach((classItem, index) => {
        classifiedClassList.push({ label: classItem, value: index + 1, selected: true });
      });
    setClassifiedClasses([...classifiedClassList]);
    setSelectedClassifiedClasses([...classifiedClassList]);

    classes[classData?.setClass] = classData?.classifiedClasses;
    setSelectedClasses(classifiedClassList);
    getClassificationTestImages(obj, classes);
  };

  const changePagination = (obj) => {
    let classes = {};
    if (selectedClasses?.length > 0) {
      let newList = selectedClasses.filter((i) => {
        if (i.selected) {
          return i;
        }
      });
      classes[classData?.setClass] = newList.map((i) => i.label);
      getClassificationTestImages(obj, classes);
    }
  };

  const handleChangeDropDownClasses = (updatedList) => {
    let classes = {};
    let newList = updatedList.filter((i) => {
      if (i.selected) {
        return i;
      }
    });
    classes[classData?.setClass] = newList.map((i) => i.label);
    setSelectedClasses(updatedList);
    getClassificationTestImages(page, classes);
  };

  const getClassificationTestImages = (obj, classes) => {
    setLoader(true);
    let pageNo = (obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo) * obj.pageSize;
    let threshold = localStorage.getItem("confusionMatrixThreshold") ? parseFloat(localStorage.getItem("confusionMatrixThreshold")) : 0.8;
    let payload = {
      probability: threshold,
      classes: JSON.parse(JSON.stringify(classes)),
      from_index: pageNo,
      end_index: pageNo + (pageSize || 9),
      asc: "seqNo"
    };
    testManagementStore
      .fetchConfusionMatrixImageListData(params.id, payload)
      .then((result) => {
        setImages([]);
        setLoader(false);
        if (result?.status === API_RESPONSE.SUCCESS_STATUS_CODE && result?.data) {
          setTotalImageCount(result?.count);
          setImages(result?.data);
          setClassDetails({
            className: classData?.setClass
          });
        }
      })
      .catch((error) => {
        console.log(error);
        setLoader(false);
        setImages([]);
      });
  };

  const handleViewImage = (index, imageData) => {
    setSelectedImageData(imageData);
    setActiveImage(index);
    setImageview((isOpen) => !isOpen);
  };

  const selectImages = (image) => {
    // image = { ...image, selected: !image?.selected };
    let selected = selectedImages;
    if (selected.some((item) => item.seqNo === image?.seqNo)) {
      selected.splice(
        selected.findIndex((item) => item.seqNo === image?.seqNo),
        1
      );
    } else {
      selected.push({ seqNo: image?.seqNo, imageMode: image?.imageMode });
    }
    setSelectedImages([...selected]);

    const trainingImages = selected.filter((item) => item.imageMode === 1);
    const validationImages = selected.filter((item) => item.imageMode === 2);
    if (trainingImages.length > 0 && validationImages.length > 0) {
      setDisableMoveImageButton(true);
    } else {
      trainingImages.length > 0
        ? setImageData({ buttonText: "pages.training.manageImages.controls.moveToValidation", imgType: "validation" })
        : validationImages.length > 0
          ? setImageData({ buttonText: "pages.training.manageImages.controls.moveToTraining", imgType: "training" })
          : setImageData({ buttonText: "pages.training.manageImages.controls.moveToTraining", imgType: "training" });
      trainingImages.length < 1 && validationImages.length < 1 ? setDisableMoveImageButton(true) : setDisableMoveImageButton(false);
    }
  };

  const deleteSelectedImages = () => {
    if (selectedImages?.length > 0 && classDetails?.seqNo) {
      const reqPayload = {
        img_seqNo: selectedImages.map((img) => img.seqNo)
      };
      setLoader(true);
      deleteImagesForDataset(params.id, classDetails.seqNo, reqPayload)
        .then((response) => {
          if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            setsnapbarMessage({
              message: t("pages.training.manageImages.messages.imageRecordDeleted")
            });
            getImages(page);
            setSelectedImages([]);
            updateDatasetImageCount(classDetails.seqNo, response?.data?.length);
            setLoader(false);
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.delete-failed") });
          }
        })
        .catch((error) => {
          setLoader(false);
          setsnapbarMessage({ message: t("pages.training.errors.delete-failed") });
        });
    }
  };

  const onSelectImageClass = (event, value) => {
    if (value?.value) {
      setSelectedSeqNo(value?.value);
    }
  };

  const moveSelectedImages = () => {
    if (classDetails?.seqNo && selectedSeqNo) {
      setLoader(true);
      let pageUrl = API_URL.GET_IMAGES_FOR_DATASET;
      if (url === API_URL.CORRECTION_IMAGES) {
        pageUrl = API_URL.SUGGESTION_CLASS_UPDATE;
      }
      let seqNos = selectedImages.map((img) => img.seqNo);
      imageManagementStore
        .saveEditImageClassDetails(params.id, classDetails?.seqNo, { img_seqNo: seqNos, dst_seqNo: selectedSeqNo }, pageUrl)
        .then((response) => {
          setLoader(false);
          if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            trainingManagementStore.removeTransferedSelectedMasks(classDetails?.seqNo,seqNos)
            setsnapbarMessage({ message: t("pages.training.manageImages.messages.imageRecordUpdated") });
            setSelectedImages([]);
            setDestinationClassSeqNo(selectedSeqNo);
            setEditImageClass(false);
            getImages(page);
          } else {
          }
        })
        .catch((error) => {
          setLoader(false);
        });
    }
  };

  const handleImageTypeChange = () => {
    const reqPayload = {
      images: {
        [classDetails?.seqNo]: selectedImages.map((img) => img.seqNo)
      }
    };
    setLoader(true);
    setsnapbarMessage({ message: "" });
    changeImageType(params.id, imageData.imgType, reqPayload)
      .then((response) => {
        if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setsnapbarMessage({ message: t("pages.training.success.image-list.updated", {imageType: imageData.imgType}) });
          setSelectedImages([]);
          getImages(page);
          setLoader(false);
          setImageData({ buttonText: "pages.training.manageImages.controls.moveToTraining", imgType: "" });
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.image-list.update-failed") });
          setLoader(false);
        }
      })
      .catch((error) => {
        setLoader(false);
        setsnapbarMessage({ message: "update failed" });
      });
  };

  const onChangeClassName = (event) => {
    let errMsg = [];
    let value = event.target.value;
    errMsg["errExist"] = t("pages.training.input-parameter.modal.already-exist");
    errMsg["errAlphanumeric"] = t("pages.training.input-parameter.modal.alphanumeric");
    setCurrentClassName(value);
  };

  const renderImages = () => {
    return loader ? (
      <div className={classes.loaderPosition}>
        <Loader size={24} />{" "}
      </div>
    ) : images.length > 0 ? (
      <Grid key={key} container spacing={2}>
        {reverseImages().map((image, key) => {
          return (
            <ViewImage
              masking={masking || maskConfirmation}
              maskData={maskData.filter((obj) => obj.imageSeqNo === image.seqNo)}
              selectedImages={selectedImages}
              selectImages={selectImages}
              imageKey={key}
              index={"image-" + image.seqNo}
              imageData={{ ...image, className: classDetails?.className }}
              handleViewImage={handleViewImage}
              viewParameter={viewParameter}
              imageSelection={imageSelection}
              url={url}
            />
          );
        })}
      </Grid>
    ) : (
      !loader && (
        <div className={classes.noContentMiddle}>
          <div className={classes.noContent}>
            <span>
              <ErrorOutline fontSize="large" className={classes.warningIcon} />
            </span>
            <span className={classes.noContentLabel}>{t("components.basic-table.no-content")}</span>
          </div>
        </div>
      )
    );
  };
  const renderMaskingOutput = () => {
    return loader ? (
      <div className={classes.loaderPosition}>
        <Loader size={24} />
      </div>
    ) : images.length > 0 ? (
      <Grid key={key} container spacing={2}>
        {reverseImages()?.map((image, key) => {
          return (
            <ViewImage
              masking={false}
              maskingConfirmation={true}
              selectedImages={selectedImages}
              selectImages={selectImages}
              imageKey={key}
              index={"image-" + image.seqNo}
              imageData={{ ...image, className: classDetails?.className }}
              handleViewImage={handleViewImage}
              viewParameter={viewParameter}
              imageSelection={imageSelection}
              url={url}
            />
          );
        })}
      </Grid>
    ) : (
      !loader && (
        <div className={classes.noContentMiddle}>
          <div className={classes.noContent}>
            <span>
              <ErrorOutline fontSize="large" className={classes.warningIcon} />
            </span>
            <span className={classes.noContentLabel}>{t("components.basic-table.no-content")}</span>
          </div>
        </div>
      )
    );
  };

  const reverseImages = () => {
    return images; //!important: In order to avoid array reverse during production build this is required
  };

  const handleClick = (type) => {
    if (viewParameter) {
      return;
    }
    if (type === 0) {
      setUploaderAction({
        isOpen: true,
        uploaderType: "add-images",
        className: classDetails?.className,
        id: params?.id
      });
    } else if (type === 1) {
      setConfirmAction("delete");
    } else if (type === 2) {
      // getClassLists();
      // setConfirmAction("move");
      setEditImageClass(true);
    } else if (type === 3) {
      setCurrentClassName(classDetails?.className);
      setConfirmAction("edit");
    }
  };

  useEffect(() => {
    if (maskData.length > 0) {
      trainingManagementStore.setSelectedMasks({ className: classDetails.className, classSeqNo: classDetails.seqNo, masks: maskData });
      setMaskedImageCount(CommonMethod.getUniqueDataByField(maskData, "imageSeqNo").length);
    }
  }, [maskData?.length, maskData]);

  const updateMasking = (defectData) => {
    let maskedData = [];
    let payload = {
      classSeqNo: classDetails.seqNo,
      defectData
    };
    trainingManagementStore
      .updateMaskingCoordinates(params.id, payload)
      .then((res) => {
        if (res.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          getImages(page);
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.image-list.update-failed") });
        }
      })
      .catch((error) => {
        setLoader(false);
        setsnapbarMessage({ message: "update failed" });
      });
  };

  return (
    <>
      {editImageClass && (
        <EditImageClass
          open={editImageClass}
          setOpen={setEditImageClass}
          trainingClasses={trainingClasses}
          classDetails={classDetails}
          setSelectedSeqNo={setSelectedSeqNo}
          moveSelectedImages={moveSelectedImages}
        />
      )}
      <Accordion key={key} expanded={!expanded} onChange={() => setExpanded(!expanded)} defaultExpanded={true} className={classes.accMarginTop}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          className={!classificationTest ? classes.accSummary : classes.classificationAccSummary}
        >
          {classDetails && (
            <Grid container>
              <Grid item xs={!classificationTest ? 2 : 4}>
                <label htmlFor="">{classDetails?.className}</label>
              </Grid>
              <Grid item xs={2}>
                {masking || maskConfirmation ? (
                  <label>{t("pages.image-management.image-list.no-of-masked-images")}: {maskedImageCount}</label>
                ) : (
                  <label htmlFor="">{trainingDetails?.modelName}</label>
                )}
              </Grid>
            </Grid>
          )}
        </AccordionSummary>
        <AccordionDetails className={classes.accDetails}>
          <div className={classes.container}>
            {classificationTest && dropdown && (
              <div className={classes.dorpdown}>
                <DropDown
                  classifiedClasses={classifiedClasses}
                  selectedClassifiedClasses={selectedClassifiedClasses}
                  setClassifiedClasses={setClassifiedClasses}
                  setSelectedClassifiedClasses={setSelectedClassifiedClasses}
                  handleChangeDropDownClasses={handleChangeDropDownClasses}
                  count={setSelectedCount}
                />
              </div>
            )}
            <div className={classes.thumbWrap}>
              {renderImages()}
              {showMaskedImages && renderMaskingOutput()}
            </div>
            <div className={classes.bottom}>
              <Pagination
                onChange={onPagination}
                itemCount={totalImageCount}
                pageNo={page?.pageNo || 1}
                pageSize={page?.pageSize || 9}
                disableItemPerPage={true}
                disabled={false}
              />
              <div className={classes.buttonWrapper}>
                {showAddImage && (
                  <>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => handleClick(0)}
                      disabled={selectedImages?.length > 0 || viewParameter}
                    >
                      {t("pages.training.manageImages.controls.addImages")}
                    </Button>{" "}
                    &nbsp;&nbsp;
                  </>
                )}
                {showDeleteImage && (
                  <>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => handleClick(1)}
                      disabled={selectedImages?.length < 1 || viewParameter}
                    >
                      {t("pages.training.manageImages.controls.deleteImages")}
                    </Button>{" "}
                    &nbsp;&nbsp;
                    <CustomConfirmation
                      open={confirmAction === "delete"}
                      onClose={() => {
                        setConfirmAction("");
                      }}
                      onSubmit={deleteSelectedImages}
                      primary={"pages.training.manageImages.modal.delete-btn"}
                      secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                      title={t("pages.training.manageImages.modal.deleteRecordTitle")}
                      message={t("pages.training.manageImages.modal.deleteRecordMessage")}
                    />
                  </>
                )}
                {showEditClassName && (
                  <>
                    <CustomConfirmation
                      open={confirmAction === "edit"}
                      onClose={() => {
                        setConfirmAction("");
                      }}
                      onSubmit={moveSelectedImages}
                      primary={"pages.training.manageImages.modal.ok-btn"}
                      secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                      title={t("pages.training.manageImages.controls.editClass")}
                      message={
                        <>
                          <FormControl className={classes.formControl}>
                            <TextField
                              fullWidth
                              id="className"
                              name="className"
                              label={t("pages.training.input-parameter.grid.class-name")}
                              value={currentClassName}
                              autoFocus
                              onChange={onChangeClassName}
                              error={modalFormErrors["className"]}
                              helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
                            />
                          </FormControl>
                        </>
                      }
                    />
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => handleClick(3)}
                      disabled={selectedImages?.length !== 1 || viewParameter}
                    >
                      {t("pages.training.manageImages.controls.editClass")}
                    </Button>
                    &nbsp;&nbsp;
                  </>
                )}

                {showEditClass && (
                  <>
                    <CustomConfirmation
                      open={confirmAction === "move"}
                      onClose={() => {
                        setConfirmAction("");
                      }}
                      onSubmit={moveSelectedImages}
                      primary={"pages.training.manageImages.modal.ok-btn"}
                      secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                      title={t("pages.training.manageImages.modal.editImageClassTitle")}
                      message={
                        <>
                          <FormControl className={classes.formControl}>
                            <Autocomplete
                              id="combo-box"
                              clearOnEscape
                              options={classList?.map((dataset) => {
                                return { label: dataset.className, value: dataset.seqNo };
                              })}
                              getOptionLabel={(option) => option?.label}
                              onChange={(event, value) => onSelectImageClass(event, value)}
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  label="Class Name"
                                  id="className"
                                  name="className"
                                  margin="normal"
                                  error={modalFormErrors["className"]}
                                  helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
                                />
                              )}
                            />
                          </FormControl>
                        </>
                      }
                    />
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => handleClick(2)}
                      disabled={selectedImages?.length < 1 || viewParameter}
                    >
                      {t("pages.training.manageImages.controls.editImageClass")}
                    </Button>
                    &nbsp;&nbsp;
                  </>
                )}

                {showMoveImages && (
                  <>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={handleImageTypeChange}
                      disabled={selectedImages?.length < 1 || disableMoveImageButton}
                    >
                      {t(imageData.buttonText)}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      {carouselView && (
        <>
          {!maskConfirmation && (
            <Carousel
              open={isImageview}
              maskingFuncs={maskingFuncs}
              onClose={() => {
                setImageview((isOpen) => !isOpen);
                // onMaskingPagination({
                //   ...maskpage, pageNo: 1
                // });
                // reverseImages();
              }}
              active={activeImage}
              page={page}
              totalImageCount={totalImageCount}
              setActiveImage={setActiveImage}
              sliderData={reverseImages()}
            />
          )}
          {maskConfirmation && (
            <CompareImageCarousel
              open={isImageview}
              onClose={() => {
                setImageview((isOpen) => !isOpen);
              }}
              maskData={selectedImageData ? maskData.filter((obj) => obj.imageSeqNo === selectedImageData.seqNo) : []}
              imageData={selectedImageData}
              active={activeImage}
              page={page}
              totalImageCount={totalImageCount}
              setActiveImage={setActiveImage}
              sliderData={reverseImages()}
              className={classDetails?.className}
            />
          )}
        </>
      )}
    </>
  );
});

export default ImageLists;
