import { TextField, Slider } from "@material-ui/core";
import PropTypes from "prop-types";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useStyles } from "./styles";

const ThresholdSlider = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();

  const { onThresholdChange, disabled, initialProbabilityTreshold, decimalPoints } = props;

  const thresholdValues = [
    { value: 0.0, label: "0.0000" },
    { value: 1.0, label: "1.0000" }
  ];
  const [sliderValue, setSliderValue] = useState(initialProbabilityTreshold.toFixed(decimalPoints));

  const handleSliderChange = (event, newValue) => {
    if (newValue) {
      console.log("newValue", newValue)
      setSliderValue(parseFloat(newValue).toFixed(decimalPoints));
    }
  };

  const handleThresholdChange = (newValue, event) => {
    setSliderValue(parseFloat(newValue));
    onThresholdChange(parseFloat(newValue));
  };

  return (
    <div className={classes.buttonWrapper}>
      {!disabled && (
        <>
          <label>{t("pages.defect-inspection.controls.thresholdSlider")}</label>
          <div className={classes.sliderRoot}>
            <Slider
              className={classes.sliderClass}
              value={sliderValue}
              onChange={handleSliderChange}
              onChangeCommitted={() => handleThresholdChange(sliderValue)}
              aria-labelledby="continuous-slider"
              max={1}
              min={0}
              step={0.0001}
              marks={thresholdValues}
            />
          </div>
          <TextField
            id="probabilityThreshold"
            name="probabilityThreshold"
            margin="normal"
            type="number"
            className={classes.thresholdInput}
            value={sliderValue}
            inputProps={{ maxLength: 6, max: 1, min: 0, step: 0.0001 }}
            onChange={(event) => handleThresholdChange(event.target.value, event)}
            onBlur={(event) => handleSliderChange(event, sliderValue)}
          />
        </>
      )}
    </div>
  );
};

export default ThresholdSlider;

ThresholdSlider.propTypes = {
  disabled: PropTypes.bool,
  onThresholdChange: PropTypes.func,
  initialProbabilityTreshold: PropTypes.number,
  decimalPoints: PropTypes.number
};
