import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import { Checkbox, FormControlLabel, TextField } from '@material-ui/core';
import { useHistory, useParams } from "react-router";
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TestManagementStore from "../../stores/testManagementStore";
import CustomSnackBar from "../snackbar";
import { Loader } from "../../shared/components/ui";
import { API_RESPONSE, APP_ROUTES } from "../../appconstants";

const AddClassificationTest = (props) => {
  const classes = useStyles();
  const params = useParams();
  const history = useHistory();
  const { t } = useTranslation();
  const form = useRef();
  const { open, setOpen, noRedirect, title, comment, callBack, askTrainingModel, id } = props;
  const testManagementStore = useContext(TestManagementStore);
  const [formError, setFormError] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loader, setLoader] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [config, setConfig] = useState({
    fields: {
      title: {
        isRequired: { message: t("validation.message.required") },
        isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.title") }) }
      },
      comment: {
        isRequired: { message: t("validation.message.required") },
      },
      useTrainingModel: {
        initialValue: true
      }
    },
    onSubmit: state => {
      setSubmitted(state?.submitted);
      if (state?.errors) {
        setFormError({ ...state.errors });
      }
    },
    showErrors: 'blur',
    submitted: false
  });
  const [formContent, setFormContent] = useState({
    title: title || "",
    comment: comment || "",
    deviceName: "",
    designGroup: "",
    processGroup: "",
    lotId: "",
    trainingId: id,
    useTrainingModel: false
  });
  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  const saveNewTest = (e) => {
    form.current.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );

    if (formError?.title === null && formError?.comment === null) {
      let data = {...formContent, lotId: formContent?.lotId?.toString()}
      //Validation passed
      setsnapbarMessage({ message: "" });
      testManagementStore
        .insertTestingList(data)
        .then((response) => {
          if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE && response?.data?.testing?._id) {
            if (!noRedirect) {
              testManagementStore.clearTestingData();
              testManagementStore.setSelectedTestModel(response.data.testing._id, params.id);
              history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS.replace(":id", response.data.testing._id));
            }
            setsnapbarMessage({ message: t("pages.classification-test.success.testing-list.update") });
            if (callBack) {
              callBack();
            }
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.training-list.save-failed") });
          }
        })
        .catch((error) => {
          console.log("error", error);
          setsnapbarMessage({ message: t("pages.training.errors.training-list.save-failed") });
        });
    }
  }

  useEffect(() => { //Sets values after change
    setFormContent({ ...formContent, ...values });
  }, [values]);

  useEffect(() => {//This is required to validate and show error message
    errors && !submitted && setFormError(errors);
    submitted && setSubmitted(false);
  }, [errors])

  useEffect(() => { //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
  }, [form?.current])

  const onClose = () => {    
    setOpen(false);
    values.title=null;
    values.comment=null;
    formContent.title=null;
    formContent.comment=null; 
    formError.title = null;
    formError.comment = null;
    errors.title=null;
    errors.comment=null; 
  }
  return (
    <Observer>
      {() => (
        <>
          {loader && <Loader size={24} />}
          {snapbarMessage.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          <CustomConfirmation
            open={open}
            onClose={onClose}
            noImmediateClose={true}
            onSubmit={saveNewTest}
            primary={'pages.classification-test.testing-list.controls.ok'}
            secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
            title={t("pages.classification-test.testing-list.modal.new-testing")}
            message={<>
              <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                <TextField
                  fullWidth
                  id="title"
                  name="title"
                  label={'Title'}
                  margin="normal"
                  value={formContent?.title} autoFocus
                  {...getFieldProps('title')}
                  error={formError.title}
                  helperText={formError.title}
                />
                <TextField
                  fullWidth
                  id="comment"
                  name="comment"
                  label={'Comment'}
                  margin="normal"
                  value={formContent?.comment}
                  {...getFieldProps('comment')}
                  error={formError.comment}
                  helperText={formError.comment}
                />
               {askTrainingModel && <FormControlLabel
                  control={
                    <Checkbox
                    {...getFieldProps('useTrainingModel')}
                      checked={formContent?.useTrainingModel}
                      value={formContent?.useTrainingModel}
                      name="usetrainingmodel"
                      id="usetraninigmodel-checkbox"
                      color="primary"
                    />
                  }
                  label={
                    <label>
                      {t("pages.classification-test.testing-list.modal.new-testing-checkbox")}
                    </label>
                  }
                 />}
              </form>
            </>} />
        </>
      )}
    </Observer >
  );
};
export default AddClassificationTest;
