import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from "@material-ui/core";
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TestManagementStore from "../../stores/testManagementStore";
import CustomSnackBar from "../snackbar";
import { Loader } from "../../shared/components/ui";
import { API_RESPONSE, APP_ROUTES } from "../../appconstants";
import { checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";
import { useHistory } from "react-router";

const EditClassificationTest = (props) => {
  const { t } = useTranslation();
  const form = useRef();
  const history = useHistory();
  const { open, setOpen, callBack, testing, title } = props;
  const testManagementStore = useContext(TestManagementStore);
  const [formError, setFormError] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loader, setLoader] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [config, setConfig] = useState({
    fields: {
      title: {
        initialValue: testing?.title || "",
        isRequired: { message: t("validation.message.required", { field: "" }) },
        isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.title") }) }
      },
      comment: {
        initialValue: testing?.comment || "",
        isRequired: { message: t("validation.message.required", { field: "" }) }
      }
    },
    onSubmit: (state) => {
      setSubmitted(state?.submitted);
      if (state?.errors) {
        setFormError({ ...state.errors });
      }
    },
    showErrors: "blur",
    submitted: true
  });
  const [formContent, setFormContent] = useState({
    title: testing?.title || "",
    comment: testing?.comment || "",
    deviceName: testing?.deviceName || "",
    designGroup: testing?.designGroup || "",
    processGroup: testing?.processGroup || "",
    lotId: testing?.lotId || "0"
  });
  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  const updateTest = (e) => {
    
    let data = {...formContent, lotId: formContent?.lotId?.toString()}
    testManagementStore
      .updateTestingList(testing?._id, data)
      .then((response) => {
        if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setsnapbarMessage({ message: t("pages.classification-test.success.testing-list.update") });
          setOpen(false);
          if (callBack) {
            callBack();
          }
        } else {
          setsnapbarMessage({ message: t("pages.classification-test.errors.testing-list.update-failed") });
        }
      })
      .catch((error) => {
        console.log("error", error);
        setsnapbarMessage({ message: t("pages.training.errors.training-list.save-failed") });
      });
  };

  const copyAndReexecuteTest = () => {
    testManagementStore
      .copyAndReexecuteTest(testing?._id, formContent)
      .then((response) => {
        if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          testManagementStore.clearTestingData();
          history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS.replace(":id", response.data._id));
        } else {
          setsnapbarMessage({ message: t("pages.classification-test.errors.testing-list.save-failed") });
        }
      })
      .catch((error) => {
        console.log("error", error);
        setsnapbarMessage({ message: t("pages.training.errors.training-list.save-failed") });
      });
  };

  const handleSubmit = () => {
    form.current.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    let formArray = objToArray(formError);
    let notNull = checkNotNullFromArray(formArray);
    if ((formArray?.length <= 0 || !notNull) && testing?._id) {
      //Validation passed
      setsnapbarMessage({ message: "" });
      switch (title) {
        case "pages.classification-test.testing-list.modal.edit-testing":
          updateTest();
          break;
        case "pages.classification-test.testing-list.modal.copy-and-reexecute":
          copyAndReexecuteTest();
          break;
        default:
          break;
      }
    }
  };

  useEffect(() => {
    //Sets values after change
    setFormContent({ ...formContent, ...values });
  }, [values]);

  useEffect(() => {
    //This is required to validate and show error message
    errors && !submitted && setFormError(errors);
    submitted && setSubmitted(false);
  }, [errors]);

  useEffect(() => {
    //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
  }, [form?.current]);

  return (
    <Observer>
      {() => (
        <>
          {loader && <Loader size={24} />}
          {snapbarMessage.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}

          <CustomConfirmation
            open={open}
            onClose={() => {
              setOpen(false);
            }}
            noImmediateClose={true}
            onSubmit={handleSubmit}
            primary={"pages.classification-test.testing-list.controls.ok"}
            secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
            title={t(title)}
            message={
              <>
                <form action="javascript:;" ref={form} autoComplete="off" {...getFormProps()}>
                  <TextField 
                    fullWidth
                    aria-valuetext={formContent?.title}
                    id="title"
                    name="title"
                    margin="normal"
                    label={t("validation.field.title")}
                    value={formContent?.title} autoFocus
                    {...getFieldProps("title")}
                    error={formError.title}
                    helperText={formError.title}
                  />
                  <TextField
                    aria-valuetext={formContent?.comment}
                    fullWidth
                    id="comment"
                    name="comment"
                    margin="normal"
                    label={t("validation.field.comment")}
                    value={formContent?.comment}
                    {...getFieldProps("comment")}
                    error={formError.comment}
                    helperText={formError.comment}
                  />
                </form>
              </>
            }
          />
        </>
      )}
    </Observer>
  );
};
export default EditClassificationTest;
