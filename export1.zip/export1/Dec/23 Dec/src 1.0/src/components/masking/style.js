import { makeStyles } from "@material-ui/core/styles"

const handleSize = 8;
export const useStyles = makeStyles(()=>({
	deleteButton:{
		display:'none',
		'&:hover':{
			display:'inline-block'
		}
	},
	drawMaskBox: {
		position: 'absolute',
		border: '1px solid #FF0000',
		outline: '2px solid #FF0000',
		cursor:(props)=> props.readOnly?'':'move',
		zIndex:1,
		'&:hover button':{
			display:'inline-block'
		}
	},
	resizeHandleSE: {
		position: 'absolute',
		bottom: -1 * handleSize/2,
		right: -1 * handleSize/2,
		width: handleSize,
		height: handleSize,
		outline: '1px solid rgba(0,0,0,0.5)',
		border: '1px solid rgba(255,255,255,0.5)',
		cursor: 'se-resize'
	},
	resizeHandleSW: {
		position: 'absolute',
		bottom: -1 * handleSize/2,
		left: -1 * handleSize/2,
		width: handleSize,
		height: handleSize,
		outline: '1px solid rgba(0,0,0,0.5)',
		border: '1px solid rgba(255,255,255,0.5)',
		cursor: 'sw-resize'
	},
	resizeHandleNW: {
		position: 'absolute',
		top: -1 * handleSize/2,
		left: -1 * handleSize/2,
		width: handleSize,
		height: handleSize,
		outline: '1px solid rgba(0,0,0,0.5)',
		border: '1px solid rgba(255,255,255,0.5)',
		cursor: 'nw-resize'
	},
	resizeHandleNE: {
		position: 'absolute',
		top: -1 * handleSize/2,
		right: -1 * handleSize/2,
		width: handleSize,
		height: handleSize,
		outline: '1px solid rgba(0,0,0,0.5)',
		border: '1px solid rgba(255,255,255,0.5)',
		cursor: 'ne-resize'
	},
	container: {
		position: 'relative',
		display: 'inline-block',
		width:'100%',
		border:'1px solid rgb(203, 203, 203,0.1)',	
	},
	countMasks:{
		position:'absolute',
		bottom:0,
		right:0,
		margin:5 ,
		padding:5,
		background:'#ffffff',
		border:'1px solid #707070',
		zIndex:3,
	},
	saveMasks:{
		position:'absolute',
		bottom:0,
		left:0,
		margin:5 ,
		padding:5,
		background:'#ffffff',
		border:'1px solid #707070',
		zIndex:3,
	},
	localStyle:{
        width:(props)=> `${props.rect?.[props.returnType?.width]}%`,
        height:(props)=> `${props.rect?.[props.returnType?.height]}%`,
        left:(props)=> `${props.rect?.[props.returnType?.x]}%`,
        top:(props)=> `${props.rect?.[props.returnType?.y]}%`,  
    }
}))