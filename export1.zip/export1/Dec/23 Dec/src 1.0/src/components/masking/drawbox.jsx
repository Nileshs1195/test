import React from 'react'
import {useStyles} from './style';
import clsx from 'clsx';

const DrawBox = (props) => {

    const {key, rect, drawMask, readOnly, deleteMask, returnType } = props;
    const classes = useStyles(props);
    
    return (
        <div key={key} className={clsx(classes.localStyle,classes.drawMaskBox)}  onMouseDown={drawMask} onTouchStart={drawMask} data-wrapper="wrapper">
            {!readOnly && <div>
                <div data-dir="se" className={classes.resizeHandleSE}/>{/* width */}
                <div data-dir="sw" className={classes.resizeHandleSW}/>{/* height */}
                <div data-dir="nw" className={classes.resizeHandleNW}/>{/* x */}
                <div data-dir="ne" className={classes.resizeHandleNE}/>{/* y */}
            </div>}
            {!readOnly && <button data-button="button" onClick={()=>deleteMask(rect)} className={classes.deleteButton}>Delete</button>}
        </div>
    )
}
export default DrawBox;
