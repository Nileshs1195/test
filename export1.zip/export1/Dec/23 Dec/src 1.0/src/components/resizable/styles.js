import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles((theme)=>({
    root:{
        height: '100%',
        zIndex: 0,
        marginTop: theme.spacing(2),
        overflow:props=> props?.overflow?props.overflow:'auto',
        boxShadow:'0px 2px 1px -1px rgb(0 0 0 / 20%), 0px 1px 1px 0px rgb(0 0 0 / 14%), 0px 1px 3px 0px rgb(0 0 0 / 12%)'
    },
    panel:{
        zIndex:2,
        overflow:props=> props?.overflow?props.overflow:'auto',
    },
    dragBox:{
        cursor: 'row-resize',
        alignSelf: 'stretch',
        alignItems: 'center',
        padding: '0 1rem',
        // margin: 1,
    },
    divider:{
        height: '100%',
        border: '1px solid #fff',
    }
}));