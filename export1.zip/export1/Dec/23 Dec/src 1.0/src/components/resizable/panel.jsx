import React, { useEffect, useRef } from 'react';

const Panel = (props) => {
    const { classname, children, height, setHeight } = props;
    const panelRef = useRef(null);
  
    useEffect(() => {
      if (panelRef.current) {
        if (!height) {
          setHeight(panelRef.current.clientHeight);
          return;
        }
  
        panelRef.current.style.maxHeight = `${height}px`;
        panelRef.current.style.minHeight = `55px`;
      }
    }, [panelRef, height, setHeight]);
  
    return <div className={classname} {...props} ref={panelRef}>{children}</div>;
};
  
export default Panel;