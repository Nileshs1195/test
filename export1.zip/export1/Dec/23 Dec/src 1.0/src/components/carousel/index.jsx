import React, { useState, useEffect } from 'react';
import { useStyles } from './style';
import { Modal } from '@material-ui/core';
import Slide from './slide';

const Carousel = (props) => {
  const { open, onClose,  maskingFuncs, sliderData, active, setActiveImage, totalImageCount, page } = props;
  const classes = useStyles();
  const [currentIndex, setCurrentIndex] = useState(() => active);

  useEffect(() => {
    setCurrentIndex(active);
  }, [active]);

  useEffect(() => {
    window.addEventListener('keyup', onKeyup);
  }, []);

  const onKeyup = (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      previous();
    } else if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      next();
    }
  }

  const next = () => {
    setActiveImage(active + 1 <= sliderData?.length ? active + 1 : active);
  }

  const previous = () => {
    setActiveImage(active - 1 >= 0 ? active - 1 : 0);
  }

  return (
    <Modal open={open} onClose={onClose}>
      <div className={classes.main}>
        <div className={classes.slides}>
          {sliderData?.length > 0 && sliderData?.map((slide, index) => {
            return (
              <Slide
                key={index}
                index={index + 1}
                totalImages={sliderData.length}
                slideData={slide}
                onClose={onClose}
                activeImage={active}
                seqNos = {sliderData?.map(seqNo=>seqNo?.seqNo).join(',')}
                page={page}
                totalImageCount={totalImageCount}
                offset={currentIndex - index}
                previous={previous}
                maskingFunc = {maskingFuncs}
                next={next}
              />
            )
          })}
        </div>
      </div>
    </Modal>
  )
}
export default Carousel
