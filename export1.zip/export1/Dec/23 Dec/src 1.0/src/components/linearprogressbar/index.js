import React, { useState, useEffect, useContext } from "react";
import LinearProgress from "@material-ui/core/LinearProgress";
import Typography from "@material-ui/core/Typography";
import { useParams } from "react-router-dom";
import Box from "@material-ui/core/Box";
import { useStyles } from "./style";
import IO from "socket.io-client";
import { SETTINGS } from "../../appsettings";
import { useTranslation } from "react-i18next";
import AppStore from "../../stores/appstore";
import { ErrorOutlineOutlined } from "@material-ui/icons";
import { Loader } from "../../shared/components/ui";
import { secondsToHms } from "../../helpers/CommonMethods";
const socket = IO(SETTINGS.SOCKET_URL, {
  withCredentials: true,
  upgrade: true,
  // transports:["socket"]
});

const LinearProgressWithLabel = props => {
  const classes = useStyles();
  const { t } = useTranslation();

  return (
    <div>
      <Box display="flex">
        <Box width="50%">
          <Typography variant="body2">{`${t(
            "pages.training.training-parameter.dataset-mode.auto-param-search.progress"
          )}: ${Math.round(props?.value)}%`}</Typography>
        </Box>
        <Box>
        {
            props.executionType === "trainingExecution" &&
          <Typography variant="body2">
            {`${t(
              "pages.training.training-parameter.dataset-mode.auto-param-search.passed-time"
            )}:
              ${props?.passedTime?.hours +
              ":" +
              props?.passedTime?.minutes +
              ":" +
              props?.passedTime?.seconds}`}
          </Typography>
        }
        </Box>
      </Box>
      <Box display="flex" alignItems="center" mt={1}>
        <Box width="100%">
          <LinearProgress
            className={classes.bar}
            variant="determinate"
            value={props.value}
            {...props}
          />
        </Box>
      </Box>
    </div>
  );
};


const LinearIndeterminateWithLabel = props => {
  const classes = useStyles();
  const { t } = useTranslation();

  return (
    <>
          <Box display="flex">
            <Box width="50%">
          {
            props.executionType !== "parameterSearch" &&
              <Typography variant="body2">{`${t(
                "pages.training.training-parameter.dataset-mode.auto-param-search.progress"
              )}: ${Math.round(props?.value)}%`}</Typography>
          }
            </Box>
          
          {
            (props.executionType === "parameterSearch" || props.executionType === "trainingExecution") &&
            <Typography variant="body2">
              {`${t(
                "pages.training.training-parameter.dataset-mode.auto-param-search.passed-time"
              )}:
                ${props?.passedTime?.hours +
                ":" +
                props?.passedTime?.minutes +
                ":" +
                props?.passedTime?.seconds}`}
            </Typography>
          }
        </Box>

      <Box display="flex" alignItems="center" mt={1}>
        <Box width="100%">
          <LinearProgress
            className={classes.bar}
            variant={props.value > 99 ? "determinate" : "indeterminate"}
            {...props}
          />
        </Box>
      </Box>
    </>
  );
};

const LinearProgressBar = props => {
  const {
    setResultSet,
    displayData,
    method,
    stopExecution,
    executionType,
    loadingAction,
    batchData,
  } = props;
  const params = useParams();
  const { t } = useTranslation();
  const classes = useStyles();
  const appStore = useContext(AppStore);
  const { setsnapbarMessage } = appStore;
  const [progressPercentage, setProgressPercentage] = useState(batchData?.progress || 0);
  const [elapsedTime, setElapsedTime] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0,
    milliseconds: 0
  });
  const [loader, setLoader] = useState(false);
  const [resultSet, setResultData] = useState();
  const [executionFailed, setExecutionFailed] = useState(false);

  useEffect(() => {
    setProgressPercentage(batchData?.progress);
  }, [batchData]);

  useEffect(() => {
    if (!socket.connected) {
      socket.connect();
    }
    runExecutionLog(params.id, progressPercentage);
    setTimeout(() => {
      if (!resultSet || resultSet?.status === 0) {
        setExecutionFailed(true);
        if (progressPercentage === 100) {
          setExecutionFailed(false);
        }
      }
    }, SETTINGS.EXECUTION_TIMEOUT || 1000 * 60);
  }, []);

  useEffect(() => {
    if (stopExecution && socket.connected) {
      socket.disconnect();
    }
  }, [stopExecution]);

  const runExecutionLog = (id, pgr) => {
    setLoader(false);
    socket.emit(method, { id, seqNo: params.seqNo, pgr }, result => {
      setLoader(false);
      if (result?.seqNo == params.seqNo) {
        renderData({ ...result }, pgr);
        if (result?.status === 5 || result?.status === 7 || result?.status === 8) {
          if (result?.status !== 7) {
            setsnapbarMessage({
              message: t("pages.training.errors.training-list.execution-failed")
            });
            setExecutionFailed(true);
          }
          setLoader(false);
          socket.disconnect();
        } else if (result?.status < 5 && result?.baseMode === 0) {
          if (result?.status !== 7) {
            setsnapbarMessage({
              message: t("pages.training.errors.training-list.execution-failed")
            });
            setExecutionFailed(true);
          }
          setLoader(false);
          socket.disconnect();
        } else if (result?.status < 5 || result?.status === 6) {
          setTimeout(() => {
            setLoader(true);
          }, 5000);
          runExecutionLog(id, result.progress);
        }
      } else {
        setLoader(false);
        socket.disconnect();
      }
    });
  };

  const renderData = (data, previousPercentage) => {
    let time = msToTime(data?.elapsedTime);
    data.time = time;
    setProgressPercentage(data.progress);
    setResultSet(data);
    setResultData(data);
    setLoader(false);
    if (data.progress === 100 || (data.progress > previousPercentage && executionType === "trainingExecution")) {
      displayData();
    }
  };

  const msToTime = duration => {
    let time = secondsToHms(duration);
    setElapsedTime(time);
    return time;
  };

  return (
    <div className={classes.root}>
      {
        progressPercentage >= 100 && (resultSet?.status === 3 || resultSet?.status === 4 || resultSet?.status === 6) && <Loader size={24} />
      }
      {(!resultSet || resultSet?.status === 0 || resultSet?.status === 1 || resultSet?.status === 2 || resultSet?.status === 7 || resultSet?.status === 6) && !executionFailed &&
        <>
          {!loadingAction && progressPercentage > 0 ?
            <>
              {
                progressPercentage < 100 && loader && <Loader size={24} />
              }
              <LinearProgressWithLabel
                value={progressPercentage}
                passedTime={elapsedTime}
                executionType={executionType}
              /></> :
            <LinearIndeterminateWithLabel
              value={progressPercentage}
              passedTime={elapsedTime}
              executionType={executionType}
            />
          }
        </>
      }
      {executionFailed && resultSet?.status !== 7 && <div className={classes.textExecutionError}>
        <ErrorOutlineOutlined style={{ fontSize: "24px" }} />
        <br />
        {t("pages.training.errors.training-list.execution-failed-title")}
      </div>}
    </div>
  );
};
export default LinearProgressBar;
