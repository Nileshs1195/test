import React from 'react'
import { useStyles } from "./style";
import { Grid } from "@material-ui/core";
import { SETTINGS } from "../../appsettings";
import { API_URL } from "../../appconstants";

const GraphImage = ({ graphData, params }) => {
    const classes = useStyles();
    return (
        <>
            <Grid container spacing={1} className={classes.imageBox}>
                <Grid item xs={12} sm={6}>
                    {graphData?.accuracyData?.image && 
                        <>
                            {graphData?.accuracyData?.data?.length > 0 && graphData?.accuracyData?.data?.map((data, key) => {
                                return (
                                    <div key={key} style={{display: "flex"}}>
                                        <hr className={classes.imageLegendTraining} style={{backgroundColor: graphData?.accuracyData?.color?.[key] || "orange"}} />
                                        <div>{data}</div>
                                    </div>
                                )
                            })}
                            <img className={classes.imageItem} src={SETTINGS.BASE_API_URL + API_URL.LOG_IMAGE_URL.replace("{id}", params.id).replace("{seqNo}", params.seqNo).replace("{fileName}", graphData?.accuracyData?.image)} alt="Accuracy Image" />
                        </>                  
                    }
                </Grid>
                <Grid item xs={12} sm={6}>
                    {graphData?.lossData?.image && 
                    <>
                        {graphData?.lossData?.data?.length > 0 && graphData?.lossData?.
                            data?.map((data, key) => {
                                return (
                                    <div key={key} style={{display: "flex"}}>
                                        <hr className={classes.imageLegendTraining} style={{backgroundColor: graphData?.lossData?.color?.[key] || "orange"}} />
                                        <div>{data}</div>
                                    </div>
                                )
                            })}
                            <img className={classes.imageItem} src={SETTINGS.BASE_API_URL + API_URL.LOG_IMAGE_URL.replace("{id}", params.id).replace("{seqNo}", params.seqNo).replace("{fileName}", graphData?.lossData?.image)} alt="Loss Image" />
                    </>
                    }
                </Grid>
            </Grid>
        </>
    )
}

export default GraphImage
