import React, { useEffect, useState } from "react";
import Modal from "../../shared/components/ui/modal";
import { useTranslation } from "react-i18next";
import CompareImageSlide from "./compareImageSlide";

const CompareImageCarousel = (props) => {
  const { open, onClose, sliderData, active, setActiveImage, totalImageCount, page, imageData, maskData, className } = props;
  const { t } = useTranslation();
  const [currentIndex, setCurrentIndex] = useState(() => active);

  useEffect(() => {
    setCurrentIndex(active);
  }, [active]);

  useEffect(() => {
    window.addEventListener("keyup", onKeyup);
  }, []);

  const onKeyup = (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      previous();
    } else if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      next();
    }
  };

  const next = () => {
    setActiveImage(active + 1 <= sliderData?.length ? active + 1 : active);
  };

  const previous = () => {
    setActiveImage(active - 1 >= 0 ? active - 1 : 0);
  };

  return (
    <Modal open={open} onClose={onClose}>
      <CompareImageSlide
        index={currentIndex + 1}
        totalImages={sliderData.length}
        page={page}
        totalImageCount={totalImageCount}
        previous={previous}
        next={next}
        imageData={imageData}
        maskData={maskData}
        className={className}
      />
    </Modal>
  );
};
export default CompareImageCarousel;
