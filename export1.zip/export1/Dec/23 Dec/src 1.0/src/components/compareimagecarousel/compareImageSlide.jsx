import React from "react";
import { useStyles } from "./style";
import { ChevronLeft, ChevronRight } from "@material-ui/icons";
import { Grid, Typography } from "@material-ui/core";
import { SETTINGS } from "../../appsettings";
import MaskingImage from "../masking";
import { API_URL } from "../../appconstants";
import { useParams } from "react-router";
import { useTranslation } from "react-i18next";

const CompareImageSlide = (props) => {
  const { index, totalImages, previous, next, page, totalImageCount, imageData, maskData, className } = props;
  const classes = useStyles();
  const params = useParams();
  const { t } = useTranslation();

  const titleLimit = 20;
  const returnFormat = {
    x: "xmin",
    height: "ymax",
    y: "ymin",
    width: "xmax"
  };

  const shortenFileName = (fileName) => {
    if (fileName) {
      let extensionIndex = fileName?.lastIndexOf(".");
      let fileNameWithoutExtension = fileName?.substring(0, extensionIndex);
      let extension = fileName.substring(extensionIndex);
      return fileName?.length > titleLimit ? fileNameWithoutExtension.substring(0, titleLimit) + "...." + extension : fileName;
    }
  };

  const getAIMaskedImage = () => {
    return (
      SETTINGS.BASE_API_URL +
      API_URL.MASKING_AI_IMAGE.replace("{id}", params.id)
        .replace("{className}", className)
        .replace("{bacthSeqNo}", params.batchSeqNo)
        .replace("{fileName}", [imageData.fileName, t("pages.training.masking.ai-output-image-url")].join(""))
    );
  };

  return (
    <>
      <h3 className={classes.modalTitle}>{t("pages.training.masking.modal.defect-mask-confirmation-image-view")}</h3>
      <Typography className={classes.textAlign}>
        {index + (page?.pageNo > 0 ? page?.pageNo - 1 : 0) * page?.pageSize} -{" "}
        {totalImages + (page?.pageNo > 0 ? page?.pageNo - 1 : 0) * page?.pageSize} / {totalImageCount}
      </Typography>
      <div className={classes.imageBox}>
        {totalImages !== index && (
          <button className={classes.rightArrow} onClick={next}>
            <ChevronRight />
          </button>
        )}
        <div className={classes.modalTextPadding}>
          <div className={classes.content}>
            <Grid item xs={12} sm={6} className={classes.box}>
              <label>{t("pages.training.masking.modal.original-image")}</label>
              <MaskingImage
                readOnly={true}
                returnFormat={returnFormat}
                totalMasks={maskData?.length}
                masks={maskData?.length > 0 ? maskData : []}
                src={SETTINGS.IMAGE_FULL_URL + imageData?.fileName}
                alt={imageData?.uploadFileName}
                imageClassName={classes.imageCenter}
                enableMask={true}
                showMaskedAreaCount={true}
              />
              <label className={classes.imageLabel}>
                {t("pages.training.masking.modal.compare-images-data", {
                  name: imageData.uploadFileName,
                  size: Math.floor(imageData?.fileSize / 1024) + " kb",
                  class: className
                })}
              </label>
            </Grid>
            <Grid item xs={12} sm={6} className={classes.box}>
              <label>{t("pages.training.masking.modal.ai-output-image")}</label>
              <img src={getAIMaskedImage()} alt={getAIMaskedImage()} className={classes.imageCenter} />
            </Grid>
          </div>
        </div>
        {index !== 1 && (
          <button className={classes.leftArrow} onClick={previous}>
            <ChevronLeft />
          </button>
        )}
      </div>
    </>
  );
};

export default CompareImageSlide;
