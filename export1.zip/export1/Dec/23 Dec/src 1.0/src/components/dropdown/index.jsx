import React from "react";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import { Checkbox, InputLabel, ListItemIcon, ListItemText, MenuItem, FormControl, Select } from "@material-ui/core";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const SELECT_ALL = "all";
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250
        }
    },
    getContentAnchorEl: null,
    anchorOrigin: {
        vertical: "bottom",
        horizontal: "center"
    },
    transformOrigin: {
        vertical: "top",
        horizontal: "center"
    },
    variant: "menu"
};


const DropDown = props => {
    const classes = useStyles();
    const { t } = useTranslation();
    const { classifiedClasses, count, selectedClassifiedClasses, setClassifiedClasses, setSelectedClassifiedClasses, handleChangeDropDownClasses } = props;
    const isAllSelected = classifiedClasses.length > 0 && selectedClassifiedClasses.length === classifiedClasses.length;
    let updatedList = [];
    const onSelectClassifiedClass = (event) => {
        let values = event.target.value;
        if (values[values.length - 1] === SELECT_ALL) {
            // if (selectedClassifiedClasses.length === classifiedClasses.length) {
            //     let temp1 = classifiedClasses.map(element => ({ ...element, selected: false }));
            //     updatedList = [];
            //     setClassifiedClasses(temp1);
            //     setSelectedClassifiedClasses([]);
            // } else {
            //     let temp2 = classifiedClasses.map(element => ({ ...element, selected: true }));
            //     updatedList = temp2;
            //     setClassifiedClasses(temp2)
            //     setSelectedClassifiedClasses(temp2);
            // }
            values = selectedClassifiedClasses?.length > 0 ? [] : classifiedClasses;
        }

        let excludeElements = selectedClassifiedClasses.filter(element => !values.includes(element));
        if (excludeElements.length > 0) {
            excludeElements.forEach((b) => {
                classifiedClasses.forEach((a) => {
                    if (b.label === a.label) {
                        a.selected = !a.selected;
                    }
                });
            });
            updatedList = values;
            setSelectedClassifiedClasses([...values]);
        }

        let includeElements = values.filter(element => !selectedClassifiedClasses.includes(element));
        if (includeElements.length > 0) {
            includeElements.forEach((b) => {
                classifiedClasses.forEach((a) => {
                    if (b.label === a.label) {
                        a.selected = true;
                    }
                });
            });
            updatedList = values;
            setSelectedClassifiedClasses([...values]);
        }
        count(updatedList.length === 0 ? true : false)
        handleChangeDropDownClasses(classifiedClasses);
    };

    return (
        <>
            <FormControl className={classes.formControl}>
                <InputLabel id="mutiple-select-label">{t("pages.classification-test.classification-images.dropdown.label")}</InputLabel>
                <Select
                    labelId="mutiple-select-label"
                    multiple
                    value={selectedClassifiedClasses}
                    onChange={onSelectClassifiedClass}
                    renderValue={(selectedClassifiedClasses) => selectedClassifiedClasses.map(item => item.label).join(", ")}
                    MenuProps={MenuProps}
                    className={classes.multiSelect}
                >
                    <MenuItem
                        value={SELECT_ALL}
                        classes={{
                            root: isAllSelected ? classes.selectedAll : ""
                        }}
                    >
                        <ListItemIcon>
                            <Checkbox
                                classes={{ indeterminate: classes.indeterminateColor }}
                                checked={isAllSelected}
                                indeterminate={
                                    selectedClassifiedClasses.length > 0 && selectedClassifiedClasses.length < classifiedClasses.length
                                }
                            />
                        </ListItemIcon>
                        <ListItemText
                            classes={{ primary: classes.selectAllText }}
                            primary={t("pages.classification-test.classification-images.dropdown.select-all")}
                        />
                    </MenuItem>
                    {classifiedClasses.length > 0 && classifiedClasses.map((option) => (
                        <MenuItem key={option.label} value={option} classes={{ root: classes.selectOne }} >
                            <ListItemIcon>
                                <Checkbox checked={option.selected} />
                            </ListItemIcon>
                            <ListItemText primary={option.label} />
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
        </>
    );
};

export default DropDown;