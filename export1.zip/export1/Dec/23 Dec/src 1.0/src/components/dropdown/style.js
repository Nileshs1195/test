import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
    formControl: {
        margin: theme.spacing(1),
        width: 300
      },
      indeterminateColor: {
        color: "#3a5faa"
      },
      selectAllText: {
        fontWeight: 500
      },
      selectedAll: {
        "& .MuiCheckbox-colorSecondary.Mui-checked": {
          color: "#3a5faa"
        },
        backgroundColor: "rgba(0, 0, 0, 0.08)",
        "&:hover": {
          backgroundColor: "rgba(0, 0, 0, 0.08)"
        }
      },
      selectOne: {
        "& .MuiCheckbox-colorSecondary.Mui-checked": {
          color: "#3a5faa"
        }
      },
      multiSelect: {
        width: "325px",
        "& .MuiSelect-root": {
          display: "block",
          paddingLeft: "0px"
        }
      }
}));
