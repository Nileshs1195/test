import React from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableRow from "@material-ui/core/TableRow";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";

const ImageDetails = ({ imageData, masking }) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const rows = [
    {
      title: t("pages.training.manageImages.messages.fileName"),
      text: imageData.uploadFileName
    },
    {
      title: t("pages.training.manageImages.messages.fileSize"),
      text: Math.round(imageData.fileSize / 1024) + " kb"
    },
    {
      title: t("pages.training.manageImages.messages.pixelSize"),
      text: imageData.dimentionX + " X " + imageData.dimentionY
    },
    { title: t("pages.training.manageImages.messages.className"), text: imageData.className }
  ];

  return (
    <TableContainer>
      <Table className={classes.table} aria-label="simple table">
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.title} className={classes.tRow}>
              <TableCell>{row.title}</TableCell>
              <TableCell>{row.text}</TableCell>
            </TableRow>
          ))}

          {masking && imageData?.defectCoordinates?.length > 0 && imageData?.defectCoordinates?.slice(0,3)?.map((item, key) => {
            return (
              <TableRow key={"mask-" + key} className={classes.tRow}>
                <TableCell>Mask {key + 1}</TableCell>
                <TableCell>
                  xmin: {item?.xmin},
                  xmax: {item?.xmax},
                  ymin: {item?.ymin},
                  ymax: {item?.ymax}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
};
export default ImageDetails;
