import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from '@material-ui/core';
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import { checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";
import { Autocomplete } from "@material-ui/lab";

const EditImageClass = (props) => {
    const { t } = useTranslation();
    const form = useRef();
    const { open, setOpen, trainingClasses, classDetails, setSelectedSeqNo, moveSelectedImages } = props;
    const [formError, setFormError] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const [classList, setClassList] = useState([]);
    const [formContent, setFormContent] = useState({ seqNo: "", className: "" });
    const [config, setConfig] = useState({
        fields: {
            className: {
                initialValue: "",
                isRequired: { message: t("validation.message.required", { field: t("validation.field.className") }) },
                isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.className") }) }
            }
        },
        onSubmit: state => {
            setSubmitted(state?.submitted);
            if (state?.errors) {
                setFormError({ ...state.errors });
            }
        },
        showErrors: 'blur',
        submitted: true
    });
    const { getFieldProps, getFormProps, errors, values } = useValidation(config);

    useEffect(() => {
        let allClasses = trainingClasses?.filter(dataset => dataset?.seqNo !== classDetails?.seqNo);
        let list = allClasses?.map(dataset => {
            return { label: dataset.className, value: dataset.seqNo };
        })
        setClassList(list);
    }, []);

    useEffect(() => { //Sets values after change
        setFormContent({ ...formContent, ...values });
        if (values?.className !== formContent?.className) {
            setFormContent(values);
            let selectedSeq = "";
            classList?.filter((item) => {
                if (item?.label === values?.className) {
                    selectedSeq = item.value;
                }
            });
            onSelectImageClass({
                className: values?.className,
                seqNo: selectedSeq
            });
        }
    }, [values]);

    useEffect(() => {//This is required to validate and show error message
        errors && !submitted && setFormError(errors);
        submitted && setSubmitted(false);
    }, [errors])

    useEffect(() => { //This is required to trigger the submit event on load
        form?.current?.dispatchEvent(
            new Event("submit", { bubbles: true, cancelable: true })
        );
    }, [form?.current])

    const onSelectImageClass = (value) => {
        if (value) {
            setFormContent(value);
            setSelectedSeqNo(value?.seqNo);
        }else {
            setFormContent({className:'',seqNo:''})
        }
    }

    const changeClassName = (event, value)  => {
        if(value?.value) {
            onSelectImageClass({
                className: value?.label, seqNo: value?.value
            });
        } else {
            onSelectImageClass();
        }
    }

    // useEffect(() => {
    //     setSelectedSeqNo(value?.value);
    // }, [formContent?.seqNo])

    const updateImageClassData = (e) => {
        form.current.dispatchEvent(
            new Event("submit", { bubbles: true, cancelable: true })
        );
        let formArray = objToArray(formError);
        let notNull = checkNotNullFromArray(formArray);
        if ((formArray?.length <= 0 || !notNull)) {
            //Validation passed
            moveSelectedImages();
        }
    }
    return (
        <Observer>
            {() => (
                <>
                    <CustomConfirmation
                        open={open}
                        onClose={() => setOpen(false)}
                        noImmediateClose={true}
                        onSubmit={updateImageClassData}
                        primary={"pages.training.manageImages.modal.ok-btn"}
                        secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                        title={t("pages.training.manageImages.modal.editImageClassTitle")}
                        message={<>
                            <form action="javascript:;" ref={form}  {...getFormProps()}>                            
                                <Autocomplete
                                    id="combo-box"
                                    clearOnEscape
                                    options={classList}
                                    {...getFieldProps('className')}
                                    getOptionLabel={(option) =>{return option?.label}}
                                    value={classList.length > 0 && classList.filter(item => item.label === formContent?.className)?.[0]}
                                    error={formError?.className}
                                    helperText={formError?.seqNo}
                                    renderInput={(params) => (<>
                                        <TextField
                                            fullWidth
                                            aria-valuetext={formContent?.className}
                                            autoFocus
                                            id="className"
                                            name="className"
                                            {...getFieldProps('className')}
                                            {...params}
                                            inputProps={{
                                                ...{ ...params.inputProps, value: formContent?.className !== undefined && formContent?.className !== "" && formContent?.className !== null ? formContent?.className: "" },
                                            }}
                                            label={t("pages.training.training-parameter.dataset-mode.modal.className")}
                                            margin="normal" />
                                    </>)}
                                />
                            </form>
                        </>} />
                </>
            )}
        </Observer >
    );
};
export default EditImageClass;
