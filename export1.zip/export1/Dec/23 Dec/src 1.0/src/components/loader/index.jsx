import { Box, CircularProgress } from "@material-ui/core";
import { useStyles } from "./style";

const Loader = (props) => {
  const classes = useStyles();
  const { size } = props;
  const style = {
    zIndex: "999",
    top: `calc(50% - ${size / 2}px)`,
    left: `calc(50% - ${size / 2}px)`,
  };

  return (
    <>
      <Box className={classes.root} style={style}>
        <CircularProgress disableShrink {...props} />
      </Box>
    </>
  );
};

export default Loader;

// Note : Parent of Loader must have postion:'relative' to center the loader
