import IO from "socket.io-client";
import React from "react";
import { observer } from "mobx-react-lite";
import { useState, useEffect, useContext, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useStyles } from "./style";
import { useHistory, useParams } from "react-router-dom";
import AppStore from "../../stores/appstore";
import TrainingManagementStore from "./../../stores/trainingmanagementstore";
import ImageManagementStore from "../../stores/imagemanagementstore";
import ModalComponent from "../../pages/training/training-parameter-setting/dataset/dataset-list/modal";
import { SETTINGS } from "../../appsettings";
import ProgressBar from "../progressbar";
import { API_URL } from "../../appconstants";
import CustomSnackBar from "../snackbar";
const socket = IO(SETTINGS.SOCKET_URL, {
  withCredentials: true,
  upgrade: true
  // transports:["socket"]
});

const ImageUploader = observer((props) => {
  const params = useParams();
  const appStore = useContext(AppStore);
  const classes = useStyles();
  const { t } = useTranslation();
  const inputFileRef = useRef(null);
  const { setLoader, setLoaderMessage } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { traingingId, setReloadList, fetchTrainingDatasetWithTraining, setTrainingDataset } = trainingManagementStore;
  const { uploaderAction, handleFileUploadClose } = props;
  const { showUploader, setShowUploader, setImageUploadStatus, setNewlyCreatedClasses } = imageManagementStore;
  const [action, setAction] = useState({ actionName: "", isOpen: false });
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [imageDetailsList, setImageDetailsList] = useState([]);
  const [imageList, setImageList] = useState([]);
  const [snapbar, setSnapbar] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({
    message: "",
    open: false,
    type: ""
  });
  const [progressBarData, setProgressBarData] = useState({
    completedCount: 0,
    totalCount: 0
  });
  const [isProgressBarVisible, setProgressBarVisibility] = useState(false);
  const [classNames, setclassNames] = useState([]);

  useEffect(() => {
    if (uploaderAction?.isOpen) {
      inputFileRef.current.click();
      // hideUploader();
    }
  }, [uploaderAction]);

  const onFileChange = (event) => {
    if (socket.disconnected) {
      socket.connect();
    }
    let files = event.target.files;
    let imageDetailsArray = [];
    let imageArray = [];
    let originalClassName = props.className;
    let classArrayName = [];
    Object.entries(files).forEach((image) => {
      if (image && image[1] && (image[1].type === "image/png" || image[1].type === "image/jpg" || image[1].type === "image/jpeg")) {
        if (originalClassName) {
          image[1].className = originalClassName;
        } else {
          let path = image[1].webkitRelativePath.substr(image[1].webkitRelativePath.indexOf("/") + 1);
          image[1].path = path;
          let className = path.substring(0, path.lastIndexOf("/")).replaceAll("/", "_");
          image[1].className = className !== null && className !== "" ? className : "Unlabelled";
        }
        if (!classArrayName.includes(image[1].className)) {
          classArrayName.push(image[1].className);
        }

        imageDetailsArray.push({
          className: image[1].className,
          fileName: image[1].name,
          fileType: image[1].type,
          fileSize: image[1].size
        });
        imageArray.push({
          fileName: image[1].name,
          source: image[1]
        });
      }
    });
    if (imageDetailsArray.length > 0) {
      setImageDetailsList(imageDetailsArray);
      setImageList(imageArray);
      handleModalActions("UPLOAD-FILES");
      if (uploaderAction.uploaderType === "add-class") {
        setclassNames(classArrayName);
      }
    }
  };

  const handleModalActions = (name) => {
    setAction({ actionName: name, isOpen: true });
  };

  const setModalActive = () => {
    setAction({ actionName: action.actionName, isOpen: false }); // display file upload confirmation modal
  };

  const handleAPICall = (API, data) => {
    setSnapbar(false);
    uploadImages();
  };
  const fetchTrainingData = (id) => {
    if (uploaderAction.uploaderType !== "add-testing-class") {
      fetchTrainingDatasetWithTraining(id).then(() => {
        setNewlyCreatedClasses(classNames);
      });
    }
  };

  const uploadImages = () => {
    setSnapbar(false);
    if (socket.disconnected) {
      socket.connect();
    }
    const saveRequestData = {
      files: imageDetailsList,
      priorKnowledge: false
    };
    setLoader(true);
    setLoaderMessage("pages.training.success.image-upload.uploading");
    let id = params.id || uploaderAction?.id;
    if (id) {
      let url = API_URL.SAVE_IMAGE_DETAILS;
      if (uploaderAction.uploaderType === "add-testing-class") {
        url = API_URL.SAVE_TEST_IMAGE_DETAILS;
      }
      setsnapbarMessage({
        message: "",
        open: false,
        type: ""
      });
      imageManagementStore
        .saveImageDetails(url, id, saveRequestData)
        .then((result) => {
          setLoader(false);
          setLoaderMessage("");
          if (result && result.duplicate && result.duplicate.length > 0) {
            setSnapbar(true);
            setsnapbarMessage({ open: true, message: t("pages.training.errors.image-upload.duplicate"), type: "error" });
            // result.result ? result.result : "Unknown error occurred while uploading images, please try again."
            if (socket.connected) {
              socket.disconnect();
            }
            handleFileUploadClose();
            return;
          }
          if (result && result.data && result.data.length > 0) {
            const imageUploadData = result.data.map((item, i) => {
              if (item.fileName === imageList[i].fileName) {
                //merging two objects
                return Object.assign({}, item, imageList[i]);
              }
            });
            setReloadList(true);
            if (props.reloadCurrentList) {
              props.reloadCurrentList("uploadProgress", classNames);
              setImageUploadStatus("in-progress");
              fetchTrainingData(id);
              // setNewlyCreatedClasses(classNames);
            }
            // fetchTrainingDatasetWithTraining(params.id);
            setLoader(true);
            setTimeout(() => {
              imageUploadHandler(imageUploadData);
            }, 1000);
            setLoader(false);
          } else {
            setSnapbar(true);
            setsnapbarMessage({ open: true, message: t("pages.training.errors.image-upload.unknown"), type: "error" });
            if (socket.connected) {
              socket.disconnect();
            }
            // result.result ? result.result :
            handleFileUploadClose();
          }
        })
        .catch((err) => {
          setLoader(false);
          setLoaderMessage("");
          handleFileUploadClose();
          if (socket.connected) {
            socket.disconnect();
          }
        });
    }
  };

  const imageUploadHandler = async (imageGroupList) => {
    let obj = {
      imageArray: imageGroupList,
      currentImageIndex: 0,
      imageContext: {
        failedImgs: {
          f_count: 0,
          f_array: []
        },
        succeedImgs: {
          s_count: 0
        }
      }
    };

    if (socket.disconnected) {
      socket.connect();
    }

    for (var i = 0; i < obj.imageArray.length; i++) {
      startUploadingProcess(obj.imageArray[i]);
    }
    initUpload(obj);
  };

  const initUpload = (imageObj) => {
    if (imageObj && imageObj.imageArray.length > 0 && imageObj.currentImageIndex < imageObj.imageArray.length) {
      setProgressBarVisibility(true);
      // setLoader(true);
      setProgressBarData({
        completedCount: imageObj.currentImageIndex,
        totalCount: imageObj.imageArray.length
      });
      var file = imageObj.imageArray[imageObj.currentImageIndex];
      readFileChunk(file.fileName, file, 0, imageObj);
    } else {
      setsnapbarMessage({
        message: "",
        open: false,
        type: ""
      });
      setReloadList(true);
      let id = params.id || uploaderAction?.id;
      if (props.reloadCurrentList) {
        props.reloadCurrentList("uploadComplete", classNames);
        var file = imageObj.imageArray[imageObj.currentImageIndex];
        fetchTrainingData(id);
        setImageUploadStatus("completed");
      }
      setProgressBarData({
        completedCount: imageObj.imageArray.length,
        totalCount: imageObj.imageArray.length
      });
      handleFileUploadClose();
      if (socket.connected) {
        socket.disconnect();
      }
      setProgressBarVisibility(false);
      setSnapbar(false);
      setSnapbar(true);
      setsnapbarMessage({ open: true, message: t("pages.training.success.image-upload.uploadMsg", { count: imageObj.imageArray.length }), type: "success" });
    }
  };

  const readFileChunk = (filename, file, offset, imageObj) => {
    var CHUNK_SIZE = 500000; // 500kb
    let end_offset = offset + CHUNK_SIZE;
    if (end_offset > file.source.size) {
      end_offset = file.source.size;
    }
    let r = new FileReader();
    r.onload = function (filename, file, offset, length, imageObj, event) {
      if (event.target.error != null) {
        console.log("Error in readFileChunk");
        imageObj.currentImageIndex++;
        // update failure count and update array
        imageObj.imageContext.failedImgs.f_count++;
        // initUpload(imageObj);
      } else {
        onReadSuccess(file.fileName, file, offset, length, event.target.result, imageObj);
      }
    }.bind(r, filename, file, offset, CHUNK_SIZE, imageObj);
    let blob = file.source.slice(offset, end_offset);
    r.readAsArrayBuffer(blob);
  };

  const startUploadingProcess = (file) => {
    if (file !== undefined) {
      let event = "start-transfer";
      if (uploaderAction.uploaderType === "add-testing-class") {
        event = "start-testing-transfer";
      }
      socket.emit(event, {
        id: file.id,
        seqNo: file.seqNo,
        fileName: file.fileName,
        imgName: file.imgName
      });
    }
  };

  const onReadSuccess = (filename, file, offset, length, chunk, imageObj) => {
    if (socket.disconnected) {
      socket.connect();
    }
    const end_offset = offset + length;

    let event = "imageUpload";
    if (uploaderAction.uploaderType === "add-testing-class") {
      event = "testingImageUpload";
    }
    socket.emit(
      event,
      {
        id: file.id,
        seqNo: file.seqNo,
        fileName: filename,
        imgName: file.imgName,
        offset,
        chunk,
        isLastChunk: end_offset >= file.source.size
      },
      function (offset, imageObj, ack) {
        // const porcentage = (end_offset / file.source.size) * 100;
        if (end_offset < file.source.size) {
          readFileChunk(filename, file, end_offset, imageObj);
        } else {
          console.log("update success");
          imageObj.currentImageIndex++; // increment index for reading next file
          imageObj.imageContext.succeedImgs.s_count++; // update success count
          // updateProgress(imageObj);
          initUpload(imageObj);
          // renderFileDetails()                         // display the uploaded file name or progress bar
        }
      }.bind(this, offset, imageObj)
    );
  };

  const handleProgressBarClose = () => {
    setProgressBarVisibility(false);
  };

  return (
    <>
      {isProgressBarVisible ? (
        <ProgressBar
          isVisible={isProgressBarVisible}
          progressData={progressBarData}
          message={t("pages.image-management.image-group-list.modal.image-uploading-message")}
          closeProgressBar={handleProgressBarClose}
          horizontalPosition="center"
          verticalPosition="top"
        />
      ) : null}
      {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
      <ModalComponent
        action={action}
        imageList={imageDetailsList && imageDetailsList.length > 0 && imageDetailsList}
        setModalActive={setModalActive}
        handleAPICall={handleAPICall}
        disableAddButton={disableAddButton}
      />
      {uploaderAction &&
        uploaderAction.uploaderType &&
        (uploaderAction.uploaderType === "add-dataset" ||
          uploaderAction.uploaderType === "add-class" ||
          uploaderAction.uploaderType === "add-testing-class") ? (
        <>
          <input
            type="file"
            accept="image/png, image/jpeg, image/jpg"
            directory=""
            webkitdirectory=""
            ref={inputFileRef}
            onClick={(e) => (e.target.value = null)}
            onChange={onFileChange}
            multiple
            className={classes.fileUpload}
          />
        </>
      ) : (
        <input
          type="file"
          accept="image/png, image/jpeg, image/jpg"
          ref={inputFileRef}
          onClick={(e) => (e.target.value = null)}
          onChange={onFileChange}
          multiple
          className={classes.fileUpload}
        />
      )}
    </>
  );
});

export default ImageUploader;
