import React from 'react'
import Modal from "../shared/components/ui/modal";
import { makeStyles } from '@material-ui/core/styles'
import { useTranslation } from 'react-i18next';


const useStyles = makeStyles((theme) => ({
  modalWidth: {
    minWidth: "25%",
    maxWidth: "25%",
    minHeight: "auto"
  },
  modalTextPadding: {
    paddingBottom: "16px"
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: 18,
    fontWeight: "normal",
    Height: "42px",
    margin: "-16px -16px 0px -16px",
    padding: "8px 16px",
    borderRadius: "4px 4px 0 0"
  },
  confirmationModalPadding: {
    paddingTop: "10px"
  },
  fontsize: {
    fontSize: "16px"
  }
}))
const CustomPrompt = ({ message, cleanUp }) => {
  
  const { t } =  useTranslation();
  const classes = useStyles();
  const cancel = () => {
 
    cleanUp(false);
  }

  const ok = () =>{
    cleanUp(true);
  }

  return (
    <>
      <Modal
        open
        onClose={cancel}
        onSubmit={ok}
        widthClass={classes.modalWidth}
        showControls
        primaryButtonTextKey={t("pages.training.input-parameter.controls.ok")}
        secondaryButtonTextKey={t("pages.training.input-parameter.grid.cutomization.modal.cancel-btn")}
      >
        <div className={classes.modalTextPadding}>
          <h3 className={classes.modalTitle}>{t("pages.training.cofirm.parameter-settings.cancel-unsaved.title")}</h3>
          <div className={classes.confirmationModalPadding}>
            <label className={classes.fontsize}>{message}</label>
          </div>
        </div>
      </Modal>

    </>
  )
}

export default CustomPrompt
