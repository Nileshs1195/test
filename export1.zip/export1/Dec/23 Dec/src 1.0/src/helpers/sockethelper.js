import IO, { io } from "socket.io-client";
import { SETTINGS } from "../appsettings";

// export const connectSocket = () => {
//     return io(SETTINGS.SOCKET_URL, {
//         withCredentials: true,
//         upgrade: true,
//         // transports:["socket"]
//     });

// }

const ENDPOINT = SETTINGS.SOCKET_URL;

export const socket = IO(SETTINGS.SOCKET_URL, {
    withCredentials: true,
    upgrade: true
        // transports:["socket"]
});

export default class SocketService {
    socket = {};

    constructor(emisor_id) {
        if (this.socket && this.socket.connected) {
            //Already connected
        } else {
            this.socket = IO(ENDPOINT, {
                withCredentials: true,
                upgrade: true,
                // transports:["socket"]
            });
            console.log('socket', this.socket);
        }
    }

    getSocket = () => {
        return this.socket;
    }

    send = (event, message) => {
        return this.socket.emit(event, message)
    }

    // disconnect - used when unmounting
    disconnect = () => {
        this.socket.disconnect();
    }
}