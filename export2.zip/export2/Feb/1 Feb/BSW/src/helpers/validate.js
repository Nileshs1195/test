
import { useReducer, useMemo } from "react";
import useDeepCompareEffect from 'use-deep-compare-effect';
import * as validators from "./validators";

const validateField = (fieldValue = '', fieldConfig) => {
    const specialProps = ['initialValue'];
    for (let validatorName in fieldConfig) {
        if (specialProps.includes(validatorName)) {
            continue;
        }
        let validatorConfig = fieldConfig[validatorName];
        const configuredValidator = validators[validatorName](validatorConfig);
        const errorMessage = configuredValidator(fieldValue);

        if (errorMessage) {
            console.log("Error Occurred: ", errorMessage);
            return errorMessage !== "Invalid type, see console for details." ? errorMessage: null;
        }
    }
    return null;
}

const validateFields = (fieldValues, fieldConfigs) => {
    const errors = {};
    for (let fieldName in fieldConfigs) {
        const fieldConfig = fieldConfigs[fieldName];
        const fieldValue = fieldValues[fieldName];

        errors[fieldName] = validateField(fieldValue, fieldConfig);
    }
    return errors;
}

const getInitialState = (config) => {
    if (typeof config === 'function') {
        config = config({});
    }
    const initialValues = {};
    const initialBlurred = {};
    for (let fieldName in config.fields) {
        initialValues[fieldName] = config.fields[fieldName].initialValue || '';
        initialBlurred[fieldName] = false;
    }
    const initialErrors = validateFields(initialValues, config.fields);
    return {
        values: initialValues,
        errors: initialErrors,
        blurred: initialBlurred,
        submitted: false,
    };
}

const validationReducer = (state, action) => {
    switch (action.type) {
        case 'change':
            const values = { ...state.values, ...action.payload };
            return {
                ...state,
                values,
            };
        case 'submit':
            return { ...state, submitted: true, errors: state.errors };
        case 'validate':
            return { ...state, errors: action.payload };
        case 'blur':
            const blurred = {
                ...state.blurred,
                [action.payload]: true,
            };
            return { ...state, blurred };
        default:
            throw new Error('Unknown action type');
    }
}

function getErrors(state, config) {
    if (config.showErrors === 'always') {
        return state.errors;
    }
    if (config.showErrors === 'blur') {
        return Object.entries(state.blurred)
            .filter(([, blurred]) => blurred)
            .reduce((acc, [name]) => ({ ...acc, [name]: state.errors[name] }), {});
    }
    return state.submitted ? state.errors : {};
}

function getValues(state, config) {
    return state.values
}

export const useValidation = config => {
    const [state, dispatch] = useReducer(
        validationReducer,
        getInitialState(config),
    );

    if (typeof config === 'function') {
        config = config(state.values);
    }

    useDeepCompareEffect(() => {
        const errors = validateFields(state.values, config.fields);
        dispatch({ type: 'validate', payload: errors });
    }, [state.values, config.fields]);

    const errors = useMemo(() => getErrors(state, config), [state, config]);
    const values = useMemo(() => getValues(state, config), [state, config]);

    return {
        errors,
        values,
        submitted: state.submitted,
        getFormProps: () => ({
            onSubmit: e => {
                e.stopPropagation();
                e.preventDefault();
                dispatch({ type: 'submit' });
                if (config.onSubmit) {
                    config.onSubmit(state);
                }
            },
        }),
        getFieldProps: fieldName => ({
            onClick: e => {
                let { value } = e.target;
            },
            onChange: e => {
                let { value } = e.target;
                if (e.target.type === "checkbox" && (value === "" || value === "false" || value === "true")) {
                    value = value === "" || value === "false" ? true : false;
                } else if (e.target.type === "" && (value === 0) && e.target.textContent) {
                    value = e.target.textContent;
                }
                if (!config.fields[fieldName]) {
                    return;
                }
                dispatch({
                    type: 'change',
                    payload: { [fieldName]: value },
                });
            },
            onBlur: () => {
                dispatch({ type: 'blur', payload: fieldName });
            },
            name: fieldName,
            value: state.values[fieldName] || '',
        }),
    };
};