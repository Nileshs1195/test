export const validateModalForm = (
  validateData,
  modalFormErrors,
  errorMessage,
  handleModalFormErrors
) => {
  let errorObj = {
    isFormValid: true,
    formErrors: {}
  };
  const setErrorMessage = (fieldName, fieldNameError) => {
    errorObj.isFormValid = false;
    errorObj.formErrors[fieldName] = true;
    errorObj.formErrors[fieldNameError] = errorMessage;
  };

  for (const fieldName in validateData) {
    if (validateData[fieldName] === "" || validateData[fieldName] === null || validateData[fieldName] === undefined) {
      setErrorMessage(fieldName, `${fieldName}ErrorMsg`);
    } else {
      if (modalFormErrors[fieldName]) {
        errorObj.isFormValid = false;
      }
    }
  }
  handleModalFormErrors(errorObj.formErrors);
  return errorObj.isFormValid;
};

export const onChangeDataSetting = (
  event,
  handleSetTrainingData,
  handleModalFormErrors,
  records,
  errMsg,
) => {
  const { name, value } = event.target
  const fieldName = name
  const fieldError = `${name}ErrorMsg`

  handleSetTrainingData(name, value)
  const classNameExist = checkClassName(records, value.trim())
  let validReg = validateString(value)
  if (classNameExist) {
    let errorObj = {
      isFormValid: true,
      modalFormErrors: {},
    }
    errorObj.modalFormErrors[fieldName] = true
    errorObj.modalFormErrors[fieldError] = errMsg['errExist']
    handleModalFormErrors(errorObj.modalFormErrors)
  } else {
    if (value.length > 0) {
      if (validReg) {
        handleModalFormErrors({
          [fieldName]: false,
          [fieldError]: '',
        })
      } else {
        handleModalFormErrors({
          [fieldName]: true,
          [fieldError]: errMsg['errAlphanumeric'],
        })
      }
    }
  }
}

export const checkClassName = (records, name) => {
  let exist = false;
  if (records?.length > 0) {
    const list = records?.map((item) => {
      const container = {};
      container["name"] = item.className;
      return container;
    });
    exist = list.some((item) => item?.name?.toLowerCase() === name.toLowerCase());
  }
  return exist;
};


export const validateString = (value) => {
  let regExp = new RegExp("^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9_. -]+$");
  let status = regExp.test(value) ? true : false;
  return status;
};

export const validateDigits = (value) => {
  let regExp = new RegExp("^[0-9]+$");
  let status = regExp.test(value) ? true : false;
  return status;
};

export const validateFloatAndIntValue = (value) => {
  // let regExp = new RegExp(/^-?\d*(\.\d+)?$/);
  // let status = regExp.test(value) ? true : false;
  return !isNaN(value);
};

export const getUniqueDataByField = (obj, field) => {
  let data = []
  for (let i in obj) {
    if (data.indexOf(obj[i][field]) == -1) {
      data.push(obj[i][field])
    }
  }
  return data
}

export const secondsToHms = (d) => {
  d = Number(d);
  var h = Math.floor(d / 3600);
  var m = Math.floor(d % 3600 / 60);
  var s = Math.floor(d % 3600 % 60);

  if (h < 10) { h = "0" + h; }
  if (m < 10) { m = "0" + m; }
  if (s < 10) { s = "0" + s; }

  return {
    hours: h,
    minutes: m,
    seconds: s
  };
}

export const convertToTimezone = (d) => { // This is an alternative solution to fix the shared component basic table date time conversion
  if (d) {
    let date = new Date(d);
    var localOffset = date.getTimezoneOffset() * 60000;
    return date.getTime() - localOffset;
  }
}
