export const upsert = (array, item) => {
  const i = array.findIndex((elem) => elem.field === item.field);
  if (i > -1) array[i] = { ...array[i], ...item };
  else array.push(item);
  return array;
};

export const removeField = (array, field) => {
  return array.filter((elem) => elem.field !== field);
};

export const addOrRemove = (array, item) => {
  const newArray = [...array];
  const index = newArray.indexOf(item);
  if (index > -1) {
    newArray.splice(index, 1);
    return newArray;
  } else {
    newArray.push(item);
    return newArray;
  }
};

export const arrayUnique = (array) => {
  return array?.length > 0 && array.filter((v, i, a) => a.indexOf(v) === i);
}

export const arrayMultiSplit = (array, chunk = 5) => {
  let i, j;
  let temporary = [];
  for (i = 0, j = array.length; i < j; i += chunk) {
    temporary.push(array.slice(i, i + chunk));
  }
  return temporary;
}

export const objToArray = (obj = {}) => {
  return Object.keys(obj).map((key) => obj[key]);
}

export const checkNotNullFromArray = (arr = []) => {
  let status = false;
  arr.length > 0 && arr.forEach(a => {
    if (a !== null) {
      status = true;
    }
  });
  return status;
}

export const sort = (arr = [], name, asc = false) => {
  return !asc ? arr.sort((a, b) => a?.[name] - b?.[name]).reverse() : arr.sort((a, b) => a?.[name] - b?.[name]);
}

export const localCompareSort = (arr = [], name) => {
  return arr.sort((a, b) => a?.[name]?.localeCompare(b?.[name], undefined, { numeric: true }));
}

export const arrayVariance = (arr = []) => {
  if (arr?.length > 0) {
    const sum = arr.reduce((acc, val) => acc + val);
    const { length: num } = arr;
    const median = sum / num;
    let variance = 0;
    arr.forEach(num => {
      variance += ((num - median) * (num - median));
    });
    variance /= num;
    return variance;
  }
  return 0;
}
