import { useState } from 'react';

const useInfinityScroll = (props) => {
  const { scrolling, scrollLeft, scrollRight, scrollTop, scrollBottom } = props;
  const [isScroll, setIsScroll] = useState(true);

  const getImagesFromList = (args) => {
    const { page, imagesList, ref } = args;
    let startPage = (page?.startPage - 1) * page?.pageSize;
    let endPage = imagesList?.length < page?.imageCount
                    ? (imagesList?.length / page?.pageSize) * page?.pageSize
                    : page?.endPage * page?.pageSize;
    let currentImages = imagesList?.length > 0 ? imagesList?.slice(startPage, endPage) : [];

    if (imagesList?.length > 0 && scrolling) {
      if (page?.type === 1) {
        setTimeout(() => {
          setIsScroll(true);
          ref.current?.scrollTo({
            left: ref.current?.scrollLeft - (scrollLeft || 300),
            top: ref.current?.scrollTop - (scrollBottom || 300),
          });
        }, 500);
      } else if (page?.type === 0) {
        setTimeout(() => {
          setIsScroll(true);
          ref.current?.scrollTo({
            left: ref.current?.scrollLeft + (scrollRight || 300),
            top: ref.current?.scrollTop + (scrollTop || 300),
          });
        }, 500);
      }
    }
    return currentImages;
  }

  return { getImagesFromList, setIsScroll, isScroll };

}

export default useInfinityScroll;
