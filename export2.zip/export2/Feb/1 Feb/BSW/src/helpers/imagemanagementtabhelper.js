import { IMAGE_MANAGEMENT_TABS, APP_ROUTES } from "../appconstants";

export const getTabBreadcrumb = (tab) => {
  let label = "";
  let path = "";

  switch (tab) {
    case IMAGE_MANAGEMENT_TABS.IMAGE_GROUP:
      path = APP_ROUTES.IMAGE_MANAGEMENT_TABS.IMAGE_GROUP;
      label = "pages.inspection-tabs.wafer-list.title";
      break;
    case IMAGE_MANAGEMENT_TABS.IMAGE_LIST:
      path = APP_ROUTES.IMAGE_MANAGEMENT_TABS.IMAGE_LIST;
      label = "pages.inspection-tabs.image-list.title";
      break;
    default:
      break;
  }

  return {
    path: path,
    label: label,
  };
};
