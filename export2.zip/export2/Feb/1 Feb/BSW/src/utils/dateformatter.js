const addZero = (data) => {
  if (data.length === 1) {
    data = "0" + data;
  }
  return data;
};

export const convertUTCDateToLocalDate = (date) => {
  date = new Date(date);
  var localOffset = date.getTimezoneOffset() * 60000;
  var localTime = date.getTime();
  date = localTime + localOffset;
  date = new Date(date);
  var day = date.getDate() + "";
  var month = date.getMonth() + 1 + "";
  var year = date.getFullYear() + "";
  var hour = date.getHours() + "";
  var minutes = date.getMinutes() + "";
  var seconds = date.getSeconds() + "";

  day = addZero(day);
  month = addZero(month);
  year = addZero(year);
  hour = addZero(hour);
  minutes = addZero(minutes);
  seconds = addZero(seconds);
  return (
    year + "/" + month + "/" + day + " " + hour + ":" + minutes + ":" + seconds
  );
};

