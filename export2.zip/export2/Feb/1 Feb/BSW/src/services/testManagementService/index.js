import { get, post, put, deletes } from "../../core/api";
import { API_URL } from "../../appconstants";

export const getTestingList = async () => {
  return await get(API_URL.TESTING_LIST);
};

export const insertTestingList = async (data) => {
  return await post(API_URL.TESTING_LIST, data);
};

export const deleteTestingList = async (testID) => {
  return await deletes(API_URL.EDIT_DELETE_TESTINGLIST.replace("{id}", testID));
};

export const deleteMultipleTestingList = async (recordID) => {
  return await deletes(API_URL.EDIT_DELETE_MULTIPLE_TESTINGLIST, recordID);
};

export const updateTestingList = async (testID, data) => {
  return await put(API_URL.EDIT_DELETE_TESTINGLIST.replace("{id}", testID), data);
};

export const copyAndReexecuteTest = async (testID, payLoad) => {
  return await post(API_URL.COPY_AND_REEXECUTE_TEST.replace("{id}", testID), payLoad);
};

export const getTestDataset = async (testId) => {
  return await get(API_URL.TEST_DATASET.replace("{id}", testId));
};

export const createTestDataset = async (testId, payLoad) => {
  return await post(API_URL.TEST_DATASET.replace("{id}", testId), payLoad);
};

export const updateTestDataset = async (testId, payLoad) => {
  return await put(API_URL.TEST_DATASET.replace("{id}", testId), payLoad);
};

export const deleteTestDataset = async (testId, payLoad) => {
  return await deletes(API_URL.TEST_DATASET.replace("{id}", testId), payLoad);
};

export const getConfusionMatrixData = async (testId, payload) => {
  return await post(API_URL.CONFUSION_MATRIX.replace("{id}", testId), payload);
};

export const getConfusionMatrixImageListData = async (testId, payload) => {
  return await post(API_URL.CONFUSION_MATRIX_IMAGE_LIST.replace("{id}", testId), payload);
};
export const getBatch = async (id, seqNo) => {
  return await get(API_URL.GET_TESTING_BATCH.replace("{id}", id).replace("{seqNo}", seqNo));
};

export const executeTesting = async (id, seqNos) => {
  return await post(API_URL.EXECUTE_MODE.replace("{id}", id), seqNos);
};

export const saveTestModel = async (id, data) => {
  return await post(API_URL.SAVE_TEST_MODEL.replace("{id}", id), data);
};

export const setConfusionMatrixNewClass = async (id, payLoad) => {
  return await post(API_URL.SET_CONFUSION_MATRIX_NEW_CLASS.replace("{id}", id), payLoad);
};

export const stopExecutionLog = async (id, seqNo) => {
  return await put(API_URL.STOP_TESTING_EXECUTION.replace("{id}", id).replace("{seqNo}", seqNo));
};

export const changeDatasetOrder = async (id, payload) => {
  return await post(API_URL.CHANGE_DATASET_ORDER.replace("training","testing").replace("{id}",id),payload);
}
