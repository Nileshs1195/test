import { API_URL } from "../../appconstants";
import { get, post, put, deletes } from "../../core/api";

export const getImageGroupData = async (data) => {
  return await get(API_URL.IMAGE_GROUP_DATA);
};

export const updateGroupNameServices = async (editData, GroupId) => {
  return await put(API_URL.EDIT_GROUP_NAME.replace("{id}", GroupId), editData);
};

export const insertGroupRecord = async (data) => {
  return await post(API_URL.GROUP_RECORD, data);
};

export const getImageList = async (id) => {
  return await get(API_URL.IMAGE_DETAILS, id);
};

export const saveImageDetails = async (url, trainingId, requestData) => {
  return await post(url.replace("{id}", trainingId), requestData);
};

export const getImagesForDataset = async (url, trainingId, datasetSeqId, paginationData) => {
  url = url || API_URL.GET_IMAGES_FOR_DATASET;
  return await post(url.replace("{id}", trainingId).replace("{seqNo}", datasetSeqId), paginationData);
};

export const deleteImagesForDataset = async (trainingId, datasetSeqId, data) => {
  return await deletes(API_URL.DELETE_DATASET_IMAGES.replace("{tid}", trainingId).replace("{seqNo}", datasetSeqId), data);
};

export const saveEditImageClassDetails = async (trainingId, datasetSeqId, imageData, url = "") => {
  url = url || API_URL.GET_IMAGES_FOR_DATASET;
  return await put(url.replace("{id}", trainingId).replace("{seqNo}", datasetSeqId), imageData);
};

export const changeImageType = async (trainingId, imgType, imageData) => {
  return await post(API_URL.CONVERT_IMAGES.replace("{id}", trainingId).replace("{type}", imgType), imageData);
};