import { API_URL } from "../../appconstants";
import { get, post } from "../../core/api";

export const login = (username, password) => {
  if (username === "dev" && password === "123") {
    const user = {
      id: 1,
      username: "dev",
      firstName: username,
      lastName: "",
    };
    return user;
  }
};
export const getUserColumnPrefence = async () => {
  return await get(API_URL.USER_COLUMN_PREFERENCE);
};

export const saveUserColumnPreference = async (columnPreference) => {
  return await post(API_URL.USER_COLUMN_PREFERENCE, {
    imageGroupList: { columnPreference },
  });
};

export const saveFilterPreferenceData = async (data) => {
  return await post(API_URL.FILTER_PREFERENCEDATA, data);
};

export const getUserPreferences = async () => {
  return await get(API_URL.FILTER_PREFERENCEDATA);
};
