import { API_URL } from "../../appconstants";
import { get, getImg, post, put, deletes } from "../../core/api";

export const getTrainingDataset = async (trainingId) => {
  return await get(API_URL.DATASET_LIST.replace("{id}", trainingId));
};

export const getTrainingWithDataset = async (trainingId) => {
  return await get(API_URL.DATASET_LIST_WITH_TRAINING.replace("{id}", trainingId));
};

export const getInputParameter = async () => {
  let mockdata = [
    {
      _id: 101,
      className: "ClassA",
      priorKnowledge: true,
      totalImages: 37,
      maskedImages: 0
    },
    {
      _id: 102,
      className: "ClassB",
      priorKnowledge: false,
      totalImages: 70,
      maskedImages: 0
    },
    {
      _id: 103,
      className: "ClassC",
      priorKnowledge: true,
      totalImages: 140,
      maskedImages: 0
    },
    {
      _id: 104,
      className: "ClassD",
      priorKnowledge: false,
      totalImages: 100,
      maskedImages: 6
    }
  ];
  // return await get(API_URL.DATASET_LIST, data);
  return mockdata;
};

export const editDatasetService = async (trainingId, reqPayload) => {
  return await put(API_URL.EDIT_DATASET.replace("{tId}", trainingId), reqPayload);
};

export const saveNewPercentages = async (trainingId, reqPayload) => {
  return await put(API_URL.UPDATE_DATASET_PERCENTAGES.replace("{tId}", trainingId), reqPayload);
};

export const deleteDatasetRecords = async (trainingId, reqPayload) => {
  return await deletes(API_URL.DELETE_DATASET.replace("{tid}", trainingId), reqPayload);
};

export const getMaskingStatus = async (trainingId, reqPayload) => {
  return await get(API_URL.MASKING_STATUS.replace("{id}", trainingId), reqPayload);
};

export const createDuplicateDataset = async (trainingId, reqPayload) => {
  return await put(API_URL.COPY_PAST_MODAL_DATA.replace("{tId}", trainingId), reqPayload);
};

export const getTrainedDataSetRecords = async (trainingID) => {
  return await get(API_URL.COPY_PAST_MODAL_DATA.replace("{tId}", trainingID));
};

export const getImageGrouptData = async (editData, GroupId) => {
  return await get(API_URL.IMAGE_GROUP_DATA);
};

export const getTrainingListtData = async () => {
  return await get(API_URL.TRAINING_LIST_DATA);
};

export const insertDatasetRecord = async (data) => {
  return await post(API_URL.CREATE_DATASET, data);
};

export const insertInputParameterRecord = async (data) => {
  return await post(API_URL, data);
};

export const getTrainParamsData = async (trainingId) => {
  return await get(API_URL.TRAIN_PARAMS.replace("{id}", trainingId));
};
export const getTrainParamsCommonData = async (trainingId) => {
  return await get(API_URL.TRAIN_PARAMS_DEVELOPER.replace("{id}", trainingId));
};

export const insertTrainParamsCommonData = async (trainingId, data) => {
  return await post(API_URL.TRAIN_PARAMS.replace("{id}", trainingId), data);
};

export const insertTrainParamsData = async (trId, data) => {
  return await post(API_URL.TRAIN_PARAMS_DEVELOPER.replace("{id}", trId), data);
};

export const subclassificationResult = async (id, seqNo) => {
  return await get(API_URL.SUBCLASSIFICATION_EXECUTION_RESULT.replace("{id}", id).replace("{seqNo}", seqNo));
};

export const updateInputParameterServices = async (editData, GroupId) => {
  return true;
};

export const getTrainingListData = async (seqNos) => {
  return await post(API_URL.TRAINING_LIST, { seqNos: seqNos });
};

export const insertParameterData = async (trId, data) => {
  return await post(API_URL.EDIT_SUBCLASS_PARAMETER.replace("{id}", trId), data);
};

export const changeTrainingStatus = async (id, mode, reqPayload) => {
  if (id && mode) {
    return await post(API_URL.TEMP_CHANGE_TRAINING_STATUS.replace("{id}", id).replace("{mode}", mode), reqPayload);
  }
};

export const startExecution = async (id, mode, reqPayload) => {
  if (id && mode) {
    return await post(API_URL.START_EXECUTION.replace("{id}", id).replace("{mode}", mode), reqPayload);
  }
};

export const stopExecution = async (id, seqNo) => {
  if (id) {
    return await put(API_URL.STOP_EXECUTION.replace("{id}", id).replace("{seqNo}", seqNo));
  }
};

export const getBatch = async (id, seqNo) => {
  if (id) {
    return await get(API_URL.GET_BATCH.replace("{id}", id).replace("{seqNo}", seqNo));
  }
};

export const insertTrainingListRecord = async (data) => {
  return await post(API_URL.TRAINING_LIST_DATA, data);
};

export const updateTrainingRecordData = async (recordID, updateData) => {
  return await put(API_URL.EDIT_TRAINING_RECORD.replace("{id}", recordID), updateData);
};

export const cloneTrainingListRecord = async (recordID, data) => {
  return await post(API_URL.TRAINING_CLONE.replace("{id}", recordID), data);
};

export const deleteTrainingListRecord = async (recordID) => {
  return await deletes(API_URL.DELETE_TRAININGLIST.replace("{id}", recordID));
};

export const deleteMultipleTrainingListRecords = async (recordID) => {
  return await deletes(API_URL.DELETE_MULTIPLE_TRAININGLIST, recordID);
};

export const saveAugmentationMode = async (trainingId, data) => {
  return await put(API_URL.AUGMENTATION_MODE.replace("{id}", trainingId), data);
};

export const getAugmentationMode = async (trainingId) => {
  return await get(API_URL.AUGMENTATION_MODE.replace("{id}", trainingId));
};

export const getExecutionLogData = async (trainingId, seqNo) => {
  return await get(API_URL.TRAIN_EXECUTION_LOG.replace("{id}", trainingId).replace("{seqNo}", seqNo));
};

export const getListingExecuteModal = async () => {
  return await get(API_URL.LISTING_EXISTING_MODAL);
};

export const saveExecutedDatasetClone = async (data) => {
  return await post(API_URL.EXECUTED_DATASET_CLONE, data);
};

export const subclassificationSuggestionResult = async (trainingID, seqNo) => {
  return await get(API_URL.SUGGESTION_RESULT.replace("{id}", trainingID).replace("{seqNo}", seqNo));
};

export const subclassificationSuggestionImage = async (trainingID, seqNo, data) => {
  return await post(API_URL.SUGESSTION_IMAGES.replace("{id}", trainingID).replace("{seqNo}", seqNo), data);
}

export const subclassificationSuggestionGraphData = async (trainingID, seqNo) => {
  return await get(API_URL.SUGGESTION_CLASS_GRAPH_DATA.replace("{id}", trainingID).replace("{seqNo}", seqNo));
}
export const getSuggestionClassList = async (trainingId) => {
  return await get(API_URL.CLASSIFICATION_DATASET.replace("{id}", trainingId));
};

export const getSuggestionClassImages = async (trainingID, seqNo, paginationData) => {
  return await get(API_URL.SUGESSTION_IMAGES.replace("{id}", trainingID).replace("{seqNo}", seqNo), paginationData);
}

export const getCorrectionClassImages = async (trainingID, seqNo, paginationData) => {
  return await get(API_URL.CORRECTION_IMAGES.replace("{id}", trainingID).replace("{seqNo}", seqNo), paginationData);
}

export const suggestionResultClassUpdate = async (trainingID, seqNo, updateData) => {
  return await post(API_URL.SUGGESTION_CLASS_UPDATE.replace("{id}", trainingID).replace("{seqNo}", seqNo), updateData);
};

export const suggestionResultCreateClass = async (trainingID, data) => {
  return await post(API_URL.SUGGESTION_RESULT_CLASS_CREATE.replace("{id}", trainingID), data);
};

export const datasetCreateClass = async (trainingID, data) => {
  return await post(API_URL.DATASET_CLASS_CREATE.replace("{id}", trainingID), data);
};

export const classificationDatasets = async (trainingID, seqNo) => {
  return await get(API_URL.CLASSIFICATION_DATASET.replace("{id}", trainingID).replace("{seqNo}", seqNo));
};

export const resetSuggestionResultClass = async (trainingID, data) => {
  return await post(API_URL.CLASSIFICATION_DATASET.replace("{id}", trainingID), data);
}

export const getSuggestionResultProbabilityGraphDetails = async (trainingId, classSeqNo, data) => {
  return await post(API_URL.SUGGESTION_CLASS_GRAPH_DATA.replace("{id}", trainingId).replace("{seqNo}", classSeqNo), data);
};

export const storeCorrectionFixData = async (trainingId, seqNo) => {
  return await post(API_URL.SUGGESTION_RESULT_FIX_SUBMIT.replace("{id}", trainingId).replace("{seqNo}", seqNo), {});
};

export const suggestionResultImageMove = async (trainingId, classData) => {
  return await post(API_URL.SUGGESTION_RESULT_IMAGE_MOVE.replace("{id}", trainingId), classData);
};

export const displayAdvisor = async (trainingId, seqNo) => {
  return await get(API_URL.DISPLAY_ADVISOR.replace("{id}", trainingId).replace("{seqNo}", seqNo));
}

export const getAccuracyLossImages = async (seqNo) => {
  return await get(API_URL.ACCURACY_LOSS_IMAGES.replace("{seqNo}", seqNo));
}

export const updateMaskingCoordinates = async (id, payload) => {
  return await put(API_URL.UPDATE_MASKING.replace("{id}", id), payload);
}

export const executeMasking = async (id, payload) => {
  return await post(API_URL.EXECUTE_MASKING.replace("{id}", id), payload);
}

export const maskingResult = async (id, seqNo, payload) => {
  return await post(API_URL.MASKING_RESULT.replace("{id}", id).replace("{seqNo}", seqNo), payload)
}

export const changeDatasetOrder = async (id, payload) => {
  return await post(API_URL.CHANGE_DATASET_ORDER.replace("{id}",id),payload);
}