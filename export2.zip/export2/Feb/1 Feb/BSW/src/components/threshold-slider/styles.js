import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  sliderRoot: { width: 250 },
  sliderClass: {
    marginBottom: "0px",
    "& .MuiSlider-markLabel": {
      left: "16px !important",
      fontSize: "12px",
      fontWeight: 300,
      lineHeight: "100%",
      "&[data-index='1']": {
        right: "-25px",
        left: "inherit !important"
      }
    }
  },
  
  thresholdInput: {
    width: "65px"
  },
}));
