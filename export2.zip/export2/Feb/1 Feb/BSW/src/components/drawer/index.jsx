import clsx from "clsx";
import { useState, useContext, useEffect } from "react";
import { Link } from "react-router-dom";
import { Drawer, Button, Paper, Tabs, Tab, ListItem, ListItemIcon, ListItemText } from "@material-ui/core";
import UserStore from "../../shared/stores/userstore";
import RoundIcon from "../../shared/components/ui/roundIcon";
import { APPMENULIST, APP_ROUTES } from "../../appconstants";
import { useStyles } from "./style";
import { useTheme } from "@material-ui/core/styles";
import { useHistory } from "react-router-dom";
import Sidebar from "../../shared/components/sidebarnavigator";
import SidebarList from "../../shared/components/sidebarnavigator/listitems/sidebarlist";
import SidebarListItem from "../../shared/components/sidebarnavigator/listitems/sidebarlistitem";
import TabPanel from "../../shared/components/tabpanel";

const AppDrawerSection = (props) => {
  const classes = useStyles();
  const userStore = useContext(UserStore);
  const history = useHistory();
  const { open } = props;
  const theme = useTheme();
  const [active, setActive] = useState("");
  const listItemClick = (name) => {
    setActive(name);
  };

  const findActiveTab = (url) => {
    if (url.includes(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST)) {
      setActive("CT");
    } else {
      setActive("TR");
    }
  };

  useEffect(() => {
    return history.listen((location) => {
      findActiveTab(location.pathname);
    });
  }, [history]);

  useEffect(() => {
    findActiveTab(window.location.href);
  }, [window.location.href]);

  const renderAppIcons = (props, index) => {
    const activeClass = active === props.shortName ? classes.sidebarappmenuselect : classes.sidebarappmenu;
    const roundactiveClass = props.shortName === active ? true : false;
    return (
      <div key={props.shortName}>
        <ListItem button onClick={() => listItemClick(props.shortName)} component={Link} to={props.url} className={activeClass}>
          <ListItemIcon className={classes.sidebarAppTextCollapsed}>
            <RoundIcon title={props.shortName} active={roundactiveClass} />
            {!open && <ListItemText primary={props.title} className={`${props.title}`} />}
          </ListItemIcon>
        </ListItem>
      </div>
    );
  };

  const drawerElements = () =>
    userStore.currentUser && (
      <Drawer
        variant="permanent"
        classes={{
          paper: clsx(classes.drawerPaper, open && classes.drawerPaperClose)
        }}
        open={open}
      >
        {
          <div className={open ? classes.collapsedList : classes.drawerList}>
            {APPMENULIST.map(function (data, idx) {
              return renderAppIcons(data, idx);
            })}
          </div>
        }

        {/*!open && (
          <Sidebar appMenus={APPMENULIST}>
            <Tabs
              value={value}
              onChange={handleChange}
              indicatorColor="primary"
              textColor="primary"
              variant="fullWidth"
              aria-label="full width"
            >
              <Tab className={classes.MuiTab} label="DATA" />
              <Tab className={classes.MuiTab} label="GRAPH" />
            </Tabs>
            <TabPanel
              value={value}
              index={0}
              dir={theme.direction}
              className={classes.tabheight}
            >
              {dataMenus.map(function(data, index) {
                return (
                  <SidebarList
                    dataTitle={data.title}
                    index={index}
                    key={data.title}
                  >
                    {labels[data.name].map(function(item, lindex) {
                      return (
                        <SidebarListItem
                          type="checkbox"
                          key={item}
                          fieldName={data.name}
                          index={lindex}
                          item={item}
                          handleCheck={handleCheck}
                        ></SidebarListItem>
                      );
                    })}
                  </SidebarList>
                );
              })}
            </TabPanel>

            <TabPanel
              value={value}
              index={1}
              dir={theme.direction}
              className={classes.tabheight}
            ></TabPanel>

            <Paper
              className={clsx(classes.buttons, classes.SidebarButtonGroup)}
            >
              <Button
                className={clsx(classes.buttons, classes.sidebarbutton)}
                variant="contained"
                size="small"
                color="primary"
                onClick={backToDefault}
              >
                Back To Default
              </Button>

              <Button
                className={clsx(classes.buttons, classes.sidebarApplybutton)}
                variant="contained"
                size="small"
                color="primary"
                onClick={backToDefault}
              >
                Apply
              </Button>
            </Paper>
          </Sidebar>
            )*/}
      </Drawer>
    );

  return drawerElements();
};

export default AppDrawerSection;
