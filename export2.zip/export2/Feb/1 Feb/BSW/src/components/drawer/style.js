import { makeStyles } from "@material-ui/core/styles";
const drawerWidth = 214;

export const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    height: 48
  },

  drawerPaper: {
    height: `calc(100vh - 48px)`,
    top: 48,
    background: "white",
    paddingTop: 8,
    zIndex: 0,
    position: "relative",
    whiteSpace: "nowrap",
    width: drawerWidth,
    overflowX: "hidden",
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  drawerPaperClose: {
    overflowX: "hidden",

    zIndex: 0,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    width: 48,
    [theme.breakpoints.up("sm")]: {
      width: 48
    }
  },
  collapsedList: {
    position: "absolute",
    active: {
      width: "47px",
      height: "48px"
    }
  },

  content: {
    flexGrow: 1,
    height: "100vh",
    overflow: "auto"
  },
  appBarSpacer: {
    minHeight: 48
  },
  container: {
    paddingTop: theme.spacing(2),
    paddingLeft: "16px",
    paddingRight: "16px",
    paddingBottom: "16px"
  },
  drawerList: {
    "& > *": {
      display: "flex",
      alignItems: "center",
      placeContent: "center",
      backgroundColor: "#e3e3e3c0"
    }
  },
  sidebarbutton: {
    fontSize: 12
  },
  sidebarappmenu: {
    backgroundColor: "white",
    padding: "0px",
    height: 48,

    "& span": {
      fontSize: "14px",
      color: "#323130"
    }
  },
  defaultSidebarSelection: {
    backgroundColor: "rgba(0 0 0 /0.07)",
    padding: "0",
    marginTop: "0",
    height: "48px",
    width: "100%",
    textAlign: "center",
    alignItems: "center",
    justifyContent: "left",
    "& span": {
      color: "#3a5faa",
      fontSize: 14,
      fontWeight: 500
    }
  },
  sidebarappmenuselect: {
    backgroundColor: "rgba(0 0 0 /0.04)",
    padding: "0px",
    height: 48,
    "& span": {
      color: "#3a5faa",
      fontSize: 14,
      fontWeight: 500
    }
  },
  sidebarmenuicon: {
    fontSize: 20,
    fontWeight: 300
  },
  sidebarAppTextCollapsed: {
    justifyContent: "left",
    "& div:first-child": {
      width: "28px",
      height: "28px",
      fontSize: 12,
      fontWeight: 400,
      margin: "0 10px",
      justifyContent: "center",
      alignItems: "center"
    },
    minWidth: "48px !important"
  },
  tabheight: {
    height: "calc(100vh - 187px)",
    overflow: "auto"
  },
  MuiTab: {
    minWidth: "unset !important",
    fontSize: 14,
    fontWeight: 600,
    backgroundColor: "#f5f5f5"
  },
  SidebarButtonGroup: {
    justifyContent: "space-between",
    display: "flex",
    padding: "0px 7px 5px"
  }
}));
