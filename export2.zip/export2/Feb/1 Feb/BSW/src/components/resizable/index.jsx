import React, { useRef, useEffect, useState } from "react";
import {useStyles} from './styles';
import Panel from './panel';

const ResizablePanel = (props) => {

  const { hideDrag } = props;
  const classes =  useStyles(props);
  const ref = useRef(null);
  const [maxHeight, setMaxHeight] = useState(0);
  const [height, setHeight] = useState(undefined);
  const [separatorYPosition, setSeparatorYPosition] = useState(undefined);
  const [dragging, setDragging] = useState(false);



  const onMouseDown = (e) => {
    setSeparatorYPosition(e.clientY);
    setDragging(true);
  };

  const onTouchStart = (e) => {
    setSeparatorYPosition(e.touches[0].clientY);
    setDragging(true);
  };

  const onMove = (clientY) => {
    // let convetheight = height.split('%')[0];
    if (dragging && height && separatorYPosition) {
      const newHeight = height + clientY - separatorYPosition;
      setSeparatorYPosition(clientY);

      if (newHeight < maxHeight) {
        setHeight(maxHeight);
        return;
      }

      if (ref.current) {
        const splitPaneWidth = ref.current.clientWidth;

        if (newHeight > splitPaneWidth - maxHeight) {
          setHeight(newHeight);
          setMaxHeight(newHeight);
          return;
        }
      }

      setHeight(newHeight);
    }
  };

  const onMouseMove = (e) => {
    e.preventDefault();
    onMove(e.clientY);
  };

  const onTouchMove = (e) => {
    console.log(e.touches)
    onMove(e.touches[0].clientY);
  };

  const onMouseUp = () => {
    setDragging(false);
  };

  useEffect(()=>{
    setHeight('100%');
    // if(!hideDrag){
      setMaxHeight(0)
    // }
  },[hideDrag]);

  useEffect(() => {
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("touchmove", onTouchMove);
    document.addEventListener("mouseup", onMouseUp);

    return () => {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("touchmove", onTouchMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
  });

  return (<>
    <div className={classes.root} ref={ref}>
      
        <Panel className={classes.panel} height={height} setHeight={setHeight}>
         {props.children}
        </Panel>
      
      {hideDrag && <div className={classes.dragBox} onMouseDown={onMouseDown} onTouchStart={onTouchStart} onTouchEnd={onMouseUp}>
        <div className={classes.divider} />
      </div>}
    </div>
    </>
    
  );
};

export default ResizablePanel;