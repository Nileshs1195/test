import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from '@material-ui/core';
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TrainingManagementStore from '../../stores/trainingmanagementstore';
import { API_RESPONSE, APP_ROUTES } from "../../appconstants";
import { checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";
import { useHistory } from "react-router";

const CopyTraining = (props) => {
  const { t } = useTranslation();
  const form = useRef();
  const history = useHistory();
  const { open, setOpen, callBack, training, setSnapbar } = props;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [formError, setFormError] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [formContent, setFormContent] = useState({
    modelName: training?.modelName,
    comment: training?.comment
  });
  const [config, setConfig] = useState({
    fields: {
      modelName: {
        initialValue: training?.modelName || "",
        isRequired: { message: t("validation.message.required", { field: t("validation.field.modelName") }) },
        isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.modelName") }) }
      },
      comment: {
        initialValue: training?.comment || "",
        isRequired: { message: t("validation.message.required", { field: t("validation.field.comment") }) }
      }
    },
    onSubmit: state => {
      setSubmitted(state?.submitted);
      if (state?.errors) {
        setFormError({ ...state.errors });
      }
    },
    showErrors: 'blur',
    submitted: true
  });

  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  useEffect(() => { //Sets values after change
    setFormContent({ ...formContent, ...values });
  }, [values]);

  useEffect(() => {//This is required to validate and show error message
    errors && !submitted && setFormError(errors);
    submitted && setSubmitted(false);
  }, [errors])

  useEffect(() => { //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
  }, [form?.current])

  const handleDuplicateEntry = (data) => {
    let find = trainingManagementStore.trainingListData.filter(e => e.modelName === data.modelName);
    return !find.length;
  }

  const gotoTrainParameterSetting = (trainingId) => {
    trainingManagementStore.clearTrainingDataset();
    trainingManagementStore.setTabIndex(0);
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(':id', trainingId));
  }

  const saveCloneTrainingListData = () => {
    form.current.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
    // setSnapbar({ message: "" });
    let formArray = objToArray(formError);
    let notNull = checkNotNullFromArray(formArray);
    let isNotDuplicate = handleDuplicateEntry(formContent);
    if ((formArray?.length <= 0 || !notNull) && isNotDuplicate && training?._id) {
      //Validation passed
      trainingManagementStore
        .cloneTrainingListRecord(training?._id, formContent)
        .then((response) => {
          if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            setSnapbar({ message: t("pages.training.success.training-list.update") });
            setOpen(false);
            trainingManagementStore.clearSelectedTrainingListData();
            gotoTrainParameterSetting(response?.data?.data?._id);
            if (callBack) {
              callBack();
            }
          } else {
            setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
          }
        })
        .catch((error) => {
          console.log("error", error);
          setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
        });
    } else {
      setSnapbar({ message: "Duplicate Entry" });
    }
    setTimeout(() => {
      setSnapbar({ message: "" });
    }, 2000)
  }

  return (
    <Observer>
      {() => (
        <>
          <CustomConfirmation
            open={open}
            onClose={() => setOpen(false)}
            noImmediateClose={true}
            onSubmit={saveCloneTrainingListData}
            primary={'pages.training.training-list.controls.ok'}
            secondary={'pages.training.training-list.controls.cancel-btn'}
            title={t("pages.training.training-list.modal.copy-to-new-training")}
            message={<>
              <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                <TextField
                  fullWidth
                  aria-valuetext={training?.modelName}
                  id="modelName"
                  name="modelName"
                  margin="normal"
                  label={t("validation.field.modelName")}
                  value={formContent?.modelName} autoFocus
                  {...getFieldProps('modelName')}
                  error={formError?.modelName}
                  helperText={formError?.modelName}
                />
                <TextField
                  aria-valuetext={formContent?.comment}
                  fullWidth
                  id="comment"
                  name="comment"
                  margin="normal"
                  label={t("validation.field.comment")}
                  value={formContent?.comment}
                  {...getFieldProps('comment')}
                  error={formError?.comment}
                  helperText={formError?.comment}
                />
              </form>
            </>} />
        </>
      )}
    </Observer >
  );
};
export default CopyTraining;
