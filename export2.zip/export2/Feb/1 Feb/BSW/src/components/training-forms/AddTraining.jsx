import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from '@material-ui/core';
import { useHistory } from "react-router";
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TrainingManagementStore from '../../stores/trainingmanagementstore';
import { API_RESPONSE, APP_ROUTES } from "../../appconstants";
import { checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";

const AddTraining = (props) => {
    const history = useHistory();
    const { t } = useTranslation();
    const form = useRef();
    const { open, setOpen, noRedirect, setSnapbar } = props;
    const [closed, setClosed] = useState(false);
    const trainingManagementStore = useContext(TrainingManagementStore);
    const [formError, setFormError] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const [formContent, setFormContent] = useState({ modelName: "", comment: "" });
    const [config, setConfig] = useState({
        fields: {
            modelName: {
                initialValue: "",
                isRequired: { message: t("validation.message.required", { field: t("validation.field.modelName") }) },
                isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.modelName") }) }
            },
            comment: {
                initialValue: "",
                isRequired: { message: t("validation.message.required", { field: t("validation.field.comment") }) },
            }
        },
        onSubmit: state => {
            setSubmitted(state?.submitted);
            if (state?.errors) {
                setFormError({ ...state.errors });
            }
        },
        showErrors: 'blur',
        submitted: false
    });

    const { getFieldProps, getFormProps, errors, values } = useValidation(config);
    useEffect(() => { //Sets values after change
       setFormContent({ ...formContent, ...values });
    }, [values]);

    useEffect(() => {//This is required to validate and show error message        
        errors && !submitted && !closed && setFormError(errors);
        setClosed(false);
        submitted && setSubmitted(false);
    }, [errors])

    useEffect(() => { //This is required to trigger the submit event on load
        form?.current?.dispatchEvent(
            new Event("submit", { bubbles: true, cancelable: true })
        );
    }, [form?.current])

    const gotoTrainParameterSetting = (trainingId) => {
        trainingManagementStore.clearTrainingDataset();
        trainingManagementStore.setTabIndex(0);
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(':id', trainingId));
    }

    const onClose = () => {
        setOpen(false);
        setClosed(true);
        values.modelName = "";
        values.comment = "";
        formContent.modelName = "";
        formContent.comment = "";
        formError.modelName = null;
        formError.comment = null;
        errors.modelName = null;
        errors.comment = null;
        setFormError({});
       }

    const saveNewTraining = () => {
        form.current.dispatchEvent(
            new Event("submit", { bubbles: true, cancelable: true })
        );
        let formArray = objToArray(formError);
        let notNull = checkNotNullFromArray(formArray);
        
        if (formArray?.length <= 0 || !notNull) {
            //Validation passed
            setSnapbar({ message: "" });
            trainingManagementStore
                .insertTrainingListRecord(formContent)
                .then((response) => {
                    if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                        if (response?.data?.exists) {
                            setSnapbar({
                                message: t("pages.training.errors.training-list.record-exists"),
                                timeout: 10000
                            });
                            return;
                        } else {
                            if (!noRedirect) {
                                trainingManagementStore.setSelectedTrainingListRecord(response.data);
                                gotoTrainParameterSetting(response.data.training._id);
                            }
                        }
                    } else {
                        setSnapbar({
                            message: t("pages.training.errors.training-list.save-failed"),
                            timeout: 10000
                        });
                    }
                })
                .catch((error) => {
                    console.log("error", error);
                    setSnapbar({
                        message: t("pages.training.errors.training-list.save-failed"),
                        timeout: 10000
                    });
                });
        }
    }

    return (
        <Observer>
            {() => (
                <>
                    <CustomConfirmation
                        open={open}
                        onClose={onClose}
                        noImmediateClose={true}
                        onSubmit={saveNewTraining}
                        primary={'pages.training.training-list.controls.ok'}
                        secondary={'pages.training.training-list.controls.cancel-btn'}
                        title={t('pages.training.training-list.modal.new-training')}
                        message={<>
                            <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                                <TextField
                                    fullWidth
                                    id="modelName"
                                    name="modelName"
                                    margin="normal"
                                    label={t("validation.field.modelName")}
                                    aria-valuetext={formContent?.modelName}
                                    value={formContent?.modelName} autoFocus
                                    {...getFieldProps('modelName')}
                                    error={formError.modelName}
                                    helperText={formError.modelName}
                                />
                                <TextField
                                    fullWidth
                                    id="comment"
                                    name="comment"
                                    margin="normal"
                                    label={t("validation.field.comment")}
                                    aria-valuetext={formContent?.comment}
                                    value={formContent?.comment}
                                    {...getFieldProps('comment')}
                                    error={formError.comment}
                                    helperText={formError.comment}
                                />
                            </form>
                        </>} />
                </>
            )}
        </Observer >
    );
};
export default AddTraining;
