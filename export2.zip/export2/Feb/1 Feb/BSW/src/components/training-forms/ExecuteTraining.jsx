import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from '@material-ui/core';
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TrainingManagementStore from '../../stores/trainingmanagementstore';
import { API_RESPONSE } from "../../appconstants";
import { checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";
import { useHistory } from 'react-router-dom';
import { APP_ROUTES, IMAGE_GROUP_LIST } from '../../appconstants';

const ExecuteTraining = (props) => {
  const { t } = useTranslation();
  const history = useHistory();
  const form = useRef();
  const [snapbarMessage, setsnapbarMessage] = useState({ message: '' });
  const [confirm, setConfirm] = useState({ mode: "", status: "", open: false });
  const { open, setOpen, callBack, training, setSnapbar, disableAddButton } = props;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [formError, setFormError] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [openModel,setOpenModel] = useState(false);
  const [popup,setPopup] = useState(open);
  const [config, setConfig] = useState({
    fields: {
      modelName: {
        initialValue: training?.modelName || "",
        isRequired: { message: t("validation.message.required", { field: t("validation.field.modelName") }) },
        isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum") }
      },
      comment: {
        initialValue: training?.comment || "",
        isRequired: { message: t("validation.message.required", { field: t("validation.field.comment") }) }
      }
    },
    onSubmit: state => {
      setSubmitted(state?.submitted);
      if (state?.errors) {
        setFormError({ ...state.errors });
      }
    },
    showErrors: 'blur',
    submitted: true
  });
  const [formContent, setFormContent] = useState({
    modelName: training?.modelName || "",
    comment: training?.comment || ""
  });
  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  useEffect(() => { //Sets values after change
    setFormContent({ ...formContent, ...values });
  }, [values]);

  useEffect(() => {//This is required to validate and show error message
    errors && !submitted && setFormError(errors);
    submitted && setSubmitted(false);
  }, [errors])

  useEffect(() => { //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
  }, [form?.current])

  const handleDuplicateEntry = (data) => {
    let find = trainingManagementStore.trainingListData.filter(e => e.modelName === data.modelName);
    return !find.length;
  }
  const gotoTrainParameterSetting = (trainingId) => {
    trainingManagementStore.clearTrainingDataset();
    trainingManagementStore.setTabIndex(0);
    history.push(
      APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(
        ':id',
        trainingId,
      ),
    );
  }
  const updateTraining = () => {
       let formArray = objToArray(formError);
    let notNull = checkNotNullFromArray(formArray);
    // let isNotDuplicate = handleDuplicateEntry(formContent);
    setSnapbar({ message: "" });
    if ((formArray?.length <= 0 || !notNull)  && training?._id) {
      //Validation passed
      trainingManagementStore
        .updateTrainingRecordData(training?._id, formContent)
        .then((response) => {
          if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            if(response?.data?.exists) {
              setSnapbar({ message: t("pages.training.errors.training-list.record-exists") });              
            }  else {
              trainingManagementStore.clearSelectedTrainingListData();
              setSnapbar({ message: t("pages.training.success.training-list.update") });
              setOpen(false);
              disableAddButton(false);
              if (callBack) {
                callBack();
              }
            }              
          } else {
            setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
          }
        })
        .catch((error) => {
          setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
        });
    } else {
      setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
    }

    if (trainingManagementStore?.selectedTrainingListData?.[0]?._id) {
        let selectedTraining = Object.assign({}, trainingManagementStore?.selectedTrainingListData?.[0]);
        if (selectedTraining?.status === 7 || selectedTraining?.status === "Ok" || selectedTraining?.status === "Executed" || selectedTraining?.status === "Stop" || selectedTraining?.status === "Stopping" || selectedTraining?.status === "Stopped" || !selectedTraining.batchSeqNo || selectedTraining.statusString === "Not Running") {
          if (selectedTraining?.status === "Ok") {
            trainingManagementStore.startExecution(trainingManagementStore?.selectedTrainingListData?.[0]?._id, "none", {}).then(res => {
              if (res?.status === 200 && res?.data?.seqNo && res?.data?.mode === "none") {
                gotoTrainParameterSetting(selectedTraining._id);
              } else {
                console.log("Mode", res?.data?.mode);
              }
            }).catch(error => {
              console.log(error);
            });
          } else {
            gotoTrainParameterSetting(selectedTraining._id);
          }
        } else {
          setConfirm({
            mode: selectedTraining.mode,
            status: selectedTraining.status,
            open: true,
            submit: () => redirectToExecution(selectedTraining),
            title: "pages.training.errors.training-list.execution-failed-title",
            message: "pages.training.errors.training-list.execution-failed-training-reexecute",
            primary: "pages.training.errors.training-list.fail-redirect",
            secondary: "pages.training.input-parameter.grid.cutomization.modal.cancel-btn"
          });
        }
      } else {
        setsnapbarMessage({ message: t("pages.training.errors.training-list.selected-id-unavailable") });
      }
  

    setTimeout(() => {
      setSnapbar({ message: "" });
    }, 2000)
  }
  const redirectToExecution = (selectedTraining) => {
    if (selectedTraining?.mode === "subclassification") {
      history.push(
        APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION.replace(
          ':id',
          selectedTraining._id,
        ).replace(
          ':seqNo',
          selectedTraining.batchSeqNo,
        )
      )
    } else if (selectedTraining?.mode === "training") {
      history.push(
        APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(
          ':id',
          selectedTraining._id,
        ).replace(
          ':seqNo',
          selectedTraining.batchSeqNo,
        )
      )
    } else if (selectedTraining?.mode === "parameterSearch") {
      history.push(
        APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH.replace(
          ':id',
          selectedTraining._id,
        ).replace(
          ':seqNo',
          selectedTraining.batchSeqNo,
        )
      )
    } else {

    }
  }

  const onSubmit = () =>{
      setPopup(false);
      setOpenModel(true);
  }

  return (
    <Observer>
      {() => (
        <>
        <>
          <CustomConfirmation
            open={popup}
            onClose={() => setOpen(false)}
            noImmediateClose={true}
            // onSubmit={updateTraining}
            onSubmit={onSubmit}
            primary={'pages.training.training-list.controls.ok'}
            secondary={'pages.training.training-list.controls.cancel-btn'}
            title={t('pages.training.training-list.modal.re-execute-training')}
            message={<>
              <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                <TextField
                  disabled
                  fullWidth
                  aria-valuetext={formContent?.modelName}
                  id="modelName"
                  name="modelName"
                  margin="normal"
                  label={t("validation.field.modelName")}
                  value={formContent?.modelName} autoFocus
                  {...getFieldProps('modelName')}
                  error={formError.modelName}
                  helperText={formError.modelName}
                />
                <TextField
                  aria-valuetext={formContent?.comment}
                  fullWidth
                  id="comment"
                  name="comment"
                  margin="normal"
                  label={t("validation.field.comment")}
                  value={formContent?.comment}
                  {...getFieldProps('comment')}
                  error={formError?.comment}
                  helperText={formError?.comment}
                />
              </form>
            </>} />
        </>
        {openModel &&<>
            <CustomConfirmation
            open={open}
            onClose={() => setOpen(false)}
            noImmediateClose={true}
            onSubmit={updateTraining}
            primary={'pages.training.training-list.modal.overwrite'}
            secondary={'pages.training.training-list.controls.cancel-btn'}
            title={t('pages.training.training-list.modal.re-execute-training')}
            message={"Do you want to overwrite the original training"} />
        </>}
      </>
      )}
    </Observer >
  );
};
export default ExecuteTraining;
