import { useContext } from "react";
import { DragDropContext } from "react-beautiful-dnd";
import { useParams } from "react-router";
import { API_RESPONSE, API_URL } from "../../appconstants";
import TrainingManagementStore from "../../stores/trainingmanagementstore";
import ImageManagementStore from "../../stores/imagemanagementstore";
import ImageLists from ".";

const ImageListComponent = (props) => {
  const {
    classes,
    trainingDetails,
    imageType,
    url,
    order,
    masking,
    maskConfirmation,
    heatMapImages,
    showAddImage,
    showDeleteImage,
    showMoveImages,
    imageSelection,
    showEditClass,
    carouselView,
    trainingClasses,
    expand,
    pageSize,
    showEditClassName,
    paginationPosition,
    classificationTest,
    dropdown,
    isDragDropDisabled,
    classTitle,
    showSecondImageSet
  } = props;
  const params = useParams();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);

  const onDragEnd = async ({ source, destination }) => {
    // Make sure we have a valid destination
    if (destination === undefined || destination === null || source.droppableId === destination.droppableId) return null;
    let sourceClassIndex = trainingClasses.findIndex((e) => e.seqNo.toString() === source.droppableId);
    let destinationClassIndex = trainingClasses.findIndex((e) => e.seqNo.toString() === destination.droppableId);
    const otherColumns = JSON.parse(JSON.stringify(trainingClasses));
    // Set start and end variables
    const start = otherColumns[sourceClassIndex];
    const end = otherColumns[destinationClassIndex];
    const saveImageData = {
      dst_seqNo: end.seqNo,
      img_seqNo: [source.index]
    };

    let pageUrl = url;
    if (url === API_URL.CORRECTION_IMAGES) {
      pageUrl = API_URL.SUGGESTION_CLASS_UPDATE;
    }
    await imageManagementStore
      .saveEditImageClassDetails(params.id, start.seqNo, saveImageData, pageUrl)
      .then((response) => {
        if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          console.log("Success");
          trainingManagementStore.setDestinationClassSeqNo(saveImageData.dst_seqNo);
          trainingManagementStore.setSourceClassSeqNo(start.seqNo);
        } else {
          console.log("Error occurred while saving image group record");
        }
      })
      .catch((error) => {});
  };

  const getImageAccodian = () => {
    let result = [];
    classes.forEach((element, index) => {
      const seqNo = typeof element === "object" ? index : element;
      result.push(
        <ImageLists
          url={url}
          seqNo={seqNo}
          trainingDetails={trainingDetails}
          order={order}
          key={"image-" + seqNo}
          expand={expand}
          masking={masking}
          maskConfirmation={maskConfirmation}
          heatMapImages={heatMapImages}
          imageType={imageType}
          showAddImage={showAddImage}
          showDeleteImage={showDeleteImage}
          showMoveImages={showMoveImages}
          imageSelection={imageSelection}
          showEditClass={showEditClass}
          carouselView={carouselView}
          trainingClasses={trainingClasses}
          pageSize={pageSize}
          showEditClassName={showEditClassName}
          paginationPosition={paginationPosition}
          classData={element}
          classificationTest={classificationTest}
          dropdown={dropdown}
          isDragDropDisabled={isDragDropDisabled}
          classTitle={classTitle}
          showSecondImageSet={showSecondImageSet}
        />
      );
    });
    return result;
  };
  return <DragDropContext onDragEnd={onDragEnd}>{getImageAccodian()}</DragDropContext>;
};
export default ImageListComponent;
