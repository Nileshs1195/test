import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between"
  },
  thumbWrap: {
    margin: "16px 16px 16px 16px"
  },
  gridContainer: {
    flexWrap: 'nowrap',
    overflowX: 'auto',
  },
  gridParent: {
    '& *::-webkit-scrollbar': {
      width: '0.5em',
      height: '1em'
    },
    '& ::-webkit-scrollbar-button:single-button': {
      borderWidth: '0 8px 8px 8px',
      backgroundColor: '#ccc',
      borderColor: 'transparent transparent #555555 transparent'
    }
  },
  activationContainer: {
    flexWrap: "nowrap",
    overflowX: "auto",
    marginTop: "30px",

    
    '& *::-webkit-scrollbar': {
      width: '0.5em',
      height: '1em'
    },
    '& ::-webkit-scrollbar-button:single-button': {
      borderWidth: '0 8px 8px 8px',
      backgroundColor: '#ccc',
      borderColor: 'transparent transparent #555555 transparent'
    }
  },
  thumbItem: {
    position: "relative",
    zIndex: 0,
    "&:hover $thumbCheckbox": {
      display: "flex",
      backgroundColor: "white"
    },
    "@media (min-width: 960px)": {
      maxWidth: "11.11%"
    }
  },
  noContentMiddle: {
    flex: "auto"
  },
  left: {
    position: "relative",
    width: "55.55%",
    flexBasis: "55.5%",
    maxWidth: "55.5%",
    margin: "8px 0px",
    borderRight: "solid 2px red",
    // zIndex: 0,
    "& .MuiGrid-item": {
      padding: "0px 8px",
      flexBasis: "inherit",
      maxWidth: "20%"
    }
  },
  accordionTitle: {
    position: "absolute",
    // width: "100%",
    right: "80px",
    display: "flex",
    alignItems: "center",
    // flexDirection: "column",
    top: "-12px",
    zIndex: "5",
    padding: "2px",
    "& div[class*='makeStyles-controlContainer-'] div:not(:first-of-type)": {
      display: "none"
    }
  },
  left: {
    position: "relative",
    width: "55.55%",
    flexBasis: "55.5%",
    maxWidth: "55.5%",
    margin: "8px 0px",
    borderRight: "solid 3px red",
    // zIndex: 0,
    "& .MuiGrid-item": {
      padding: "0px 8px",
      flexBasis: "inherit",
      maxWidth: "20%"
    }
  },
  right: {
    position: "relative",
    width: "44.44%",
    flexBasis: "44.4%",
    maxWidth: "44.4%",
    margin: "8px 0px",
    // zIndex: 0,
    "& .MuiGrid-item": {
      padding: "0px 8px",
      flexBasis: "inherit",
      maxWidth: "25%"
    }
  },
  leftImageSection: { display: "flex", flexDirection: "row", justifyContent: "flex-end" },
  rightImageSection: { display: "flex", flexDirection: "row", justifyContent: "flex-start" },

  navL: {
    position: "relative",
    // zIndex: "5",
    padding: "2px",
    "& div[class*='makeStyles-controlContainer-'] div:not(:first-of-type)": {
      display: "none"
    }
  },
  navR: {
    position: "relative",
    // zIndex: "5",
    padding: "2px",
    "& div[class*='makeStyles-controlContainer-'] div:not(:first-of-type)": {
      display: "none"
    }
  },
  right: {
    position: "relative",
    width: "44.44%",
    flexBasis: "44.4%",
    maxWidth: "44.4%",
    margin: "8px 0px",
    // zIndex: 0,
    "& .MuiGrid-item": {
      padding: "0px 8px",
      flexBasis: "inherit",
      maxWidth: "25%"
    }
  },
  navR: {
    position: "absolute",
    right: "48px",
    top: "5px",
    zIndex: "5",
    padding: "2px",
    "& div[class*='makeStyles-controlContainer-'] div:not(:first-of-type)": {
      display: "none"
    }
  },
  noContent: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
  },
  fixedContent: {
    backgroundColor: "#ffffff",
    position: "relative",
  },
  warningIcon: {
    fontSize: "4rem",
    color: "#00000020",
  },
  thumbCheckbox: {
    display: "none",
    position: "absolute",
    zIndex: 5,
    right: 12,
    top: 12,
    width: "16px",
    height: "16px",
    backgroundColor: "white",
    "&.Mui-checked": {
      display: "flex",
      backgroundColor: "white"
    }
  },
  trainingThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #3a5faa"
  },
  validationThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #dd0a55"
  },
  popover: {
    pointerEvents: "none"
  },
  popover_paper: {
    padding: theme.spacing(2)
  },
  bottom: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    paddingBottom: "16px",
    padding: "0px 16px",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  buttonWrapper: {
    display: "flex",
    alignSelf: "center",
    justifyContent: "flex-end",
    zIndex: 1
  },
  marginLeft20: {
    marginLeft: "20px"
  },
  accMarginTop: {
    marginTop: theme.spacing(2)
  },
  accSummary: {
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      minHeight: "48px !important"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  classificationAccSummary: {
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      minHeight: "68px !important"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  accDetails: {
    padding: 0,
    display: "block"
  },
  fileUpload: {
    display: "none"
  },
  modalTextPadding: {
    paddingBottom: "16px"
  },
  confirmationModalPadding: {
    paddingTop: theme.spacing(2)
  },
  confirmationModalWidth: {
    minWidth: "370px",
    maxWidth: "25%",
    minHeight: "auto"
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: 18,
    fontWeight: "normal",
    Height: "42px",
    margin: "-16px -16px 0px -16px",
    padding: "8px 16px",
    borderRadius: "4px 4px 0 0"
  },
  formControl: {
    minWidth: "100%"
  },
  loaderPosition: {
    zIndex: "9",
    marginTop: 130,
    marginBottom: 20
  },
  dorpdown: {
    top: "-8px",
    left: "350px",
    zIndex: "5",
    position: "absolute",
    padding: "3px"
  }
}));
