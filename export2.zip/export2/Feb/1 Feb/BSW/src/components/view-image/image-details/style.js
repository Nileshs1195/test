import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
      tRow: {
        "& td": {
            border: "1px solid #f1f1f1",
            height: "40px",
            boxSizing: "border-box",
            padding: "0 16px"
          }
      }, 
      textInfo: {
        width: "350px"
      }
}));