import { Observer } from "mobx-react-lite";
import { Grid, Popover, Checkbox } from "@material-ui/core";
import { useStyles } from "./style";
import { useState } from "react";
import { SETTINGS } from "../../appsettings";
import Loader from "../../shared/components/ui/loader";
import ImageDetails from "./image-details";
import { ErrorOutline } from "@material-ui/icons";
import { useTranslation } from "react-i18next";
import { useEffect } from "react";
import { API_URL } from "../../appconstants";
import MaskingImage from "../masking";
import { useParams } from "react-router";
import { Draggable } from "react-beautiful-dnd";

const ViewImage = (props) => {
  const {
    imageData,
    maskingConfirmation,
    masking,
    maskData,
    heatMapImages,
    index,
    imageKey,
    selectedImages,
    selectImages,
    handleViewImage,
    viewParameter,
    imageSelection,
    url,
    isDragDropDisabled
  } = props;
  const classes = useStyles();
  const params = useParams();
  const { t } = useTranslation();
  const [anchorEl, setAnchorEl] = useState(null);
  const imageThumbnailURL = SETTINGS.IMAGE_THUMBNAIL_URL;
  const [loaded, setLoaded] = useState(false);
  const [dummyImage, setDummyImage] = useState(false);
  const [imageClass, setImageClass] = useState("");
  const [openPopOver, setOpenPopOver] = useState(false);
  const returnFormat = {
    x: "xmin",
    height: "ymax",
    y: "ymin",
    width: "xmax"
  };

  useEffect(() => {
    let selectedClass = classes.imageView;
    if ((url === API_URL.GET_IMAGES_FOR_DATASET || url === API_URL.CONFUSION_MATRIX_IMAGE_LIST) && !masking && maskData) {
      selectedClass = imageData.imageMode === "validation" || imageData.imageMode === 2 ? classes.validationThumbImg : classes.trainingThumbImg;
    } else if (url === API_URL.CORRECTION_IMAGES) {
      if (imageData?.modeOfChange === 2) {
        selectedClass = classes.movedThumbImg;
      } else if (imageData?.modeOfChange === 1) {
        selectedClass = classes.transferedThumbImg;
      }
    } else if (maskData) {
      const exist = maskData.some((obj) => obj.imageSeqNo === imageData.seqNo);
      selectedClass = exist ? classes.validationThumbImg : classes.noBorderThumbImg;
    }
    setImageClass(selectedClass);
  }, [url, maskData?.length]);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
    setOpenPopOver(true);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
    setOpenPopOver(false);
  };

  const handleCarouselView = () => {
    handleViewImage(imageKey, imageData);
  };

  const getImageURL = () => {
    let imageURL = imageThumbnailURL + imageData.fileName;
    if (maskingConfirmation) {
      imageURL =
        SETTINGS.BASE_API_URL +
        API_URL.MASKING_AI_IMAGE.replace("{id}", params.id)
          .replace("{className}", imageData?.className)
          .replace("{bacthSeqNo}", params.batchSeqNo)
          .replace("{fileName}", [imageData.fileName, t("pages.training.masking.ai-output-image-url")].join(""));
    }
    if (heatMapImages) {
      imageURL =
        SETTINGS.BASE_API_URL +
        API_URL.HEATMAP_IMAGE.replace("{id}", params.id).replace("{seqNo}", params.seqNo).replace("{fileName}", imageData.heatmapFileName);
    }

    return imageURL;
  };

  const renderComponent = () => {
    return (
      <>
        {!viewParameter && imageSelection && (
          <Checkbox
            className={classes.thumbCheckbox}
            color="primary"
            checked={selectedImages.some((item) => item.seqNo === imageData?.seqNo)}
            onChange={() => {
              selectImages(imageData);
            }}
            id={index}
          />
        )}
        <div
          id="imageContainer"
          key={imageData.seqNo}
          aria-owns={opened ? "mouse-over-popover" : undefined}
          aria-haspopup="true"
          onClick={() => {
            handleCarouselView();
            handlePopoverClose();
          }}
          onMouseEnter={handlePopoverOpen}
          onWheel={handlePopoverClose}
          onMouseOut={handlePopoverClose}
          onMouseLeave={handlePopoverClose}
          style={{ cursor: "pointer" }}
          className={imageClass}
        >
          {imageData.fileName ? (
            <>
              {!dummyImage && loaded ? null : <Loader size={20} />}
              {masking && (
                <MaskingImage
                  readOnly={true}
                  returnFormat={returnFormat}
                  totalMasks={maskData.length}
                  masks={maskData?.length > 0 ? maskData : []}
                  src={imageThumbnailURL + imageData.fileName}
                  alt={imageData.uploadFileName}
                  imageClassName={classes.imageCenter}
                  enableMask={true}
                />
              )}
              {!masking && (
                <img
                  id="image"
                  onLoad={() => {
                    setLoaded(true);
                  }}
                  onError={() => {
                    setDummyImage(true);
                  }}
                  src={getImageURL()}
                  alt={imageData.uploadFileName}
                  id={index}
                  className={classes.imageCenter}
                />
              )}
            </>
          ) : (
            <div id={"image-" + imageData.seqNo} style={{ padding: 15 }} className={classes.imageCenter}>
              <div className={classes.noContent}>
                <span>
                  <ErrorOutline fontSize="large" className={classes.warningIcon} />
                </span>
                <span className={classes.noContentLabel}>{t("components.basic-table.image-unavailable")}</span>
              </div>
            </div>
          )}
        </div>
      </>
    );
  };
  const renderDraggableComponent = () => {
    return (
      <Draggable draggableId={imageData.seqNo.toString()} key={imageData.seqNo.toString()} index={index} isDragDisabled={isDragDropDisabled}>
        {(provided) => (
          <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
            {renderComponent()}
          </div>
        )}
      </Draggable>
    );
  };

  const opened = Boolean(anchorEl);
  return (
    <Observer>
      {() => (
        <>
          <Grid item xs={4} sm={4} md id="thumbItem" className={classes.thumbItem} key={imageData.seqNo}>
            {isDragDropDisabled ? renderComponent() : renderDraggableComponent()}
          </Grid>
          <Popover
            id="mouse-over-popover"
            className={classes.popover}
            classes={{
              paper: classes.popover_paper
            }}
            open={openPopOver}
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left"
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "left"
            }}
            onClose={handlePopoverClose}
            disableRestoreFocus
          >
            <ImageDetails masking={masking} imageData={imageData} />
          </Popover>
        </>
      )}
    </Observer>
  );
};
export default ViewImage;
