import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  thumbItem: {
    position: "relative",
    // zIndex: 0,
    
    "&:hover $thumbCheckbox": {
      display: "flex",
      backgroundColor: "white"
    },
    "@media (min-width: 960px)": {
      minWidth: '11.11%',
      maxWidth: "11.11%"
    }
  },
  thumbCheckbox: {
    display: "none",
    position: "absolute",
    zIndex: 5,
    right: 12,
    top: 12,
    width: "16px",
    height: "16px",
    backgroundColor: "white",
    "&.Mui-checked": {
      display: "flex",
      backgroundColor: "white"
    }
  },
  trainingThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #3a5faa"
  },
  imageView: {
    width: "100%",
    height: "130px"
  },
  validationThumbImg: {
    width: "100%",
    height: "130px",
    boxShadow: "0px 2px 0px #dd0a55"
  },
  movedThumbImg: {
    width: "100%",
    height: "130px",
    borderTop: "3px solid #dd0a55"
  },
  transferedThumbImg: {
    width: "100%",
    height: "130px",
    // boxShadow: "0px 2px 0px #3a5faa"
    borderBottom: "3px solid #3a5faa"
  },
  noBorderThumbImg: {
    width: "100%",
    height: "130px"
  },
  popover: {
    pointerEvents: "none"
  },
  popover_paper: {
    padding: theme.spacing(2)
  },
  imageCenter: {
    position: "relative",
    width: "100%",
    height: "100%",
    objectFit: "cover",
    overflow: "hidden"
  },
  noContentMiddle: {
    flex: "auto"
  },
  noContent: {
    display: "flex",
    alignItems: "center",
    flexDirection: "column"
  },
  fixedContent: {
    backgroundColor: "#ffffff",
    position: "relative"
  },
  warningIcon: {
    fontSize: "4rem",
    color: "#00000020"
  },
  container: {
    position: "relative",
    display: "inline-block",
    width: "100%",
    height: "400px",
    border: "1px solid rgb(203, 203, 203,0.1)"
  }
}));
