import React from 'react'
import Modal from "../../shared/components/ui/modal";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";

const CancelExecutionModal = (props) => {
    const classes = useStyles();
    const { t } = useTranslation();
    return (
        <div>
            <Modal
                open={props.open}
                onClose={props.onClose}
                onSubmit={props.onSubmit}
                widthClass={classes.modalWidth}
                showControls
                primaryButtonTextKey={"pages.training.input-parameter.controls.ok"}
                secondaryButtonTextKey={
                    "pages.training.input-parameter.grid.cutomization.modal.cancel-btn"
                }
            >
                <div className={classes.modalTextPadding}>
                    <h3 className={classes.modalTitle}>
                        {t(
                            "pages.training.input-parameter.modal.confirm-cancel-execution.title"
                        )}
                    </h3>
                    <div className={classes.confirmationModalPadding}>
                        <label className={classes.fontsize}>
                            {t("pages.training.input-parameter.modal.confirm-cancel-execution.text")}
                        </label>
                    </div>
                </div>
            </Modal>
        </div>
    )
};
export default CancelExecutionModal;
