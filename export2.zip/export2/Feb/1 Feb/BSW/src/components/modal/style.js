import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  modalWidth: {
    minWidth: "25%",
    maxWidth: "25%",
    minHeight: "auto"
  },
  modalTextPadding: {
    paddingBottom: "16px"
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: 18,
    fontWeight: "normal",
    Height: "42px",
    margin: "-16px -16px 0px -16px",
    padding: "8px 16px",
    borderRadius: "4px 4px 0 0"
  },
  confirmationModalPadding: {
    paddingTop: "10px"
  },
  fontsize: {
    fontSize: "16px"
  }
}));