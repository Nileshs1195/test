import { IconButton, Snackbar } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useState } from "react";
import { useStyles } from "./style";

const CustomSnackBar = props => {
  const classes = useStyles();
  const { t } = useTranslation();
  const {
    snapbarMessage,
    timeout
  } = props;
  const [open, setOpen] = useState(true);

  useEffect(() => {
    handleClose();
    if (open) {
      setOpen(true);
      setTimeout(() => {
        handleClose();
      }, snapbarMessage.timeout || 10000)
    }
  }, [open])

  const handleClose = (event, reason) => {
    setOpen(false);
  };

  return (
    <Snackbar
      open={open}
      message={snapbarMessage.message}
      alertType={snapbarMessage.type || "error"}
      autoHideDuration={snapbarMessage.timeout || 10}
      anchorOrigin={{
        vertical: "top",
        horizontal: "center"
      }}
      action={
        <IconButton
          key="close"
          aria-label="close"
          color="inherit"
          className={classes.close}
          onClick={handleClose}
        >
          <CloseIcon />
        </IconButton>
      }
    ></Snackbar>
  );
};

export default CustomSnackBar;