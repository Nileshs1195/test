import { observer } from "mobx-react-lite";
import { useEffect, useRef, useState, useContext } from "react";
import Plotly from 'plotly.js-basic-dist';
import { useParams } from "react-router";
import { useStyles } from './style';
import { Grid, Tooltip } from "@material-ui/core";
import * as GraphSettings from './settings';
import { IconButton, Loader } from "../../../shared/components/ui";
import { HighlightOff } from '@material-ui/icons';
import TrainingManagmentStore from '../../../stores/trainingmanagementstore';
import { useTranslation } from "react-i18next";

const ProbabilityGraph = observer((props) => {
    const { images, selectedImages, setSelectedImages, className } = props;
    const classes = useStyles();
    const { t } =  useTranslation();
    const trainingManagementStore = useContext(TrainingManagmentStore);
    const [layout, setLayout] = useState({
        hovermode: "closest",
        hoverlabel: {
            bgcolor: "#fff",
            align: 'left'
        },
        showlegend: false,
        autosize: true,
        height: 400,
        margin: {
            l: 75,
            r: 85,
            b: 40,
            t: 20,
            pad: 6
        },
        xaxis: {
            range: [0,images.length],
            rangeslider: {},
            fixedrange: true,
            dtick: 5,
        },
        yaxis: {
            range: [0,1.1],
            fixedrange: true,
            dtick: 0.1 
        },
        dragmode: 'select',
        zoom: 'in',
        clickmode: 'event'
    });
    const graphArea = useRef(null);

    useEffect(() => {
        processImages();
    }, []);

    useEffect(()=>{
        GraphSettings.initialSelect(graphArea, trainingManagementStore.subclassificationSelectedGraphImages);
    },[selectedImages, graphArea]);

    const processImages = () => {

        var trace1 = {
            x: Array.from({ length: images.length }, (_, id) => id + 1 ),//images?.map(image => image?.probabilityValue ? parseFloat(image?.probabilityValue).toFixed(2) : 0.0),
            y: images?.map(image => image?.probabilityValue ? parseFloat(image?.probabilityValue).toFixed(4) : 0.0),
            mode: 'lines+markers',
            name: 'Probability',
            type: 'scatter',
            text: images,
            marker: {
                size: 8,
                color: Array.from({ length: images.length },() => '#000' ),
                defaultcolor: '#000' // Customized Property
            },
            hovertemplate: '%{y}',
            line: {
                color: '#000'
            },
        };
        var data = [trace1];

        Plotly.newPlot(graphArea.current, data, layout, { responsive: true });
        GraphSettings.exces(graphArea, setSelectedImages, className, trainingManagementStore);
    }
   
    const handleReset = (ev) => {
        Plotly.restyle(graphArea?.current, "selectedpoints",null);
        setSelectedImages([]);
        trainingManagementStore.setSubclassificationSelectedGraphImages([])
    }

    return (
        <>
            <div className={classes.leftButtonContainer}>
                <IconButton
                  onClick={handleReset}
                  data-attr="zoom"
                  data-val="reset"
                  id="highlight"
                  variant="outlined"
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.reset',
                    )}
                  >
                    <HighlightOff
                      fontSize="small"
                      className={classes.iconColor}
                    />
                  </Tooltip>
                </IconButton>
            </div>
            <Grid item xs={12} sm={12} lg={12}>
                <div ref={graphArea} id="lineGraph" className={classes.scatterGraph}>
                </div>
            </Grid>
            
        </>
    );
});
export default ProbabilityGraph;
