import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles((theme)=>({
    scatterGraph:{
        '& .modebar':{
          display:'none !important'
        }
    },
    loaderPosition: {
        position: 'absolute',
        zIndex: "9",
        marginTop: 130,
        marginBottom: 0,
        left: '50%'
    },
    leftButtonContainer: {
      display: 'grid',
      alignItems: 'center',
      position: 'absolute',
      left: theme.spacing(2),
      overflow:'hidden',
      zIndex: 1,
      textAlign: 'end',
      '& > *': {
        marginTop: theme.spacing(1.5),
      },
    },
    iconColor: {
      color: '#000'
    }
}))