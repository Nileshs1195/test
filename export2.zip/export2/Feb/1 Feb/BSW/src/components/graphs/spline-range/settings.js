import Plotly from 'plotly.js-basic-dist'


export const exces = (ref, setSelectedImages, className, trainingManagementStore) => {

    const element = ref.current;

    element.on('plotly_click', (data) => {
        let plots = trainingManagementStore?.subclassificationSelectedGraphImages;

        if (plots.some((item) => item?.seqNo === data?.points[0]?.text?.seqNo)) {
            plots?.splice(
                plots.findIndex((item) => item?.seqNo === data?.points[0]?.text?.seqNo),
                1,
            );
        } else {
            plots.push({
                seqNo: data?.points[0]?.text?.seqNo,
                imageMode: data?.points[0]?.text?.imageMode,
                className: className,
            });
        }
        setSelectedImages([...plots]);
        trainingManagementStore.setSubclassificationSelectedImages([...plots]);
    })

    element.on('plotly_selected', (data) => {
        if (data !== undefined) {
            let plots = trainingManagementStore?.subclassificationSelectedGraphImages;
            data.points.forEach((plot) => {
                plots.push({
                    seqNo: plot?.text?.seqNo,
                    imageMode: plot?.text?.imageMode,
                    className: className,
                });
            });
            setSelectedImages([...plots])
            trainingManagementStore?.setSubclassificationSelectedImages([...plots]);
        }
    });
}

export const initialSelect = (ref, selectedImages) => {

  const element = ref.current;

  let colors = Array.from(
    { length: element?.calcdata[0]?.length },
    (_, i) => element?.data[0]?.marker?.defaultcolor,
  );

  if (selectedImages.length > 0) {
    selectedImages.forEach((plot) => {
      let plotIndex = element?.data[0]?.text.findIndex(
        (img) => img.seqNo === plot.seqNo,
      );
      colors[plotIndex] = '#f00';
      let update = { marker: { color: colors, size: 8 } }
      Plotly.restyle(element, update);
    })
  } else {
    let update = { marker: { color: colors, size: 8 } }
    Plotly.restyle(element, update);
  }
}
