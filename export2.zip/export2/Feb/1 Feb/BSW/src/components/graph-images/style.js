import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  imageBox: {
    display:'flex',
    marginTop: "2rem"
  },
  imageItem: {
    marginTop: "8px"
  },
  imageLegendTraining: {
    display: "inline-block",
    width: "20px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    backgroundColor: "dodgerblue",
    verticalAlign: "middle"
  },
  imageLegendValidation: {
    display: "inline-block",
    width: "20px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    backgroundColor: "orange",
    verticalAlign: "middle"
  },
  imageLegendText: {
    display: "inline-block",
    verticalAlign: "middle",
    marginRight: "16px"
  },
}));