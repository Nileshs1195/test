import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TrainingManagementStore from '../../stores/trainingmanagementstore';
import ImageManagementStore from "../../stores/imagemanagementstore";
import { API_RESPONSE } from "../../appconstants";
import { TextField, FormControl, InputAdornment, FormControlLabel, Checkbox, InputLabel, Select, FormHelperText, MenuItem, RadioGroup, Radio } from "@material-ui/core";
import GridMaterial from "@material-ui/core/Grid";
import { useStyles } from "./style";
import { checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";

const AddDataset = (props) => {
    const { t } = useTranslation();
    const classes = useStyles();
    const form = useRef();
    const { open, setOpen, trainingId, callBack, setSnapbar } = props;    
    const [closed, setClosed] = useState(false);
    const trainingManagementStore = useContext(TrainingManagementStore);
    const imageManagementStore = useContext(ImageManagementStore);
    const { executedModels } = trainingManagementStore;
    const { setUploaderAction } = imageManagementStore;
    const [formError, setFormError] = useState({});
    const [submitted, setSubmitted] = useState(false);
    const [disableTextField, setDisableTextField] = useState(true);
    const [formContent, setFormContent] = useState({
        checkboxValue: false,
        radioValue: "Keep",
        modelName: "",
        trainingPercent: null
    });
    const [config, setConfig] = useState({
        fields: {
            checkboxValue: {
                initialValue: false,
            },
            radioValue: {
                initialValue: "Keep",
            },
            modelName: {
                initialValue: "",
                isRequired: { message: t("validation.message.required", { field: t("validation.field.pastExecutionModel") }) },
                isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.pastExecutionModel") }) }
            },
            trainingPercent: {
                initialValue: null,
                isRequired: { message: t("validation.message.required", { field: t("validation.field.trainPercent") }) },
                isRegexMatch: { regex: /^[0-9]+$/, message: t("validation.message.numeric", { field: t("validation.field.trainPercent") }) }
            }
        },
        onSubmit: state => {
            setSubmitted(state?.submitted);
            if (state?.errors) {
                setFormError({ ...state.errors });
            }
        },
        showErrors: 'blur',
        submitted: false
    });

    const { getFieldProps, getFormProps, errors, values } = useValidation(config);

    useEffect(() => { //Sets values after change
        setFormContent({ ...formContent, ...values });
    }, [values]);

    useEffect(() => {//This is required to validate and show error message
        errors && !submitted && !closed && setFormError(errors);
        setClosed(false);
        submitted && setSubmitted(false);
    }, [errors])

    useEffect(() => { //This is required to trigger the submit event on load
        form?.current?.dispatchEvent(
            new Event("submit", { bubbles: true, cancelable: true })
        );
    }, [form?.current])

    useEffect(() => {
        if (formContent.radioValue === "Keep") {
            values.trainingPercent = null;
            setDisableTextField(true);
            setFormContent({ ...formContent, trainingPercent: null });
        } else {
            setDisableTextField(false);
            setFormContent({ ...formContent, trainingPercent: null });
        }
    }, [formContent.radioValue]);

    useEffect(() => {
        setDisableTextField(true);
        if(!formContent.checkboxValue) {            
            setClosed(true);
            clearData();
        }
    }, [formContent.checkboxValue]);

    const saveNewDataset = () => {
        form.current.dispatchEvent(
            new Event("submit", { bubbles: true, cancelable: true })
        );
        let formArray = objToArray(formError);
        let notNull = checkNotNullFromArray(formArray);
        if (formArray?.length <= 0 || !notNull) {
            let id = "";
            executedModels.filter((obj) => obj.id !== trainingId).map((item) => {
                if (item.modelName === formContent.modelName) {
                    id = item.id
                }
            });
            let reqPayload = {
                src_train_id: id,
                dst_train_id: trainingId,
            }
            if (formContent.radioValue === "New") {
                reqPayload["trainPercentage"] = formContent?.trainingPercent > 0 ? parseInt(formContent.trainingPercent) : null
            }
            //Validation passed
            setSnapbar({ message: "" });
            trainingManagementStore
                .saveExecutedDatasetClone(reqPayload)
                .then((response) => {
                    if (response[1].data && response[0].status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                        handleModalClose();
                        setSnapbar({ message: t("pages.training.success.dataset.updated") });
                        if (callBack) {
                            callBack();
                        }
                    } else {
                        setSnapbar({ message: t("pages.training.errors.dataset.update-failed") });
                    }
                })
                .catch((error) => {
                    handleModalClose();
                    console.log("error", error);
                    setSnapbar({ message: t("pages.training.errors.dataset.update-failed") });
                });
        }
    }

    const createDataset = () => {
        formContent.checkboxValue ? saveNewDataset() : handleImageUpload()
    }

    const handleImageUpload = () => {
        setUploaderAction({
            isOpen: true,
            uploaderType: "add-dataset",
            className: "",
            id: trainingId
        });
        setOpen(false);
    }

    const handleModalClose = () => {
        setOpen(false); 
        clearData();                   
        setClosed(true);    
    }

    const clearData = () => {
        values.checkboxValue = false;
        values.modelName = "";
        values.radioValue = "Keep";
        values.trainingPercent = null;
        setFormContent({ checkboxValue: false, modelName: "", radioValue: "Keep", trainingPercent: null });
        setFormError({});
        for(let formField in errors) {
            errors[formField] = null
        }
    }
    
    const renderMenuItems = () => {
        const filteredArray = executedModels.filter((obj) => obj.id !== trainingId);
        return filteredArray.map((item, index) => (
            <MenuItem key={index} value={item.modelName}>{item.modelName}</MenuItem>
        ));
    };

    return (
        <Observer>
            {() => (
                <>
                    <CustomConfirmation
                        widthClass={classes.modalWidth}
                        open={open}
                        onClose={handleModalClose}
                        noImmediateClose={true}
                        onSubmit={createDataset}
                        primary={
                            formContent.checkboxValue ?
                                'pages.training.training-parameter.dataset-mode.controls.save'
                                :
                                'pages.training.training-parameter.dataset-mode.controls.upload'
                        }
                        secondary={'pages.training.training-list.controls.cancel-btn'}
                        title={t("pages.training.training-parameter.dataset-mode.modal.add-dataset")}
                        message={<>
                            <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            {...getFieldProps('checkboxValue')}
                                            value={formContent?.checkboxValue}
                                            checked={formContent?.checkboxValue}
                                            name="past-execution"
                                            id="past-execution-checkbox"
                                            color="primary"
                                        />
                                    }
                                    label={
                                        <label className={classes.fontsize}>
                                            {t("pages.training.training-parameter.dataset-mode.modal.past-execution-title")}
                                        </label>
                                    }
                                />
                                {
                                    formContent.checkboxValue && (
                                        <GridMaterial container item xs={12} justify="center" spacing={2}>
                                            <GridMaterial item xs={12}>
                                                <FormControl
                                                    className={classes.mT4}
                                                    margin="normal"
                                                    error={formError.modelName}
                                                >
                                                    <InputLabel
                                                        id="pastExecutionLabel"
                                                    >
                                                        {t("pages.training.training-parameter.dataset-mode.modal.past-execution-label")}
                                                    </InputLabel>
                                                    <Select
                                                        labelId="modelName"
                                                        id="modelName"
                                                        value={formContent?.modelName}
                                                        {...getFieldProps('modelName')}
                                                        name="modelName"
                                                        renderValue={value => value}
                                                    >
                                                        {renderMenuItems()}
                                                    </Select>
                                                    <FormHelperText error>
                                                        {formError.modelName}
                                                    </FormHelperText>
                                                </FormControl>
                                            </GridMaterial>
                                            <GridMaterial item xs={7}>
                                                <label className={classes.font}>
                                                    {t("pages.training.training-parameter.dataset-mode.modal.trainPercentage")}
                                                </label>
                                                <RadioGroup
                                                    aria-label="mode"
                                                    name="mode"
                                                    value={formContent?.radioValue}
                                                    {...getFieldProps('radioValue')}
                                                    row="true"
                                                >
                                                    <FormControlLabel
                                                        value="Keep"
                                                        control={<Radio color="primary" />}
                                                        label={t("pages.training.training-parameter.dataset-mode.modal.keep")}
                                                        labelPlacement="end"
                                                        disabled={formContent?.modelName ? false : true}
                                                    />
                                                    <FormControlLabel
                                                        value="New"
                                                        control={<Radio color="primary" />}
                                                        label={t("pages.training.training-parameter.dataset-mode.modal.new")}
                                                        labelPlacement="end"
                                                        disabled={formContent?.modelName ? false : true}
                                                    />
                                                </RadioGroup>
                                            </GridMaterial>
                                           
                                            <GridMaterial item xs={5}>
                                            {formContent?.radioValue === "New" &&
                                                <FormControl margin="none">
                                                    <TextField
                                                        disabled={disableTextField}
                                                        className={classes.textSize}
                                                        fullWidth
                                                        id="trainingPercent"
                                                        name="trainingPercent"
                                                        label={
                                                            <label style={{ fontSize: "14px" }}>
                                                                {t("pages.training.training-parameter.dataset-mode.modal.new-percentage")}
                                                            </label>
                                                        }
                                                        InputProps={{
                                                            endAdornment: (
                                                                <InputAdornment position="end">{t("pages.training.training-parameter.dataset-mode.modal.percentSign")}</InputAdornment>
                                                            )
                                                        }}
                                                        value={formContent?.trainingPercent}
                                                        {...getFieldProps('trainingPercent')}
                                                        error={formError.trainingPercent}
                                                        helperText={formError.trainingPercent}
                                                    />
                                                </FormControl>}
                                            </GridMaterial>
                                        </GridMaterial>
                                    )
                                }
                            </form>
                        </>} />
                </>
            )}
        </Observer >
    );
};
export default AddDataset;
