import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  formControl: {
    minWidth: "100%"
},
fontsize: {
    fontSize: "16px"
},
mT4: {
    "&.MuiFormControl-marginNormal": {
        marginTop: "8px",
        marginBottom: "8px"
    },
    minWidth: "100%"
},
font: {
    fontSize: "16px",
    fontWeight: 400
},
textSize: {
    "&.MuiFormLabel-root ": {
        fontSize: "14px"
    },
    minWidth: "100%"
},
modalWidth: {
  minWidth: "30%",
  maxWidth: "25%",
  minHeight: "auto"
}
}));
