import React from 'react'

export default class ImageUpload extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {

        }
    }
}