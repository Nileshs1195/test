import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from '@material-ui/core';
import { useHistory, useParams } from "react-router";
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TrainingManagementStore from '../../stores/trainingmanagementstore';
import { API_RESPONSE, APP_ROUTES } from "../../appconstants";
import { arrayMultiSplit, arrayUnique, checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";

const AddClass = (props) => {
  const history = useHistory();
  const { t } = useTranslation();
  const form = useRef();
  const params = useParams();
  const { open, setOpen, selectedClasses, setSelectedClasses, page, trainingId, setSnapbar, classData } = props;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [formError, setFormError] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [formContent, setFormContent] = useState({ className: "" });
  const [config, setConfig] = useState({
    fields: {
      className: {
        initialValue: "",
        isRequired: { message: t("validation.message.required", { field: "" }) },
        isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.className") }) },
        isBlacklisted: {
          message: t("validation.message.alreadyAvailable", { field: "" }),
          blacklist: classData?.length > 0 ? classData : []
        }
      }
    },
    onSubmit: state => {
      setSubmitted(state?.submitted);
      if (state?.errors) {
        setFormError({ ...state.errors });
      }
    },
    showErrors: 'blur',
    submitted: false
  });
  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  useEffect(() => { //Sets values after change
    setFormContent({ ...formContent, ...values });
  }, [values]);

  useEffect(() => {//This is required to validate and show error message
    errors && !submitted && setFormError(errors);
    submitted && setSubmitted(false);
  }, [errors])

  useEffect(() => { //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
  }, [form?.current])

  const handleNewClass = async (newClass) => {
    if (newClass?.seqNo) {
      let pageNo = page.pageNo > 0 ? page.pageNo - 1 : page.pageNo;
      let uniqueClasses = arrayUnique(selectedClasses?.split(","));
      let selectedClass = arrayMultiSplit(uniqueClasses, page?.pageSize);
      selectedClass.forEach((item, key) => {
        if (key === pageNo) {
          item.unshift(newClass?.seqNo);
        }
      });
      setSelectedClasses(selectedClass.join(","));
      history.replace(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST.replace(":id", trainingId).replace(":classes", selectedClass.join(",")));
    }
  };

  const handleDuplicateEntry = (data) => {
    let find = trainingManagementStore.TrainingDataset.filter(e => e.className.toLowerCase() === data.className.toLowerCase());
    return !find.length;
  }

  const AddNewClass = (e) => {
    form.current.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
    let isNotDuplicate = handleDuplicateEntry(formContent);
    let formArray = objToArray(formError);
    let notNull = checkNotNullFromArray(formArray);
    
    if ((formArray?.length <= 0 || !notNull) && trainingId) {
      if (isNotDuplicate) {
      //Validation passed
      trainingManagementStore
        .datasetsCreateClass(trainingId, { className: formContent?.className, batchSeqNo: params.batchNo || params.seqNo })
        .then((response) => {
          if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            trainingManagementStore.TrainingDataset.push(response?.data);
            handleNewClass(response?.data);
            setSnapbar({ message: t("pages.training.success.image-list.create-class") });
            onClose();
          } else {
            setSnapbar({ message: t("pages.training.errors.image-list.create-failed") });
          }
        })
        .catch((error) => {
          onClose();
          console.log("error", error);
          setSnapbar({ message: t("pages.training.errors.image-list.create-failed") });
        });
      } else {
        setSnapbar({ message: t("pages.training.errors.image-list.record-exists") });
      }
    }
    setTimeout(() => {
      setSnapbar({ message: "" });
    }, 3000);
  }

  const onClose = () => {
    setOpen(false);
    values.className = "";
    formContent.className = "";
    formError.className = null;
    errors.className = null;
}

  return (
    <Observer>
      {() => (
        <>
          <CustomConfirmation
            open={open}
            onClose={onClose}
            noImmediateClose={true}
            onSubmit={AddNewClass}
            primary={"pages.training.input-parameter.controls.ok"}
            secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
            title={t("pages.training.suggestion-result.modal.add-class")}
            message={<>
              <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                <TextField
                  fullWidth
                  id="className"
                  name="className"
                  label={t("pages.training.input-parameter.grid.class-name")}
                  aria-valuetext={formContent?.className}
                  value={formContent?.className} autoFocus
                  {...getFieldProps('className')}
                  error={formError.className}
                  helperText={formError.className}
                />
              </form>
            </>} />
        </>
      )}
    </Observer >
  );
};
export default AddClass;
