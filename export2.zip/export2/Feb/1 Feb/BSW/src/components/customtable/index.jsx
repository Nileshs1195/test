import Checkbox from "../../shared/components/ui/checkbox";
import React, { useState } from "react";
import { Tr, Td, BodyCellContent } from "../../shared/components/basictable";
import { useStyles } from "./style";
import clsx from "clsx";
import { Link, Popover, Box } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { objToArray } from "../../helpers/arrayutils";
import { Draggable } from "react-beautiful-dnd";
import DragIndicatorIcon from '@material-ui/icons/DragIndicator';

const CustomTable = (props) => {
  const { enableDrag, headerData, bodyData, onRowSelect, disableCheckbox, filterCells, onCellFilter, PopoverComponent, onCheckboxClick } = props;
  const history = useHistory();
  const [anchorEl, setAnchorEl] = useState(null);
  const [eventName, setEventName] = useState("");
  const [hoveredData, setHoveredData] = useState(null);
  const classes = useStyles();

  const handleMouseEnter = (event, hoveredData) => {
    setHoveredData(hoveredData);
    setEventName(event.target.attributes.getNamedItem("data-key").value);
    setAnchorEl(event.currentTarget);
  };

  const handleMouseLeave = () => {
    setHoveredData(null);
    setAnchorEl(null);

  };

  const onLinkClicked = (link) => {
    history.push(link);
  };
  
  const open = Boolean(anchorEl);

  const renderDraggable= (row,index,labelId) => {
    return (
      <Draggable draggableId={`tr-${row._id}`} key={row._id} index={index}>
        {(provided,snapshot)=>(
          <Tr key={row._id} innerRef={provided.innerRef} {...provided.draggableProps}>
            {renderCells(row,labelId,{...provided.dragHandleProps})}
          </Tr>
        )}
      </Draggable>
    )
  }

  const renderCells = (row,labelId,dragHandler) => {
    return headerData.map((headCell) => {
      let toRender = null;
      let link = null;

      switch (headCell.type) {
        case "checkbox":
          toRender = (
            <Checkbox
              color="primary"
              className={classes.checkbox}
              checked={row.selected}
              onChange={(event) => onRowSelect(event, row._id)}
              inputProps={{ "aria-labelledby": labelId }}
              disabled={disableCheckbox}
            />
          );
          break;
        case "empty":
          if(headCell.value === 'drag'){
            toRender = (
              <Box className={classes.dragCell}>
                <div {...dragHandler}>
                  <DragIndicatorIcon />
                </div>
              </Box>
            );
          }
        break;
        case "date":
          toRender = (
            <BodyCellContent
              type="date"
              headCell={headCell}
              filterCells={filterCells}
              columnId={headCell.key}
              content={row[headCell.key]}
            />
          );
          break;
        case "number":
          toRender = <BodyCellContent type="number" headCell={headCell} columnCells={headCell} content={row[headCell.key]} />;
          break;
        case "customStringWithLink":
          if (row?.subCassificationBatch?.seqNo && headCell?.url?.subclassification) {
            link = headCell.url ? headCell?.url?.subclassification.replace(":id", row._id).replace(":seqNo", row?.subCassificationBatch?.seqNo) : null;
          }
          if (row?.maskingBatch?.status == 7 && row?.maskingBatch?.seqNo && headCell?.url?.masking) {
            let classes = objToArray(row.classData);
            classes = classes.map(data => data.seqNo).join(",");
            link = headCell.url ? headCell?.url?.masking.replace(":id", row._id).replace(":seqNo", row?.maskingBatch?.seqNo).replace(":classes", classes) : null;
          }
          toRender = (
            <Link
              style={{ cursor: "pointer" }}
              onClick={() => {
                link && onLinkClicked(link);
              }}
            >
              <BodyCellContent headCell={headCell} columnCells={headCell} content={row[headCell.key]} />
            </Link>
          );
          break;
        case "customProgressBgWithLink":
          let percentage = row?.trainingBatch?.progress; // || row?.subCassificationBatch?.progress;
          let style = {
            background: `linear-gradient(90deg, ${headCell.topColor} ${percentage}%, ${headCell.bgColor} ${percentage}%)`,
            width: "100%",
            color: headCell.color || "#000"
          };
          if (row?.trainingBatch?.seqNo) {
            link = headCell.url ? headCell?.url?.training.replace(":id", row._id).replace(":seqNo", row?.trainingBatch?.seqNo) : null;
          }
          if (row?.subCassificationBatch?.seqNo && headCell?.url?.subclassification) {
            link = headCell.url ? headCell?.url?.subclassification.replace(":id", row._id).replace(":seqNo", row?.subCassificationBatch?.seqNo) : null;
          }
          toRender = (
            <Link
              style={{ cursor: "pointer" }}
              onClick={() => {
                link && onLinkClicked(link);
              }}
            >
              <BodyCellContent type="number" headCell={headCell} columnCells={headCell} style={style} content={percentage} />
            </Link>
          );
          break;
        case "stringWithCheckbox":
            let content = row[headCell.key];
            const columnCheck = row[headCell.key] === 'Yes'?true:false;
            let options = { messages: true }
            toRender = (
              <Box className={classes.dataWithCheckbox}>
                <Box>
                  <BodyCellContent headCell={headCell} columnId={headCell.key} content={content} />
                </Box>
                <Box>
                  <Checkbox
                    color="primary"
                    className={classes.dataCheckbox}
                    checked={columnCheck}
                    onChange={(event) => onCheckboxClick(
                        Object.assign(options,{checked:event.target.checked}), 
                        row)
                      }
                    inputProps={{ "aria-labelledby": labelId }}
                  />
                </Box>
              </Box>
            );
          break;
        case "dataWithCheckbox":
          const columnData = row[headCell.key]?.value ? row[headCell.key]?.value : headCell.defaultValue;
          const columnSelected = row[headCell.key]?.selected;
          toRender = (
            <Box className={classes.dataWithCheckbox}>
              {columnData && <Box>
                <BodyCellContent headCell={headCell} columnCells={headCell} content={columnData} />
              </Box>}
              <Box>
                <Checkbox
                  color="primary"
                  className={classes.dataCheckbox}
                  checked={columnSelected}
                  onChange={(event) => onCheckboxClick(event, headCell.key, row._id)}
                  inputProps={{ "aria-labelledby": labelId }}
                />
              </Box>
            </Box>
          );
          break;
        case "commaSeparatedData":
          let columnDataString1 = row[headCell.key]?.join(", ");
          toRender = <BodyCellContent headCell={headCell} columnId={headCell.key} content={columnDataString1} />;
          break;
        case "commaSeparatedDataWithBreak":
          let columnDataString2 = row[headCell.key]?.join(", ");
          toRender = <BodyCellContent headCell={headCell} columnId={headCell.key} content={columnDataString2} className={classes.cellBreakLines} />;
          break;
        default:
          toRender = headCell?.hover ? (
            <BodyCellContent
              aria-owns={open ? headCell.key : undefined}
              data-key={headCell.key}
              className={classes.cell}
              columnId={headCell.key}
              content={row[headCell.key]}
              onMouseEnter={(event) => handleMouseEnter(event, row)}
              onMouseLeave={handleMouseLeave}
            />
          ) : (
            <BodyCellContent columnId={headCell.key} content={row[headCell.key]} />
          );
          break;
      }
      return (
        <Td
          data-sticky={headCell.isSticky}
          className={clsx(headCell.isSticky && classes.stickyCell)}
          key={`${row._id}-${headCell.key}`}
        >
          {toRender}
        </Td>
      );
    })
  }
  
  return (
    <>
    {bodyData?.map((row, index) => {
        const labelId = `enhanced-table-checkbox-${index}`;
        return (
          <>
            {enableDrag? renderDraggable(row,index,labelId):(
              <Tr key={row._id}>
                {renderCells(row,labelId)}
              </Tr>
            )}
            <Popover
              id="mouse-over-popover"
              open={open}
              className={classes.popover}
              classes={{
                paper: classes.paper
              }}
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left"
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "left"
              }}
            >
              <PopoverComponent type={eventName} data={hoveredData} />
            </Popover>
          </>
        );
      })}
    </>
  );
};

export default CustomTable;
