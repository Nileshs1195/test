import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  stickyCell: {
    position: "sticky",
    left: "0px",
    backgroundColor: "white",
    zIndex: 0,
  },
  popover: {
    pointerEvents: "none",
    boxShadow: "none"
  },
  paper: {
    padding: theme.spacing(1)
  },
  cursorPointer: {
    cursor: "pointer"
  },
  dataWithCheckbox: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    alignContent: "space-around"
  },
  dragCell: {
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    alignContent: "space-around"
  },
  dataCheckbox: {
    padding: "0px"
  },
  cellBreakLines: {
    
  },
  table:{
    "& div[class^='makeStyles-fixedWrapper-']":{
      top: 'unset !important'
    },
  }
  //   cell: {
  //     border: '1px solid black !important',
  //     width: '100%',
  //     margin: 0,
  //     padding: 0,
  //   },
}));
