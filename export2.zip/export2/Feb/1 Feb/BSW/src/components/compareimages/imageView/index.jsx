import { Grid } from '@material-ui/core';
import React from 'react';
import Modal from '../../../shared/components/ui/modal';
import { SETTINGS } from "../../../appsettings";
import { useStyles } from './style';
import { useTranslation } from 'react-i18next';

function CompareImageView(props) {
  
  const { open, onClose, imageData } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  const imageThumbnailURL = SETTINGS.IMAGE_FULL_URL;

  return (
    <Modal
      open={open}
      onClose={onClose}
      widthClass={classes.modalwidth}
    // showControls
    // primaryButtonTextKey="pages.training.manageImages.modal.ok-btn"
    // secondaryButtonTextKey="pages.training.manageImages.modal.cancel-btn"
    >
      <div className={classes.modalTextPadding}>
        <h3 className={classes.modalTitle}>
          {t("pages.training.suggestion-result.modal.label.compare-images")}
        </h3>

        <div className={classes.content}>
            {imageData.map((item, index) => (
              <Grid item xs={12} sm={6} className={classes.box} key={index}>
                <img
                  src={imageThumbnailURL + item.fileName}
                  alt={item.uploadFileName}
                  className={classes.imageCenter}
                />
                <label className={classes.imageLabel} >
                  {t("pages.training.suggestion-result.modal.label.compare-images-data", 
                    {
                      name: item.uploadFileName,
                      class: item.className,
                      size: Math.floor(item.fileSize / 1024) 
                    } 
                  )}
                </label>
              </Grid>
            ))}
        </div>
      </div>
    </Modal>
  )
}
export default CompareImageView
