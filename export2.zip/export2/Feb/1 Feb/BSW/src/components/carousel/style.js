import { makeStyles } from '@material-ui/core/styles'

export const useStyles = makeStyles((theme) => ({
  main: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: "relative",
    minWidth: "100%",
    overflowX:'hidden',
    minHeight: "100%",
    
  },
  slides: {
    display: 'grid',
    padding:'5%',
    overflow:'hidden',

    minHeight:'100%',
    alignItems:'center',
    justifyItems:'center',
    [theme.breakpoints.up('xl')]: {
      width:'100%'
    },
    [theme.breakpoints.between('lg', 'xl')]: {     
      width:'1200.9px'
    },
    [theme.breakpoints.between('sm', 'lg')]: {
      width:'1200px'
    },
  },
  slide: {
    padding: 10,
    gridArea: '1/-1',
    gridGap:10,
    border: 'none',
    justifyItems: 'center',
    borderRadius: 5,
    backgroundColor: '#fff',
    backgroundSize: 'cover',
    backgroundPosition: 'center center',
    transform: 'translateX(calc( -100% * var(--offset)))',
  },
  slideActive: {
    zIndex: 10,
    boxShadow:'0 24px 38px 3px rgba(0,0,0,0.14), 0 9px 46px 8px rgba(0,0,0,0.12), 0 11px 15px -7px rgba(0,0,0,0.2)',
    transform: 'scale(1.08)',
    [theme.breakpoints.up('xl')]: {
      minHeight: '100%',
      width: '100%',
    },
    [theme.breakpoints.between('lg', 'xl')]: {
      height: 530,
      width: 400,
    },
    [theme.breakpoints.between('sm', 'lg')]: {
      minHeight: 400,
      width: 400,
    },
  },
  slideInActive: {
    [theme.breakpoints.up('xl')]: {
      minHeight: '100%',
      width: '100%',
    },
    [theme.breakpoints.between('lg', 'xl')]: {
      height:502,
      width: 400,
    },
    [theme.breakpoints.between('sm', 'lg')]: {
      minHeight: 400,
      width: 400,
    },
  },
  rightArrow: {
    border: 'none',
    position: 'absolute',
    width: '2rem',
    top: '45%',
    right: '-5%',
    backgroundColor: '#fff',
    borderRadius: 5,
    boxShadow:'0 24px 38px 3px rgba(0,0,0,0.14), 0 9px 46px 8px rgba(0,0,0,0.12), 0 11px 15px -7px rgba(0,0,0,0.2)',
    transition: 'opacity 0.3s',
    zIndex: 12,
    cursor: 'pointer',
  },
  leftArrow: {
    border: 'none',
    position: 'absolute',
    width: '2rem',
    top: '45%',
    left: '-5%',
    backgroundColor: '#fff',
    borderRadius: 5,
    boxShadow:
      '0 24px 38px 3px rgba(0,0,0,0.14), 0 9px 46px 8px rgba(0,0,0,0.12), 0 11px 15px -7px rgba(0,0,0,0.2)',
    transition: 'opacity 0.3s',
    zIndex: 12,
    cursor: 'pointer',
  },
  textAlign: {
    textAlign: 'center',
    margin: 0
  },
  closeBtn: {
    float: "right",
    position: "absolute",
    right: -13,
    top: -13,
    boxShadow: theme.spacing(0, 0, 0.4),
    padding: theme.spacing(0.6),
    zIndex: 2,
    backgroundColor: '#fff',
    "&:hover": {
      backgroundColor: '#fff',
    },
  },
  imageBox: {
    width: '100%',
    height: '400px',
    border:'1px solid rgb(203, 203, 203,1)',
    display: 'flex',
    alignContent: 'stretch',
    justifyContent: 'space-evenly',
    alignItems:' center'
  },
  image: {
    position: 'relative',
    // border: '1px solid rgb(203, 203, 203,1)',
    borderRadius: 3,
    maxWidth: '100%',
    maxHeight: '100%',
    objectFit: 'contain',
    overflow: 'hidden',
  },
  countMasks:{
		position:'absolute',
		bottom:0,
		right:0,
		margin:1,
		padding:'2px 3px',
		background:'#ffffff',
		border:'1px solid #707070',
		zIndex:3,
	},
}))
