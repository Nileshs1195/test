import React, { useState, useEffect } from 'react';
import { useStyles } from './style';
import { Modal } from '@material-ui/core';
import Slide from './slide';
import useInfinityScroll from '../../helpers/hooks/useInfinityScroll';

const Carousel = (props) => {
  const { open, onClose,  maskingFuncs, sliderData, active, setActiveImage, totalImageCount, page } = props;
  const classes = useStyles();
  const [currentIndex, setCurrentIndex] = useState(() => active);
  const [currentData, setCurrentData] = useState([]);
  const [currentPage, setCurrentPage] = useState(page);

  const  { getImagesFromList } = useInfinityScroll({ scrolling: false });

  useEffect(()=>{
    setCurrentPage(page);
    setCurrentData([...getImagesFromList({ page: page, imagesList: sliderData })])
  },[sliderData,page,open])

  useEffect(() => {
    setCurrentIndex(active);
    if(active === page?.imageCount - 1) {
      updateImages(
        Object.assign(
          JSON.parse(JSON.stringify(page)), 
          {
            startPage: page?.startPage + 1,
            endPage: page?.endPage + 1,
          }
        ),
        active - page?.pageSize,
      );
    } else if (active === 0) {
      previous();
    }
  }, [active]);

  useEffect(() => {
    window.addEventListener('keyup', onKeyup);
  }, []);

  const onKeyup = (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      previous();
    } else if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      next();
    }
  }

  const updateImages = (pageObj, activeIndex) => {
    setCurrentPage(pageObj);
    setActiveImage(activeIndex);
    setCurrentData([...getImagesFromList({ page: pageObj, imagesList: sliderData })])
  }

  const next = () => {
    let nextIndex = active + 1 <= sliderData?.length ? active + 1 : active;
    if(nextIndex > (page?.imageCount - 3) && Math.ceil(totalImageCount / page?.pageSize) >  currentPage?.endPage) {
      let pageObj = {
        pageSize: currentPage?.pageSize,
        imageCount: currentPage?.imageCount,
        type: 1,
        startPage: currentPage?.startPage + 1,
        endPage: currentPage?.endPage + 1,
      }
      console.log(nextIndex - page?.pageSize, nextIndex, page?.imageCount - 3)
      updateImages(pageObj, nextIndex - page?.pageSize);  
    } else {
      setActiveImage(nextIndex);
    }
  }

  const previous = () => {
    let prevIndex = active - 1 >= 0 ? active - 1 : 0;
    if(prevIndex < 3 && currentPage?.startPage > 1) {
      let pageObj = {
        pageSize: currentPage?.pageSize,
        imageCount: currentPage?.imageCount,
        type: 0,
        startPage: currentPage?.startPage - 1,
        endPage: currentPage?.endPage - 1,
      }
      updateImages(pageObj, prevIndex + page?.pageSize)
    } else {
      setActiveImage(prevIndex);
    }
  }

  return (
    <Modal open={open} onClose={onClose}>
      <div className={classes.main}>
        <div className={classes.slides}>
          {currentData?.length > 0 && currentData?.map((slide, index) => {
            return (
              <Slide
                key={index}
                index={index + 1}
                totalImages={currentData.length}
                slideData={slide}
                onClose={onClose}
                activeImage={active}
                seqNos = {currentData?.map(seqNo=>seqNo?.seqNo).join(',')}
                page={currentPage}
                totalImageCount={totalImageCount}
                offset={currentIndex - index}
                previous={previous}
                maskingFunc = {maskingFuncs}
                next={next}
              />
            )
          })}
        </div>
      </div>
    </Modal>
  )
}
export default Carousel
