export const login = (username, password) => {
  if (username === "dev" && password === "123") {
    const user = {
      id: 1,
      username: "DV",
      firstName: username,
      lastName: "",
    };
    return user;
  }
};
