import {
  Avatar,
  Button,
  Checkbox,
  Container,
  FormControlLabel,
  Grid,
  Paper,
  TextField,
  Typography,
} from "@material-ui/core";
import { LockOutlined } from "@material-ui/icons";
import PropTypes from "prop-types";
import { useContext, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link, useHistory } from "react-router-dom";
import UserStore from "../../stores/userstore";
import { useStyles } from "./style";

const SignIn = ({ successUrl }) => {
  const classes = useStyles();
  const history = useHistory();
  const { t } = useTranslation();
  const userStore = useContext(UserStore);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSignIn = () => {
    userStore.login(username, password);
    if (userStore.currentUser) {
      history.push(successUrl);
    }
  };

  const onInputChange = (callback) => (e) => {
    callback(e.target.value);
  };

  return (
    <Container maxWidth="sm">
      <Paper className={classes.paper} elevation={3}>
        <Avatar className={classes.avatar}>
          <LockOutlined />
        </Avatar>
        <Typography component="h1" variant="h5">
          {t("pages.signin.sign-in")}
        </Typography>
        <form className={classes.form}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="email"
            label={t("pages.signin.email")}
            name="email"
            autoComplete="email"
            onChange={onInputChange(setUsername)}
            autoFocus
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label={t("pages.signin.password")}
            type="password"
            id="password"
            autoComplete="current-password"
            onChange={onInputChange(setPassword)}
          />
          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label={t("pages.signin.remember")}
          />
          <Button
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            onClick={handleSignIn}
          >
            {t("pages.signin.sign-in")}
          </Button>

          <Grid container>
            <Grid item xs>
              <Link to="/signup" variant="body2">
                {t("pages.signin.forgot-pass")}
              </Link>
            </Grid>
            <Grid item>
              <Link to="/signup" variant="body2">
                {t("pages.signin.no-account")}
              </Link>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Container>
  );
};

export default SignIn;

SignIn.propTypes = {
  successUrl: PropTypes.string.isRequired,
};
