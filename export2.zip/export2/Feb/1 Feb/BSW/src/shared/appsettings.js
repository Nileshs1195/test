export const SETTINGS = {
  I18N: {
    LANGUAGES: {
      EN: "en",
      JP: "jp",
    },
    DEFAULT_LANG: "en",
  },
  DATE_TIME_FORMAT: "yyyy/MM/dd HH:mm",
  API_CONFIG: {
    TIMEOUT: 10000,
  },
  INSPECTION_GRID: {
    DATE_OFFSET: 30,
  },
  GRID: {
    PAGINATION: {
      DIRECTIONS: {
        PREV: "prev",
        NEXT: "next",
      },
      PAGE_SIZES: [
        { value: 25, label: 25 },
        { value: 50, label: 50 },
        { value: 75, label: 75 },
        { value: 100, label: 100 },
      ],
    },
    CELL_FILTERS: {
      CELL: "cell",
      EXCLUDE: "exclude",
      INCLUDE: "include",
    },
    MIN_COL_WIDTH: 100,
    COLUMN_TYPE: {
      NUMBER: "number",
      DATE: "date",
      BOOLEAN: "boolean",
      JSX: "jsx",
    },
  },
  LOCAL_STORAGE_KEYS: {
    I18N: "i18nextLng",
  },
};
