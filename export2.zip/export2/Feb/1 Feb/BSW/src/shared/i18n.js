import i18n from "i18next";
import Backend from "i18next-http-backend";
import { initReactI18next } from "react-i18next";
import { SETTINGS } from "./appsettings";
import { getItem, setItem } from "./utils/storagehelper";

export const getCurrentLanguage = () =>
  getItem(SETTINGS.LOCAL_STORAGE_KEYS.I18N);

export const changeLanguage = (language) => {
  i18n.changeLanguage(language);
  setItem(SETTINGS.LOCAL_STORAGE_KEYS.I18N, language);
};

const fallbackLng = [SETTINGS.I18N.DEFAULT_LANG];
const availableLanguages = Object.values(SETTINGS.I18N.LANGUAGES);

const options = {
  order: ["localStorage"],

  // keys to lookup language from
  lookupLocalStorage: SETTINGS.LOCAL_STORAGE_KEYS.I18N,

  // caches user language on
  caches: ["localStorage"],

  // only detect languages that are in the whitelist
  checkWhitelist: true,
};

i18n
  .use(Backend)
  .use(initReactI18next)
  .init({
    detection: options,
    debug: process.env.NODE_ENV === "development",
    lng: getCurrentLanguage() ?? SETTINGS.I18N.DEFAULT_LANG,
    fallbackLng,
    whitelist: availableLanguages,
    interpolation: {
      escapeValue: false,
    },
    react: {
      wait: true,
      useSuspense: false,
    },
  });

export default i18n;
