export const convertObjArrayToObj = (array, key) => {
  const object = {};
  for (const field of array) object[field[key]] = field;
  return object;
};
