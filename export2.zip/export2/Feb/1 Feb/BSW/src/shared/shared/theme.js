import { createMuiTheme } from "@material-ui/core";
import { common } from "@material-ui/core/colors";
import { colors } from "./appcolors";
import RobotoBold from "./assets/font/Roboto-Bold.ttf";
import RobotoLight from "./assets/font/Roboto-Light.ttf";
import RobotoMedium from "./assets/font/Roboto-Medium.ttf";
import RobotoRegular from "./assets/font/Roboto-Regular.ttf";

const fontWeight = {
  light: 300,
  regular: 400,
  medium: 500,
  bold: 700,
};

const robotoLight = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoLight}) format("truetype")`,
  fontWeight: fontWeight.light,
  fontStyle: "normal",
};

const robotoRegular = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoRegular}) format("truetype")`,
  fontWeight: fontWeight.regular,
  fontStyle: "normal",
};

const robotoMedium = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoMedium}) format("truetype")`,
  fontWeight: fontWeight.medium,
  fontStyle: "normal",
};

const robotoBold = {
  fontFamily: "Roboto",
  src: `local("Roboto"), url(${RobotoBold}) format("truetype")`,
  fontWeight: fontWeight.bold,
  fontStyle: "normal",
};

export const theme = createMuiTheme({
  palette: {
    primary: {
      main: colors.primary.main,
      dark: colors.primary.dark,
    },
  },
  typography: {
    fontSize: 14,
    fontWeightLight: fontWeight.light,
    fontWeightRegular: fontWeight.regular,
    fontWeightMedium: fontWeight.medium,
    fontWeightBold: fontWeight.bold,
    body2: {
      color: common.black,
    },
  },
  overrides: {
    MuiCssBaseline: {
      "@global": {
        "@font-face": [robotoLight, robotoRegular, robotoMedium, robotoBold],
        "*::-webkit-scrollbar": {
          width: "0.5em",
          height: "0.5em",
          backgroundColor: colors.scrollBar.bg,
        },
        "*::-webkit-scrollbar-thumb": {
          borderRadius: 10,
          background: colors.scrollBar.thumb.bg,
        },
      },
    },
    MuiButton: {
      root: {
        height: 36,
        fontSize: 14,
        fontWeight: fontWeight.medium,
        lineHeight: "110%",
      },
      contained: {
        "&:active": {
          background: colors.button.active,
        },
        "&$disabled": {
          background: colors.button.disabled.bg,
          color: colors.button.disabled.color,
        },
      },
      outlined: {
        padding: "6px 16px",
        color: colors.primary.main,
        borderColor: colors.primary.main,
        background: common.white,
        "&:hover": {
          background: colors.button.outlined.hover,
        },
        "&:active": {
          background: colors.button.outlined.active,
        },
      },
      endIcon: {
        marginLeft: 2,
      },
    },
    MuiInput: {
      root: {
        fontWeight: fontWeight.regular,
      },
    },
    MuiTableCell: {
      root: {
        fontSize: 14,
        padding: "0 16px",
        height: 38,
      },
      head: {
        fontWeight: fontWeight.light,
      },
    },
    MuiSelect: {
      root: {
        fontSize: 16,
        color: colors.select.textColor,
        display: "flex",
        alignItems: "center",
        padding: "8px 12px",
        "& > *": {
          marginRight: 4,
        },
        "&.Mui-disabled": {
          opacity: 0.5,
        },
      },
      icon: {
        color: colors.select.icon,
      },
      outlined: {
        fontSize: 14,
      },
    },
    MuiMenuItem: {
      root: {
        fontSize: 12,
        display: "flex",
        alignItems: "center",
        color: "#000000bf",
      },
    },
    MuiChip: {
      root: {
        fontSize: 12,
        minWidth: 80,
        justifyContent: "space-around",
      },
      outlined: {
        border: `1px solid ${colors.chip.outlined.border}`,
        color: colors.chip.outlined.color,
        "&:hover": {
          background: colors.chip.outlined.hover,
        },
        "&:active": {
          background: colors.chip.outlined.active,
        },
      },
    },
    MuiFormControlLabel: {
      label: {
        fontSize: 14,
      },
    },
    MuiTab: {
      root: {
        fontSize: 18,
        background: colors.tab.bg,
        fontWeight: fontWeight.medium,
        "&$selected": {
          color: colors.primary.main,
        },
        "&$labelIcon": {
          minHeight: "20px",
        },
      },
    },
    MuiTabs: {
      root: {
        color: colors.tab.color,
        background: colors.tab.bg,
      },
      indicator: {
        background: colors.primary.main,
        height: 3,
      },
    },
    MuiPickerDTTabs: {
      tabs: {
        "& .MuiTab-root": {
          backgroundColor: colors.primary.main,
        },
        "& .Mui-selected": {
          backgroundColor: colors.primary.main,
          color: common.white,
        },
      },
    },
    MuiInputLabel: {
      root: {
        color: colors.inputLabel.color,
        "&$error": {
          color: colors.input.validationError,
        },
      },
    },
    MuiInputBase: {
      root: {
        color: common.black,
        fontWeight: fontWeight.light,
      },
    },
    MuiRadio: {
      root: {
        color: colors.radio.color,
      },
    },
    MuiFormHelperText: {
      root: {
        color: colors.inputLabel.color,
        "&$error": {
          color: colors.input.validationError,
        },
      },
    },
    MuiTextField: {
      root: {
        "& .MuiInput-underline.Mui-error:after": {
          borderBottom: `2px solid ${colors.input.validationError}`,
        },
      },
    },
  },
});
