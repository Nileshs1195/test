import { createContext } from "react";
import * as UserService from "../services/userservice";
import { makeObservable, observable, action, computed } from "mobx";

class UserStore {
  user = {
    id: 1,
    username: "DV",
    firstName: 'dev',
    lastName: "",
  };

  constructor() {
    makeObservable(this, {
      user: observable,
      login: action,
      logout: action,
      currentUser: computed
    });
  }

  get currentUser() {
    return this.user;
  }

  login = (userName, passWord) => {
    const user = UserService.login(userName, passWord);
    if (user) {
      this.user = user;
      this.hasLoginError = false;
    } else {
      this.user = null;
      this.hasLoginError = true;
    }
  };

  logout = () => {
    this.user = null;
  };
}

export default createContext(new UserStore());
