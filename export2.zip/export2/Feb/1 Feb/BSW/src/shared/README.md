Contains re-usable componnets pages and services etc across applicaions
