import { useRef } from "react";
import * as PIXI from "pixi.js";
import { useEffect } from "react";
import { useStyles } from "./style";
import { removeDuplicatesFrom2DArray, degreeToRadian } from "./waferareahelper";
import { COLORS, SHAPES, SELECTION_TYPE } from "../../appconstants";

const WaferAreaSelector = (props) => {
  const classes = useStyles();
  const {
    areaOptions,
    radiusDivision,
    angleDivision,
    circumference,
    invert,
    resetArea,
    onSelectionChanged,
    selectionDetails,
  } = props;
  const stage = useRef();
  const divRef = useRef();
  const renderer = useRef();
  const invertFlag = useRef(false);
  const waferDiameter = areaOptions.diameter;
  const canvasSize = areaOptions.canvasSize;
  const scale = canvasSize / waferDiameter;
  const { allWaferAreas } = selectionDetails;

  const generateRenderer = () => {
    renderer.current = PIXI.autoDetectRenderer(canvasSize, canvasSize, {
      transparent: true,
      antialias: true,
    });
    divRef.current.appendChild(renderer.current.view);
  };

  const destroyRenderer = () => {
    renderer.current.destroy(true);
    renderer.current = null;
  };

  useEffect(() => {
    generateRenderer();
    return () => destroyRenderer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleGraphicsClick = (area) => {
    area.click = () => {
      if (area.selected) {
        area.tint = COLORS.UNSELECTED;
        area.selected = false;
      } else {
        area.tint = COLORS.SELECTED;
        area.selected = true;
      }
      renderer.current.render(stage.current);
      updateAreaSelection();
    };
  };

  const updateAreaSelection = () => {
    let selectedCount = 0;
    let areasSelected = [];
    for (let graphics of stage.current.children) {
      if (graphics.selected) {
        selectedCount++;
        areasSelected.push(graphics.properties);
      }
    }

    let type = SELECTION_TYPE.NONE;
    if (selectedCount === stage.current.children.length) {
      type = SELECTION_TYPE.FULL;
    } else if (selectedCount !== 0) {
      type = SELECTION_TYPE.PARTIAL;
    }

    if (type === SELECTION_TYPE.PARTIAL) {
      areasSelected = simplifySelection(
        JSON.parse(JSON.stringify(areasSelected))
      );
    }
    onSelectionChanged({
      selectionType: type,
      areas: areasSelected,
      allWaferAreas: stage.current.children,
    });
  };

  const simplifySelection = (areas) => {
    let simplifiedAreas = [];

    if ((radiusDivision !== 0 || circumference !== 0) && angleDivision === 0) {
      // only radius or circumference division selected.
      simplifiedAreas = simplifySelectionsByRadius(areas);
    } else if (
      angleDivision !== 0 &&
      radiusDivision === 0 &&
      circumference === 0
    ) {
      // only angle division selected.
      simplifiedAreas = simplifySelectionsByAngle(areas);
    } else {
      // angle and radius/circumference division selected.
      // since we can have circumference division, radius won't be always in same interval.

      /**
       * Algorithm steps
       *
       * 1. Group all selections by radius
       * 2. Check if selection areas in a radius group can form a circle.
       *    2.1 - If we can form a cicle, then add a circle shape to simplified list
       *    2.2 - remove all selection areas that form a cicle in previous step
       * 3. Try grouping all cicles formed in step 2.
       * 4. Try grouping selection areas by continus angle which cant be formed
       *    as circle in step 2, to a max of 180 degree
       */

      let ranges = areas.map((area) => {
        return { from: area.radius.from, to: area.radius.to };
      });
      // remove duplicate ranges and sort in ASC order of range.
      ranges = removeDuplicatesFrom2DArray(ranges);

      ranges.forEach((radiusRange) => {
        // check if we have all parts selected in a radius range which form a circle.
        const parts = areas.filter(
          (item) =>
            item.radius.from === radiusRange.from &&
            item.radius.to === radiusRange.to
        );
        if (parts.length === 360 / angleDivision) {
          // this will form a circle. remove parts from areas.
          areas = areas.filter(
            (item) =>
              item.radius.from !== radiusRange.from &&
              item.radius.to !== radiusRange.to
          );
          // add a circle shape with this radius range
          simplifiedAreas.push({
            shape: SHAPES.CIRCLE,
            radius: { from: radiusRange.from, to: radiusRange.to },
          });
        }
      });

      // try grouping circles formed in step 1
      if (simplifiedAreas.length) {
        simplifiedAreas = simplifySelectionsByRadius(simplifiedAreas);
      }

      // try simplifying rest of areas which can't form a circle.
      ranges.forEach((radiusRange) => {
        const parts = areas.filter(
          (item) =>
            item.radius.from === radiusRange.from &&
            item.radius.to === radiusRange.to
        );

        if (parts.length) {
          const simplifiedByAngle = simplifySelectionsByAngle(parts);
          simplifiedAreas.push(...simplifiedByAngle);
        }
      });
    }

    return simplifiedAreas;
  };

  const simplifySelectionsByRadius = (areas) => {
    // sort based on asc order of "from radius"
    const sortedAreas = areas.sort((a, b) => a.radius.from - b.radius.from);
    const simplifiedAreas = [];
    let prev = sortedAreas[0];
    simplifiedAreas.push(prev);

    for (const area of sortedAreas) {
      const prevUpperBound = prev.radius.to;
      const newLowerBound = area.radius.from;
      const newUpperBound = area.radius.to;

      if (prevUpperBound >= newLowerBound) {
        prev.radius.to = Math.max(prevUpperBound, newUpperBound);
      } else {
        prev = area;
        simplifiedAreas.push(prev);
      }
    }

    return simplifiedAreas;
  };

  const simplifySelectionsByAngle = (areas) => {
    // sort based on asc order of "from angle"
    const sortedAreas = areas.sort((a, b) => a.angle.from - b.angle.from);
    const simplifiedAreas = [];
    let prev = sortedAreas[0];
    simplifiedAreas.push(prev);

    for (const area of sortedAreas) {
      const prevLowerBound = prev.angle.from;
      const prevUpperBound = prev.angle.to;
      const newLowerBound = area.angle.from;
      const newUpperBound = area.angle.to;

      if (
        prevUpperBound >= newLowerBound &&
        Math.max(prevUpperBound, newUpperBound) - prevLowerBound <= 180
      ) {
        prev.angle.to = Math.max(prevUpperBound, newUpperBound);
      } else {
        prev = area;
        simplifiedAreas.push(prev);
      }
    }

    return simplifiedAreas;
  };

  const drawCircleGraphics = (center, radius) => {
    const graphics = new PIXI.Graphics();
    graphics.lineStyle(1, COLORS.BORDER, COLORS.OPACITY);
    graphics.interactive = true;
    graphics.beginFill(COLORS.UNSELECTED, 1);
    graphics.drawCircle(center, center, radius);
    graphics.endFill();
    graphics.tint = COLORS.SELECTED;
    graphics.selected = true;
    graphics.buttonMode = true;
    handleGraphicsClick(graphics);
    return graphics;
  };

  const drawSectorGraphics = (center, radius, start, end) => {
    const graphics = new PIXI.Graphics();
    graphics.lineStyle(1, COLORS.BORDER, COLORS.OPACITY);
    graphics.interactive = true;
    graphics.beginFill(COLORS.UNSELECTED, 1);
    graphics.arc(center, center, radius, start, end);
    graphics.lineTo(center, center);
    graphics.tint = COLORS.SELECTED;
    graphics.selected = true;
    graphics.buttonMode = true;
    handleGraphicsClick(graphics);
    return graphics;
  };

  const draw = () => {
    const canvasCenter = canvasSize / 2;
    const waferRadius = waferDiameter / 2;
    stage.current = new PIXI.Container(COLORS.UNSELECTED, true);
    stage.current.interactive = true;
    stage.current.pivot.set(canvasCenter);
    stage.current.position.set(canvasCenter);
    stage.current.scale.set(scale, -scale);

    if (radiusDivision === 0 && angleDivision === 0 && circumference === 0) {
      const graphics = drawCircleGraphics(canvasCenter, waferRadius);
      graphics.properties = {
        shape: SHAPES.CIRCLE,
        radius: { from: 0, to: waferRadius },
      };
      stage.current.addChild(graphics);
    } else if (
      radiusDivision !== 0 &&
      angleDivision === 0 &&
      circumference === 0
    ) {
      for (let radius = waferRadius; radius > 0; radius -= radiusDivision) {
        let from = radius - radiusDivision > 0 ? radius - radiusDivision : 0;
        let to = radius;
        const graphics = drawCircleGraphics(canvasCenter, radius);
        graphics.properties = {
          shape: SHAPES.CIRCLE,
          radius: { from: from, to: to },
        };
        stage.current.addChild(graphics);
      }
    } else if (
      radiusDivision === 0 &&
      angleDivision !== 0 &&
      circumference === 0
    ) {
      for (let angle = 0; angle < 360; angle += angleDivision) {
        let startRadian = degreeToRadian(angle);
        let endRadian = degreeToRadian(angle + angleDivision);
        let startAngle = angle;
        let endAngle = angle + angleDivision;

        const graphics = drawSectorGraphics(
          canvasCenter,
          waferRadius,
          startRadian,
          endRadian
        );
        graphics.properties = {
          shape: SHAPES.CIRCLE_SECTOR,
          radius: { from: 0, to: waferRadius },
          angle: { from: startAngle, to: endAngle },
        };
        stage.current.addChild(graphics);
      }
    } else if (
      radiusDivision === 0 &&
      angleDivision === 0 &&
      circumference !== 0
    ) {
      for (
        let radius = waferRadius;
        radius >= waferRadius - circumference;
        radius -= circumference
      ) {
        let from = radius - circumference;
        if (radius === waferRadius - circumference) from = 0;
        let to = radius;
        const graphics = drawCircleGraphics(canvasCenter, radius);
        graphics.properties = {
          shape: SHAPES.CIRCLE,
          radius: { from: from, to: to },
        };
        stage.current.addChild(graphics);
      }
    } else if (
      radiusDivision !== 0 &&
      angleDivision !== 0 &&
      circumference === 0
    ) {
      for (let radius = waferRadius; radius > 0; radius -= radiusDivision) {
        for (let angle = 0; angle < 360; angle += angleDivision) {
          let startRadian = degreeToRadian(angle);
          let endRadian = degreeToRadian(angle + angleDivision);
          let from = radius - radiusDivision > 0 ? radius - radiusDivision : 0;
          let to = radius;
          let startAngle = angle;
          let endAngle = angle + angleDivision;

          const graphics = drawSectorGraphics(
            canvasCenter,
            radius,
            startRadian,
            endRadian
          );
          graphics.properties = {
            shape: SHAPES.PARTIAL_CIRCLE_SECTOR,
            radius: { from: from, to: to },
            angle: { from: startAngle, to: endAngle },
          };
          stage.current.addChild(graphics);
        }
      }
    } else if (
      radiusDivision === 0 &&
      angleDivision !== 0 &&
      circumference !== 0
    ) {
      for (
        let radius = waferRadius;
        radius >= waferRadius - circumference;
        radius -= circumference
      ) {
        for (let angle = 0; angle < 360; angle += angleDivision) {
          let startRadian = degreeToRadian(angle);
          let endRadian = degreeToRadian(angle + angleDivision);
          let from = radius - circumference;
          if (radius === waferRadius - circumference) from = 0;
          let to = radius;
          let startAngle = angle;
          let endAngle = angle + angleDivision;

          const graphics = drawSectorGraphics(
            canvasCenter,
            radius,
            startRadian,
            endRadian
          );
          graphics.properties = {
            shape: SHAPES.PARTIAL_CIRCLE_SECTOR,
            radius: { from: from, to: to },
            angle: { from: startAngle, to: endAngle },
          };
          stage.current.addChild(graphics);
        }
      }
    } else if (
      radiusDivision !== 0 &&
      angleDivision === 0 &&
      circumference !== 0
    ) {
      let radiusWithBuffer = 0;
      for (let radius = waferRadius; radius > 0; radius -= radiusDivision) {
        let calculatedRadius = findNextRadius(
          radius,
          waferRadius,
          radiusWithBuffer
        );
        radiusWithBuffer = calculatedRadius.radiusWithBuffer;
        let nextRadius = calculatedRadius.nextRadius;
        let from =
          nextRadius - radiusDivision > 0 ? nextRadius - radiusDivision : 0;
        let to = radius;

        const graphics = drawCircleGraphics(canvasCenter, radius);
        graphics.properties = {
          shape: SHAPES.CIRCLE,
          radius: { from: from, to: to },
        };
        stage.current.addChild(graphics);

        radius = nextRadius;
      }
    } else if (
      radiusDivision !== 0 &&
      angleDivision !== 0 &&
      circumference !== 0
    ) {
      let radiusWithBuffer = 0;
      for (let radius = waferRadius; radius > 0; radius -= radiusDivision) {
        let calculatedRadius = findNextRadius(
          radius,
          waferRadius,
          radiusWithBuffer
        );
        radiusWithBuffer = calculatedRadius.radiusWithBuffer;
        let nextRadius = calculatedRadius.nextRadius;
        for (let angle = 0; angle < 360; angle += angleDivision) {
          let startRadian = degreeToRadian(angle);
          let endRadian = degreeToRadian(angle + angleDivision);
          let from =
            nextRadius - radiusDivision > 0 ? nextRadius - radiusDivision : 0;
          let to = radius;
          let startAngle = angle;
          let endAngle = angle + angleDivision;

          const graphics = drawSectorGraphics(
            canvasCenter,
            radius,
            startRadian,
            endRadian
          );
          graphics.properties = {
            shape: SHAPES.PARTIAL_CIRCLE_SECTOR,
            radius: { from: from, to: to },
            angle: { from: startAngle, to: endAngle },
          };
          stage.current.addChild(graphics);
        }
        radius = nextRadius;
      }
    }
    onSelectionChanged({
      selectionType: SELECTION_TYPE.FULL,
      areas: [],
    });
    renderer.current.render(stage.current);
  };

  // Calculating the next radius while circuference is coming
  const findNextRadius = (currentRadius, waferRadius, radiusWithBuffer) => {
    let nextRadius = currentRadius;
    // if circumference and radius division both are same we don't need to do anything
    if (circumference !== radiusDivision) {
      // when we need to draw circle including circumference
      if (nextRadius === waferRadius) {
        nextRadius = waferRadius + (radiusDivision - circumference);
        radiusWithBuffer = nextRadius;
      } else if (nextRadius === radiusWithBuffer - radiusDivision) {
        // when circumference less than radius division
        if (circumference < radiusDivision) {
          nextRadius = nextRadius + circumference;
        } else if (circumference % radiusDivision !== 0) {
          nextRadius = nextRadius + (circumference - radiusDivision);
        }
      }
    }
    return { nextRadius, radiusWithBuffer };
  };

  const invertSelection = (updateArea = true) => {
    if (stage.current.children.length > 0) {
      for (let graphics of stage.current.children) {
        if (graphics.selected) {
          graphics.selected = false;
          graphics.tint = COLORS.UNSELECTED;
        } else {
          graphics.selected = true;
          graphics.tint = COLORS.SELECTED;
        }
      }
      renderer.current.render(stage.current);
      updateArea && updateAreaSelection();
    }
  };

  useEffect(() => {
    draw();
    invertFlag.current = false;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [radiusDivision, circumference, angleDivision, resetArea]);

  useEffect(() => {
    if (invert) invertFlag.current = true;
    if (invertFlag.current) invertSelection();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [invert]);

  useEffect(() => {
    if (allWaferAreas) {
      stage.current.removeChildren();
      for (let graphics of allWaferAreas) {
        handleGraphicsClick(graphics);
        stage.current.addChild(graphics);
      }
      renderer.current.render(stage.current);
      updateAreaSelection();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <div ref={divRef} className={classes.waferArea}></div>;
};

export default WaferAreaSelector;
