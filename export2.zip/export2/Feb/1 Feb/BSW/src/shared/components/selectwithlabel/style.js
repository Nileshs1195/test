import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  selectRoot: {
    padding: theme.spacing(1, 1, 1, 0),
    marginTop: theme.spacing(-1),
  },
}));
