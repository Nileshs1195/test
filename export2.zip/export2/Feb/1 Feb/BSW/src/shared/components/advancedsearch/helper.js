import { format } from "date-fns";
export const STRING_PLACEHOLDER = "ex) AS1212349012";
export const NUMBER_COMMA_SEPERATED_PLACEHOLDER = "ex) 1,2,3,225";

export const columnTypes = {
  BOOLEAN: "boolean",
  DATE: "date",
  NUMBER: "number",
  STRING: "string",
  TIME: "time",
  DATE_TIME: "dateTime",
  NUMBER_COMMA_SEPERATED: "numberCommaSeperated",
};

export const BOOLEAN_TYPE = [
  { value: "", label: "None" },
  { value: true, label: "True" },
  { value: false, label: "False" },
];

export const DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
export const filterTypes = {
  CONTAINS: "contains",
  STARTSWITH: "startsWith",
  ENDSWITH: "endsWith",
  EQUALS: "equals",
};

export const regx = {
  REG_ENDSWITH: /^[*]/,
  REG_STARTSWITH: /[*]$/,
  REG_CONTAINS: /^[*].*[*]$/,
};

export const addCharacterToString = (firstValue, operator) => {
  switch (operator) {
    case filterTypes.CONTAINS:
      return `*${firstValue}*`;
    case filterTypes.ENDSWITH:
      return `*${firstValue}`;
    case filterTypes.STARTSWITH:
      return `${firstValue}*`;
    default:
      return firstValue;
  }
};

export const formatStringField = (value, operatorValue) => {
  switch (operatorValue) {
    case filterTypes.CONTAINS:
      return value.substring(1, value.length - 1);
    case filterTypes.ENDSWITH:
      return value.substring(1);
    case filterTypes.STARTSWITH:
      return value.substring(0, value.length - 1);
    default:
      return value;
  }
};

export const trimValue = (value) => value.trim();

export const validateNumberFields = (fields, operators) => {
  const errors = {};
  let isFormValid = true;
  const multiFieldOperator = operators.find(
    (operator) => operator.multiField === true
  );
  if (!multiFieldOperator) return [errors, isFormValid];
  for (const field in fields) {
    const numberField = fields[field];
    if (numberField.operator === multiFieldOperator.value) {
      // checking both fields have value
      if (
        (!Boolean(numberField.valueFirst) &&
          Boolean(numberField.valueSecond)) ||
        (Boolean(numberField.valueFirst) && !Boolean(numberField.valueSecond))
      ) {
        // either one or two fields are blank
        errors[field] = true;
        isFormValid = false;
      } else {
        // either blank or filled
        if (
          !Boolean(numberField.valueFirst) &&
          !Boolean(numberField.valueSecond)
        )
          // blank
          return [errors, isFormValid];

        if (!(+numberField.valueFirst < +numberField.valueSecond)) {
          // if first value is greater than second - error
          errors[field] = true;
          isFormValid = false;
        }
      }
    }
    if (isNaN(numberField.valueFirst) || isNaN(numberField.valueSecond)) {
      errors[field] = true;
      isFormValid = false;
    }
  }
  return [errors, isFormValid];
};

export const validateDate = (fromDate, toDate) => toDate >= fromDate;

export const isValidFilter = (filter) => {
  const isValid =
    Boolean(
      Boolean(filter.valueFirst && filter.operator) ||
        filter.includeValue ||
        filter.excludeValues?.length
    ) ||
    filter.valueFirst !== "" ||
    filter?.firstValues?.length;
  return isValid;
};

export const clearHeadFilter = (filter) => {
  return { ...filter, operator: "", valueFirst: "", valueSecond: "" };
};

export const clearCommaSeperatedNumberFilter = (filter) => {
  return {
    ...filter,
    operator: "",
    valueFirst: "",
    valueSecond: "",
    firstValues: [],
  };
};

export const timeToDateConversion = (time) => {
  let date = new Date();
  let [hours, minutes, seconds] = time.split(":");
  date.setHours(+hours);
  date.setMinutes(minutes);
  date.setSeconds(seconds);
  return date;
};

export const formatDates = (date, formats) => {
  return format(date, formats);
};

export const convertCommaSeperatedToArray = (value) => {
  value = value.split(",");
  value = value.filter((num) => {
    if (num !== "") return num;
  });
  value = value.map((num) => +num);
  //remove duplicates if any
  return [...new Set(value)];
};

export const isFutureDate = (from, to) => {
  return new Date() < from || new Date() < to;
};
