import { makeStyles } from "@material-ui/core";
import { common } from "@material-ui/core/colors";
import { colors } from "../../../appcolors";

export const useStyles = makeStyles((theme) => ({
  acrd_Summary: {
    borderBottom: `1px solid ${colors.accordion.summaryBorder}`,
    marginBottom: -1,
  },
  summaryRoot: {
    minHeight: "48px !important",
  },
  summaryContent: {
    margin: `${theme.spacing(1.5, 0)} !important`,
  },
  acrd_Details: {
    padding: theme.spacing(2),
  },
  summaryTxt: {
    fontWeight: theme.typography.fontWeightRegular,
    fontSize: 15,
  },
  icon: {
    color: common.black,
  },
}));
