import { AppBar, IconButton, Toolbar, Typography } from "@material-ui/core";
import { ChevronLeft, Menu } from "@material-ui/icons";
import clsx from "clsx";
import PropTypes from "prop-types";
import { Fragment, useContext } from "react";
import { useTranslation } from "react-i18next";
import UserStore from "../../stores/userstore";
import LanguageSwitch from "../languageswitcher";
import { useStyles } from "./style";

const AppBarSection = (props) => {
  const { t } = useTranslation();
  const classes = useStyles();
  const userStore = useContext(UserStore);
  const { handleDrawerToggle, open, toolbarItems } = props;

  return (
    <AppBar
      position="absolute"
      className={clsx(classes.appBar, !open && classes.appBarShift)}
    >
      <Toolbar className={classes.toolbar}>
        {userStore.currentUser ? (
          <Fragment>
            <div className={classes.toolbarElements}>
              <IconButton
                edge="start"
                color="inherit"
                aria-label="open drawer"
                onClick={handleDrawerToggle}
              >
                {open ? <Menu /> : <ChevronLeft />}
              </IconButton>
              <div
                className={clsx(
                  classes.toolbarDrawer,
                  classes.toolbarDrawerCollapsedText
                )}
              >
                <Typography component="h6" variant="h6" color="inherit" noWrap>
                  {t("project-short-title")}
                </Typography>
              </div>
            </div>
            <div className={clsx(classes.toolbarElements, classes.rightItems)}>
              {toolbarItems && toolbarItems()}
              <LanguageSwitch />
            </div>
          </Fragment>
        ) : (
          <LanguageSwitch className={classes.alignRight} />
        )}
      </Toolbar>
    </AppBar>
  );
};

AppBarSection.propTypes = {
  handleDrawerToggle: PropTypes.func,
  open: PropTypes.bool,
  toolbarItems: PropTypes.func,
};
export default AppBarSection;
