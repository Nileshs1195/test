import { makeStyles } from "@material-ui/core";
import { common } from "@material-ui/core/colors";
import { colors } from "../../appcolors";

export const useStyles = makeStyles((theme) => ({
  mainTitle: {
    color: common.white,
  },
  title: {
    fontSize: 18,
    fontWeight: theme.typography.fontWeightRegular,
  },
  contents: {
    "& > div": {
      padding: theme.spacing(0.75, 2),
    },
  },
  columns: {
    minHeight: "75vh",
    maxHeight: "75vh",
    overflowY: "auto",
  },
  datePickers: {
    display: "flex",
    flexDirection: "column",
  },
  pickers: {
    display: "flex",
    marginTop: theme.spacing(0.5),
    width: "100%",
  },
  inputDate: {
    marginBottom: 0,
    marginRight: theme.spacing(1.5),
  },
  inputGroup: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    columnGap: "1em",
    paddingBlock: theme.spacing(1, 0),
    alignItems: "baseline",
  },
  numCol: {
    gridTemplateColumns: "1fr 1fr 1fr",
    padding: 0,
  },
  timeCol: {
    gridTemplateColumns: "1fr 0.8fr 1fr",
    padding: 0,
  },
  inputGroupTime: {
    display: "grid",
    columnGap: "1em",
    alignItems: "baseline",
    width: "88.5%",
  },
  inputDateGroup: {
    gridTemplateColumns: "1fr",
    paddingBlock: theme.spacing(0.5, 0),
    display: "grid",
    columnGap: "1em",
    alignItems: "baseline",
    width: "99%",
  },
  dateCol: {
    gridTemplateColumns: "1fr 0.5fr 1fr",
    padding: 0,
  },
  input: {
    margin: theme.spacing(0.5, 0),
    alignSelf: "flex-end",
  },
  stringField: {
    width: "70%",
  },
  selectIcon: {
    color: colors.table.dropIcon,
  },
  btnContainer: {
    display: "flex",
    justifyContent: "flex-end",
    paddingBottom: `${theme.spacing(1.5)}px !important`,
    alignItems: "center",
    "& button": {
      margin: theme.spacing(0, 1),
    },
    "& button:last-child": {
      marginRight: 0,
    },
  },
  numberLabel: {
    margin: 0,
    lineHeight: "100%",
  },
  numberColWrapper: {
    display: "flex",
    flexDirection: "column",
    marginBlock: theme.spacing(1),
  },
  timeColWrapper: {
    display: "flex",
    flexDirection: "column",
    width: "63%",
  },
  excludeField: {
    display: "flex",
    justifyContent: "space-between",
  },
  waferDateTimeColWrapper: {
    display: "flex",
    flexDirection: "column",
    width: "85%",
  },
  calenderIcon: {
    marginTop: "0px !important",
    "& .MuiIconButton-root": {
      padding: "0px !important",
    },
  },
}));
