import { Typography } from "@material-ui/core";
import clsx from "clsx";
import PropTypes from "prop-types";
import { useStyles } from "./style";

const EmptySpace = ({ message, className }) => {
  const classes = useStyles();
  return (
    <div className={clsx(classes.root, className)}>
      <Typography variant="h6">{message}</Typography>
    </div>
  );
};

export default EmptySpace;

EmptySpace.propTypes = {
  message: PropTypes.string.isRequired,
  className: PropTypes.string,
};
