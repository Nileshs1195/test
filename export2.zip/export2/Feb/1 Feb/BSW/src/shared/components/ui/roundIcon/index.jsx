import clsx from "clsx";
import PropTypes from "prop-types";
import { useStyles } from "./style";

const RoundIcon = ({ active, title, size }) => {
  const classes = useStyles();
  return (
    <div
      className={clsx(classes.root, active && classes.active)}
      style={{ width: size, height: size }}
    >
      {title}
    </div>
  );
};

export default RoundIcon;
RoundIcon.propTypes = {
  title: PropTypes.string.isRequired,
  active: PropTypes.bool,
  size: PropTypes.number,
};
