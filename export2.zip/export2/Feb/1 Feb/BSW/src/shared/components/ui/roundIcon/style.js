import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    height: 28,
    width: 28,
    borderRadius: "50%",
    display: "grid",
    placeItems: "center",
    fontSize: 12,
    border: `1px solid ${theme.palette.primary.main}`,
    background: "#ffffff",
    color: theme.palette.primary.main,
    textTransform: "capitalize",
    overflow: "hidden",
    cursor: "pointer",
  },
  active: {
    background: theme.palette.primary.main,
    color: "#ffffff",
    border: "none",
  },
}));
