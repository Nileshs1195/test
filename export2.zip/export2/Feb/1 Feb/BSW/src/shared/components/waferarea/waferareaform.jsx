import { useState, useEffect, memo } from "react";
import PropTypes from "prop-types";
import { FormControlLabel, Typography } from "@material-ui/core";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import clsx from "clsx";
import SelectWithLabel from "../selectwithlabel";
import Checkbox from "../ui/checkbox";
import { useStyles } from "./style";

const WaferAreaForm = (props) => {
  const classes = useStyles();
  const { onFormChange, areaOptions, labels, doReset, selectionDetails } =
    props;
  const { selectedOptions } = selectionDetails;
  const { divisions, diameter } = areaOptions;
  const [radiusDivision, setRadiusDivision] = useState(
    selectedOptions.radiusDivision
  );
  const [angleDivision, setAngleDivision] = useState(
    selectedOptions.angleDivision
  );
  const [perimeter, setPerimeter] = useState(selectedOptions.perimeter);
  const [invert, setInvert] = useState(selectedOptions.invert);

  const reset = () => {
    setRadiusDivision(selectedOptions.radiusDivision);
    setAngleDivision(selectedOptions.angleDivision);
    setPerimeter(selectedOptions.perimeter);
    setInvert(selectedOptions.invert);
    onFormChange({
      radiusDivision: selectedOptions.radiusDivision,
      angleDivision: selectedOptions.angleDivision,
      perimeter: selectedOptions.perimeter,
      invert: selectedOptions.invert,
      reset: true,
    });
  };

  useEffect(() => {
    if (doReset) {
      reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doReset]);

  const onSelectRadius = (e) => {
    setRadiusDivision(e.target.value);
    setInvert(false);
    onFormChange({
      radiusDivision: e.target.value,
      angleDivision: angleDivision,
      perimeter: perimeter,
      invert: false,
    });
  };
  const onSelectAngle = (e) => {
    setAngleDivision(e.target.value);
    setInvert(false);
    onFormChange({
      radiusDivision: radiusDivision,
      angleDivision: e.target.value,
      perimeter: perimeter,
      invert: false,
    });
  };
  const onSelectPerimeter = (e) => {
    setPerimeter(e.target.value);
    setInvert(false);
    onFormChange({
      radiusDivision: radiusDivision,
      angleDivision: angleDivision,
      perimeter: e.target.value,
      invert: false,
    });
  };
  const doInvert = (e) => {
    setInvert(e.target.checked);
    onFormChange({
      radiusDivision: radiusDivision,
      angleDivision: angleDivision,
      perimeter: perimeter,
      invert: e.target.checked,
    });
  };

  const CustomExpandMore = ({ className }, label) => {
    return (
      <div>
        <div className={clsx(className, classes.customSelect)}>{label}</div>
        <ArrowDropDownIcon className={clsx(className, classes.selectIcon)} />
      </div>
    );
  };

  return (
    <>
      <div className={classes.formArea}>
        <div className={classes.label1}>
          <Typography variant="body2" className={classes.colTitile}>
            {labels.waferDiameter} : {diameter} mm
          </Typography>
        </div>
        <SelectWithLabel
          id={"wafer-area-radius-division"}
          label={labels.divisions.radiusDivision}
          value={radiusDivision}
          onChange={onSelectRadius}
          list={divisions.radius}
          fullWidth
          IconComponent={(className) => CustomExpandMore(className, "mm")}
        />
        <SelectWithLabel
          id={"wafer-area-angle-division"}
          label={labels.divisions.angleDivision}
          value={angleDivision}
          onChange={onSelectAngle}
          list={divisions.angle}
          fullWidth
          IconComponent={(className) => CustomExpandMore(className, "degree")}
        />
        <SelectWithLabel
          id={"wafer-area-perimeter-division"}
          label={labels.divisions.outerCircumference}
          value={perimeter}
          onChange={onSelectPerimeter}
          list={divisions.perimeter}
          fullWidth
          IconComponent={(className) => CustomExpandMore(className, "mm")}
        />
        <div className={classes.label1}>
          <FormControlLabel
            classes={{ label: classes.label }}
            control={
              <Checkbox
                color="default"
                id="wafer-area-invert-selection"
                checked={invert}
                onChange={doInvert}
              />
            }
            label={labels.divisions.invertSelection}
          />
        </div>
      </div>
    </>
  );
};

export default memo(WaferAreaForm);

WaferAreaForm.propTypes = {
  onFormChange: PropTypes.func,
  areaOptions: PropTypes.object,
  handleSelect: PropTypes.func,
  doReset: PropTypes.object,
  labels: PropTypes.object,
};
