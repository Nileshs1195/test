import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
    zIndex: 2,
  },
  icon: {
    cursor: "pointer",
  },
  allFilters: {
    display: "flex",
    margin: theme.spacing(1, 0, 1, 0),
    maxWidth: "70%",
    flexDirection: "column",
  },
  filterContent: {
    display: "flex",
    paddingTop: theme.spacing(1),
    alignItems: "flex-start",
    "& div ": {
      margin: theme.spacing(0, 0.5, 0.5, 0.5),
    },
  },
  moreButton: {
    height: 24,
    width: 24,
    marginLeft: theme.spacing(1),
  },
  active: {
    background: "#0000001f",
  },
  paper: {
    position: "absolute",
    display: "flex",
    flexDirection: "column",
    padding: theme.spacing(2),
    background: "#fafafa",
    width: "60%",
    maxHeight: "30vh",
    overflowY: "auto",
    "& .child:not(:last-child)": {
      marginBottom: theme.spacing(2),
    },
  },
  filterTitle: {
    fontWeight: theme.typography.fontWeightMedium,
    fontSize: 16,
    lineHeight: 1,
  },
  chipContainer: {
    display: "flex",
    flexWrap: "wrap",
    padding: theme.spacing(1, 0, 1, 0),
    "& > *": {
      margin: theme.spacing(0.5),
    },
  },
  noMargin: {
    margin: "0 !important",
  },
}));
