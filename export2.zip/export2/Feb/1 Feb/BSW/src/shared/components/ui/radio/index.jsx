import { Radio as MuiRadio } from "@material-ui/core";

const Radio = (props) => {
  return <MuiRadio {...props} />;
};
export default Radio;
