import { useState } from "react";
import PropTypes from "prop-types";
import WaferAreaForm from "../waferarea/waferareaform";
import WaferAreaSelector from "../waferarea/waferareaselector";
import { SELECTION_TYPE } from "../../appconstants";
import { useEffect } from "react";

const WaferArea = (props) => {
  const { handleSelect, selectionDetails } = props;
  const { selectedOptions } = selectionDetails;
  const [resetArea, setResetArea] = useState();
  const [options, setOption] = useState({
    radiusDivision: selectedOptions.radiusDivision,
    angleDivision: selectedOptions.angleDivision,
    perimeter: selectedOptions.perimeter,
    invert: selectedOptions.invert,
  });
  const [selectionArea, setSelectionArea] = useState({
    selectedOptions: options,
    selectionType: SELECTION_TYPE.FULL,
    areas: [],
  });

  const onFormChange = (formObject) => {
    if (formObject.reset) {
      setResetArea({});
    }
    setOption(formObject);
  };

  const onSelectionChanged = (areas) => {
    setSelectionArea({ selectedOptions: options, ...areas });
  };

  useEffect(() => {
    const selection = {
      ...selectionArea,
      selectedOptions: { ...selectionArea.selectedOptions, ...options },
    };
    handleSelect(selection);
  }, [selectionArea, options, handleSelect]);

  return (
    <>
      <WaferAreaForm onFormChange={onFormChange} {...props} />
      <WaferAreaSelector
        radiusDivision={options.radiusDivision}
        angleDivision={options.angleDivision}
        circumference={options.perimeter}
        invert={options.invert}
        resetArea={resetArea}
        onSelectionChanged={onSelectionChanged}
        {...props}
      />
    </>
  );
};

export default WaferArea;

WaferArea.propTypes = {
  areaOptions: PropTypes.object,
  handleSelect: PropTypes.func,
  doReset: PropTypes.object,
  labels: PropTypes.object,
};
