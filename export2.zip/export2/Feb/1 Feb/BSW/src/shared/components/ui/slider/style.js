import { makeStyles } from "@material-ui/core";
import { colors } from "../../../appcolors";

export const useStyles = makeStyles((theme) => ({
  slider: {
    background: colors.slider.railbg,
  },
}));
