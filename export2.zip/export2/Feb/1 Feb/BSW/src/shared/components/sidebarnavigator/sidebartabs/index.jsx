import { Tab, Tabs } from "@material-ui/core";
import { useTheme } from "@material-ui/styles";
import clsx from "clsx";
import Tabpanel from "../../tabpanel";
import { useStyles } from "./style";

export const SidebarTabs = ({ children, ...props }) => (
  <Tabs
    indicatorColor="primary"
    textColor="primary"
    variant="fullWidth"
    {...props}
  >
    {children}
  </Tabs>
);

export const SidebarTab = (props) => <Tab {...props} />;

export const SidebarTabPanel = ({ children, className, ...props }) => {
  const classes = useStyles();
  const theme = useTheme();
  return (
    <Tabpanel
      {...props}
      dir={theme.direction}
      className={clsx(classes.tabheight, className)}
    >
      {children}
    </Tabpanel>
  );
};
