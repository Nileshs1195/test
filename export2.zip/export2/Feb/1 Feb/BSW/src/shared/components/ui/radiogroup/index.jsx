import {
  FormControlLabel,
  Radio,
  RadioGroup as MuiRadioGroup,
} from "@material-ui/core";
import PropTypes from "prop-types";

const RadioGroup = ({ items, selected, disabled, ...props }) => {
  return (
    <MuiRadioGroup {...props}>
      {items.map((item) => (
        <FormControlLabel
          key={item.label}
          value={item.value}
          control={
            <Radio
              color="primary"
              disabled={item.isDisable ?? disabled}
              checked={item.value === selected}
            />
          }
          label={item.label}
        />
      ))}
    </MuiRadioGroup>
  );
};

export default RadioGroup;
RadioGroup.propTypes = {
  items: PropTypes.array.isRequired,
};
