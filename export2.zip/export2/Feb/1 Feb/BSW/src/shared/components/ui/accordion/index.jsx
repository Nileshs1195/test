import {
  Accordion as MuiAccordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from "@material-ui/core";
import { ExpandMoreRounded } from "@material-ui/icons";
import { useStyles } from "./styles";

const Accordion = ({ id, title, children, ...props }) => {
  const classes = useStyles();
  const ExpandIcon = <ExpandMoreRounded className={classes.icon} />;

  return (
    <MuiAccordion elevation={3} id={`accordion-${id}`} {...props}>
      <AccordionSummary
        className={classes.acrd_Summary}
        expandIcon={ExpandIcon}
        classes={{
          root: classes.summaryRoot,
          content: classes.summaryContent,
        }}
      >
        <Typography variant="body2" className={classes.summaryTxt}>
          {title}
        </Typography>
      </AccordionSummary>
      <AccordionDetails className={classes.acrd_Details}>
        {children}
      </AccordionDetails>
    </MuiAccordion>
  );
};

export default Accordion;
