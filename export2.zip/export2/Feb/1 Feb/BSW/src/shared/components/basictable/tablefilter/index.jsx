import {
  ArrowDownward,
  ArrowUpward,
  FilterList,
  Lock,
} from "@material-ui/icons";
import clsx from "clsx";
import { Observer } from "mobx-react-lite";
import { useState } from "react";
import FilterContextMenu from "./filtercontextmenu";
import { useStyles } from "./style";

const TableFilter = (props) => {
  const {
    id,
    columnDefnition,
    onFilterApplyClick,
    filter,
    sortPriority,
    sortOrder,
    lock,
  } = props;
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const onFilterApply = (value) => {
    onFilterApplyClick && onFilterApplyClick(value);
  };

  const open = Boolean(anchorEl);
  return (
    <Observer>
      {() => (
        <>
          <div
            aria-controls={open ? "menu-list-grow" : undefined}
            aria-haspopup="true"
            onClick={handleClick}
            className={clsx(open && classes.filterDivBgColor)}
          >
            {lock === true || sortOrder !== undefined ? (
              <div
                className={
                  sortOrder !== undefined && lock
                    ? classes.filterWrapper3
                    : classes.filterWrapper4
                }
              >
                <div className={classes.filterIcon}>
                  {lock && (
                    <>
                      <Lock className={classes.lockIconSize} />
                      <FilterList
                        fontSize={"small"}
                        className={classes.iconSize2}
                      />
                    </>
                  )}
                </div>
                <div className={classes.arrowIcon}>
                  {sortOrder ? (
                    <ArrowUpward
                      className={lock ? classes.iconSize3 : classes.iconSize}
                    />
                  ) : (
                    <ArrowDownward
                      className={lock ? classes.iconSize3 : classes.iconSize}
                    />
                  )}{" "}
                  <div className={classes.marginRight}>
                    {lock && sortPriority}
                  </div>
                </div>
                <div className={classes.filterIcon}>
                  {!lock && <FilterList fontSize={"small"} />}
                </div>
              </div>
            ) : (
              <div className={classes.filterWrapper1}>
                <FilterList />
              </div>
            )}
          </div>
          <FilterContextMenu
            id={id}
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            columnDefnition={columnDefnition}
            filter={
              filter ?? {
                exclude: false,
                field: "",
                operator: "",
                valueFirst: "",
                valueSecond: "",
                saveFilter: false,
              }
            }
            onFilterApplyClick={onFilterApply}
            sortOrder={sortOrder}
            lock={lock}
          />
        </>
      )}
    </Observer>
  );
};

export default TableFilter;
