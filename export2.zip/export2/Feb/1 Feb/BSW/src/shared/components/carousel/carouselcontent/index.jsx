import { Card, CardContent, Tooltip, Typography } from "@material-ui/core";
import clsx from "clsx";
import { useStyles } from "./style";

const CarousalContents = (props) => {
  const { carousalType, carouselData, isActive } = props;
  const classes = useStyles();
  const id = `${props.id}-content-${carouselData.slotNo}-${carouselData.waferId}`;
  if (carousalType === "text") {
    return (
      <Tooltip
        id={`${id}-tooltip`}
        title={carouselData.waferId}
        classes={{
          tooltip: classes.toolTip,
        }}
      >
        <CardContent className={classes.cardContent}>
          <Typography
            id={`${id}-lotid`}
            gutterBottom
            variant="body2"
            className={clsx(
              isActive && classes.normalFont,
              classes.ribbonText1
            )}
          >
            {carouselData.lotId}
          </Typography>
          <Typography
            id={`${id}-slotno`}
            variant="body2"
            className={clsx(isActive && classes.textStyle, classes.ribbonText2)}
          >
            {carouselData.slotNo}
          </Typography>
        </CardContent>
      </Tooltip>
    );
  }
};

const CarousalContent = (props) => {
  const classes = useStyles();
  const { isActive, hideFromLeft, isMaxAvailable } = props;

  return (
    <Card
      elevation={0}
      onClick={props.onClick}
      className={
        hideFromLeft
          ? classes.hideCard
          : isMaxAvailable
          ? isActive
            ? clsx(classes.card, classes.activeCard)
            : clsx(classes.card, classes.inactiveCard)
          : isActive
          ? clsx(classes.cardCentre, classes.activeCard)
          : clsx(classes.cardCentre, classes.inactiveCard)
      }
    >
      <CarousalContents {...props} />
    </Card>
  );
};

export default CarousalContent;
