import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    top: "10.6px",
  },
  popperStyle: {
    zIndex: 10,
  },
  paper: {
    marginRight: theme.spacing(2),
  },
  buttonHolder: {
    placeContent: "flex-end",
  },
  buttonStyle: {
    fontSize: 11,
    margin: "0px 0px 0px 10px",
  },
  formControl: {
    minWidth: 195,
  },
  sort: {
    color: "#839aca",
  },

  filterWrapper: {
    backgroundColor: "#304f8d",
    height: "45px !important",
    width: "40px",
    paddingTop: "6px",
    display: "flex",
  },
  filterWrapper1: {
    height: 45,
    width: 40,
    paddingTop: 10,
    paddingLeft: 8,
  },
  ascending: {
    left: "0",
    top: "0",
    paddingTop: "12px",
    paddingLeft: "3px",
    width: "10px",
  },
  descending: {
    right: "0",
    top: "0",
    paddingLeft: "2px",
  },
  lock: {
    display: "flex",
    flexDirection: "row",
    height: "24px",
    paddingTop: "6px",
  },
  filterDivBgColor: {
    backgroundColor: theme.palette.primary.dark,
  },
  customInputText: {
    "& input::-webkit-clear-button, & input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button":
      {
        display: "none",
      },
    "& input[type=number]": {
      mozAppearance: "textfield",
    },
    "& label": {
      fontSize: 14,
    },
    "& .MuiInputBase-fullWidth": {
      width: "90% !important",
    },
  },
  menuItemStyle: {
    display: "flex",
    flexDirection: "column",
  },
  checkboxItem: {
    marginLeft: ".25em",
  },
  menuItem: {
    fontSize: 14,
    textTransform: "capitalize",
  },
  filterIcon: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: 1,
  },
  arrowIcon: {
    display: "flex",
    justifyContent: "space-between",
  },
  marginRight: {
    marginRight: 8,
    marginTop: -1,
    fontSize: 12.8,
  },
  iconSize: {
    fontSize: 16,
    marginLeft: 8,
    marginTop: 3,
  },
  iconSize3: {
    fontSize: 16,
    marginLeft: 2,
    marginTop: 3,
  },
  iconSize2: {
    marginRight: 7,
    marginTop: 3,
    fontSize: 18,
  },
  filterWrapper3: {
    height: 42,
    width: 40,
    backgroundColor: "#304f8d",
  },
  filterWrapper4: {
    height: 42,
    width: 40,
    display: "grid",
    placeItems: "center",
    backgroundColor: "#304f8d",
  },
  lockIconSize: {
    fontSize: 14,
    marginLeft: 2,
    marginTop: 6,
  },
}));
