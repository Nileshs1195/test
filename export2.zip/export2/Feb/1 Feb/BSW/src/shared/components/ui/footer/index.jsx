import React from "react";
import { useTranslation } from "react-i18next";
import { useStyles } from "./style";

export const Footer = () => {
  const classes = useStyles();
  const { t } = useTranslation();
  return (
    <div className={classes.root}>
      <p className={classes.text}> {t("copyright")} </p>
    </div>
  );
};
export default Footer;
