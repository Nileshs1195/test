import { Checkbox as MuiCheckbox } from "@material-ui/core";
import DoneIcon from "@material-ui/icons/Done";
import { useStyles } from "./style";

const Checkbox = (props) => {
  const classes = useStyles();
  const checkboxIcon = <span className={classes.checkboxIcon} />;
  const checkboxCheckedIcon = <DoneIcon className={classes.checkboxIcon} />;

  return (
    <MuiCheckbox
      {...props}
      icon={checkboxIcon}
      checkedIcon={checkboxCheckedIcon}
    />
  );
};

export default Checkbox;
