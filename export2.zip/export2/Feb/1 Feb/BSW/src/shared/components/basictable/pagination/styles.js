import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  controlContainer: {
    display: "flex",
    alignItems: "center",
    "& > :not(:last-child)": {
      padding: theme.spacing(0, 2, 0, 0),
    },
  },
  select: {
    width: "4em",
    textAlign: "center",
    margin: theme.spacing(0, 0.75),
  },
  selectPaper: {
    maxHeight: "35%",
  },
  totalPages: {
    marginLeft: theme.spacing(0.25),
  },
  pageDisplay: {
    margin: theme.spacing(0, 0.75),
    width: "max-content",
  },
  customInputText: {
    "& input::-webkit-clear-button, & input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button":
      {
        display: "none",
      },
    width: "3vw",
    paddingLeft: theme.spacing(1),
    textAlign: "center",
  },
  pageWrapper: {
    display: "flex",
    alignItems: "center",
  },
}));
