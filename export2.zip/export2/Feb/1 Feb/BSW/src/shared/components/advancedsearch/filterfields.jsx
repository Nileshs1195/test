import {
  FormHelperText,
  IconButton,
  InputAdornment,
  TextField,
} from "@material-ui/core";
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDateTimePicker,
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import {
  AccessTime as AccessTimeIcon,
  DateRange as DateRangeIcon,
} from "@material-ui/icons";
import clsx from "clsx";
import { memo, useCallback, useEffect, useState } from "react";
import { REG_EX } from "../../appconstants";
import { debounce } from "../../utils";
import { SelectField } from "../ui";
import {
  DATE_FORMAT,
  formatDates,
  STRING_PLACEHOLDER,
  timeToDateConversion,
  trimValue,
  NUMBER_COMMA_SEPERATED_PLACEHOLDER,
  convertCommaSeperatedToArray
} from "./helper";
import { useStyles } from "./style";
import { FormControlLabel } from "@material-ui/core";
import { Checkbox } from "../../../shared/components/ui";
import { setHours, subDays, format } from "date-fns";

export const StringField = memo(
  ({
    column,
    value,
    onChange,
    reset,
    showExclude,
    applyStringFilters,
    handleCheckBox,
    checked,
    checkboxLabel,
    ...props
  }) => {
    const classes = useStyles();
    const [inputValue, setInputValue] = useState(value);

    // eslint-disable-next-line react-hooks/exhaustive-deps
    const notifyParent = useCallback(
      debounce((colInfo, colId) => {
        onChange(colInfo, colId);
      }, 250),
      []
    );

    useEffect(() => {
      if (reset) setInputValue("");
    }, [reset, value]);

    const handleChange = (event, column) => {
      let { name, value } = event.target;
      if (REG_EX.INVALID_REGEX.test(value)) return;
      value = trimValue(value);
      setInputValue(value);
      notifyParent({ name, value }, column);
    };

    return (
      <div className={clsx(classes.input, showExclude && classes.excludeField)}>
        <TextField
          {...props}
          autoComplete="off"
          label={column.label}
          className={clsx(showExclude && classes.stringField)}
          value={inputValue}
          onChange={(e) => handleChange(e, column.key)}
          name="valueFirst"
          fullWidth={!showExclude}
          placeholder={STRING_PLACEHOLDER}
          InputLabelProps={{
            shrink: true,
          }}
        />
        {showExclude && (
          <FormControlLabel
            control={
              <Checkbox
                {...props}
                color="default"
                checked={checked}
                onChange={(e) => handleCheckBox(e, column.key)}
              />
            }
            label={checkboxLabel}
          />
        )}
      </div>
    );
  }
);

export const NumberField = ({
  id,
  column,
  value,
  filterMenus,
  onChange,
  reset,
  error,
  errorMsg,
  ...props
}) => {
  const initialState = {
    valueFirst: "",
    operator: filterMenus[0].value,
    valueSecond: "",
  };

  const classes = useStyles();

  const [inputValues, setInputValues] = useState(
    value?.operator ? value : initialState
  );
  const [disableFirstField, setDisableFirstField] = useState(true);

  useEffect(() => {
    if (reset) {
      setInputValues(initialState);
      setDisableFirstField(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reset]);

  const canDisableMultiField = (operator) => {
    if (!Boolean(operator)) return true;
    const multiFieldOperators = [];

    filterMenus.forEach((menu) => {
      if (menu.multiField) multiFieldOperators.push(menu.value);
    });

    return !multiFieldOperators.includes(operator);
  };

  useEffect(() => {
    if (!reset) {
      setDisableFirstField(canDisableMultiField(inputValues.operator));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const notifyParent = useCallback(
    debounce((colInfo, colId) => {
      onChange(colInfo, colId);
    }, 250),
    []
  );

  const onColumnChange = (e, key) => {
    const { value, name } = e.target;
    const { pattern } = column.validation;
    const regex = pattern ? pattern : REG_EX.DECIMAL;
    const trimedValue = trimValue(value);
    let updated = { ...inputValues, [name]: trimedValue };

    if (name !== "operator") {
      if (!Boolean(value)) {
        setInputValues(updated);
        notifyParent(updated, key);
        return;
      }
      if (!regex.test(value)) return;
    }

    if (name === "operator") {
      const disableField = canDisableMultiField(value);
      setDisableFirstField(disableField);
      updated = { ...updated, valueFirst: "", valueSecond: "" };
    }
    setInputValues(updated);
    notifyParent(updated, key);
  };

  return (
    <div className={classes.numberColWrapper}>
      <FormHelperText className={classes.numberLabel}>
        {column.label}
      </FormHelperText>
      <div className={clsx(classes.inputGroup, classes.numCol)} {...props}>
        <TextField
          id={`${id}-adv-search-${column.key}-valueSecond`}
          autoComplete="off"
          className={classes.input}
          name={disableFirstField ? "valueSecond" : "valueFirst"}
          value={
            disableFirstField ? inputValues.valueSecond : inputValues.valueFirst
          }
          onChange={(e) => onColumnChange(e, column.key)}
          error={!disableFirstField && error}
          disabled={disableFirstField}
        />
        <SelectField
          id={`${id}-${column.key}-num-filter`}
          value={inputValues.operator}
          classes={{ icon: classes.selectIcon }}
          items={filterMenus}
          name="operator"
          onChange={(e) => onColumnChange(e, column.key)}
        />
        <TextField
          id={`${id}-adv-search-${column.key}-valueFirst`}
          autoComplete="off"
          className={classes.input}
          name={disableFirstField ? "valueFirst" : "valueSecond"}
          value={
            disableFirstField ? inputValues.valueFirst : inputValues.valueSecond
          }
          onChange={(e) => onColumnChange(e, column.key)}
          error={error}
        />
      </div>
      {error && (
        <FormHelperText error className={classes.numberLabel}>
          {errorMsg}
        </FormHelperText>
      )}
    </div>
  );
};

export const TimeField = ({
  id,
  column,
  value,
  filterMenus,
  onChange,
  reset,
  error,
  errorMsg,
  ...props
}) => {
  const classes = useStyles();

  const initialState = {
    valueFirst: setHours(new Date().setHours(0, 0, 0, 0), 0),
    operator: filterMenus[0].value,
    valueSecond: setHours(new Date().setHours(23, 59, 59, 999), 23),
  };

  const [inputValues, setInputValues] = useState(
    value?.operator ? value : initialState
  );
  const [disableFirstField, setDisableFirstField] = useState(false);

  useEffect(() => {
    setInputValues(value?.operator ? getDateFormat() : initialState);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (reset) {
      setInputValues(initialState);
      setDisableFirstField(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reset]);

  useEffect(() => {
    if (!reset) {
      setDisableFirstField(canDisableMultiField(inputValues.operator));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const getDateFormat = () => {
    const secondValue =
      value.valueSecond === ""
        ? setHours(new Date().setHours(0, 0, 0, 0), 0)
        : timeToDateConversion(value.valueSecond);
    let upDatedTimeValue = {
      ...value,
      valueFirst: timeToDateConversion(value.valueFirst),
      valueSecond: secondValue,
    };
    return upDatedTimeValue;
  };

  const canDisableMultiField = (operator) => {
    if (!Boolean(operator)) return true;
    const multiFieldOperators = [];
    filterMenus.forEach((menu) => {
      if (menu.multiField) multiFieldOperators.push(menu.value);
    });
    return !multiFieldOperators.includes(operator);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const notifyParent = useCallback(
    debounce((colInfo, colId) => {
      onChange(colInfo, colId);
    }, 250),
    []
  );

  const onColumnChange = (e, key) => {
    const { value, name } = e.target;
    let updated = { ...inputValues, [name]: value };
    const disableField = canDisableMultiField(value);
    setDisableFirstField(disableField);
    setInputValues(updated);
    notifyParent(updated, key);
  };

  const onTimeChange = (time, name) => {
    let updated = { ...inputValues, [name]: time };
    setInputValues(updated);
    notifyParent(
      {
        valueFirst:
          updated.valueFirst && updated.valueFirst !== "Invalid Date"
            ? format(updated.valueFirst, "HH:mm:ss")
            : "",
        operator: updated.operator,
        valueSecond:
          updated.valueSecond && updated.valueSecond !== "Invalid Date"
            ? format(updated.valueSecond, "HH:mm:ss")
            : "",
      },
      column.key
    );
  };

  const convertToTimeFormat = () => {
    const time = disableFirstField
      ? inputValues.valueFirst
      : inputValues.valueSecond;
    return time;
  };

  return (
    <div className={classes.timeColWrapper}>
      <FormHelperText>{column.label}</FormHelperText>
      <div className={clsx(classes.inputGroupTime, classes.timeCol)} {...props}>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <KeyboardTimePicker
            id={`${id}-adv-search-${column.key}-valueSecond`}
            classes={{ root: classes.calenderIcon }}
            ampm={false}
            openTo="hours"
            views={["hours", "minutes", "seconds"]}
            format="HH:mm:ss"
            name={disableFirstField ? "valueSecond" : "valueFirst"}
            value={
              disableFirstField
                ? inputValues.valueSecond
                : inputValues.valueFirst
            }
            onChange={(e) =>
              onTimeChange(e, disableFirstField ? "valueSecond" : "valueFirst")
            }
            keyboardIcon={<AccessTimeIcon />}
            disabled={disableFirstField}
            error={!disableFirstField && error}
          />
        </MuiPickersUtilsProvider>
        <SelectField
          id={`${id}-${column.key}-num-filter`}
          value={inputValues.operator}
          classes={{ icon: classes.selectIcon }}
          items={filterMenus}
          name="operator"
          onChange={(e) => onColumnChange(e, column.key)}
        />
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <KeyboardTimePicker
            id={`${id}-adv-search-${column.key}-valueSecond`}
            className={classes.calenderIcon}
            ampm={false}
            openTo="hours"
            views={["hours", "minutes", "seconds"]}
            format="HH:mm:ss"
            name={disableFirstField ? "valueFirst" : "valueSecond"}
            value={convertToTimeFormat()}
            onChange={(e) =>
              onTimeChange(e, disableFirstField ? "valueFirst" : "valueSecond")
            }
            keyboardIcon={<AccessTimeIcon />}
          />
        </MuiPickersUtilsProvider>
      </div>
      {error && (
        <FormHelperText error className={classes.numberLabel}>
          {errorMsg}
        </FormHelperText>
      )}
    </div>
  );
};

export const WaferDateTimeField = ({
  id,
  column,
  value,
  filterMenus,
  onChange,
  reset,
  error,
  errorMsg,
  ...props
}) => {
  const classes = useStyles();

  const initialState = {
    valueFirst: subDays(new Date(), 1),
    operator: filterMenus[0].value,
    valueSecond: new Date(),
  };

  const [inputValues, setInputValues] = useState(
    // eslint-disable-next-line no-use-before-define
    value?.operator ? value : initialState
  );
  const [disableFirstField, setDisableFirstField] = useState(false);

  useEffect(() => {
    setInputValues(value?.operator ? getDateTimeFormat() : initialState);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (reset) {
      setInputValues(initialState);
      setDisableFirstField(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reset]);

  useEffect(() => {
    if (!reset) {
      setDisableFirstField(canDisableMultiField(inputValues.operator));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const getDateTimeFormat = () => {
    const secondValue =
      value.valueSecond === "" ? subDays(new Date(), 1) : value.valueSecond;
    let upDatedDateValue = {
      ...value,
      valueFirst: value.valueFirst,
      valueSecond: secondValue,
    };
    return upDatedDateValue;
  };

  const canDisableMultiField = (operator) => {
    if (!Boolean(operator)) return true;
    const multiFieldOperators = [];
    filterMenus.forEach((menu) => {
      if (menu.multiField) multiFieldOperators.push(menu.value);
    });
    return !multiFieldOperators.includes(operator);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const notifyParent = useCallback(
    debounce((colInfo, colId) => {
      onChange(colInfo, colId);
    }, 250),
    []
  );

  const onColumnChange = (e, key) => {
    const { value, name } = e.target;
    let updated = { ...inputValues, [name]: value };
    const disableField = canDisableMultiField(value);
    setDisableFirstField(disableField);
    setInputValues(updated);
    notifyParent(updated, key);
  };

  const onDateChange = (date, name) => {
    let updated = { ...inputValues, [name]: date };
    setInputValues(updated);
    notifyParent(
      {
        valueFirst:
          updated.valueFirst && String(updated.valueFirst) !== "Invalid Date"
            ? formatDates(updated.valueFirst, DATE_FORMAT)
            : updated.valueFirst,
        operator: updated.operator,
        valueSecond:
          updated.valueSecond && String(updated.valueSecond) !== "Invalid Date"
            ? formatDates(updated.valueSecond, DATE_FORMAT)
            : updated.valueFirst,
      },
      column.key
    );
  };

  return (
    <div className={classes.waferDateTimeColWrapper}>
      <FormHelperText>{column.label}</FormHelperText>
      <div className={clsx(classes.inputDateGroup, classes.dateCol)} {...props}>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <KeyboardDateTimePicker
            id={`${id}-adv-search-${column.key}-valueSecond`}
            variant="inline"
            className={classes.calenderIcon}
            ampm={false}
            margin="normal"
            views={["date", "year", "month", "hours", "minutes", "seconds"]}
            format="MM/dd/yyyy HH:mm:ss"
            allowKeyboardControl={false}
            name={disableFirstField ? "valueSecond" : "valueFirst"}
            value={
              disableFirstField
                ? inputValues.valueSecond
                : inputValues.valueFirst
            }
            onChange={(e) =>
              onDateChange(e, disableFirstField ? "valueSecond" : "valueFirst")
            }
            disabled={disableFirstField}
            KeyboardButtonProps={{
              id: "FilterDatePicker-ChangeDate",
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton>
                    <DateRangeIcon />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </MuiPickersUtilsProvider>
        <SelectField
          id={`${id}-${column.key}-num-filter`}
          value={inputValues.operator}
          classes={{ icon: classes.selectIcon }}
          items={filterMenus}
          name="operator"
          onChange={(e) => onColumnChange(e, column.key)}
        />
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <KeyboardDateTimePicker
            id={`${id}-adv-search-${column.key}-valueSecond`}
            variant="inline"
            className={classes.calenderIcon}
            ampm={false}
            margin="normal"
            views={["date", "year", "month", "hours", "minutes", "seconds"]}
            format="MM/dd/yyyy HH:mm:ss"
            allowKeyboardControl={false}
            name={disableFirstField ? "valueFirst" : "valueSecond"}
            value={
              disableFirstField
                ? inputValues.valueFirst
                : inputValues.valueSecond
            }
            onChange={(e) =>
              onDateChange(e, disableFirstField ? "valueFirst" : "valueSecond")
            }
            KeyboardButtonProps={{
              id: "FilterDatePicker-ChangeDate",
            }}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton>
                    <DateRangeIcon />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </MuiPickersUtilsProvider>
      </div>
      {error && (
        <FormHelperText error className={classes.numberLabel}>
          {errorMsg}
        </FormHelperText>
      )}
    </div>
  );
};

export const NumberFieldCommaSeperated = memo(
  ({
    column,
    value,
    onChange,
    reset,
    ...props
  }) => {
    const classes = useStyles();
    const [inputValue, setInputValue] = useState(value);

    // eslint-disable-next-line react-hooks/exhaustive-deps
    const notifyParent = useCallback(
      debounce((colInfo, colId) => {
        onChange(colInfo, colId);
      }, 250),
      []
    );

    useEffect(() => {
      if (reset) setInputValue("");
    }, [reset, value]);

    const handleChange = (event, key) => {
      let { name, value } = event.target;
      const { pattern } = column.validation;
      const regex = pattern ? pattern : REG_EX.DECIMAL;
      if (!regex.test(value)) return;
      setInputValue(value);
      value = convertCommaSeperatedToArray(value)
      notifyParent({ name, value }, key);
    };

    return (
        <TextField
          {...props}
          autoComplete="off"
          label={column.label}
          value={inputValue}
          className={classes.input}
          onChange={(e) => handleChange(e, column.key)}
          name="firstValues"
          placeholder={NUMBER_COMMA_SEPERATED_PLACEHOLDER}
          InputLabelProps={{
            shrink: true,
          }}
        />
       
    );
  }
);