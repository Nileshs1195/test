import { IconButton, Typography } from "@material-ui/core";
import { MoreHoriz } from "@material-ui/icons";
import clsx from "clsx";
import PropTypes from "prop-types";
import { Chip } from "../../ui";
import { getChipLabel } from "./helper";
import { useStyles } from "./styles";

const AllFilters = ({
  filters,
  onChipDelete,
  onIconClick,
  label,
  id,
  showPanel,
}) => {
  const classes = useStyles();
  const onButtonClick = () => {
    onIconClick();
  };

  const renderAllChips = (chips) => {
    return (
      <div className={classes.noMargin}>
        {chips.map((chip) => {
          const label = getChipLabel(chip);

          return (
            <Chip
              id={`${id}_all_${label}`}
              key={label}
              label={label}
              onDelete={() => onChipDelete(chip)}
            />
          );
        })}
      </div>
    );
  };

  if (!filters.length) return null;

  return (
    <div className={classes.allFilters}>
      <Typography variant="body2" className={classes.filterTitle}>
        {label}
      </Typography>
      <div className={classes.filterContent}>
        {renderAllChips(filters)}
        <IconButton
          id={`${id}_more_filters`}
          className={clsx(classes.moreButton, showPanel && classes.active)}
          onClick={onButtonClick}
        >
          <MoreHoriz className={classes.icon} />
        </IconButton>
      </div>
    </div>
  );
};

export default AllFilters;

AllFilters.propTypes = {
  filters: PropTypes.array.isRequired,
  onChipDelete: PropTypes.func.isRequired,
  onIconClick: PropTypes.func.isRequired,
  label: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
};
