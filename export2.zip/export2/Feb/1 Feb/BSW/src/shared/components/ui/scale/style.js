import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    width: 52,
  },
  wrapper: {
    position: "relative",
    width: 42,
  },
  iconContainer: {
    width: "100%",
    height: 9,
    border: "solid 1pt #000000",
    borderWidth: "0 1pt",
    zIndex: 0,
  },
  icon: {
    width: "100%",
    height: "1pt",
    background: "#000000",
    position: "absolute",
    zIndex: 0,
    top: 4,
    left: 0,
    right: 0,
  },
  text: {
    fontSize: 14,
    marginTop: theme.spacing(0.2),
    fontWeight: 300,
    color: "rgba(0,0,0,1)",
  },
}));
