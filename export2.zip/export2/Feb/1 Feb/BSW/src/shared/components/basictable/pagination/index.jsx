import { TextField, Typography } from "@material-ui/core";
import { ChevronLeft, ChevronRight } from "@material-ui/icons";
import PropTypes from "prop-types";
import { useCallback, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { REG_EX } from "../../../appconstants";
import { SETTINGS } from "../../../appsettings";
import { debounce } from "../../../utils";
import { IconButton, SelectField } from "../../ui/";
import { useStyles } from "./styles";

const Pagination = (props) => {
  const maxPage = useRef();
  const classes = useStyles();
  const { t } = useTranslation();

  const {
    id,
    itemCount,
    onChange,
    disabled,
    resetPageNo,
    pageSizeDetails,
    labelName,
    pageNo,
    pageSize,
    disableItemPerPage,
    labels,
  } = props;

  const pageItems = pageSizeDetails ?? SETTINGS.GRID.PAGINATION.PAGE_SIZES;
  const pageSizes = pageSize ?? SETTINGS.GRID.PAGINATION.PAGE_SIZES[0].value;
  const navDirections = SETTINGS.GRID.PAGINATION.DIRECTIONS;
  const pageNumber = pageNo ?? 0;
  const [currentPage, setCurrentPage] = useState(pageNumber);
  const [itemPerPage, setItemPerPage] = useState(pageSizes);
  const currentPageRef = useRef(pageNumber);
  const [, updateState] = useState();
  const [updateMaxPage, setUpdateMaxPage] = useState();

  const updateCurrentPage = (pageNo) => {
    setCurrentPage(pageNo);
    currentPageRef.current = pageNo;
  };

  useEffect(() => {
    maxPage.current = Math.ceil(itemCount / itemPerPage);
    setUpdateMaxPage(maxPage.current);
    if ((currentPage === 0 && maxPage.current > 0) || resetPageNo) {
      updateCurrentPage(1);
      onChange(getPaginationObject(itemPerPage, 1));
    }

    if (currentPage > maxPage.current) {
      updateCurrentPage(maxPage.current);
      onChange(getPaginationObject(itemPerPage, maxPage.current));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemPerPage, itemCount, resetPageNo, onChange, currentPage]);

  const onNav = (direction) => {
    let page = 0;
    if (direction === navDirections.NEXT) {
      page = currentPage + 1;
    } else {
      page = currentPage - 1;
    }
    updateCurrentPage(page);
    onChange(getPaginationObject(itemPerPage, page));
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const notifyParent = useCallback(
    debounce((itemPerPage, page) => {
      if (
        page <= maxPage.current &&
        page > 0 &&
        currentPageRef.current !== page
      ) {
        currentPageRef.current = page;
        onChange(getPaginationObject(itemPerPage, page));
      }
    }, 750),
    []
  );

  const onPageChange = (e) => {
    const page = +e.target.value;
    if (page > 0 && REG_EX.NUMBER.test(page)) {
      notifyParent(itemPerPage, page);
      setCurrentPage(page);
    } else setCurrentPage("");
  };
  const onItemPerPageChange = (e) => {
    let page = currentPage;
    const itemPerPage = e.value;
    maxPage.current = Math.ceil(itemCount / itemPerPage);
    setUpdateMaxPage(maxPage.current);
    if (page > maxPage.current) {
      page = maxPage.current;
    }
    setItemPerPage(itemPerPage);
    updateCurrentPage(page);
    onChange(getPaginationObject(itemPerPage, page));
  };

  const getPaginationObject = (pageSize, pageNo) => {
    return {
      pageSize: pageSize,
      pageNo: pageNo,
    };
  };

  const handleFocus = (event) => {
    event.target.select();
  };

  const handleBlur = (event) => {
    if (!Boolean(event.target.value)) {
      setCurrentPage(currentPageRef.current);
    }
  };

  const renderPageDisplay = () => {
    let secondPart = currentPage * itemPerPage;
    let firstPart = secondPart - itemPerPage + 1;
    if (secondPart > itemCount) {
      secondPart = itemCount;
    }
    if (firstPart < 0) {
      firstPart = 0;
    }
    if (itemCount === 0) {
      firstPart = 0;
      secondPart = 0;
    }

    return (
      <Typography variant="body2" className={classes.pageDisplay}>
        {firstPart}-{secondPart} / {itemCount}
      </Typography>
    );
  };

  return (
    <div className={classes.controlContainer}>
      <div className={classes.pageWrapper}>
        <IconButton
          size="small"
          id={`${id}-page-nav-left`}
          variant="outlined"
          disabled={disabled || currentPage <= 1}
          onClick={() => onNav(navDirections.PREV)}
        >
          <ChevronLeft />
        </IconButton>
        {renderPageDisplay()}
        <IconButton
          size="small"
          id={`${id}-page-nav-right`}
          variant="outlined"
          onClick={() => onNav(navDirections.NEXT)}
          disabled={disabled || currentPage === maxPage.current}
        >
          <ChevronRight />
        </IconButton>
      </div>
      <div className={classes.pageWrapper}>
        <Typography variant="body2">
          {labels?.page ?? t("pages.defect-inspection.controls.page")}
        </Typography>
        <TextField
          id={`${id}-current-page-no`}
          value={currentPage}
          onChange={onPageChange}
          inputProps={{ min: 1, max: maxPage.current }}
          classes={{ root: classes.customInputText }}
          onFocus={handleFocus}
          onBlur={handleBlur}
        />
        <Typography variant="body2">
          {labels?.of ?? t("pages.defect-inspection.controls.of")}
        </Typography>
        <Typography variant="body2" className={classes.totalPages}>
          &nbsp;{updateMaxPage}
        </Typography>
      </div>
      <div>
        {!disableItemPerPage && (
          <div className={classes.pageWrapper}>
            <Typography variant="body2">
              {labelName ?? t("pages.defect-inspection.controls.item-per-page")}
            </Typography>
            <SelectField
              id={`${id}-item-per-page`}
              disabled={disabled}
              value={itemPerPage}
              className={classes.select}
              onClick={onItemPerPageChange}
              paperClassName={classes.selectPaper}
              items={pageItems}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default Pagination;

Pagination.propTypes = {
  itemCount: PropTypes.number,
  onChange: PropTypes.func,
  disabled: PropTypes.bool,
  resetPageNo: PropTypes.bool,
  pageSizeDetails: PropTypes.array,
  labelName: PropTypes.string,
  pageNo: PropTypes.number,
  pageSize: PropTypes.number,
  disableItemPerPage: PropTypes.bool,
  labels: PropTypes.object,
};
