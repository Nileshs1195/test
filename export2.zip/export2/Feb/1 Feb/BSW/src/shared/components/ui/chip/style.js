import { makeStyles } from "@material-ui/core";
import { colors } from "../../../appcolors";

export const useStyles = makeStyles((theme) => ({
  root:{
    lineHeight:1
  },
  main: {
    color: colors.chip.delete.color,
    border: `1px solid ${colors.chip.delete.color}`,
    "&:hover": {
      background: `${colors.chip.delete.hoverBg} !important`,
    },
  },
}));
