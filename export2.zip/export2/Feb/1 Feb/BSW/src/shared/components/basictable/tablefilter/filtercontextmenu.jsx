import {
  Button,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  InputLabel,
  MenuItem,
  MenuList,
  Popover,
  Select,
  TextField,
} from "@material-ui/core";
import ArrowDownwardIcon from "@material-ui/icons/ArrowDownward";
import ArrowUpwardIcon from "@material-ui/icons/ArrowUpward";
import CancelOutlinedIcon from "@material-ui/icons/CancelOutlined";
import clsx from "clsx";
import { format, subDays } from "date-fns";
import { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import Checkbox from "../../../components/ui/checkbox";
import DatePicker from "../../datepicker";
import {
  DATE_FORMAT,
  FIELD_TYPE,
  FILTER_DEFAULT_VALUE,
  FILTER_OPERATOR,
  INITIAL_BOOL_STATE,
} from "./constants";
import { useStyles } from "./style";
import { checkBoolean, validate } from "./validationhelper";

const FilterContextMenu = (props) => {
  const { t } = useTranslation();

  const formatDates = (date, formats) => {
    if (Boolean(date)) {
      const dateInFormat = format(date, formats);
      return dateInFormat;
    }
  };

  const {
    id,
    open,
    anchorEl,
    onClose,
    columnDefnition,
    onFilterApplyClick,
    filter,
    lock,
    sortOrder,
  } = props;
  const fieldName = columnDefnition.key;
  const fieldType = columnDefnition.type;
  const classes = useStyles();
  const [isColumnLocked, setIsColumnLocked] = useState(lock === true);
  const [saveFilter, setSaveFilter] = useState(
    filter?.saveFilter ? true : false
  );
  const [filterValues, setFilterValues] = useState(
    filter ?? FILTER_DEFAULT_VALUE
  );

  const [selectFilterType, setSelectFilterType] = useState("");
  const [isFilterApplying, setIsFilterApplying] = useState(false);
  const [textFieldError, setTextFieldError] = useState(FILTER_DEFAULT_VALUE);
  const [fromDate, setFromDate] = useState(subDays(new Date(), 1));
  const [toDate, setToDate] = useState(new Date());
  const [dates, setDates] = useState(new Date());
  const [sortToggleAsc, setSortToggleAsc] = useState(sortOrder === true);
  const [sortToggleDes, setSortToggleDes] = useState(sortOrder === false);
  const [boolean, setBoolean] = useState(INITIAL_BOOL_STATE);

  useEffect(() => {
    setBoolean(checkBoolean(filter, columnDefnition));
  }, [columnDefnition, filter]);

  useEffect(() => {
    if (isFilterApplying) {
      setIsFilterApplying(false);
      onClose();
    }
  }, [textFieldError, isFilterApplying, onClose, filter]);

  const reset = useCallback(() => {
    setSelectFilterType(
      filter !== undefined && filter.operator !== undefined
        ? filter.operator
        : ""
    );
    setFilterValues(filter ?? FILTER_DEFAULT_VALUE);
    setIsColumnLocked(lock === true);
    setSaveFilter(filter?.saveFilter ? true : false);
  }, [filter, lock]);

  useEffect(() => {
    reset();
    setSortToggleDes(sortOrder === false);
    setSortToggleAsc(sortOrder === true);
  }, [filter, filter.sortOrder, reset, sortOrder]);

  const handleApply = () => {
    const validationResults = validate(columnDefnition, filterValues);

    const errorText = t("components.table-filter.error-text");
    let validationErrorMsg = {
      operator: "",
      valueFirst: "",
      valueSecond: "",
      valueDate: "",
    };
    if (validationResults) {
      if (!validationResults.valueFirst)
        validationErrorMsg.valueFirst = errorText;
      if (!validationResults.valueSecond)
        validationErrorMsg.valueSecond = errorText;
      if (!validationResults.valueDate)
        validationErrorMsg.valueDate = errorText;
      if (!validationResults.operator) validationErrorMsg.operator = errorText;
      setTextFieldError(validationErrorMsg);
      setIsFilterApplying(false);
    }
    if (
      validationResults.valueFirst &&
      validationResults.valueSecond &&
      validationResults.operator &&
      validationResults.valueDate
    ) {
      let sort = sortToggleAsc;
      if (!sortToggleAsc && !sortToggleDes) {
        sort = undefined;
      }

      onFilterApplyClick &&
        onFilterApplyClick(
          {
            ...filterValues,
            field: columnDefnition.key,
            saveFilter: saveFilter,
            isColumnLocked: isColumnLocked,
            asc: sort,
            excludeValues: [],
          },
          sort
        );
      setIsFilterApplying(true);
    }
  };

  const handleSaveFilter = (e) => {
    setSaveFilter(e.target.checked);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleCancel = (event) => {
    if (anchorEl.current && anchorEl.current.contains(event.target)) {
      return;
    }
    handleClose();
    setTextFieldError(FILTER_DEFAULT_VALUE);
    setSortToggleAsc(sortOrder === true);
    setSortToggleDes(sortOrder === false);
    setIsColumnLocked(lock === true);
  };

  const handleClearFilter = () => {
    setSelectFilterType("");
    setSaveFilter(false);
    setFilterValues({ ...FILTER_DEFAULT_VALUE, field: filterValues.field });
    setTextFieldError(FILTER_DEFAULT_VALUE);
    setBoolean(INITIAL_BOOL_STATE);
  };

  const appendTextFieldError = () => {
    setTextFieldError({
      ...textFieldError,
      valueFirst: "",
      valueSecond: "",
      valueDate: "",
    });
  };

  const handleFilterValues = (event) => {
    const { value, name } = event.target;
    appendTextFieldError();
    setFilterValues({
      ...filterValues,
      [name]: value,
      operator: selectFilterType,
      field: fieldName,
    });
  };

  const handleFromDate = (date) => {
    setFromDate(date);
    appendTextFieldError();
    setFilterValues({
      ...filterValues,
      valueFirst: formatDates(date, DATE_FORMAT),
      operator: selectFilterType,
      field: fieldName,
    });
  };

  const handleToDate = (date) => {
    setToDate(date);
    appendTextFieldError();
    setFilterValues({
      ...filterValues,
      valueSecond: formatDates(date, DATE_FORMAT),
      operator: selectFilterType,
      field: fieldName,
    });
  };

  const handleDate = (date) => {
    setDates(date);
    appendTextFieldError();
    setFilterValues({
      ...filterValues,
      valueFirst: formatDates(date, DATE_FORMAT),
      operator: selectFilterType,
      field: fieldName,
    });
  };

  const handleLockColumn = () => {
    setIsColumnLocked(!isColumnLocked);
  };

  const handleChange = (event) => {
    setSelectFilterType(event.target.value);
    setTextFieldError({
      ...textFieldError,
      operator: "",
    });
    if (fieldType === FIELD_TYPE.NUMBER_COMMA_SEPERATED) {
      setFilterValues({
        ...filterValues,
        operator: event.target.value,
        field: fieldName,
        valueFirst: "",
        valueSecond: "",
        isAdvanceSearch: 0,
        firstValues: [],
      });
    } else {
      setFilterValues({
        ...filterValues,
        operator: event.target.value,
        field: fieldName,
        valueFirst: "",
        valueSecond: "",
      });
    }

    appendTextFieldError();
  };

  const handleChangeDate = (event) => {
    setSelectFilterType(event.target.value);
    if (event.target.value === FILTER_OPERATOR.BETWEEN) {
      setFilterValues({
        ...filterValues,
        operator: event.target.value,
        field: fieldName,
        valueFirst: formatDates(fromDate, DATE_FORMAT),
        valueSecond: formatDates(toDate, DATE_FORMAT),
      });
    } else {
      setFilterValues({
        ...filterValues,
        operator: event.target.value,
        field: fieldName,
        valueFirst: formatDates(dates, DATE_FORMAT),
        valueSecond: "",
      });
    }
  };

  const handleCheckedField = (event) => {
    const { checked, name } = event.target;
    const { [name]: source, ...rest } = { ...boolean };
    const isTrue = name === "trueValue" ? true : false;
    Object.keys(rest).forEach((key) => (rest[key] = false));
    const updated = { ...rest, [name]: checked };
    const haveFilter = Object.values(updated).some((value) => value === true);

    setBoolean({ ...rest, [name]: checked });
    setFilterValues({
      ...filterValues,
      valueFirst: haveFilter ? isTrue : "",
      operator: haveFilter ? "=" : "",
      field: fieldName,
    });
  };

  const handleOnKeyPress = (e) => {
    var key = e.keyCode || e.which;
    if (key === 13) {
      e.preventDefault();
      handleApply();
    }
  };

  const stopPropagation = (e) => {
    // stop propagating keydown event of textfield to reach parent menu item
    // and lose focus of textfield while entering text
    e.stopPropagation();
  };

  return (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "left",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
    >
      <MenuList autoFocusItem={false} autoFocus={false}>
        <MenuItem autoFocus={false} className={classes.menuItem}>
          <FormControlLabel
            control={
              <Checkbox
                id={`${id}-lock-column-${fieldName}`}
                className={classes.checkboxItem}
                checked={isColumnLocked}
                onChange={handleLockColumn}
                color="default"
              />
            }
            label={t("components.table-filter.lock-column")}
          />
        </MenuItem>
        <MenuItem
          autoFocus={false}
          className={clsx(
            classes.menuItem,
            sortToggleAsc ? classes.sort : classes.default
          )}
          name="ascending"
          onClick={() => {
            setSortToggleAsc(!sortToggleAsc);
            setSortToggleDes(false);
          }}
          id={`${id}-sort-asc-${fieldName}`}
        >
          <ArrowUpwardIcon
            autoFocus={false}
            color={sortToggleAsc ? "primary" : "inherit"}
          />
          &nbsp;{t("components.table-filter.sort-asc")}
        </MenuItem>
        <MenuItem
          autoFocus={false}
          className={clsx(
            classes.menuItem,
            sortToggleDes ? classes.sort : classes.default
          )}
          name="decending"
          onClick={() => {
            setSortToggleDes(!sortToggleDes);
            setSortToggleAsc(false);
          }}
          id={`${id}-sort-desc-${fieldName}`}
        >
          <ArrowDownwardIcon
            autoFocus={false}
            color={sortToggleDes ? "primary" : "inherit"}
          />
          &nbsp;{t("components.table-filter.sort-desc")}
        </MenuItem>
        <Divider />

        {fieldType === FIELD_TYPE.BOOLEAN ? (
          <div>
            <MenuItem autoFocus={false} className={classes.menuItem}>
              <FormControlLabel
                control={
                  <Checkbox
                    id={`${id}-check-true-${fieldName}`}
                    className={classes.checkboxItem}
                    checked={boolean.trueValue}
                    onChange={handleCheckedField}
                    name="trueValue"
                    color="primary"
                  />
                }
                label={t("components.table-filter.true")}
              />
            </MenuItem>
            <MenuItem autoFocus={false} className={classes.menuItem}>
              <FormControlLabel
                control={
                  <Checkbox
                    id={`${id}-check-false-${fieldName}`}
                    className={classes.checkboxItem}
                    checked={boolean.falseValue}
                    onChange={handleCheckedField}
                    name="falseValue"
                    color="primary"
                  />
                }
                label={t("components.table-filter.false")}
              />
            </MenuItem>
          </div>
        ) : fieldType === FIELD_TYPE.DATE ? (
          <div>
            <MenuItem autoFocus={false}>
              <FormControl
                className={classes.formControl}
                error={textFieldError.operator !== ""}
              >
                <InputLabel id="demo-simple-select-label">
                  {t("components.table-filter.choose-filter-type")}
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={selectFilterType}
                  onChange={handleChangeDate}
                >
                  <MenuItem value="=" id={`${id}-equals-${fieldName}`}>
                    {t("components.table-filter.equals")}
                  </MenuItem>
                  <MenuItem value=">" id={`${id}-greater-then-${fieldName}`}>
                    {t("components.table-filter.greater-than")}
                  </MenuItem>
                  <MenuItem value="<" id={`${id}-less-than-${fieldName}`}>
                    {t("components.table-filter.less-than")}
                  </MenuItem>
                  <MenuItem value=">=" id={`${id}-gt-equal-to-${fieldName}`}>
                    {t("components.table-filter.gt-equal-to")}
                  </MenuItem>
                  <MenuItem value="<=" id={`${id}-lt-equal-to-${fieldName}`}>
                    {t("components.table-filter.lt-equal-to")}
                  </MenuItem>
                  <MenuItem value="between" id={`${id}-between-${fieldName}`}>
                    {t("components.table-filter.between")}
                  </MenuItem>
                </Select>
                <FormHelperText>{textFieldError.operator}</FormHelperText>
              </FormControl>
            </MenuItem>
            {selectFilterType &&
            selectFilterType === FILTER_OPERATOR.BETWEEN ? (
              <div>
                <MenuItem>
                  <div style={{ width: "190px" }}>
                    <DatePicker
                      id={`${id}-datetime-from-${fieldName}`}
                      name="valueFirst"
                      maxDate={new Date()}
                      date={
                        selectFilterType === FILTER_OPERATOR.BETWEEN
                          ? fromDate
                          : toDate
                      }
                      handleDateChange={handleFromDate}
                      label={t("components.table-filter.from")}
                    />
                  </div>
                </MenuItem>
                <MenuItem>
                  <div style={{ width: "190px" }}>
                    <DatePicker
                      id={`${id}-datetime-to-${fieldName}`}
                      maxDate={new Date()}
                      name="valueFirst"
                      date={toDate}
                      handleDateChange={handleToDate}
                      label={t("components.table-filter.to")}
                      validation={textFieldError}
                    />
                  </div>
                </MenuItem>
                <FormHelperText>{textFieldError.operator}</FormHelperText>
              </div>
            ) : (
              <MenuItem>
                <div style={{ width: "190px" }}>
                  <DatePicker
                    id={`${id}-dt-filter-${fieldName}`}
                    maxDate={new Date()}
                    date={dates}
                    handleDateChange={handleDate}
                    label={t("components.table-filter.search")}
                  />
                </div>
              </MenuItem>
            )}
          </div>
        ) : fieldType === FIELD_TYPE.NUMBER ||
          fieldType === FIELD_TYPE.NUMBER_COMMA_SEPERATED ? (
          <div>
            <MenuItem autoFocus={false}>
              <FormControl
                className={classes.formControl}
                error={textFieldError.operator !== ""}
              >
                <InputLabel id="demo-simple-select-label">
                  {t("components.table-filter.choose-filter-type")}
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={selectFilterType}
                  onChange={handleChange}
                >
                  <MenuItem value="=" id={`${id}-equals-${fieldName}`}>
                    {t("components.table-filter.equals")}
                  </MenuItem>
                  <MenuItem value=">" id={`${id}-greater-than-${fieldName}`}>
                    {t("components.table-filter.greater-than")}
                  </MenuItem>
                  <MenuItem value="<" id={`${id}-less-then-${fieldName}`}>
                    {t("components.table-filter.less-than")}
                  </MenuItem>
                  <MenuItem value=">=" id={`${id}-gt-equal-to-${fieldName}`}>
                    {t("components.table-filter.gt-equal-to")}
                  </MenuItem>
                  <MenuItem value="<=" id={`${id}-lt-equal-to-${fieldName}`}>
                    {t("components.table-filter.lt-equal-to")}
                  </MenuItem>
                  <MenuItem value="between" id={`${id}-between-${fieldName}`}>
                    {t("components.table-filter.between")}
                  </MenuItem>
                </Select>
                <FormHelperText>{textFieldError.operator}</FormHelperText>
              </FormControl>
            </MenuItem>
            {selectFilterType &&
            selectFilterType === FILTER_OPERATOR.BETWEEN ? (
              <div>
                <MenuItem autoFocus={false}>
                  <form className={classes.root} noValidate autoComplete="off">
                    <TextField
                      id={`${id}-txt-from-${fieldName}`}
                      className={classes.customInputText}
                      error={textFieldError.valueFirst !== ""}
                      label={t("components.table-filter.from")}
                      name="valueFirst"
                      type={"number"}
                      onKeyPress={handleOnKeyPress}
                      onKeyDown={stopPropagation}
                      onChange={handleFilterValues}
                      value={filterValues.valueFirst}
                      helperText={
                        textFieldError.valueFirst !== "" &&
                        textFieldError.valueFirst
                      }
                      InputLabelProps={{ shrink: true }}
                    />
                  </form>
                </MenuItem>
                <MenuItem autoFocus={false}>
                  <form className={classes.root} noValidate autoComplete="off">
                    <TextField
                      id={`${id}-txt-to-${fieldName}`}
                      className={classes.customInputText}
                      error={textFieldError.valueSecond !== ""}
                      label={t("components.table-filter.to")}
                      name="valueSecond"
                      type={"number"}
                      onKeyPress={handleOnKeyPress}
                      onKeyDown={stopPropagation}
                      onChange={handleFilterValues}
                      value={filterValues.valueSecond}
                      helperText={
                        textFieldError.valueSecond !== "" &&
                        textFieldError.valueSecond
                      }
                      InputLabelProps={{ shrink: true }}
                    />
                  </form>
                </MenuItem>
              </div>
            ) : (
              <MenuItem autoFocus={false}>
                <form className={classes.root} noValidate autoComplete="off">
                  <TextField
                    id={`${id}-txt-search-${fieldName}`}
                    className={classes.customInputText}
                    label={t("components.table-filter.search")}
                    name="valueFirst"
                    type={"number"}
                    onKeyPress={handleOnKeyPress}
                    onKeyDown={stopPropagation}
                    onChange={handleFilterValues}
                    value={filterValues.valueFirst}
                    helperText={
                      textFieldError.valueFirst !== "" &&
                      textFieldError.valueFirst
                    }
                    error={textFieldError.valueFirst !== ""}
                    InputLabelProps={{ shrink: true }}
                  />
                </form>
              </MenuItem>
            )}
          </div>
        ) : (
          <div>
            <MenuItem autoFocus={false}>
              <FormControl
                className={classes.formControl}
                error={textFieldError.operator !== ""}
              >
                <InputLabel id="demo-simple-select-label">
                  {t("components.table-filter.choose-filter-type")}
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={selectFilterType}
                  onChange={handleChange}
                >
                  <MenuItem
                    value="contains"
                    id={`${id}-filter-contains-${fieldName}`}
                  >
                    {t("components.table-filter.contains")}
                  </MenuItem>
                  <MenuItem
                    value="startsWith"
                    id={`${id}-filter-starts-with-${fieldName}`}
                  >
                    {t("components.table-filter.starts-with")}
                  </MenuItem>
                  <MenuItem
                    value="endsWith"
                    id={`${id}-filter-ends-with-${fieldName}`}
                  >
                    {t("components.table-filter.ends-with")}
                  </MenuItem>
                  <MenuItem
                    value="equals"
                    id={`${id}-filter-equals-${fieldName}`}
                  >
                    {t("components.table-filter.equals")}
                  </MenuItem>
                </Select>
                <FormHelperText>{textFieldError.operator}</FormHelperText>
              </FormControl>
            </MenuItem>
            <MenuItem autoFocus={false}>
              <form className={classes.root} noValidate autoComplete="off">
                <TextField
                  id={`${id}-txt-search-${fieldName}`}
                  className={classes.customInputText}
                  error={textFieldError.valueFirst !== ""}
                  label={t("components.table-filter.search")}
                  name="valueFirst"
                  onKeyDown={stopPropagation}
                  onKeyPress={handleOnKeyPress}
                  onChange={handleFilterValues}
                  value={filterValues.valueFirst}
                  helperText={
                    textFieldError.valueFirst !== "" &&
                    textFieldError.valueFirst
                  }
                />
              </form>
            </MenuItem>
          </div>
        )}
        <MenuItem
          autoFocus={false}
          onClick={handleClearFilter}
          className={classes.menuItem}
          id={`${id}-clear-filter-${fieldName}`}
        >
          <CancelOutlinedIcon /> &nbsp;
          {t("components.table-filter.clear-filter")}
        </MenuItem>
        <MenuItem autoFocus={false}>
          <FormGroup>
            <FormControlLabel
              control={
                <Checkbox
                  className={classes.checkboxItem}
                  checked={saveFilter}
                  onChange={handleSaveFilter}
                  color="default"
                  id={`${id}-save-filter-${fieldName}`}
                />
              }
              label={t("components.table-filter.save-filter")}
            />
          </FormGroup>
        </MenuItem>
        <MenuItem
          disableRipple
          autoFocus={false}
          className={classes.buttonHolder}
        >
          <Button
            variant="outlined"
            color="primary"
            className={classes.buttonStyle}
            onClick={(e) => handleCancel(e)}
            id={`${id}-btn-cancel-${fieldName}`}
          >
            {t("components.table-filter.cancel")}
          </Button>
          <Button
            variant="contained"
            color="primary"
            className={classes.buttonStyle}
            onClick={(e) => handleApply(e)}
            id={`${id}-btn-apply-${fieldName}`}
          >
            {t("components.table-filter.apply")}
          </Button>
        </MenuItem>
      </MenuList>
    </Popover>
  );
};
export default FilterContextMenu;
