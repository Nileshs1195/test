export const degreeToRadian = (angle) => +((angle * Math.PI) / 180).toFixed(5);

export const removeDuplicatesFrom2DArray = (array) => {
  const uniques = [];
  const itemsFound = {};
  for (let i = 0, l = array.length; i < l; i++) {
    const stringified = JSON.stringify(array[i]);
    if (itemsFound[stringified]) {
      continue;
    }
    uniques.push(array[i]);
    itemsFound[stringified] = true;
  }
  return uniques;
};
