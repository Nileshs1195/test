import { Breadcrumbs } from "@material-ui/core";
import PropTypes from "prop-types";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { useStyles } from "./style";

const Breadcrumb = ({ breadcrumbs, removeBreadcrumb }) => {
  const { t } = useTranslation();
  const classes = useStyles();

  const clickHandler = (e, breadcrumb) => {
    removeBreadcrumb(breadcrumb);
    if (breadcrumb.external) {
      e.preventDefault();
      window.location = breadcrumb.path;
    }
  };

  return (
    <div>
      <Breadcrumbs aria-label="breadcrumb" className={classes.root}>
        {breadcrumbs &&
          breadcrumbs.map((breadcrumb) => (
            <Link
              className={classes.capitalize}
              key={breadcrumb.label}
              onClick={(e) => clickHandler(e, breadcrumb)}
              color="inherit"
              to={breadcrumb.path}
            >
              {t(breadcrumb.label)}
            </Link>
          ))}
      </Breadcrumbs>
    </div>
  );
};

export default Breadcrumb;
Breadcrumb.propTypes = {
  breadcrumbs: PropTypes.array.isRequired,
  removeBreadcrumb: PropTypes.func,
};
