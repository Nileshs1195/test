import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
  root: {
    textAlign: "right",
    padding: theme.spacing(1, 0),
    "& button:last-child": {
      margin: theme.spacing(0, 2),
    },
  },
}));
