import { SETTINGS } from "../../../appsettings";
import { convertUTCDateToLocalDate } from "../../../utils/dateformatter";
import { commaSeparateNumber } from "../../../utils/numberformatter";

const { CELL } = SETTINGS.GRID.CELL_FILTERS;

export const getChipLabel = (chip) => {
  let label = chip.label;
  if (chip.filter !== CELL) {
    let suffix = chip.value;
    if (chip.cellInfo.type === "number") {
      suffix = chip.cellInfo.excludeFormatting
        ? chip.value
        : commaSeparateNumber(chip.value ?? "");
    } else if (chip.cellInfo.type === "date") {
      suffix = convertUTCDateToLocalDate(chip.value);
    } else if (chip.cellInfo.type === "boolean") {
      suffix = chip.cellInfo.customLabel?.[suffix].label ?? suffix;
    }
    label = `${label}: ${suffix}`;
  }
  return label;
};
