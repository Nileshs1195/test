import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles(theme => ({
  menuItemStyles: {
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    width: "100%",
    "& *:first-child": {
      marginRight: "5px"
    }
  },
  small: {
    width: theme.spacing(4),
    height: theme.spacing(4),
    fontSize: "1rem"
  }
}));
