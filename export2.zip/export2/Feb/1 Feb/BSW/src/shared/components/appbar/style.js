import { makeStyles } from "@material-ui/core/styles";
const appbarHeight = 48;

export const useStyles = makeStyles((theme) => ({
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    height: appbarHeight,
  },
  appBarShift: {
    width: "100%",
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },

  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    paddingLeft: 0,
    fontSize: 12,
    minHeight: `${appbarHeight}px !important`,
    height: appbarHeight,
    "& button": {
      padding: theme.spacing(2),
      marginLeft: "2px",
      marginRight: "2px",
      width: "44px",
      height: "44px",
    },
  },
  toolbarElements: {
    display: "flex",
    alignItems: "center",
  },
  rightItems: {
    flex: 1,
    justifyContent: "flex-end",
    "& > *": {
      marginLeft: theme.spacing(1),
    },
  },
  toolbarDrawerCollapsedText: {
    marginLeft: 0,
    minHeight: "48px !important",
  },

  toolbarDrawer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
    fontSize: 12,
    backgroundColor: theme.palette.primary.main,
    color: "#ffffff",
    ...theme.mixins.toolbar,
  },
  alignRight: {
    marginLeft: "auto",
  },
}));
