import { common } from "@material-ui/core/colors";
import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  checkboxIcon: {
    borderRadius: 5,
    width: 16,
    height: 16,
    boxShadow: "inset 0 0 0 1px #10161a, inset 0 -1px 0 #10161a",
    backgroundColor: common.white,
    color: common.black,
  },
}));
