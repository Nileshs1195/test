import { Button, FormHelperText, Typography } from "@material-ui/core";
import clsx from "clsx";
import PropTypes from "prop-types";
import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { convertObjArrayToObj } from "../../utils/arrayutils";
import DatePicker from "../datepicker";
import SelectWithLabel from "../selectwithlabel";
import { ModalTitle, SecondaryButton } from "../ui";
import {
  NumberField,
  StringField,
  TimeField,
  WaferDateTimeField,
  NumberFieldCommaSeperated,
} from "./filterfields";
import {
  BOOLEAN_TYPE,
  clearHeadFilter,
  columnTypes,
  filterTypes,
  regx,
  formatStringField,
  addCharacterToString,
  isValidFilter,
  validateDate,
  validateNumberFields,
  clearCommaSeperatedNumberFilter,
  isFutureDate,
} from "./helper";
import { useStyles } from "./style";

const AdvancedSearch = (props) => {
  const {
    id,
    className,
    filters,
    columnDefinitions,
    onApply,
    onCancel,
    onClearAll,
    operators,
    labels,
    showExclude,
    applyStringFilters,
  } = props;

  const { STRING, NUMBER, BOOLEAN, TIME, DATE_TIME, NUMBER_COMMA_SEPERATED } =
    columnTypes;
  const {
    number,
    string: stringOperator = "equals",
    boolean: booleanOperator = "=",
    array: arrayOperator = "in",
  } = operators;

  const classes = useStyles();
  const [groupedColumns, setGroupedColumns] = useState({});
  const [booleanColumns, setBooleanColumns] = useState({});
  const [errors, setErrors] = useState({});
  const [fromDate, setFromDate] = useState(filters?.date?.from);
  const [toDate, setToDate] = useState(filters?.date?.to);
  const [reset, setReset] = useState(false);
  const [reLoad, setReload] = useState(false);
  const [validDate, setValidDate] = useState(true);
  const stringColumnsRef = useRef({});
  const numberColumnsRef = useRef({});
  const timeColumnsRef = useRef({});
  const waferDateTimeColumnsRef = useRef({});
  const excludedColumns = useRef([]);
  const numberCommaSeperatedColumnsRef = useRef({});

  const headerInfo = useMemo(() => {
    return convertObjArrayToObj(columnDefinitions, "key");
  }, [columnDefinitions]);

  const filteredColumns = useMemo(() => {
    return convertObjArrayToObj(filters.columns, "field");
  }, [filters.columns]);

  const getBooleanMap = (value, colId) => {
    // customLabel => true / false
    return headerInfo[colId].customLabel?.[value]?.value ?? Boolean(value);
  };

  const getReverseBooleanMap = (value, colId) => {
    // true/false => customLabel
    return headerInfo[colId].value[value] ?? value;
  };

  useEffect(() => {
    const groupColumns = (columns) => {
      const columnTypes = {
        strings: [],
        numbers: [],
        boolean: [],
        time: [],
        dateTime: [],
        numberCommaSeperated: [],
      };
      columns.forEach((column) => {
        switch (column.type) {
          case STRING:
            columnTypes.strings.push(column);
            break;
          case NUMBER:
            columnTypes.numbers.push(column);
            break;
          case BOOLEAN:
            columnTypes.boolean.push(column);
            break;
          case TIME:
            columnTypes.time.push(column);
            break;
          case DATE_TIME:
            columnTypes.dateTime.push(column);
            break;
          case NUMBER_COMMA_SEPERATED:
            columnTypes.numberCommaSeperated.push(column);
            break;
          default:
            break;
        }
      });
      return columnTypes;
    };
    columnDefinitions && setGroupedColumns(groupColumns(columnDefinitions));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [columnDefinitions]);

  const fillFields = useCallback(() => {
    if (!filters.columns.length) return;
    let numberFields = { ...numberColumnsRef.current };
    let stringFields = { ...stringColumnsRef.current };
    let booleanFields = { ...booleanColumns };
    let timeFields = { ...timeColumnsRef.current };
    let waferDateTimeFields = { ...waferDateTimeColumnsRef.current };
    let numberCommaSeperatedFields = {
      ...numberCommaSeperatedColumnsRef.current,
    };

    const fieldErrors = {};

    for (const filter of filters.columns) {
      const {
        field,
        operator,
        valueFirst,
        valueSecond,
        exclude,
        firstValues,
        isAdvanceSearch,
      } = filter;
      const columnType = headerInfo[field]?.type;

      switch (columnType) {
        case STRING:
          let firstValue = addCharacterToString(valueFirst, operator);
          stringFields = {
            ...stringFields,
            [field]: {
              ...stringFields[field],
              valueFirst: firstValue,
              operator,
              exclude,
            },
          };
          break;
        case NUMBER:
          fieldErrors[field] = false;
          numberFields = {
            ...numberFields,
            [field]: {
              ...numberFields[field],
              operator,
              valueFirst,
              valueSecond,
            },
          };
          break;
        case BOOLEAN:
          if (valueFirst !== "") {
            const value = getBooleanMap(valueFirst, field);
            booleanFields = {
              ...booleanFields,
              [field]: { ...booleanFields[field], operator, valueFirst: value },
            };
          }
          break;
        case TIME:
          fieldErrors[field] = false;
          timeFields = {
            ...timeFields,
            [field]: {
              ...timeFields[field],
              operator,
              valueFirst,
              valueSecond,
            },
          };
          break;
        case DATE_TIME:
          fieldErrors[field] = false;
          waferDateTimeFields = {
            ...waferDateTimeFields,
            [field]: {
              ...waferDateTimeFields[field],
              operator,
              valueFirst,
              valueSecond,
            },
          };
          break;
        case NUMBER_COMMA_SEPERATED:
          numberCommaSeperatedFields = {
            ...numberCommaSeperatedFields,
            [field]: {
              ...numberCommaSeperatedFields[field],
              valueFirst,
              operator,
              firstValues,
              isAdvanceSearch,
            },
          };
          break;
        default:
          break;
      }
    }
    stringColumnsRef.current = stringFields;
    numberColumnsRef.current = numberFields;
    setBooleanColumns(booleanFields);
    timeColumnsRef.current = timeFields;
    waferDateTimeColumnsRef.current = waferDateTimeFields;
    numberCommaSeperatedColumnsRef.current = numberCommaSeperatedFields;
    setErrors(fieldErrors);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.columns, headerInfo]);

  useEffect(() => {
    fillFields();
  }, [fillFields]);

  const onNumberColumnChange = useCallback((colInfo, colId) => {
    setReset(false);
    setErrors({ ...errors, [colId]: false });
    numberColumnsRef.current = {
      ...numberColumnsRef.current,
      [colId]: colInfo,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getStringOperator = (value) => {
    let endsWith = regx.REG_ENDSWITH.test(value);
    let startsWith = regx.REG_STARTSWITH.test(value);
    let contains = regx.REG_CONTAINS.test(value);
    if (contains) {
      return filterTypes.CONTAINS;
    } else if (endsWith) {
      return filterTypes.ENDSWITH;
    } else if (startsWith) {
      return filterTypes.STARTSWITH;
    } else return filterTypes.EQUALS;
  };

  const onStringColumnChange = useCallback(
    (event, colId) => {
      setReset(false);
      const { value, name } = event;
      let updatedColumns = {
        ...stringColumnsRef.current,
        [colId]: {
          ...stringColumnsRef.current[colId],
          [name]: value,
          operator: stringOperator,
        },
      };
      if (excludedColumns.current.includes(colId)) {
        updatedColumns[colId] = { ...updatedColumns[colId], exclude: true };
      }
      stringColumnsRef.current = updatedColumns;
    },
    [stringOperator]
  );

  const onNumberCommaSeperatedColumnChange = useCallback(
    (event, colId) => {
      setReset(false);
      const { value, name } = event;
      let updatedColumns = {
        ...numberCommaSeperatedColumnsRef.current,
        [colId]: {
          ...numberCommaSeperatedColumnsRef.current[colId],
          [name]: value,
          operator: arrayOperator,
          isAdvanceSearch: 1,
          valueFirst: "",
        },
      };
      numberCommaSeperatedColumnsRef.current = updatedColumns;
    },
    [arrayOperator]
  );

  const handleExclude = (e, key) => {
    const { checked } = e.target;
    if (stringColumnsRef.current[key])
      stringColumnsRef.current[key]["exclude"] = checked;
    if (checked) {
      excludedColumns.current.push(key);
    } else {
      excludedColumns.current = excludedColumns.current.filter(
        (item) => item !== key
      );
    }
    setReload(!reLoad);
  };

  const onTimeColumnChange = useCallback((colInfo, colId) => {
    timeColumnsRef.current = {
      ...timeColumnsRef.current,
      [colId]: colInfo,
    };
    setErrors({ ...errors, [colId]: false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onWaferDateTimeColumnChange = useCallback((colInfo, colId) => {
    waferDateTimeColumnsRef.current = {
      ...waferDateTimeColumnsRef.current,
      [colId]: colInfo,
    };
    setErrors({ ...errors, [colId]: false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onBooleanColumnChange = (event, colId) => {
    const { value } = event.target;
    setReset(false);
    setBooleanColumns({
      ...booleanColumns,
      [colId]: {
        ...booleanColumns[colId],
        operator: booleanOperator,
        valueFirst: value,
      },
    });
  };

  const onFromDateChange = (date) => {
    setValidDate(true);
    setReset(false);
    setFromDate(date);
  };

  const onToDateChange = (date) => {
    setValidDate(true);
    setReset(false);
    setToDate(date);
  };

  const resetFields = () => {
    stringColumnsRef.current = {};
    numberColumnsRef.current = {};
    timeColumnsRef.current = {};
    waferDateTimeColumnsRef.current = {};
    numberCommaSeperatedColumnsRef.current = {};
    setFromDate(filters?.date?.from);
    setToDate(filters?.date?.to);
    setBooleanColumns({});
    setReset(true);
    setErrors({});
    setValidDate(true);
  };

  const getStringFilters = () => {
    let stringColumns = {},
      operatorValue;
    Object.keys(stringColumnsRef.current).forEach((key) => {
      const value = stringColumnsRef.current[key];
      operatorValue = getStringOperator(value.valueFirst);
      let updatedValue = {
        ...value,
        valueFirst: formatStringField(value.valueFirst, operatorValue),
        operator: operatorValue,
      };
      stringColumns[key] = updatedValue;
    });
    return stringColumns;
  };

  const combineFilters = () => {
    let stringColumns = !applyStringFilters
      ? stringColumnsRef.current
      : getStringFilters();
    const allFields = {
      ...stringColumns,
      ...numberColumnsRef.current,
      ...timeColumnsRef.current,
      ...waferDateTimeColumnsRef.current,
      ...booleanColumns,
      ...numberCommaSeperatedColumnsRef.current,
    };
    const filters = [];
    for (const field in allFields) {
      let {
        operator,
        valueFirst,
        valueSecond,
        exclude,
        firstValues,
        isAdvanceSearch,
      } = allFields[field];
      valueSecond = valueSecond ?? "";
      if (BOOLEAN === headerInfo[field]?.type) {
        valueFirst = getReverseBooleanMap(valueFirst, field);
      }
      if (filteredColumns[field]) {
        let filterObj = {
          ...filteredColumns[field],
          operator,
          valueFirst,
          valueSecond,
          firstValues,
          isAdvanceSearch,
        };
        if (showExclude) filterObj = { ...filterObj, exclude };
        filters.push(filterObj);
      } else
        filters.push({
          ...allFields[field],
          valueFirst,
          valueSecond,
          field,
          firstValues,
          isAdvanceSearch,
        });
    }
    for (const column in filteredColumns) {
      if (!allFields[column]) filters.push(filteredColumns[column]);
    }
    // removing filters doesn't have value
    return filters.filter((filter) => {
      if (isValidFilter(filter)) {
        return filter;
      }
      return false;
    });
  };

  const validateFields = () => {
    const [numberFieldErrors, isFormValid] = validateNumberFields(
      numberColumnsRef.current,
      number
    );
    setErrors(numberFieldErrors);
    if (filters.date) {
      const isValidDate =
        validateDate(fromDate, toDate) && !isFutureDate(fromDate, toDate);
      setValidDate(isValidDate);
      return isValidDate && isFormValid;
    } else return isFormValid;
  };

  const clearFilters = () => {
    const newFilters = [];
    for (const col of filters.columns) {
      const filter = filteredColumns[col.field];
      const columnType = headerInfo[col.field].type;
      switch (columnType) {
        case STRING:
          newFilters.push(clearHeadFilter(filter));
          break;
        case NUMBER_COMMA_SEPERATED:
          if (filter.operator === arrayOperator) {
            newFilters.push(clearCommaSeperatedNumberFilter(filter));
          } else {
            newFilters.push(filter);
          }
          break;
        default:
          newFilters.push(clearHeadFilter(filter));
          break;
      }
    }
    return newFilters.filter((col) => {
      if (isValidFilter(col)) {
        return col;
      }
      return false;
    });
  };

  const handleApply = () => {
    const filter = reset ? clearFilters() : combineFilters();
    if (validateFields()) {
      onApply(filter, { fromDate, toDate });
      onCancel();
    }
  };

  const handleCancel = () => onCancel();

  const handleClearAll = () => {
    resetFields();
    onClearAll && onClearAll();
  };

  const renderDateTime = () => (
    <div className={classes.datePickers}>
      <Typography variant="body2">{labels.date.title}</Typography>
      <div className={classes.pickers}>
        <DatePicker
          className={classes.inputDate}
          id={`${id}-adv-search-from-date`}
          label={labels.date.from}
          date={fromDate}
          disableFuture
          handleDateChange={onFromDateChange}
          error={!validDate}
        />
        <DatePicker
          className={classes.inputDate}
          id={`${id}-adv-search-to-date`}
          label={labels.date.to}
          date={toDate}
          disableFuture
          handleDateChange={onToDateChange}
          error={!validDate}
        />
      </div>
      {!validDate && (
        <FormHelperText error>{labels.errors.date}</FormHelperText>
      )}
    </div>
  );

  const renderStringFields = () => (
    <div className={classes.inputGroup}>
      {groupedColumns.strings.map((col) => {
        return (
          <StringField
            id={`${id}-adv-search-${col.key}`}
            value={stringColumnsRef.current[col.key]?.valueFirst ?? ""}
            key={col.key}
            column={col}
            onChange={onStringColumnChange}
            reset={reset}
            showExclude={showExclude}
            applyStringFilters={applyStringFilters}
            handleCheckBox={handleExclude}
            checked={stringColumnsRef.current[col.key]?.exclude}
            checkboxLabel={labels.checkboxLabel}
          />
        );
      })}
    </div>
  );

  const renderTimeFields = () => (
    <div className={classes.inputGroupTime}>
      {groupedColumns.time.map((column) => {
        return (
          <TimeField
            id={id}
            key={column.key}
            filterMenus={number}
            column={column}
            onChange={onTimeColumnChange}
            value={timeColumnsRef.current[column.key]}
            reset={reset}
            error={errors[column.key]}
            errorMsg={labels.errors.time}
          />
        );
      })}
    </div>
  );

  const renderWaferDateTimeFields = () => (
    <div className={classes.inputDateGroup}>
      {groupedColumns.dateTime.map((column) => {
        return (
          <WaferDateTimeField
            id={id}
            key={column.key}
            filterMenus={number}
            column={column}
            onChange={onWaferDateTimeColumnChange}
            value={waferDateTimeColumnsRef.current[column.key]}
            reset={reset}
            error={errors[column.key]}
            errorMsg={labels.errors.dateTime}
          />
        );
      })}
    </div>
  );

  const renderNumberFields = () => (
    <div className={classes.inputGroup}>
      {groupedColumns.numbers.map((column) => (
        <NumberField
          id={id}
          key={column.key}
          filterMenus={number}
          column={column}
          onChange={onNumberColumnChange}
          value={numberColumnsRef.current[column.key]}
          reset={reset}
          error={errors[column.key]}
          errorMsg={labels.errors.number}
        />
      ))}
    </div>
  );

  const renderBooleanFields = () => (
    <div className={classes.inputGroup}>
      {groupedColumns.boolean.map((column) => (
        <SelectWithLabel
          id={`${id}-adv-search-${column.key}`}
          key={column.key}
          label={column.label}
          value={booleanColumns[column.key]?.valueFirst ?? ""}
          fullWidth
          list={BOOLEAN_TYPE}
          onChange={(e) => onBooleanColumnChange(e, column.key)}
        />
      ))}
    </div>
  );

  const renderNumberCommaSeperatedFields = () => (
    <div className={classes.inputGroup}>
      {groupedColumns.numberCommaSeperated.map((col) => {
        return (
          <NumberFieldCommaSeperated
            id={`${id}-adv-search-${col.key}`}
            value={
              numberCommaSeperatedColumnsRef.current[col.key]?.firstValues ?? ""
            }
            key={col.key}
            column={col}
            onChange={onNumberCommaSeperatedColumnChange}
            reset={reset}
          />
        );
      })}
    </div>
  );

  return (
    <div>
      <ModalTitle title={labels.title} />
      <div className={classes.contents}>
        <div>
          <Typography variant="body2" className={classes.title}>
            {labels.subTitle1}
          </Typography>
        </div>
        <div className={clsx(classes.columns, className)}>
          {Object.keys(groupedColumns).length ? (
            <>
              {filters.date && renderDateTime()}
              {renderStringFields()}
              {renderNumberCommaSeperatedFields()}
              {renderNumberFields()}
              {renderWaferDateTimeFields()}
              {renderTimeFields()}
              {renderBooleanFields()}
            </>
          ) : null}
        </div>
        <div className={classes.btnContainer}>
          <SecondaryButton
            onClick={handleCancel}
            id={`${id}-adv-search-secondary1`}
          >
            {labels.buttons.secondary1}
          </SecondaryButton>
          <SecondaryButton
            onClick={handleClearAll}
            id={`${id}-adv-search-secondary2`}
          >
            {labels.buttons.secondary2}
          </SecondaryButton>
          <Button
            onClick={handleApply}
            variant="contained"
            color="primary"
            id={`${id}-adv-search-primary`}
          >
            {labels.buttons.primary}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default memo(AdvancedSearch);

AdvancedSearch.propTypes = {
  id: PropTypes.string.isRequired,
  onApply: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  onClearAll: PropTypes.func,
  columnDefinitions: PropTypes.array.isRequired,
  filters: PropTypes.shape({
    columns: PropTypes.arrayOf(
      PropTypes.shape({
        field: PropTypes.string,
        operator: PropTypes.string,
        valueFirst: PropTypes.string,
        valueSecond: PropTypes.string,
        firstValues: PropTypes.array,
        isAdanvceSearch: PropTypes.boolean,
      })
    ),
    date: PropTypes.exact({
      from: PropTypes.any,
      to: PropTypes.any,
    }),
  }),
  operators: PropTypes.shape({
    number: PropTypes.arrayOf(
      PropTypes.shape({
        value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
        label: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
        multiField: PropTypes.bool,
      })
    ).isRequired,
    string: PropTypes.string,
    boolean: PropTypes.string,
  }).isRequired,
  labels: PropTypes.shape({
    title: PropTypes.string.isRequired,
    subTitle1: PropTypes.string.isRequired,
    checkboxLabel: PropTypes.string,
    date: PropTypes.exact({
      title: PropTypes.string.isRequired,
      from: PropTypes.string.isRequired,
      to: PropTypes.string.isRequired,
    }),
    buttons: PropTypes.shape({
      primary: PropTypes.string.isRequired,
      secondary1: PropTypes.string.isRequired,
      secondary2: PropTypes.string.isRequired,
    }),
    errors: PropTypes.shape({
      date: PropTypes.string,
      number: PropTypes.string,
    }),
  }),
  showExclude: PropTypes.bool,
  applyStringFilters: PropTypes.bool,
};

AdvancedSearch.defaultProps = {
  showExclude: false,
  applyStringFilters: false,
};
