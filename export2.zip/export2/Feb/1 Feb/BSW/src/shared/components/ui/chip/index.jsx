import { Chip as MuiChip } from "@material-ui/core";
import { CloseRounded } from "@material-ui/icons";
import clsx from "clsx";
import PropTypes from "prop-types";
import { useStyles } from "./style";

const Chip = ({ main, ...props }) => {
  const classes = useStyles();
  return (
    <MuiChip
      {...props}
      variant="outlined"
      className={clsx(classes.root, main && classes.main)}
      size="small"
      clickable={main}
      deleteIcon={<CloseRounded />}
    />
  );
};

export default Chip;

Chip.propTypes = {
  main: PropTypes.bool,
};
