import { FormControl, InputLabel, FormHelperText } from "@material-ui/core";
import SelectField from "../ui/select";
import { useStyles } from "./style";

const SelectWithLabel = ({
  label,
  fullWidth,
  width,
  list,
  helperText,
  disabled,
  error = false,
  ...props
}) => {
  const classes = useStyles();
  return (
    <FormControl fullWidth={fullWidth} disabled={disabled}>
      {label && (
        <InputLabel shrink id={label} error={error}>
          {label}
        </InputLabel>
      )}
      <SelectField
        classes={{ root: classes.selectRoot }}
        labelId={label}
        items={list}
        error={error}
        {...props}
      />
      {helperText && (
        <FormHelperText error={error}>{helperText}</FormHelperText>
      )}
    </FormControl>
  );
};
export default SelectWithLabel;
