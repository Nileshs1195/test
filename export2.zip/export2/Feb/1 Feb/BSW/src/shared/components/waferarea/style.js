import { makeStyles } from "@material-ui/core/styles";
import { colors } from "../../appcolors";

export const useStyles = makeStyles((theme) => ({
  waferArea: {
    alignSelf: "center",
    display: "flex",
    alignItems: "center",
    placeContent: "center",
  },
  formArea: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    columnGap: "1em",
    rowGap: "1em",
    padding: theme.spacing(2),
  },
  label1: {
    gridColumn: "1 / span 2",
  },
  colTitile: {
    fontSize: 16,
    fontWeight: 300,
    color: colors.inputLabel.color,
  },
  customSelect: {
    transform: "rotate(0deg)",
    padding: "2px 20px;",
    color: "#00000099",
  },
  selectIcon: {
    color: "#00000080",
  },
}));
