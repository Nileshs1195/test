import { makeStyles } from "@material-ui/core";
import { common } from "@material-ui/core/colors";

export const useStyles = makeStyles((theme) => ({
  root: {
    minWidth: "100%",
    minHeight: "100%",
    display: "grid",
    placeItems: "center",
  },
  container: {
    minWidth: "55%",
    minHeight: "55%",
    backgroundColor: "white",
    position: "relative",
  },
  closeBtn: {
    float: "right",
    position: "absolute",
    right: -13,
    top: -13,
    boxShadow: theme.spacing(0, 0, 0.4),
    padding: theme.spacing(0.6),
    zIndex: 2,
    backgroundColor: common.white,
    "&:hover": {
      backgroundColor: common.white,
    },
  },
  parent: {
    padding: theme.spacing(3),
    width: "100%",
    maxHeight: "100%",
    height: "auto",
  },
  content: {
    minHeight: "85%",
    width: "100%",
  },
  btnContainer: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    minHeight: "15%",
    width: "100%",
  },
  button: {
    marginLeft: theme.spacing(1.2),
    fontSize: 14,
  },
  buttonHover: {
    "&:hover": {
      backgroundColor: "rgba(58,95,170,0.12)",
    },
  },
  noPadding: {
    padding: 0,
  },
  titleBg: {
    backgroundColor: theme.palette.primary.main,
    padding: theme.spacing(1.5, 2),
  },
  title: {
    fontSize: 18,
    fontWeight: theme.typography.fontWeightRegular,
    color: common.white,
  },
}));
