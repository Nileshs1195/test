import {
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
  Typography,
} from "@material-ui/core";
import {
  ChevronLeft,
  ChevronRight,
  ExpandLess,
  ExpandMore,
  FirstPage,
  LastPage,
} from "@material-ui/icons";
import clsx from "clsx";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Checkbox, IconButton } from "../ui";
import { useStyles } from "./style";

const columns = {
  left: "left",
  right: "right",
};

const TransferList = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const {
    leftColumnTitleKey,
    rightColumnTitleKey,
    leftColumnItems,
    rightColumnItems,
    onChange,
    getAdditionalRowContent,
    controlButtons = true,
    enableDragDrop,
  } = props;

  const [leftItems, setLeftItems] = useState([]);
  const [rightItems, setRightItems] = useState([]);
  const [leftAllSelected, setLeftAllSelected] = useState(false);
  const [rightAllSelected, setRightAllSelected] = useState(false);
  const [startArray, setStartArray] = useState("");
  const [lastArray, setLastArray] = useState("");
  const [startColumn, setStartColumn] = useState("");
  const [lastColumn, setLastColumn] = useState("");

  useEffect(() => {
    setLeftItems(JSON.parse(JSON.stringify(leftColumnItems)));
    setRightItems(JSON.parse(JSON.stringify(rightColumnItems)));
  }, [leftColumnItems, rightColumnItems]);

  useEffect(() => {
    let leftColumns = JSON.parse(JSON.stringify(leftColumnItems));
    let rightColumns = JSON.parse(JSON.stringify(rightColumnItems));
    leftColumns.forEach((item) => {
      if (item.checked) {
        item.checked = false;
      }
    });
    rightColumns.forEach((item) => {
      if (item.checked) {
        item.checked = false;
      }
    });
    setLeftItems(leftColumns);
    setRightItems(rightColumns);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onMoveItem = (array, from, to) => {
    const item = array.splice(from, 1)[0];
    array.splice(to, 0, item);
    onChange([...array], rightItems);
  };

  const renderControlButtons = (disableUp, disableDown, itemIndex, item) => {
    return (
      <div className={classes.iconButtonHolder}>
        <IconButton
          disabled={disableDown}
          className={classes.iconButton}
          id="transferlist-bottommost"
          onClick={() => onMoveItem(leftItems, itemIndex, leftItems.length - 1)}
        >
          <LastPage className={clsx(classes.rotate90, classes.icon)} />
        </IconButton>
        <IconButton
          disabled={disableDown}
          className={classes.iconButton}
          id="transferlist-down"
          onClick={() => onMoveItem(leftItems, itemIndex, itemIndex + 1)}
        >
          <ExpandMore className={classes.icon} />
        </IconButton>
        <IconButton
          disabled={disableUp}
          className={classes.iconButton}
          id="transferlist-up"
          onClick={() => onMoveItem(leftItems, itemIndex, itemIndex - 1)}
        >
          <ExpandLess className={classes.icon} />
        </IconButton>
        <IconButton
          disabled={disableUp}
          className={classes.iconButton}
          id="transferlist-topmost"
          onClick={() => onMoveItem(leftItems, itemIndex, 0)}
        >
          <FirstPage className={clsx(classes.rotate90, classes.icon)} />
        </IconButton>
        {getAdditionalRowContent && getAdditionalRowContent(item)}
      </div>
    );
  };

  const disableTransferRight = () => {
    const selectedItems = leftItems.filter((i) => i.checked === true);
    return selectedItems && selectedItems.length === 0;
  };

  const disableTransferLeft = () => {
    const selectedItems = rightItems.filter((i) => i.checked === true);
    return selectedItems && selectedItems.length === 0;
  };

  const onTransfer = (column) => {
    if (column === columns.right) {
      const selectedItems = leftItems.filter((i) => i.checked === true);
      const unselectedItems = leftItems.filter((i) => i.checked !== true);
      // deselect items before moving to right column
      selectedItems.forEach((item) => (item.checked = false));
      onChange(unselectedItems, rightItems.concat(selectedItems));
    } else {
      const selectedItems = rightItems.filter((i) => i.checked === true);
      const unselectedItems = rightItems.filter((i) => i.checked !== true);
      // deselect items before moving to left column
      selectedItems.forEach((item) => (item.checked = false));
      onChange(leftItems.concat(selectedItems), unselectedItems);
    }
    setLeftAllSelected(false);
    setRightAllSelected(false);
  };

  const onItemChecked = (item, column) => {
    if (column === columns.left) {
      const selected = leftItems.filter((i) => i.key === item.key)[0];
      selected.checked = !selected.checked;
      const checkedItems = leftItems.filter((item) => {
        return item.checked;
      });
      checkedItems.length === leftItems.length
        ? setLeftAllSelected(true)
        : setLeftAllSelected(false);
      setLeftItems([...leftItems]);
    } else {
      const selected = rightItems.filter((i) => i.key === item.key)[0];
      selected.checked = !selected.checked;
      const chekcedItems = rightItems.filter((item) => {
        return item.checked;
      });
      chekcedItems.length === rightItems.length
        ? setRightAllSelected(true)
        : setRightAllSelected(false);
      setRightItems([...rightItems]);
    }
  };

  const onAllSelect = (column) => {
    if (column === columns.left) {
      const selected = leftItems.map((item) => {
        item.checked = !leftAllSelected;
        return item;
      });
      setLeftAllSelected(!leftAllSelected);
      setLeftItems(selected);
    } else {
      const selected = rightItems.map((item) => {
        item.checked = !rightAllSelected;
        return item;
      });
      setRightAllSelected(!rightAllSelected);
      setRightItems(selected);
    }
  };

  const arrayMover = (oldIndex, newIndex) => {
    let leftArray = leftItems;
    let rightArray = rightItems;
    switch (true) {
      case startColumn === columns.left && lastColumn === columns.left:
        leftArray.splice(newIndex, 0, leftArray.splice(oldIndex, 1)[0]);
        break;
      case startColumn === columns.right && lastColumn === columns.right:
        rightArray.splice(newIndex, 0, rightArray.splice(oldIndex, 1)[0]);
        break;
      case startColumn === columns.left && lastColumn === columns.right:
        rightArray.splice(newIndex, 0, leftArray.splice(oldIndex, 1)[0]);
        break;
      case startColumn === columns.right && lastColumn === columns.left:
        leftArray.splice(newIndex, 0, rightArray.splice(oldIndex, 1)[0]);
        break;
    }
    onChange(leftArray, rightArray);
  };

  const dragArray = (event, columnDrag) => {
    setStartColumn(columnDrag);
    setStartArray(event.target.value);
  };

  const allowDrop = (event) => {
    event.preventDefault();
  };

  const dragEnter = (event, columnDrop) => {
    event.preventDefault();
    event.stopPropagation();
    if (event.target.id === "drag-drop-array") {
      setLastArray(event.target.value);
      setLastColumn(columnDrop);
    } else if (event.target.id === "drag-drop-div") {
      setLastArray(
        columnDrop === columns.left
          ? leftItems.length === 0
            ? 0
            : leftItems.length
          : rightItems.length === 0
          ? 0
          : rightItems.length
      );
      setLastColumn(columnDrop);
    }
  };

  const dropArray = (event) => {
    event.preventDefault();
    event.stopPropagation();
    arrayMover(startArray, lastArray);
  };

  const renderColumn = (column, titleKey, items) => {
    const checked =
      column === columns.left ? leftAllSelected : rightAllSelected;
    const id = `col-head-${columns.left ? "left" : "right"}`;
    return (
      <Paper className={classes.columnWrapper}>
        <Typography
          noWrap
          align="center"
          id={`title-${id}`}
          variant="subtitle1"
          className={classes.columnTitle}
        >
          <Checkbox
            id={`chk-${id}`}
            color={"default"}
            checked={checked}
            onClick={() => onAllSelect(column)}
          />
          {t(titleKey)}
        </Typography>
        <div
          className={classes.itemContainer}
          id="drag-drop-div"
          onDrop={(e) => dropArray(e)}
          onDragOver={(e) => allowDrop(e)}
          onDragEnter={(e) => dragEnter(e, column)}
        >
          {items.map((item, index) => {
            const labelId = `item-${item.key}`;
            const doDisableUp = index === 0;
            const doDisableDown = index === items.length - 1;

            return (
              <ListItem
                divider
                disableRipple
                onDragStart={(e) => dragArray(e, column)}
                onDrop={(e) => dropArray(e)}
                onDragOver={(e) => allowDrop(e)}
                onDragEnter={(e) => dragEnter(e, column)}
                id="drag-drop-array"
                draggable={enableDragDrop}
                value={index}
                key={item.key}
                role="listitem"
                className={clsx(
                  classes.listItem,
                  enableDragDrop && classes.dragNDrop
                )}
              >
                <ListItemIcon classes={{ root: classes.listItemIcon }}>
                  <Checkbox
                    id={`chk-${labelId}`}
                    color={"default"}
                    disableRipple
                    checked={item.checked === true}
                    onClick={() => onItemChecked(item, column)}
                  />
                </ListItemIcon>
                <ListItemText id={labelId}>
                  <Typography variant="body2" id={`lbl-${labelId}`}>
                    {t(item.text)}
                  </Typography>
                </ListItemText>
                {controlButtons &&
                  column === columns.left &&
                  renderControlButtons(doDisableUp, doDisableDown, index, item)}
              </ListItem>
            );
          })}
        </div>
      </Paper>
    );
  };

  return (
    <div className={classes.root}>
      <div className={classes.box}>
        {renderColumn(columns.left, leftColumnTitleKey, leftItems)}
      </div>
      <div className={classes.btnHolder}>
        <IconButton
          id="btn-transfer-right"
          disabled={disableTransferRight()}
          onClick={() => onTransfer(columns.right)}
        >
          <ChevronRight
            className={clsx(!disableTransferRight() && classes.moveIcon)}
          />
        </IconButton>
        <IconButton
          id="btn-transfer-left"
          disabled={disableTransferLeft()}
          onClick={() => onTransfer(columns.left)}
        >
          <ChevronLeft
            className={clsx(!disableTransferLeft() && classes.moveIcon)}
          />
        </IconButton>
      </div>
      <div className={classes.box}>
        {renderColumn(columns.right, rightColumnTitleKey, rightItems)}
      </div>
    </div>
  );
};

export default TransferList;
