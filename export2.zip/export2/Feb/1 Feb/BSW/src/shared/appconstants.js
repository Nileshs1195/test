export const REG_EX = {
  NUMBER: /^[0-9]{0,}$/,
  DECIMAL: /^\d*\.?\d*$/,
  INVALID_REGEX: /[@#<>]$/,
};

export const COLORS = {
  SELECTED: 0xff8d8d,
  UNSELECTED: 0xffffff,
  BORDER: 0x000000,
  OPACITY: 0.22,
};

export const SELECTION_TYPE = {
  FULL: 0,
  PARTIAL: 1,
  NONE: 2,
};

export const SHAPES = {
  CIRCLE: 0,
  CIRCLE_SECTOR: 1,
  PARTIAL_CIRCLE_SECTOR: 2,
};
