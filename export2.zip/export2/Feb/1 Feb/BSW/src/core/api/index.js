import axios from "axios";
import { SETTINGS } from "../../appsettings";

const axiosInstance = axios.create({
  baseURL: SETTINGS.BASE_API_URL,
  timeout: SETTINGS.API_CONFIG.TIMEOUT,
  withCredentials: true,
  headers: {
    "Content-type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
  }
});

const axiosImgInstance = axios.create({
  baseURL: SETTINGS.BASE_API_URL,
  timeout: SETTINGS.API_CONFIG.TIMEOUT,
  responseType: "blob",
  headers: {
    "Content-type": "image/jpeg",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
  }
});

export const getImg = async (url) => {
  try {
    const response = await axiosImgInstance.get(url);
    return response.data;
  } catch (error) {
    if (error.request.status !== 404) {
      console.error(error);
    }
  }
};

export const get = async (url, params) => {
  try {
    const response = await axiosInstance.get(url, { params });
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

export const post = async (url, data) => {
  try {
    const response = await axiosInstance.post(url, data);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

export const put = async (url, data) => {
  try {
    const response = await axiosInstance.put(url, data);
    return response.data;
  } catch (error) {
    console.error(error);
  }
};

export const deletes = async (url, data) => {
  try {
    const response = await axiosInstance.delete(url, {data: data});
    return response.data;
  } catch (error) {
    console.error(error);
  }
};
