import { ThemeProvider } from '@material-ui/core';
import { BrowserRouter } from 'react-router-dom';
import AppContainer from './pages/container';
import { theme } from './theme';
import { useCallback } from 'react';
import ReactDOM from 'react-dom';
import CustomPrompt from './helpers/UserConfirmation';

const App = () => {

  const userConfirmation = useCallback((message, callback) => {
    const node = document.createElement('div');
    document.body.appendChild(node);

    const cleanUp = (answer) => {
      ReactDOM.unmountComponentAtNode(node);
      // document.body.removeChild(node);
      callback(answer);
    }

    ReactDOM.render(
      <CustomPrompt message={message} cleanUp={cleanUp} />,
      node,
    );
  }, []);

  return (
    <ThemeProvider theme={theme}>
      <BrowserRouter getUserConfirmation={userConfirmation}>
        <AppContainer />
      </BrowserRouter>
    </ThemeProvider>
  )
}

export default App
