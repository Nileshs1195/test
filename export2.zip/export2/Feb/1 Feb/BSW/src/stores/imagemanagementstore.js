import { action, computed, makeObservable, observable } from "mobx";
import { createContext } from "react";
import * as ImageManagementService from "../services/imagemanagementservice";
import { API_RESPONSE } from "../appconstants";

class ImageManagementStore {
  imageGroupData = [];
  selectedImageGroups = [];
  selectedClassImages = [];
  imageGroupDataTotalCount = null;
  imageGroupDataTotalCount = 0;
  uploaderAction = {
    isOpen: false,
    uploaderType: "",
    className: ""
  };
  newlyCreatedClasses = [];
  showImageUploader = false;
  showUploader = false;
  updateImageListForClass = false;
  imagePaginationStartIndex = 0;
  classPaginationStartIndex = 0;
  sortParameter = {
    sortBy: "waferId",
    sortOrder: "Ascending"
  };
  imageUploadStatus = ""
  showImageUploadProgress = false;
  imageUploadData = {
    completedCount: 0,
    totalCount: 0
  };
  imageUploadInProgress = false;
  selectedTrainingModelName = "";

  constructor() {
    makeObservable(this, {
      imageGroupData: observable,
      imageUploadStatus: observable,
      sortParameter: observable,
      imageUploadData: observable,
      showImageUploader: observable,
      showImageUploadProgress: observable,
      uploaderAction: observable,
      showUploader: observable,
      selectedImageGroups: observable,
      selectedClassImages: observable,
      imageGroupDataTotalCount: observable,
      newlyCreatedClasses: observable,
      imageUploadInProgress: observable,
      selectedTrainingModelName:observable,
      setNewlyCreatedClasses: action,
      setImageGroupData: action,
      setImageUploadStatus: action,
      setSelectedImageGroups: action,
      removeSelectedImageGroup: action,
      removeSelectedImageGroups: action,
      clearSelectedImageGroups: action,
      selectedImageGroupCount: computed,
      setImageGroupDataTotalCount: action,
      setImageGroupGridSortParams: action,
      setShowUploader: action,
      setShowImageUploader: action,
      getImageList: action,
      setUploaderAction: action,
      setImageUploadData: action,
      setImageUploadProgressBarVisibility: action
    });
  }

  setNewlyCreatedClasses = data => {
    this.newlyCreatedClasses = data;
  }

  setImageUploadStatus = (status) => {
    this.imageUploadStatus = status;
  }

  setImageUploadInProgress = (data) => {
    this.imageUploadInProgress = data;
  }

  setUploaderAction = (data) => {
    this.uploaderAction = data;
    console.warn(this.uploaderAction);
  };

  setShowUploader = (data) => {
    this.showUploader = data;
  };

  setShowImageUploader = (data) => {
    this.showImageUploader = data;
  };

  setImageGroupData = (data) => {
    this.imageGroupData = data;
  };

  setUpdateImageListForClass = (data) => {
    this.updateImageListForClass = data;
  };

  setImageGroupDataTotalCount = (data) => {
    this.imageGroupDataTotalCount = data;
  };

  fetchImageGroupData = async (data) => {
    await ImageManagementService.getImageGroupData().then((response) => {
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        this.setImageGroupData(response.data);
        this.setImageGroupDataTotalCount(response.data.length);
      } else {
        console.log("Error occurred while fetching image group list data");
      }
    });
  };

  setSelectedImageGroups = (selectedRow) => {
    selectedRow.selected = true;
    this.selectedImageGroups = [...this.selectedImageGroups, selectedRow];
  };

  removeSelectedImageGroup = (imageGroupId) => {
    this.selectedImageGroups = this.selectedImageGroups.filter((imageGroup) => imageGroup._id !== imageGroupId);
  };

  removeSelectedImageGroups = (imageGroupIds) => {
    this.selectedImageGroups = this.selectedImageGroups.filter((imageGroup) => !imageGroupIds.includes(imageGroup._id));
  };

  clearSelectedImageGroups = () => {
    this.selectedImageGroups = [];
  };

  get selectedImageGroupCount() {
    return this.selectedImageGroups.length;
  }

  setImageGroupGridSortParams = (key, val) => {
    this.sortParameter[key] = val;
  };

  updateImageGroupList = (data, id) => {
    const updatedData = this.imageGroupData.map((group, index) => {
      let item = { ...group };
      if (group.id === id) {
        item.groupName = data.groupName;
        item.comment = data.comment;
        item.selected = false;
      }
      return item;
    });
    this.setImageGroupData(updatedData);
  };

  updateGroupName = async (editData, groupId) => {
    var result;
    await ImageManagementService.updateGroupNameServices(editData, groupId).then((response) => {
      result = response;
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        console.log("Image group record updated successfully");
      } else {
        console.log("Error occurred while updating image group record");
      }
    });
    return result;
  };

  insertGroupRecord = async (data) => {
    var result;
    await ImageManagementService.insertGroupRecord(data).then((response) => {
      result = response;
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        console.log("Image group record saved successfully");
      } else {
        console.log("Error occurred while saving image group record");
      }
    });
    return result;
  };

  getImageList = async (id) => {
    const response = await ImageManagementService.getImageList(id);
    console.log(response);
  };

  setImageUploadData = (uploadData) => {
    this.imageUploadData = uploadData;
  };

  setImageUploadProgressBarVisibility = (progressBarVisibility) => {
    this.showImageUploadProgress = progressBarVisibility;
  };

  saveImageDetails = async (url, trainingId, imageData) => {
    return await ImageManagementService.saveImageDetails(url, trainingId, imageData);
  };

  getImagesForDataset = async (url, trainingId, datasetSeqId, paginationData) => {
    return await ImageManagementService.getImagesForDataset(url, trainingId, datasetSeqId, paginationData);
  };

  deleteImagesForDataset = async (trainingId, datasetSeqId, data) => {
    return await ImageManagementService.deleteImagesForDataset(trainingId, datasetSeqId, data);
  };

  saveEditImageClassDetails = async (trainingId, datasetSeqId, imageData, url = "") => {
    return await ImageManagementService.saveEditImageClassDetails(trainingId, datasetSeqId, imageData, url);
  };

  changeImageType = async (trainingId, imgType, imageData) => {
    return await ImageManagementService.changeImageType(trainingId, imgType, imageData);
  };

  updateImagePaginationStartIndex = (data) => {
    this.imagePaginationStartIndex = data;
  };

  updateclassPaginationStartIndex = (data) => {
    this.classPaginationStartIndex = data;
  };

  setSelectedClassImage = (imageSeqNos, classData) => {
    let selectedImages = [];
    imageSeqNos.forEach((element) => {
      selectedImages.push({ imageSeqNo: element, classSeqNo: classData.seqNo, className: classData.className });
    });
    this.selectedClassImages = [...this.selectedClassImages, ...selectedImages];
  };

  removeSelectedClassImage = (imageSeqNo, classSeqNo) => {
    this.selectedClassImages = this.selectedClassImages.filter(
      (image) => image.classSeqNo !== classSeqNo || !imageSeqNo.includes(image.imageSeqNo)
    );
  };

  clearClassSpecificImageSelection = (classSeqNo) => {
    this.selectedClassImages = this.selectedClassImages.filter((image) => image.classSeqNo !== classSeqNo);
  };

  clearSelectedClassImages = () => {
    this.selectedClassImages = [];
  };

  getSelectedClassImagesCount(classSeqNo) {
    const selectedImages = this.selectedClassImages.filter((image) => image.classSeqNo === classSeqNo);
    return selectedImages.length;
  }
}
export default createContext(new ImageManagementStore());
