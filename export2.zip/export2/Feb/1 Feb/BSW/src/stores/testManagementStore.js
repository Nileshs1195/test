import { action, computed, makeObservable, observable } from "mobx";
import { createContext } from "react";
import { API_RESPONSE } from "../appconstants";
import { convertToTimezone } from "../helpers/CommonMethods";
import * as TestManagementService from "../services/testManagementService";

class TestManagementStore {
  testingList = [];
  selectedTestingList = [];
  testDataset = [];
  selectedTestDataset = [];
  selectedTestModel = [];
  selectedConfusionMatrixClasses = [];
  selectedconfusionMatrixImages = [];
  testingData = {};
  selectedClasses = [];
  updatedClassificationData = { isListUpdated: false, updatedList: [] };

  constructor() {
    makeObservable(this, {
      testingList: observable,
      selectedTestingList: observable,
      testDataset: observable,
      selectedTestDataset: observable,
      selectedTestModel: observable,
      selectedConfusionMatrixClasses: observable,
      selectedconfusionMatrixImages: observable,
      testingData: observable,
      selectedClasses: observable,
      updatedClassificationData: observable,
      selectedTestingListCount: computed,
      selectedTestDatasetCount: computed,
      fetchTestingList: action,
      insertTestingList: action,
      deleteTestingList: action,
      deleteMultipleTestingList: action,
      fetchTestDataset: action,
      fetchConfusionMatrixData: action,
      fetchConfusionMatrixImageListData: action,
      addConfusionMatrixClass: action,
      removeConfusionMatrixClass: action,
      setSelectedClasses: action,
      updateClassificationData: action,
      setTestingData: action
    });
  }

  setTestingList = (data) => {
    this.testingList = data;
  };

  setTestDatasetList = (data) => {
    this.testDataset = data;
  };

  setSelectedTestingListRecord = (selectedRecord) => {
    selectedRecord.selected = true;
    this.selectedTestingList = [...this.selectedTestingList, selectedRecord];
  };

  removeSelectedTestingListRecord = (testingListID) => {
    this.selectedTestingList = this.selectedTestingList.filter((item) => item._id !== testingListID);
  };

  get selectedTestingListCount() {
    return this.selectedTestingList.length;
  }

  clearSelectedTestingList = () => {
    this.selectedTestingList = [];
  };

  setSelectedClasses = (data) => {
    this.selectedClasses = data;
  };

  updateClassificationData = (data) => {
    this.updatedClassificationData = data;
  };

  fetchTestingList = async () => {
    return await TestManagementService.getTestingList().then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        let testings = response?.data?.map((test) => {
          test.updatedAt = convertToTimezone(test?.updatedAt);
          return test;
        });
        this.setTestingList(testings);
      }
    });
  };

  insertTestingList = async (data) => {
    return await TestManagementService.insertTestingList(data);
  };

  deleteTestingList = async (testID) => {
    return await TestManagementService.deleteTestingList(testID);
  };

  deleteMultipleTestingList = async (recordID) => {
    return await TestManagementService.deleteMultipleTestingList(recordID);
  };

  updateTestingList = async (testID, updateData) => {
    return await TestManagementService.updateTestingList(testID, updateData);
  };

  copyAndReexecuteTest = async (testID, payLoad) => {
    return await TestManagementService.copyAndReexecuteTest(testID, payLoad);
  };

  fetchTestDataset = async (testId) => {
    return await TestManagementService.getTestDataset(testId).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {

        let datasets = response?.data?.map(dataset => {
          dataset.updatedAt = convertToTimezone(dataset?.updatedAt);
          return dataset;
        });
        this.setTestDatasetList(datasets);

        if (response?.testing?.updatedAt) {
          response.testing.updatedAt = convertToTimezone(response?.testing?.updatedAt);
        }
        this.setTestingData(response.testing)
      }
      return response;
    });
  };

  setTestingData = (data) => {
    this.testingData = data;
  };

  clearTestingData = () => {
    this.testingData = [];
  };

  get selectedTestDatasetCount() {
    return this.selectedTestDataset.length;
  }

  clearSelectedTestDataset = () => {
    this.selectedTestDataset = [];
  };

  setSelectedTestDatasetRecord = (selectedRecord) => {
    selectedRecord.selected = true;
    this.selectedTestDataset = [...this.selectedTestDataset, selectedRecord];
  };

  removeSelectedTestDatasetRecord = (testDatasetID) => {
    this.selectedTestDataset = this.selectedTestDataset.filter((item) => !testDatasetID.includes(item.seqNo));
  };

  createTestDataset = async (testId, data) => {
    return await TestManagementService.createTestDataset(testId, data);
  };

  deleteTestDataset = async (testId, data) => {
    return await TestManagementService.deleteTestDataset(testId, data);
  };

  updateTestDataset = async (testID, updateData) => {
    return await TestManagementService.updateTestDataset(testID, updateData);
  };

  setSelectedTestModel = async (testId, trainingId) => {
    const testIndex = this.selectedTestModel.findIndex((item) => item.id === testId);
    if (testIndex < 0) {
      this.selectedTestModel.push({ testId: testId, trainingId: trainingId });
    } else {
      this.selectedTestModel[testIndex].trainingId = trainingId;
    }
  };

  fetchConfusionMatrixData = async (testId, payload) => {
    return await TestManagementService.getConfusionMatrixData(testId, payload);
  };

  fetchConfusionMatrixImageListData = async (testId, payload) => {
    return await TestManagementService.getConfusionMatrixImageListData(testId, payload);
  };

  addConfusionMatrixClass = (data) => {
    this.selectedConfusionMatrixClasses = [...this.selectedConfusionMatrixClasses, ...data];
  };

  removeConfusionMatrixClass = (setClassName, actualClassName) => {
    this.selectedConfusionMatrixClasses = this.selectedConfusionMatrixClasses.filter(
      (element) => element.setClassName !== setClassName || (actualClassName && element.actualClassName !== actualClassName)
    );
  };

  clearConfusionMatrixClass = () => {
    this.selectedConfusionMatrixClasses = [];
  };

  addConfusionMatrixImages = (data) => {
    this.selectedconfusionMatrixImages = [...this.selectedconfusionMatrixImages, ...data];
  };

  removeConfusionMatrixImages = (id) => {
    this.selectedconfusionMatrixImages = this.selectedconfusionMatrixImages.filter(
      (element) => !(element.imageSeqNo === id.imageSeqNo && element.classSeqNo === id.classSeqNo)
    );
  };

  clearConfusionMatrixImages = () => {
    this.selectedconfusionMatrixImages = [];
  };

  getBatch = async (id, seqNo) => {
    return await TestManagementService.getBatch(id, seqNo);
  };

  executeTesting = async (id, seqNos) => {
    return await TestManagementService.executeTesting(id, seqNos);
  };

  saveTestModel = async (id, data) => {
    return await TestManagementService.saveTestModel(id, data);
  };

  setConfusionMatrixNewClass = async (id, payLoad) => {
    return await TestManagementService.setConfusionMatrixNewClass(id, payLoad);
  };

  stopExecutionLog = async (id, seqNo) => {
    return await TestManagementService.stopExecutionLog(id, seqNo);
  };

  changeDatasetOrder = async (id, payload) => {
    return await TestManagementService.changeDatasetOrder(id, payload);
  }
}
export default createContext(new TestManagementStore());
