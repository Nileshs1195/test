import { action, makeAutoObservable, makeObservable, observable } from "mobx";
import { createContext } from "react";
import { IMAGE_GROUP_LIST } from "../appconstants";
import { SETTINGS } from "../appsettings";
import { getItem } from "../core/utils/storagehelper";
import * as userservice from "./../services/userservice";
import { removeField, upsert } from "./../helpers/arrayutils";

class AppStore {
  breadcrumbs = [];
  inspectionGridColumnPreference = [];
  inspectionGridHiddenColumns = [];
  selectedInspectionTab = 0;
  paginationStartIndex = 0;
  uploaderAction = {
    type: "",
    isOpen: false
  };
  loader = false;
  loaderMessage = "";
  snapbarMessage = {
    message: "",
    type: "success",
    open: false
  };
  inspectionSearchFilter = {
    fromDate: new Date(
      new Date(
        new Date().setDate(
          new Date().getDate() - SETTINGS.INSPECTION_GRID.DATE_OFFSET,
        ),
      ).setHours(0, 0, 0, 0),
    ),
    toDate: new Date(),
    pageSize: 25,
    pageNo: 0,
    filter: [],
    lock: {},
    sort: [],
    validStatus: false,
  }
  inspectionListFilterPreference = []
  selectedWaferListColumn = IMAGE_GROUP_LIST.PAGINATION.DEFAULT

  imageListFilter = {
    pageSize: SETTINGS.IMAGE_LIST.ITEM_PER_PAGE,
    pageNo: 0,
  }

  initialFilterUserPreferenceAvailable = false

  suggestionResult = []
  selectedSuggestionResultClass = []
  constructor() {
    makeAutoObservable(this, {
      breadcrumbs: observable,
      inspectionGridColumnPreference: observable,
      inspectionGridHiddenColumns: observable,
      selectedInspectionTab: observable,
      inspectionSearchFilter: observable,
      selectedWaferListColumn: observable,
      inspectionListFilterPreference: observable,
      snapbarMessage: observable,
      loader: observable,
      loaderMessage: observable,
      imageListFilter: observable,
      suggestionResult: observable,
      selectedSuggestionResultClass: observable,
      uploaderAction: observable,
      setUploaderAction: action,
      updateFromDate: action,
      updateToDate: action,
      updateInspectionGridPageSize: action,
      updateInspectionGridPageNo: action,
      updateInspectionListValidStatus: action,
      addBreadcrumb: action,
      removeBreadcrumb: action,
      removeLastBreadcrumb: action,
      updateLastBreadcrumb: action,
      setSelectedInspectionTab: action,
      addInspectionGridColumnPreference: action,
      addInspectionGridHiddenColumns: action,
      setSelectedWaferListColumn: action,
      updateInspectionSearchFilter: action,
      updateInspectionSearchFilterField: action,
      updateInspectionSearchSortField: action,
      clearInspectionSearchFilterField: action,
      updateSort: action,
      updateFilter: action,
      setsnapbarMessage: action,
      setLoader: action,
      setLoaderMessage: action,
      updateUserPreference: action,
      fetchUserPreference: action,
      saveColumnPreference: action,
      updateImageListFilter: action,
      resetImageListFilter: action,
      removeAllBreadcrumbs: action,
      addSuggestionResultClasses: action,
      updateSuggestionResult: action,
    })

    const sortingPreferences = getItem(
      SETTINGS.LOCAL_STORAGE_KEYS.INSPECTION_LIST_SORT_DATA,
    )
    const inspectionSearchFilter = JSON.parse(sortingPreferences)
    if (inspectionSearchFilter)
      this.inspectionSearchFilter.sort = inspectionSearchFilter
  }

  setsnapbarMessage = data => {
    this.snapbarMessage = data;
  }

  setLoader = data => {
    this.loader = data;
  }

  setLoaderMessage = data => {
    this.loaderMessage = data;
  }

  setUploaderAction = (data) => {
    this.uploaderAction = data;
  }

  updateFromDate = date => {
    this.inspectionSearchFilter.fromDate = date;
  };

  updateToDate = (date) => {
    this.inspectionSearchFilter.toDate = date
  }

  updatePaginationStartIndex = (data) => {
    this.paginationStartIndex = data
  }

  updateInspectionListValidStatus = (status) => {
    this.inspectionSearchFilter.validStatus = status
  }

  updateInspectionGridPageSize = (size) => {
    this.inspectionSearchFilter.pageSize = size
  }

  updateInspectionGridPageNo = (no) => {
    this.inspectionSearchFilter.pageNo = no
  }

  clearInspectionSearchFilterField = () => {
    this.updateInspectionSearchFilterField([])
  }

  updateInspectionSearchFilterField = (filter) => {
    this.inspectionSearchFilter.filter = filter
  }

  updateInspectionSearchSortField = (sort) => {
    this.inspectionSearchFilter.sort = sort
  }

  updateUserPreference = (userPref) => {
    let filterPreferences = this.inspectionListFilterPreference
    if (userPref.saveFilter && userPref.operator) {
      let singlePrefIndex = filterPreferences.findIndex(
        (preference) => preference.columnId === userPref.field,
      )
      if (singlePrefIndex !== -1) {
        filterPreferences[singlePrefIndex] = this.getFilterPreference(userPref)
      } else {
        let singlePref = this.getFilterPreference(userPref)
        filterPreferences.push(singlePref)
      }
      return true
    } else {
      let singlePref = filterPreferences.filter(
        (preference) => preference.columnId === userPref.field,
      )
      if (singlePref.length) {
        filterPreferences = filterPreferences.filter(
          (preference) => preference.columnId !== userPref.field,
        )
        this.inspectionListFilterPreference = filterPreferences
        return true
      }
    }

    return false
  }

  getFilterPreference(source) {
    return {
      columnId: source.field,
      operator: source.operator,
      value1: source.valueFirst,
      value2: source.valueSecond,
      exclude: source.exclude,
    }
  }

  updateInspectionSearchFilter = (column) => {
    this.updateFilter(column)
    this.updateSort(column)
  }

  updateFilter = (column) => {
    let filter = []
    if (Boolean(column.operator)) {
      filter = upsert(this.inspectionSearchFilter.filter, column)
    } else {
      filter = removeField(this.inspectionSearchFilter.filter, column.field)
    }
    this.updateInspectionSearchFilterField(filter)
  }

  updateSort = (columnDetails) => {
    let column = {
      asc: columnDetails.asc,
      field: columnDetails.field,
      isColumnLocked: columnDetails.isColumnLocked,
    }
    let sort = []
    let asc = column.asc
    if (asc !== undefined) {
      if (column.isColumnLocked) {
        if (this.inspectionSearchFilter.sort.length) {
          sort = this.inspectionSearchFilter.sort.filter(
            (item) => item.isColumnLocked,
          )
          let index = sort.findIndex((item) => item.field === column.field)
          if (index === -1) {
            sort.push(column)
          } else {
            sort[index].asc = column.asc
          }
          let nSort = this.inspectionSearchFilter.sort.filter(
            (item) => !item.isColumnLocked,
          )
          if (nSort.length && column.field !== nSort[0].field) {
            sort.push(nSort[0])
          }
        } else {
          sort = upsert(this.inspectionSearchFilter.sort, column)
        }
      } else {
        sort = this.inspectionSearchFilter.sort.filter(
          (item) => item.isColumnLocked && item.field !== column.field,
        )
        sort.push(column)
      }
    } else {
      sort = this.inspectionSearchFilter.sort.filter(
        (item) => item.field !== column.field,
      )
    }
    this.updateInspectionSearchSortField(sort)
  }

  getBreadcrumbIndex = (bradcrumb) => {
    return this.breadcrumbs.findIndex((item) => item.path === bradcrumb.path)
  }

  addBreadcrumb = (bradcrumb) => {
    const index = this.getBreadcrumbIndex(bradcrumb)
    if (index === -1) {
      this.breadcrumbs = [...this.breadcrumbs, bradcrumb]
    }
  }
  removeAllBreadcrumbs = () => {
    this.breadcrumbs = []
  }

  removeBreadcrumb = (bradcrumb) => {
    const index = this.getBreadcrumbIndex(bradcrumb)
    this.breadcrumbs = this.breadcrumbs.slice(0, index + 1)
  }

  removeLastBreadcrumb = () => {
    this.breadcrumbs.pop()
  }

  updateLastBreadcrumb = (breadcrumb) => {
    this.removeLastBreadcrumb()
    this.addBreadcrumb(breadcrumb)
  }

  setSelectedInspectionTab = (tab) => {
    this.selectedInspectionTab = tab
  }

  addInspectionGridColumnPreference = (columnPreference) => {
    this.inspectionGridColumnPreference = columnPreference
  }

  addInspectionGridHiddenColumns = (columns) => {
    this.inspectionGridHiddenColumns = columns
  }

  setSelectedWaferListColumn = (column) => {
    this.selectedWaferListColumn = column
  }

  updateUserPreferences = (data) => {
    if (data !== undefined && data !== null) {
      this.inspectionListFilterPreference = data
      this.inspectionSearchFilter.filter = data.map((filterPref) => {
        return {
          exclude: filterPref.exclude,
          field: filterPref.columnId,
          operator: filterPref.operator,
          valueFirst: filterPref.value1,
          valueSecond: filterPref.value2,
          saveFilter: true,
        }
      })
    }
  }
  fetchUserPreference = async () => {
    const columnPreference = await userservice.getUserColumnPrefence()
    if (columnPreference) return columnPreference
  }

  saveColumnPreference = async (columnPreference) => {
    await userservice.saveUserColumnPreference(columnPreference)
  }

  saveUserPreferences = async (userPrefs) => {
    await userservice.saveFilterPreferenceData(userPrefs)
  }

  getUserPreferences = async () => {
    return await userservice.getUserPreferences()
  }

  updateImageListFilter = (pageNo, pageSize) => {
    this.imageListFilter = { pageNo, pageSize }
  }

  resetImageListFilter = () => {
    this.imageListFilter = {
      pageSize: SETTINGS.IMAGE_LIST.ITEM_PER_PAGE,
      pageNo: 0,
    }
  }

  addSuggestionResultClasses = (data) => {
    this.suggestionResult = [...this.suggestionResult, data]
  }

  updateSuggestionResult = (data) => {
    this.suggestionResult = data
  }

  setSelectedSuggestionResultClass = (selectedClass) => {
    selectedClass.selected = true;
    this.selectedSuggestionResultClass = [
      ...this.selectedSuggestionResultClass,
      selectedClass,
    ]
    console.log(this.selectedSuggestionResultClass);
  }

  removeSelectedSuggestionResultClass = (removedClass) => {
    removedClass.selected = !removedClass.selected
    this.selectedSuggestionResultClass = this.selectedSuggestionResultClass.filter(
      (item) => item.seqNo !== removedClass.seqNo,
    )
  }
  
  clearSelectedSuggestionResultClass = (selectedClasses) =>{
    selectedClasses.forEach((item)=>{
      this.removeSelectedSuggestionResultClass(item);
    })
  }

  resetSuggestionResultData = (suggestionList) => {
    this.selectedSuggestionResultClass.map(item => {
      let index = this.suggestionResult.findIndex(obj => obj.seqNo === item.seqNo);
      this.suggestionResult[index] = suggestionList[index]
    });
  }

  resetAllSuggestionResultData = (suggestionResult, data = []) => {
    this.suggestionResult = suggestionResult
    this.suggestionResult = [...this.suggestionResult, data];
  }
}

export default createContext(new AppStore())
