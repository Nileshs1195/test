import { action, computed, makeObservable, observable } from "mobx";
import { createContext } from "react";
import * as TrainingManagementService from "../services/trainingmanagementservice";
import { API_RESPONSE } from "../appconstants";
import { convertToTimezone } from "../helpers/CommonMethods";
import { sort } from '../helpers/arrayutils';

class TrainingManagementStore {
  TrainingDataset = [];
  selectedTrainingDataset = [];
  TrainingInputparameter = [];
  executedModels = [];
  selectedInputParameter = [];
  InputParameterTotalCount = null;
  viewParameter = false;
  snapbarMessage = {
    message: "",
    type: "success",
    open: false
  };
  destinationClassSeqNo = "";
  sourceClassSeqNo = "";
  isActionDisabled = false;
  tabIndex = 0;
  trainingListData = [];
  trainingListDataCount = null;
  selectedTrainingListData = [];
  reloadList = false;
  TrainingDatasetTotalCount = null;
  executionLogData = [];
  selectedExecutionLogData = [];
  trainingId = null;
  suggestionResultData = [];
  suggestionClassList = [];
  subclassificationImages = [];
  //TrainingDatasetTotalCount = 0;
  sortParameter = {
    sortBy: "waferId",
    sortOrder: "Ascending"
  };
  selectedMasks = [];
  updateGroupName = {};
  subclassificationSelectedGraphImages = [];

  constructor() {
    makeObservable(this, {
      TrainingDataset: observable,
      TrainingInputparameter: observable,
      executedModels: observable,
      sortParameter: observable,
      selectedTrainingDataset: observable,
      selectedTrainingListData: observable,
      TrainingDatasetTotalCount: observable,
      trainingListData: observable,
      trainingListDataCount: observable,
      snapbarMessage: observable,
      isActionDisabled: observable,
      tabIndex: observable,
      reloadList: observable,
      trainingId: observable,
      viewParameter: observable,
      suggestionResultData: observable,
      subclassificationImages: observable,
      destinationClassSeqNo: observable,
      sourceClassSeqNo: observable,
      selectedMasks: observable,
      subclassificationSelectedGraphImages: observable,
      setDestinationClassSeqNo: action,
      setSubclassificationImages: action,
      setViewParameter: action,
      setTrainingId: action,
      setActionDisabled: action,
      setTabIndex: action,
      setSnapbarMessage: action,
      setTrainingDataset: action,
      setInputparameter: action,
      setSelectedTrainingDataset: action,
      removeSelectedTrainingDataset: action,
      removeSelectedTrainingDatasets: action,
      clearSelectedTrainingDataset: action,
      selectedDataSetCount: computed,
      setSelectedTrainingListRecord: action,
      removeSelectedTrainingListData: action,
      removeSelectedTrainingListDataList: action,
      clearSelectedTrainingListData: action,
      selectedTrainingListDataCount: computed,
      setTrainingListData: action,
      setTrainingListDataTotalCount: action,
      setTrainingDatasetTotalCount: action,
      setImageGroupGridSortParams: action,
      setReloadList: action,

      selectedInputParameter: observable,
      setselectedInputParameter: action,
      selectedInputParameterCount: computed,
      setInputParameterTotalCount: action,
      removeselectedInputParameter: action,
      removeselectedInputParameters: action,
      clearselectedInputParameter: action,
      clearTrainingDataset: action,
      setSuggestionResultData: action,
      updateSuggestionResultData: action,
      executionLogData: observable,
      selectedExecutionLogData: observable,
      suggestionClassList: observable,
      setSuggestionClassList: action,
      setSelectedMasks: action,
      updateMaskingCoordinates: action,
      updateSelectedMasks: action,
      removeTransferedSelectedMasks: action,
      setSubclassificationSelectedGraphImages: action
    });
  }

  setSubclassificationSelectedGraphImages = (data) => {
    this.subclassificationSelectedGraphImages = data;
  }

  setSelectedMasks = (data) => {
    let doc = this.selectedMasks.findIndex(obj=>obj.classSeqNo === data.classSeqNo);
    if(doc !== -1){
      this.selectedMasks[doc] = data;
    }else {
      this.selectedMasks = [...this.selectedMasks,data]
    }  
  }

  updateSelectedMasks = (seqNo,data) => {
    let doc = this.selectedMasks.findIndex(obj=>obj.classSeqNo === seqNo);
    if(doc !== -1){
      let updateData = [...this.selectedMasks[doc]['masks'],...data]
      this.selectedMasks[doc]['masks'] = updateData;
    }
  }

  removeTransferedSelectedMasks = (sourceSeqNo,imageSeqNo) => {
    let doc = this.selectedMasks.findIndex(obj=>obj?.classSeqNo === sourceSeqNo);
    if(doc !== -1){
      imageSeqNo.map((seqNo)=>{
        let updateData = this.selectedMasks[doc]['masks'].filter(img=> img?.imageSeqNo !== seqNo)
        this.selectedMasks[doc]['masks'] = updateData;
      })
    }
  }

  setDestinationClassSeqNo = seqNo => {
    this.destinationClassSeqNo = seqNo;
  }

  setSourceClassSeqNo = seqNo => {
    this.sourceClassSeqNo = seqNo;
  }

  setSubclassificationImages = (data) => {
    this.subclassificationImages = data;
  }

  setTrainingId = (id) => {
    this.trainingId = id;
  };

  setSnapbarMessage = (data) => {
    this.snapbarMessage = data;
  };

  setTrainingDataset = (data) => {
    this.TrainingDataset = sort(data, 'classOrder', true);
  };

  setReloadList = (data) => {
    this.reloadList = data;
  };

  setTrainingDatasetTotalCount = (data) => {
    this.TrainingDatasetTotalCount = data;
  };

  clearTrainingDataset = () => {
    this.TrainingDataset = [];
  };

  fetchTrainingDataset = async (data) => {
    return await TrainingManagementService.getTrainingWithDataset(data).then((response) => {
      if (response && response?.data) {
        let datasets = response?.data?.map(dataset => {
          dataset.updatedAt = convertToTimezone(dataset?.updatedAt);
          return dataset;
        });
        console.log(datasets);
        this.setTrainingDataset(datasets);
        this.setTrainingDatasetTotalCount(response.data.length);
        if (response?.training) {
          if (response?.training?.updatedAt) {
            response.training.updatedAt = convertToTimezone(response?.training?.updatedAt);
          }
          this.setSelectedTrainingListRecord(response.training);
        }
      }
    });
  };

  fetchTrainingDatasetWithTraining = async (data) => {
    return await TrainingManagementService.getTrainingWithDataset(data).then((response) => {
      if (response && response?.data) {
        let datasets = response?.data?.map(dataset => {
          dataset.updatedAt = convertToTimezone(dataset?.updatedAt);
          return dataset;
        });
        this.setTrainingDataset(datasets);
        this.clearSelectedTrainingListData();
        // this.setTrainingDataset([...response.data]);
        this.setTrainingDatasetTotalCount(response.data.length);
        if (response?.training) {
          let totalImages = 0;
          if (response?.training?.classData) {
            let classData = Object.keys(response?.training?.classData).map((key) => response?.training?.classData[key]);
            if (classData?.length > 0) {
              classData?.forEach(data => {
                totalImages += (data?.trainCount + data?.validationCount)
              });
            }

            if (response?.training?.updatedAt) {
              response.training.updatedAt = convertToTimezone(response?.training?.updatedAt);
            }
          }
          response.training.totalImages = totalImages;
          this.setSelectedTrainingListRecord({ ...response.training });
        }
      }
    });
  };

  updateDatasetImageCount = async (seqNo, count) => {
    let datasets = this.TrainingDataset.filter(obj => {
      if (obj.seqNo === seqNo) {
        obj.imgCount = obj.imgCount >= count ? obj.imgCount - count : 0;
      }
      return obj;
    });
    this.setTrainingDataset([...datasets]);
  }

  fetchTrainingListDataData = async () => {
    return await TrainingManagementService.getTrainingListtData();
  };

  setSelectedTrainingDataset = (selectedRow) => {
    selectedRow.selected = true;
    this.selectedTrainingDataset = [...this.selectedTrainingDataset, selectedRow];
  };
  
  setInputparameter = (data) => {
    this.TrainingInputparameter = sort(data, 'classOrder', true);
  };

  setInputParameterTotalCount = (data) => {
    this.InputParameterTotalCount = data;
  };

  setViewParameter = (data) => {
    this.viewParameter = data;
  };

  setActionDisabled = (data) => {
    this.isActionDisabled = data;
  };

  setTabIndex = (data) => {
    this.tabIndex = data;
  };

  setselectedInputParameter = (selectedRow) => {
    selectedRow.selected = true;
    this.selectedInputParameter = [...this.selectedInputParameter, selectedRow];
  };

  get selectedInputParameterCount() {
    return this.selectedInputParameter.length;
  }
  removeselectedInputParameter = (inputParameterId) => {
    this.selectedInputParameter = this.selectedInputParameter.filter((inputParameter) => inputParameter.seqNo !== inputParameterId);
  };

  removeselectedInputParameters = (inputParameterIds) => {
    this.selectedInputParameter = this.selectedInputParameter.filter((inputParameter) => !inputParameterIds.includes(inputParameter.seqNo));
  };

  clearselectedInputParameter = () => {
    this.selectedInputParameter = [];
  };

  removeSelectedTrainingDataset = (dataSetId) => {
    this.selectedTrainingDataset = this.selectedTrainingDataset.filter((dataSet) => dataSet.seqNo !== dataSetId);
  };

  removeSelectedTrainingDatasets = (dataSetIds) => {
    this.selectedTrainingDataset = this.selectedTrainingDataset.filter((dataSet) => !dataSetIds.includes(dataSet.seqNo));
  };

  clearSelectedTrainingDataset = () => {
    this.selectedTrainingDataset = [];
  };

  get selectedDataSetCount() {
    return this.selectedTrainingDataset.length;
  }

  setTrainingListData = (data) => {
    this.trainingListData = data;
  };

  setTrainingListDataTotalCount = (data) => {
    this.trainingListDataCount = data;
  };

  clearTrainingListData = () => {
    this.setTrainingListData([]);
    this.setTrainingListDataTotalCount(0);
  };

  fetchTrainingListData = async (seqnos = null) => {
    await TrainingManagementService.getTrainingListData(seqnos).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        let trainings = response?.data?.map(training => {
          training.subClassificationStatus = training?.subCassificationBatch?.status === "Ok" ? "Subclassification Executed" : "";
          training.maskingStatus = training?.maskingBatch?.status === "Ok" || training?.maskingBatch?.status === 7 ? "Masking Executed" : "";
          let totalImages = 0;
          if (training?.classData) {
            let classData = Object.keys(training?.classData).map((key) => training?.classData[key]);
            if (classData?.length > 0) {
              classData?.forEach(data => {
                totalImages += (data?.trainCount + data?.validationCount)
              });
            }
          }
          training.totalImages = totalImages;
          training.updatedAt = convertToTimezone(training?.updatedAt);
          return training;
        });
        this.setTrainingListData(trainings);
        this.setTrainingListDataTotalCount(response?.data?.length);
      } else {
        console.log("Error occurred while fetching training list data");
      }
    });
  };

  fetchImageGroupData = async (data) => {
    const imageGroupList = [];
    const imageGroupData = await TrainingManagementService.getImageGrouptData();
    if (imageGroupData && imageGroupData.data) {
      const groupData = imageGroupData.data.map((item) => {
        const container = {};
        container["id"] = item._id;
        container["groupName"] = item.groupName;
        return container;
      });
      return groupData;
    } else {
      return imageGroupList;
    }
  };

  setSelectedTrainingListRecord = (selectedRow) => {
    selectedRow.selected = true;
    this.selectedTrainingListData = [...this.selectedTrainingListData, selectedRow];
  };

  removeSelectedTrainingListData = (dataSetId) => {
    this.selectedTrainingListData = this.selectedTrainingListData.filter((dataSet) => dataSet._id !== dataSetId);
  };

  removeSelectedTrainingListDataList = (dataSetIds) => {
    this.selectedTrainingListData = this.selectedTrainingListData.filter((dataSet) => !dataSetIds.includes(dataSet._id));
  };

  clearSelectedTrainingListData = () => {
    this.selectedTrainingListData = [];
  };

  get selectedTrainingListDataCount() {
    return this.selectedTrainingListData.length;
  }

  setImageGroupGridSortParams = (key, val) => {
    this.sortParameter[key] = val;
  };

  editDatasetAPI = async (trainingId, reqPayload) => {
    return await TrainingManagementService.editDatasetService(trainingId, reqPayload);
  };

  saveNewPercentages = async (trainingId, reqPayload) => {
    return await TrainingManagementService.saveNewPercentages(trainingId, reqPayload);
  };

  deleteDatasetRecords = async (trainingId, reqPayload) => {
    return await TrainingManagementService.deleteDatasetRecords(trainingId, reqPayload);
  };

  getMaskingStatus = async (trainingId, reqPayload) => {
    return await TrainingManagementService.getMaskingStatus(trainingId, reqPayload);
  };

  createDuplicateDataset = async (trainingId, reqPayload) => {
    return await TrainingManagementService.createDuplicateDataset(trainingId, reqPayload);
  };

  fetchTrainedDataSetRecords = async (trainingId) => {
    return await TrainingManagementService.getTrainedDataSetRecords(trainingId);
  };

  setExecutionLogData = (data) => {
    this.executionLogData = data;
  };

  clearExecutionLogData = () => {
    this.executionLogData = [];
  };

  insertDatasetRecord = async (traningId, data) => {
    var result;
    await TrainingManagementService.insertDatasetRecord(traningId, data).then((response) => {
      result = response;
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        console.log("Dataset record saved successfully");
      } else {
        console.log("Error occurred while saving dataset record");
      }
    });
    return result;
  };

  fetchTrainParamsData = async (data) => {
    return await TrainingManagementService.getTrainParamsData(data);
  };

  updateTrainingInputparameterList = async (data, seqNo) => {
    const trainListData = this.TrainingInputparameter;
    const trainData = trainListData?.map((item) => {
      if (item.seqNo === seqNo) {
        item.priorKnowledge = data?.priorKnowledge ? "Yes" : "No";
        item.className = data?.className;
      }
      return item;
    });
    this.setInputparameter(trainData);
  };

  saveParameterData = async (trainingId, data) => {
    this.clearSelectedTrainingListData();
    let response = await TrainingManagementService.insertParameterData(trainingId, data);
    if (response?.data?._id) {
      this.setSelectedTrainingListRecord(response.data);
    }
    return response;
  };

  fetchInputSelectedData = (async) => {
    const selectedData = this.selectedInputParameter;
    const trainData = selectedData.map((item) => item.seqNo);
    return trainData.join();
  };

  fetchTrainParamsDeveleperMode = async (data) => {
    return await TrainingManagementService.getTrainParamsCommonData(data);
  };

  insertTrainParamsCommonData = async (traningId, commonData) => {
    return await TrainingManagementService.insertTrainParamsCommonData(traningId, commonData);
  };

  subclassificationResult = async (id, seqNo) => {
    return await TrainingManagementService.subclassificationResult(id, seqNo);
  };

  insertTrainParamsData = async (traningId, insertData) => {
    return await TrainingManagementService.insertTrainParamsData(traningId, insertData);
  };

  insertTrainingListRecord = async (trainingListData) => {
    return await TrainingManagementService.insertTrainingListRecord(trainingListData);
  };

  cloneTrainingListRecord = async (recordID, data) => {
    return await TrainingManagementService.cloneTrainingListRecord(recordID, data);
  };

  updateTrainingRecordData = async (recordID, updateData) => {
    return await TrainingManagementService.updateTrainingRecordData(recordID, updateData);
  };

  deleteTrainingListRecord = async (recordID) => {
    return await TrainingManagementService.deleteTrainingListRecord(recordID);
  };
  deleteMultipleTrainingListRecords = async (recordID) => {
    return await TrainingManagementService.deleteMultipleTrainingListRecords(recordID);
  };

  insertInputParameterRecord = async (inputParameterData) => {
    let status = false;
    const response = await TrainingManagementService.insertInputParameterRecord(inputParameterData);
    if (response.result === "Record Created Successfully") {
      //this.selectedInputParameter(response.data);
      status = true;
    }
    return status;
  };

  updateInputParameter = async (editData, inputId) => {
    const response = await TrainingManagementService.updateInputParameterServices(editData, inputId);
    if (response !== undefined && response[0].result === "successfully updated") {
      return true;
    } else {
      return null;
    }
  };

  changeTrainingStatus = async (id, mode, reqPayload) => {
    const response = await TrainingManagementService.changeTrainingStatus(id, mode, reqPayload);
    if (response !== undefined && response[0].result === "successfully updated") {
      return true;
    } else {
      return null;
    }
  };

  startExecution = async (id, mode, reqPayload) => {
    return await TrainingManagementService.startExecution(id, mode, reqPayload);
  };

  stopExecution = async (id, seqNo) => {
    return await TrainingManagementService.stopExecution(id, seqNo);
  };

  getBatch = async (id, seqNo) => {
    return await TrainingManagementService.getBatch(id, seqNo);
  };

  saveAugmentationMode = async (trainingId, data) => {
    return await TrainingManagementService.saveAugmentationMode(trainingId, data);
  };

  getAugmentationMode = async (trainingId) => {
    return await TrainingManagementService.getAugmentationMode(trainingId);
  };

  fetchExecutionLogData = async (trainingId, seqNo) => {
    return await TrainingManagementService.getExecutionLogData(trainingId, seqNo);
  };

  fetchListingExecutedModal = async () => {
    this.executedModels = [];
    return await TrainingManagementService.getListingExecuteModal().then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE && response?.data?.length > 0) {
        this.executedModels = response.data;
      }
    });
  };

  saveExecutedDatasetClone = async (data) => {
    console.log(data);
    return await TrainingManagementService.saveExecutedDatasetClone(data);
  };

  fetchSuggestionResultData = async (trainingID, seqNo) => {
    return await TrainingManagementService.classificationDatasets(trainingID, seqNo).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        let data = []
        response.data.forEach((e) => {
          data.push({ className: e.className, seqNo: e.seqNo, list: {}, selected: true })
        });
        this.setSuggestionResultData(data);
      }
    });
  };

  fetchSuggestionResult = async (trainingID, seqNo) => {
    return await TrainingManagementService.classificationDatasets(trainingID, seqNo);
  };


  setSuggestionResultData = (data) => {
    this.suggestionResultData = data;
  };

  updateSuggestionResultData = (data) => {
    this.suggestionResultData = [...this.suggestionResultData, data];
  };

  addClassSuggestionResultData = (positionIndex, data) => {
    console.log(positionIndex);
    // let index = this.suggestionResultData.length > 5 ? 4 : this.suggestionResultData.length;
    let record = {
      className: data.className,
      seqNo: data.seqNo,
      list: {
        imageLeft: [],
        imageRight: []
      }
    }
    this.suggestionResultData.splice(positionIndex, 0, record);
  };

  clearSuggestionResultData = () => {
    this.suggestionResultData = [];
  };

  subclassificationSuggestionResult = async (trainingID, seqNo) => {
    return await TrainingManagementService.subclassificationSuggestionResult(trainingID, seqNo);
  };

  subclassificationSuggestionImages = async (trainingID, seqNo, data) => {
    return await TrainingManagementService.subclassificationSuggestionImage(trainingID, seqNo, data);
  };

  subclassificationSuggestionGraphData = async (trainingID, seqNo) => {
    return await TrainingManagementService.subclassificationSuggestionGraphData(trainingID, seqNo);
  };

  setSuggestionClassList = (data) => {
    this.suggestionClassList = data;
  };

  fetchSuggestionClassList = async (data) => {
    return await TrainingManagementService.getSuggestionClassList(data);
    // return await TrainingManagementService.getSuggestionClassList(data).then((response) => {
    //   if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
    //     this.setSuggestionClassList(response.data);
    //   }
    // });
  };

  fetchSuggestionClassImages = async (trainingID, seqNo, paginationData) => {
    return await TrainingManagementService.getSuggestionClassImages(trainingID, seqNo, paginationData);
  };

  fetchSuggestionResultClassImages = async (trainingID, seqNo, paginationData) => {
    return await TrainingManagementService.getCorrectionClassImages(trainingID, seqNo, paginationData);
  };

  suggestionResultClassUpdate = async (trainingID, seqNo, updateData) => {
    return await TrainingManagementService.suggestionResultClassUpdate(trainingID, seqNo, updateData);
  };

  suggestionResultCreateClass = async (trainingID, data) => {
    return await TrainingManagementService.suggestionResultCreateClass(trainingID, data);
  };

  datasetsCreateClass = async (trainingID, data) => {
    return await TrainingManagementService.datasetCreateClass(trainingID, data);
  };

  classificationDatastes = async (trainingID) => {
    return await TrainingManagementService.classificationDatasets(trainingID);
  };

  getSuggestionResultProbabilityGraphDetails = async (trainingId, classSeqNo, data) => {
    return await TrainingManagementService.getSuggestionResultProbabilityGraphDetails(trainingId, classSeqNo, data);
  };

  suggestionResultImageMove = async (trainingId, classData) => {
    return await TrainingManagementService.suggestionResultImageMove(trainingId, classData);
  };

  storeCorrectionFixData = async (id, seqNo) => {
    return await TrainingManagementService.storeCorrectionFixData(id, seqNo);
  }

  resetSuggestionResultClass = async (trainingID, data) => {
    return await TrainingManagementService.resetSuggestionResultClass(trainingID, data);
  }
  imageListCreateClass = async (trainingID, data) => {
    return await TrainingManagementService.suggestionResultCreateClass(trainingID, data)
  }

  addClassImageList = (positionIndex, data) => {
    this.TrainingDataset.splice(positionIndex, 0, data);
  }

  displayAdvisor = async (trainingId, seqNo) => {
    return await TrainingManagementService.displayAdvisor(trainingId, seqNo);
  }

  fetchAccuracyLossImages = async (seqNo) => {
    return await TrainingManagementService.getAccuracyLossImages(seqNo);
  }

  updateMaskingCoordinates = async (id,payload) => {
    return await TrainingManagementService.updateMaskingCoordinates(id, payload)
  }

  excuteMasking = async (id,payload)=> {
    return await TrainingManagementService.executeMasking(id,payload);
  }
  
  getMaskingResult = async (id, seqNo,payload)=>{
    return await TrainingManagementService.maskingResult(id,seqNo,payload);
  }

  changeDatasetOrder = async (id, payload) => {
    return await TrainingManagementService.changeDatasetOrder(id, payload);
  }
}
export default createContext(new TrainingManagementStore());
