export const colors = {
  primary: {
    main: "#3a5faa",
    dark: "#284276"
  },
  scrollBar: {
    bg: "#dfdfdf",
    thumb: {
      bg: "#a1a1a1",
      hoverBg: "#898989"
    }
  },
  select: {
    textColor: "#000000bf",
    icon: "#000000"
  }
};
