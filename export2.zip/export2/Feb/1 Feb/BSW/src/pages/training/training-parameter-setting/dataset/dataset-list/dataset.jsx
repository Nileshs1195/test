import React from "react";
import { Button, Box } from "@material-ui/core";
import { useTranslation } from "react-i18next";
import Grid from "./grid";
import { columnDefinitions } from "./grid/columndefinitions";
import { useHistory, useParams } from "react-router-dom";
import AppStore from "../../../../../stores/appstore";
import { APP_ROUTES } from "../../../../../appconstants";
import { useStyles } from "../../style";
import { useState, useEffect, useContext, useCallback } from "react";
import TrainingManagementStore from "./../../../../../stores/trainingmanagementstore";
import ImageManagementStore from "./../../../../../stores/imagemanagementstore";
import ModalComponent from "./modal";
import { API_RESPONSE } from "../../../../../appconstants";
import Loader from "../../../../../shared/components/ui/loader";
import CustomSnackBar from "../../../../../components/snackbar";
import { observer } from "mobx-react-lite";
import EditPercentage from "../../../../../components/dataset-forms/EditPercentage";
import EditDataset from "../../../../../components/dataset-forms/EditDataset";
import AddDataset from "../../../../../components/dataset-forms/AddDataset";

const DataSet = observer((props) => {
  const params = useParams();
  const appStore = useContext(AppStore);
  const { TrainingDataset, selectedDataSetCount, loading, setLoading, setTabIndex } = props;
  const { addBreadcrumb, removeAllBreadcrumbs } = appStore;
  const classes = useStyles();
  const { t } = useTranslation();
  const history = useHistory();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { selectedTrainingDataset, clearSelectedTrainingDataset, setReloadList, executedModels } = trainingManagementStore;
  const { imageUploadStatus, setUploaderAction } = imageManagementStore;
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [isButtonDisabled, disableButton] = useState(false);
  const [imageDetailsList, setImageDetailsList] = useState([]);
  const [action, setAction] = useState({ actionName: "", isOpen: false });
  const [formloader, setformloader] = useState(false);
  const [trainingPercentList, setTrainingPercentList] = useState([]);
  const [newClassNamesList, setnewClassNamesList] = useState([]);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [loadGrid, setLoadGrid] = useState(loading);
  const [editPercentage, setEditPercentage] = useState(false);
  const [editDataset, setEditDataset] = useState(false);
  const [addDataset, setAddDataset] = useState(false);
  const [datasetRecord, setDatasetRecord] = useState({
    className: "",
    defectSize: null
  });
  useEffect(() => {
    if (selectedDataSetCount > 0) {
      // disableAddButton(true);
      if (selectedDataSetCount > 1) {
        disableButton(true);
      }
    }
    setnewClassNamesList([]);
    trainingManagementStore.clearSelectedTrainingDataset();
    trainingManagementStore.clearselectedInputParameter([]);
    if (imageUploadStatus === "completed" || imageUploadStatus === "in-progress") {
      getTrainingDatasetDetails();
      setReloadList(false);
    }
  }, [imageUploadStatus]);

  useEffect(() => {
    getTrainingDatasetDetails();
  }, []);

  // get traininglist
  const getTrainingDatasetDetails = useCallback(async () => {
    setLoading(true);
    await trainingManagementStore.fetchTrainingDatasetWithTraining(params.id);
    setLoading(false)
    disableAddButton(false);
  });

  const getExecutedTrainings = useCallback(async () => {
    await trainingManagementStore.fetchListingExecutedModal();
  });

  useEffect(() => {
    removeAllBreadcrumbs();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.dataset"
    });
    getExecutedTrainings();
  }, [addBreadcrumb]);

  const handleSubClasification = () => {
    let seqNoList = selectedTrainingDataset.reduce((seqNos, datasetDetails) => {
      seqNos.push(datasetDetails.seqNo);
      return seqNos;
    }, []);
    if (seqNoList?.length > 0) {
      localStorage.setItem("selectedTrainingDatasets", JSON.stringify(seqNoList));
      history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", seqNoList.join()));
    } else {
      setsnapbarMessage({ message: t("pages.training.errors.subclassification.dataset-not-selected") });
    }
  };

  const displayReadOnlyErrorMsg = () => {
    if (props.isActionDisabled) {
      setsnapbarMessage({ message: "pages.training.errors.params-setting.training-parameter-view" });
      return;
    }
  };

  const handleModalActions = (name) => {
    displayReadOnlyErrorMsg();
    setAction({ actionName: name, isOpen: true });
  };

  const setModalActive = () => {
    displayReadOnlyErrorMsg();
    setAction({ actionName: action.actionName, isOpen: false }); // display file upload confirmation modal
  };

  const handleAPICall = (API, data) => {
    displayReadOnlyErrorMsg();
    switch (API) {
      case "ADD-DATASET":
        copyPastDataset(data);
        break;
      case "MANAGE-IMAGES":
      case "SAVE-AND-AUGMENTATION":
        editDatasetRecord(API, data);
        break;
      case "UPLOAD-FILES":
        break;
      case "VALIDATE-PERCENTAGE":
        return validatePercentage(data);
        break;
      case "DELETE":
        deleteDatasetRecord();
        disableAddButton(false);
        break;
      default:
    }
  };

  const editDatasetRecord = (API, datasetRecord) => {
    const reqPayload = {
      // trainPercentage: datasetRecord.trainingPercent,
      // validationPercentage: MAX_VALUE - datasetRecord.trainingPercent,
      seqNos: trainingPercentList
    };
    editDatasets(reqPayload, API);
  };

  const editDatasets = (reqPayload, API) => {
    setLoading(true);
    trainingManagementStore
      .editDatasetAPI(params.id, reqPayload)
      .then((response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setsnapbarMessage({ message: t("pages.training.success.dataset.updated") });
          getTrainingDatasetDetails();
          handlePageRedirection(API);
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.dataset.update-failed") });
        }
      })
      .catch((err) => {
        setLoading(false);
        console.log("error", err);
      });
    setsnapbarMessage({ message: "" });
  };

  const handlePageRedirection = (API) => {
    if (API === "SAVE-AND-AUGMENTATION") {
      if (params.id) {
        trainingManagementStore.changeTrainingStatus(params.id, "training");
      }
      setTabIndex(1);
    }
    if (API === "MANAGE-IMAGES") {
      const seqNoList = selectedTrainingDataset.reduce((seqNos, datasetDetails) => {
        seqNos.push(datasetDetails.seqNo);
        return seqNos;
      }, []);
      history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST.replace(":id", params.id).replace(":classes", seqNoList.join()));
    }
  };

  // function useForceUpdate(datasets) {
  //   const [datasetList, setDataSetList] = useState([]); // integer state
  //   return () => {      
  //     setDataSetList(datasets)
  //     clearSelectedTrainingDataset();
  //     trainingManagementStore.setTrainingDataset(datasets);
  //   }
  // }

  const validatePercentage = (datasetList) => {
    let status = true;
    const trainPercentageList = [];
    datasetList.forEach((item) => {
      let dataset = Object.assign({}, item);
      if (dataset && (dataset.trainPercentage === null || dataset.trainPercentage <= 0) && (dataset.validationPercentage === null || dataset.validationPercentage <= 0)) {
        status = false;
        trainPercentageList.push(dataset.seqNo);
      }
    });
    setTrainingPercentList(trainPercentageList);
    return status;
  };

  const copyPastDataset = (data) => {
    let pastModalData = {
      src_train_id: data.modelNameId,
      dst_train_id: params.id,
      trainPercentage: data.trainingPercent,
    };
    trainingManagementStore.saveExecutedDatasetClone(pastModalData).then((response) => {
      if (response[1].data && response[0].status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        // fetchTrainingDatasetWithTraining(params.id);
        getTrainingDatasetDetails();
        setsnapbarMessage({ message: t("pages.training.success.dataset.updated") });
      } else {
        setsnapbarMessage({ message: t("pages.training.errors.dataset.update-failed") });
      }
    }).catch((err) => {
      console.log('error', err);
    });
  };

  const deleteDatasetRecord = () => {
    let reqPayload = {
      seqNo: selectedTrainingDataset.map((item) => item.seqNo)
    };
    // setReloadList(true);
    setLoading(true);
    trainingManagementStore
      .deleteDatasetRecords(params.id, reqPayload)
      .then((response) => {
        if (response?.data?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          clearSelectedTrainingDataset();
          trainingManagementStore.setTrainingDataset(response.data.data);
          trainingManagementStore.setTrainingDatasetTotalCount(response?.data?.data.length);
          setLoading(false);
          getTrainingDatasetDetails();
          // setReloadList(false);
          setsnapbarMessage({ message: t("pages.training.success.dataset.deleted") });
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.dataset.delete-failed") });
        }
      })
      .catch((err) => {
        console.log("error", err);
      });
  };

  const onClickAddDataset = () => {
    // displayReadOnlyErrorMsg();
    // handleModalActions("ADD-DATASET");
    if (executedModels?.length > 0) {
      setAddDataset(true);
    } else {
      setUploaderAction({
        isOpen: true,
        uploaderType: "add-dataset",
        className: "",
        id: params?.id
      });
    }
  };

  const handleEditDataset = () => {
    setDatasetRecord({
      seqNo: selectedTrainingDataset[0].seqNo,
      className: selectedTrainingDataset?.[0]?.className,
      defectSize: selectedTrainingDataset?.[0]?.defectSize,
    })
    setEditDataset(true);

  }

  let isSaveDisabled = TrainingDataset?.length > 0 ? false : true;
  
    let totalImages =0, totalValidationImages =0, totalTrainingImages =0;
    for(var i in TrainingDataset){
      totalImages = totalImages+ TrainingDataset[i].imgCount;
      totalValidationImages=totalValidationImages+TrainingDataset[i].validationCount;
      totalTrainingImages= totalTrainingImages+TrainingDataset[i].trainImgCount;    
   }  
   return (
    <Box p={2} className={classes.boxHeight}>
      {formloader && <Loader size={24} />}
      {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
      <AddDataset open={addDataset} setOpen={setAddDataset} trainingId={params.id} callBack={getTrainingDatasetDetails} setSnapbar={setsnapbarMessage} />
      {editDataset && <EditDataset dataset={datasetRecord} trainingId={params.id} open={editDataset} setOpen={setEditDataset} callBack={getTrainingDatasetDetails} setSnapbar={setsnapbarMessage} />}
      {editPercentage && <EditPercentage dataset={selectedTrainingDataset} trainingId={params.id} open={editPercentage} setOpen={setEditPercentage} callBack={getTrainingDatasetDetails} setSnapbar={setsnapbarMessage} />}
      <div>
        {totalImages > 0 &&
          <div className={classes.buttonWrapperleft}>
            <div className={classes.labelPosition}>
              {t("pages.training.training-list.grid.training-image")} : <b>{totalTrainingImages}</b>
            </div>
            <div className={classes.labelPosition}>
              {t("pages.training.training-list.grid.validation-images")} : <b>{totalValidationImages}</b>
            </div>
            <div className={classes.labelPosition}>
              {t("pages.training.training-parameter.grid.total-images")} : <b>{totalImages}</b>
            </div>
          </div>}
        <Box className={classes.buttonWrapper}>
          <Button color="primary" variant="contained" disabled={isAddButtonDisabled || props.isActionDisabled || imageUploadStatus === "in-progress"} onClick={onClickAddDataset}>
            {t("pages.training.training-parameter.dataset-mode.controls.add-btn")}
          </Button>
        </Box>
      </div>&nbsp;
      <ModalComponent
        action={action}
        imageList={imageDetailsList?.length > 0 && imageDetailsList}
        setModalActive={setModalActive}
        handleAPICall={handleAPICall}
        parameterMode={props.parameterMode}
        disableAddButton={disableAddButton}
        setTabIndex={setTabIndex}
        handleFileUploadOpen={props.handleFileUploadOpen}
      />
      <Grid
        loading={loading}
        records={TrainingDataset}
        containerClassName={selectedDataSetCount > 0 ? classes.tableContainerFooter : classes.tableContainer}
        columnDefinitions={columnDefinitions}
        disableAddButton={disableAddButton}
        disableButton={disableButton}
        disableCheckBox={(imageUploadStatus === 'in-progress')}
      />
      {selectedDataSetCount > 0 && (
        <div className={classes.footerContainer}>
          <div className={classes.buttonGroup}>
            <span className={classes.noOfDevicesWrapper}>
              {t("pages.image-management.image-group-list.controls.selected")}
              {" : "}
              {selectedDataSetCount}
            </span>
          </div>

          <div className={classes.buttonGroup}>
            <Button
              variant="outlined"
              className={classes.buttons}
              size="small"
              disabled={props.isActionDisabled || imageUploadStatus === "in-progress"}
              onClick={() => { setEditPercentage(true); }}
            >
              {t("pages.training.training-parameter.dataset-mode.controls.set-training-percentage")}
            </Button>
            <Button
              variant="outlined"
              className={classes.buttons}
              size="small"
              disabled={(props.isActionDisabled && !props.parameterMode) || imageUploadStatus === "in-progress"}
              onClick={() => handleModalActions("MANAGE-IMAGES")}
            >
              {props.isActionDisabled || imageUploadStatus === "in-progress" ? t("pages.training.training-parameter.dataset-mode.controls.view-images") : t("pages.training.training-parameter.dataset-mode.controls.manage-images")}
            </Button>
            <Button
              variant="outlined"
              className={classes.buttons}
              size="small"
              disabled={props.isActionDisabled || imageUploadStatus === "in-progress"}
              onClick={() => handleSubClasification()}
            >
              {t("pages.training.training-parameter.dataset-mode.controls.subcalssification")}
            </Button>
            <Button
              variant="outlined"
              className={classes.buttons}
              size="small"
              disabled={props.isActionDisabled || imageUploadStatus === "in-progress"}
              onClick={() => handleModalActions("DELETE")}
            >
              {t("pages.image-management.image-group-list.controls.delete")}
            </Button>
            <Button
              variant="outlined"
              size="small"
              className={classes.buttons}
              disabled={isButtonDisabled || props.isActionDisabled || imageUploadStatus === "in-progress"}
              onClick={() => handleEditDataset()}
            >
              {t("pages.image-management.image-group-list.controls.edit")}
            </Button>
          </div>
        </div>
      )}
      <Box className={classes.btnPaddingTop}>
        <Button
          color="primary"
          variant="contained"
          disabled={props.isActionDisabled || isSaveDisabled || imageUploadStatus === "in-progress"}
          onClick={() => handleModalActions("SAVE-AND-AUGMENTATION")}
        >
          {t("pages.training.training-parameter.controls.save")}
        </Button>
      </Box>
    </Box>
  );
});

export default DataSet;
