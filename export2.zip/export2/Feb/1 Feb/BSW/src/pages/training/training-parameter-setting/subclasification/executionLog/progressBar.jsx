import React from "react";
import { useEffect, useContext, useState, useCallback } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Typography } from "@material-ui/core";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useHistory, useParams } from "react-router-dom";
import { useStyles } from "./style";
import AppStore from "../../../../../stores/appstore";
import { API_RESPONSE, APP_ROUTES } from "../../../../../appconstants";
import Breadcrumb from "../../../../../shared/components/ui/breadcrumb";
import LinearProgressBar from "../../../../../components/linearprogressbar";
import { useTranslation } from "react-i18next";
import TrainingManagementStore from "./../../../../../stores/trainingmanagementstore";
import BackButton from "../../../../../components/backbutton";
import CustomSnackBar from "../../../../../components/snackbar";
import CustomConfirmation from "../../../../../components/modal/CustomConfirmation";
import { Loader } from "../../../../../shared/components/ui";
import { columnDefinitions } from "./grid/columndefinitions";
import Grid from "./grid";

const ProgressBar = (props) => {
  const params = useParams();
  const history = useHistory();
  const classes = useStyles();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, updateLastBreadcrumb, removeLastBreadcrumb } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { fetchExecutionLogData } = trainingManagementStore;
  const [isResultSetVisible, setResultSetVisibility] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loader, setLoader] = useState(false);
  const [stopExecution, setStopExecution] = useState(false);
  const [startExecution, setStartExecution] = useState(false);
  const [batchData, setBatchData] = useState({});
  const [executedSeqNumbers, setExecutedSeqNumbers] = useState("");
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [executionLogData, setExecutionLogData] = useState([]);
  const [fetchLog, setFetchLog] = useState(false);
  const [resultSet, setResultSet] = useState({
    progress: 0,
    Rate: 0,
    Ploss: 0,
    Closs: 0,
    elapsedTime: 0,
    modelName: "",
    noOfFeatures: 0,
    status: 0,
    mode: 0
  });

  useEffect(() => {
    // window.addEventListener("beforeunload", () => alert());
    removeLastBreadcrumb();
    updateLastBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });

    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.subclassificationExecutionLog"
    });
  }, [addBreadcrumb]);

  useEffect(() => {
    async function fetchInputParamsData() {
      let response = await trainingManagementStore.fetchInputSelectedData();
      if (response !== "") {
        setExecutedSeqNumbers(response);
      }
    }
    fetchInputParamsData();
  }, []);

  useEffect(() => {
    setLoading(true);
    trainingManagementStore
      .getBatch(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          if (response?.data?.mode === "subclassification") {
            setBatchData(response.data);

            if(response?.data?.selectedSeqNos?.length > 0) {
              localStorage.setItem("selectedTrainingDatasets", JSON.stringify(response?.data?.selectedSeqNos));
            }

            if (response.data.status === "Stop" || response.data.status === "Stopping" || response.data.status === "Stopped") {
              setsnapbarMessage({
                message: t("pages.training.errors.training-list.execution-cancelled", { "type": t("pages.training.errors.training-list.training") }),
                timeout: 100000
              })
            }
            if(response?.data?.isExecuted) {
              setsnapbarMessage({
                message: t("pages.training.errors.training-list.subclass-completed", { "type": t("pages.training.errors.training-list.training") }),
                timeout: 1000000
              })
            }
            setStartExecution(true);
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.training-list.invalid-execution") });
            setStartExecution(false);
          }
        } else {
          setStartExecution(false);
          setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
        }
      })
      .catch((xhr) => {
        setLoading(false);
        setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
      });
  }, [])

  // useEffect(async () => {
  //   if (resultSet?.status === 8) {
  //     // await trainingManagementStore.stopExecution(params.id);
  //     trainingManagementStore.setSnapbarMessage({
  //       message: t("pages.training.errors.subclassification.execution-failed"),
  //       type: "error",
  //       open: true
  //     });
  //     // setTimeout(() => {
  //     //   history.goBack();
  //     // }, 1000);
  //   }
  // }, [resultSet]);

  const fetchExecutionLogDataList = useCallback(async () => {
    if (!fetchLog) {
      setFetchLog(true);
      setLoading(true);
      setLoader(true);
      await fetchExecutionLogData(params.id, params.seqNo)
        .then((response) => {
          setFetchLog(false);
          setLoading(false);
          if (response?.status === 200) {
            setResultSetVisibility(true);
            setExecutionLogData(response.data);
          }
        })
        .catch((err) => {
          setLoading(false);
          setFetchLog(false);
          console.log("error", err);
        });
    }
    setLoader(false);
  });

  const handleBackButton = () => {
    if (startExecution && resultSet?.progress < 100 && resultSet?.status < 3 && resultSet?.baseMode > 0) {
      setOpenModal(true);
    } else {
      history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
    }
  };

  const stopExecutionLog = () => {
    setOpenModal(false);
    setLoading(true);
    trainingManagementStore
      .stopExecution(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setStopExecution(true);
          history.replace();
          history.goBack();
        } else {
          setsnapbarMessage({message: t("pages.training.errors.training-list.exec-cancel-failed")})
        }
      })
      .catch((xhr) => {
        setLoading(false);
        setsnapbarMessage({message: t("pages.training.errors.training-list.exec-cancel-failed")})
      });
  };

  const goToSuggestionResultPage = async () => {
    if (resultSet?.progress >= 100) {
      setLoading(true);
      await trainingManagementStore.subclassificationResult(params.id, params.seqNo).then((response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          if (response?.data?.length > 0) {
            let seqNos = response?.data.map(classes => classes.seqNo);
            history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX.replace(":id", params.id).replace(':batchNo', params.seqNo).replace(":classes", seqNos.join()));
          } else {
            setsnapbarMessage({
              message: t("pages.training.errors.subclassification.fetching-classes-failed")
            })
            // history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX.replace(":id", params.id)).replace(":classes", executedSeqNumbers);
          }
        } else {
          setsnapbarMessage({
            message: t("pages.training.errors.subclassification.fetching-classes-failed")
          })
        }
      }).catch(() => {
        setLoading(false);
        setsnapbarMessage({
          message: t("pages.training.errors.subclassification.fetching-classes-failed")
        })
      });
    }
  };

  return (
    <Observer>
      {() => (
        <div>
          {loading && <Loader size={24} />}
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton
                  handleBackButton={handleBackButton}
                />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <div>
                <Button color="primary" variant="contained" disabled={resultSet?.status !== 7 || batchData?.isExecuted === true} onClick={() => goToSuggestionResultPage()}>
                  {t("pages.training.input-parameter.controls.show-suggestion-result")}
                </Button>{" "}
                &nbsp;
                <Button color="primary" variant="contained" onClick={() => {history.goBack()}} 
                  disabled={(resultSet?.baseMode !== 0 && resultSet?.status < 3)}>
                  {t("pages.training.input-parameter.controls.back")}
                </Button>&nbsp;&nbsp;
                {/* (resultSet?.baseMode !== 0) || (resultSet?.baseMode > 0 && resultSet?.status < 5)  */}
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => handleBackButton()}
                  disabled={resultSet?.progress > 2 || resultSet?.baseMode === 0}
                >
                  {t("pages.training.input-parameter.controls.cancel-btn")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.mtop}>
              <CustomConfirmation
                open={openModal}
                onClose={() => setOpenModal(false)}
                onSubmit={stopExecutionLog}
                primary={"pages.training.input-parameter.controls.ok"}
                secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                title={t("pages.training.input-parameter.modal.confirm-cancel-execution.title")}
                message={t("pages.training.input-parameter.modal.confirm-cancel-execution.text")}
              />
              {startExecution && <LinearProgressBar
                stopExecution={stopExecution}
                setResultSet={setResultSet}
                displayData={fetchExecutionLogDataList}
                batchData={batchData}
                resultSet={resultSet}
                method="executionProgress"
                executionType="subclassification"
              />}
            </div>

            {resultSet?.progress > 0 && (
              <Accordion className={classes.accordionContainer}>
                <AccordionSummary expandIcon={<ExpandMoreIcon />} className={classes.accSummary} aria-controls="panel1a-content" id="panel1a-header">
                  <Typography className={classes.accSumTitle}>{t("pages.training.subclassification-execution-log.grid.title")}</Typography>
                </AccordionSummary>
                <AccordionDetails className={classes.accDetails}>
                  <Grid
                    loading={loader}
                    records={executionLogData}
                    containerClassName={classes.tableContainer}
                    columnDefinitions={columnDefinitions}
                  />
                </AccordionDetails>
              </Accordion>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default ProgressBar;
