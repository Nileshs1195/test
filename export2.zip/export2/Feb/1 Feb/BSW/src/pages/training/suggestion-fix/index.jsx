import { Button, Divider, FormControlLabel, Paper, Switch } from "@material-ui/core";
import { Observer, observer } from "mobx-react-lite";
import { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import { useHistory } from "react-router-dom";
import Breadcrumb from "../../../shared/components/ui/breadcrumb"; import AppStore from "../../../stores/appstore";
import TrainingManagementStore from "./../../../stores/trainingmanagementstore";
import { useStyles } from "./style";
import { API_RESPONSE, API_URL, APP_ROUTES } from "../../../appconstants";
import BackButton from "../../../components/backbutton";
import { arrayMultiSplit } from "../../../helpers/arrayutils";
import Pagination from "../../../shared/components/basictable/pagination";
import ThresholdSlider from "../../../components/threshold-slider";
import SuggestionList from "../../../components/image-list/SuggestionList";
import AddNewClass from "../../../components/add-class";
import { DragDropContext } from "react-beautiful-dnd";
import CompareImageView from "../../../components/compareimages/imageView";
import CustomConfirmation from "../../../components/modal/CustomConfirmation";

const SuggestionResultFix = observer((props) => {
    const initialProbabilityTreshold = 0.8;
    const classes = useStyles();
    const params = useParams();
    const history = useHistory();
    const { t } = useTranslation();

    const trainingManagementStore = useContext(TrainingManagementStore);
    const { fetchSuggestionResult, suggestionResultImageMove } = trainingManagementStore;

    const appStore = useContext(AppStore);
    const { addBreadcrumb, updateLastBreadcrumb, removeLastBreadcrumb, setLoader, setsnapbarMessage } = appStore;

    const [selectedClasses, setSelectedClasses] = useState([]);
    const [checkedClasses, setCheckedClasses] = useState([]);
    const [selectedClassesData, setSelectedClassesData] = useState([]);
    const [actualClasses, setActualClasses] = useState([]);
    const [currentClasses, setCurrentClasses] = useState([]);
    const [totalClasses, setTotalClasses] = useState([]);
    const [classCount, setClassCount] = useState(0);
    const [showGraph, setShowGraph] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const [selectAll, setSelectAll] = useState(true);
    const [probabilityTreshold, setProbabilityTreshold] = useState(initialProbabilityTreshold);
    const [showTransferedImagesOnly, setShowTransferedImagesOnly] = useState(false);
    const [openModal, setOpenModal] =  useState(false);
    const [training, setTraining] = useState({});
    const [addClass, setAddClass] = useState(false);
    const [totalImages, setTotalImages] = useState([]);
    const [isCompareImageView, setCompareImageview] = useState(false);
    const [selectedImages, setSelectedImages] = useState([]);
    const [reload, setReload] = useState([]);
    const [page, setPage] = useState({
        pageSize: 5,
        pageNo: 1
    });

    const setBreadCrumbs = () => {
        removeLastBreadcrumb();
        updateLastBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
            label: "pages.training.training-parameter.breadcrumb.training"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
            label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", actualClasses.join(",")),
            label: "pages.training.training-parameter.breadcrumb.subclassification"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX,
            label: "pages.training.training-parameter.breadcrumb.suggestionResultDisplay"
        });
    };

    useEffect(() => {
        setBreadCrumbs();
        getClassList();
    }, []);

    useEffect(() => {
        splitClasses(page);
    }, [selectedClasses]);

    const splitClasses = (obj) => {
        let pageNo = obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo;
        let selectedClass = arrayMultiSplit(selectedClasses, obj?.pageSize);
        setTotalClasses(selectedClasses);
        selectedClass?.length > 0 && setCurrentClasses(selectedClass[pageNo]);
    }

    const onPagination = (obj) => {
        setPage(obj);
        splitClasses(obj);
    }

    const handleShowGraphToggle = () => {
        setShowGraph((prevOpen) => !prevOpen);
    };

    const getClassList = async () => {
        if (params?.id) {
            setLoader(true);
            let response = await fetchSuggestionResult(params.id, params.batchNo);
            if (response?.status == 200 && response?.data) {
                setLoader(false);
                if (response?.training) {
                    setTraining(response?.data?.training);
                }
                setClassCount(response?.count);
                setSelectedClassesData(response?.data);
                let seqNos = response?.data.map((res) => res.seqNo);
                let actualClass = [];
                let images = [];
                response?.data?.filter(res => res?.isSubClass && actualClass.push(res.seqNo) && images.push(res.images));
                setActualClasses(actualClass);
                setTotalImages(images.flat())
                setSelectedClasses(seqNos);
                setCheckedClasses(seqNos);
            } else {
                setLoader(false);
            }
        }
    }

    const handleBackButton = () => {
        history.goBack();
    }

    const handleTresholdChangeCommit = (tresholdValue) => {
        setProbabilityTreshold(tresholdValue);
    };

    const createClass = (id, className) => {
        setLoader(true);
        trainingManagementStore
            .suggestionResultCreateClass(params.id, { className, seqNo: parseInt(params.batchNo) })
            .then((response) => {
                setLoader(false);
                if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                    // updateClassData(response.data);
                    setClassCount(classCount + 1);
                    let selectedClass = arrayMultiSplit(selectedClassesData, page?.pageSize)
                    selectedClass[page?.pageNo - 1].unshift(response?.data)
                    selectedClass = [].concat.apply([], selectedClass);
                    setSelectedClassesData(selectedClass);
                    let seqNos = selectedClass.map((res) => res.seqNo);
                    let actualClass = [];
                    selectedClass?.filter(res => res?.isSubClass && actualClass.push(res.seqNo));
                    setActualClasses(actualClass);
                    setSelectedClasses(seqNos)
                    // setCurrentClasses(currentClass);
                    setCheckedClasses(seqNos);
                }
            })
            .catch((erro) => {
                // t("pages.training.input-parameter.modal.already-exist")
                setLoader(false);
            });
    }

    const onDragEnd = async (result) => {
        const { source, destination } = result;
        if (destination === undefined || destination === null || source.droppableId === destination.droppableId)
            return null;
        const saveImageData = {
            src_seqNo: Number(source.droppableId),
            dst_seqNo: Number(destination.droppableId),
            seqNos: [source.index]
        };
        await suggestionResultImageMove(params.id, saveImageData).then((response) => {
            if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                setsnapbarMessage({
                    message: t("pages.training.manageImages.messages.imageRecordUpdated")
                });
                setReload([saveImageData.src_seqNo, saveImageData.dst_seqNo]);
            }
        });
    }

    const handleSuggestionResultModal = (actionName) => {
        switch (actionName) {
            case "COMPARE-IMAGES": {
                setCompareImageview((isOpen) => !isOpen);
                break;
            }
        }
    }

    const handleControls = (actionName, ...args) => {

        switch (actionName) {
            case "selectedImageData": {
                let compareImageView = [];
                args?.flat().forEach((selectedImage) => {
                    compareImageView.push(Object.assign(
                        JSON.parse(JSON.stringify(selectedImage)),
                        totalImages.filter((img) => img.seqNo === selectedImage.seqNo)[0]
                    ));
                });
                setSelectedImages([...compareImageView.flat()]);
                break;
            }
            case "reload": {
                setReload([]);
                break;
            }
            case "updateClass": {
                let index = selectedClassesData.findIndex((item) => item.seqNo === args[0]?.seqNo)
                console.log(index, args)
                selectedClassesData[index]['className'] = args[0]?.className
                setSelectedClassesData(selectedClassesData);
                break;
            }
            default:
                break;
        }
    }

    const reset = () => {
        trainingManagementStore.subclassificationResult(params.id, params.batchNo).then((response) => {
            if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
                setsnapbarMessage({
                    message: "Successfully Resetted"
                });
                getClassList();
            }

        });
    }

    const saveChanges = () => {
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.CORRECTION_RESULT_DISPLAY.replace(":id", params.id).replace(":classes", selectedClasses.join()).replace(":seqNo", params.batchNo));
    }
    return (
        <Observer>
            {() => (
                <div>
                    <Paper className={classes.pageContent}>
                        <AddNewClass
                            open={addClass}
                            dataset={selectedClassesData}
                            setAddClass={setAddClass}
                            handleCreateClass={createClass}
                        />
                        {isCompareImageView && (
                            <CompareImageView
                                open={isCompareImageView}
                                imageData={selectedImages}
                                onClose={() => setCompareImageview((isOpen) => !isOpen)}
                            />)
                        }
                        <div className={classes.top}>
                            <div className={classes.wrapContent}>
                                <BackButton handleBackButton={handleBackButton} />
                                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
                            </div>

                            <div className={classes.buttonWrapper}>
                                <Button color="primary" variant="contained" onClick={() => setSelectAll(!selectAll)}>
                                    {selectAll ? t("pages.training.manageImages.controls.unselectAll") : t("pages.training.manageImages.controls.selectAll")}
                                </Button>
                                <Button color="primary" variant="contained" onClick={() => setExpanded(!expanded)}>
                                    {expanded ? t("pages.training.manageImages.controls.expandAll") : t("pages.training.manageImages.controls.collapseAll")}
                                </Button>
                                <Button color="primary" onClick={() => {
                                    setAddClass(true)
                                }} variant="contained">
                                    {t("pages.training.suggestion-result.controls.add-class")}
                                </Button>
                            </div>
                        </div>
                        <Divider className={classes.divider} />
                        <br />
                        <div>
                            <hr className={classes.imageLegendAuto} />
                            <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.autoLegend")}</div>
                            <hr className={classes.imageLegendManual} />
                            <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.manualLegend")}</div>
                            <hr className={classes.imageLegendNone} />
                            <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.noneLegend")}</div>
                        </div>
                        <div className={classes.controlContainer}>
                            <Pagination
                                disabled={false}
                                disableItemPerPage={true}
                                itemCount={classCount}
                                onChange={onPagination}
                                pageNo={page.pageNo}
                                pageSize={page.pageSize}
                            />
                            <FormControlLabel
                                control={<Switch disabled={!selectAll} checked={showGraph} onChange={handleShowGraphToggle} name="showGraph" color="primary" />}
                                label={t("pages.training.suggestion-result.controls.show-graph")}
                                labelPlacement="start"
                            />
                            <div style={{ marginLeft: "10px" }}><ThresholdSlider
                                disableItem={!selectAll}
                                onThresholdChange={handleTresholdChangeCommit}
                                disabled={false}
                                initialProbabilityTreshold={initialProbabilityTreshold}
                                decimalPoints={4}
                            /></div>
                        </div>
                        <DragDropContext onDragEnd={onDragEnd}>
                            {currentClasses?.length > 0 && currentClasses.map((seqNo) => {
                                return (
                                    <SuggestionList
                                        selectAll={selectAll}
                                        showTransferedImagesOnly={showTransferedImagesOnly}
                                        overallThreshold={probabilityTreshold}
                                        url={API_URL.CORRECTION_IMAGES}
                                        seqNo={seqNo}
                                        trainingDetails={training}
                                        order={{ desc: "updatedAt" }}
                                        key={"image-" + seqNo}
                                        unique={"image-" + seqNo}
                                        expand={expanded}
                                        imageType={"all"}
                                        showAddImage={false}
                                        trainingClasses={selectedClassesData}
                                        showEditClassName
                                        showDeleteImage={false}
                                        pageSize={5}
                                        showOverallGraph={showGraph}
                                        imageSelection
                                        showEditClass
                                        carouselView={true}
                                        handleControls={handleControls}
                                        reload={reload}
                                    />
                                )
                            })}
                        </DragDropContext>
                        <div className={classes.bottom}>
                            <div className={classes.buttonWrapper}>
                                <Button 
                                    color="primary" 
                                    onClick={() => setOpenModal("RESET-ALL")} 
                                    variant="contained" 
                                    size="small" 
                                    disabled={false}
                                >
                                    {t("pages.training.suggestion-result.modal.label.reset-all")}
                                </Button>
                                <Button
                                    color="primary"
                                    onClick={() => setOpenModal("RESET")}
                                    variant="contained"
                                    size="small"
                                    // disabled={appStore?.selectedSuggestionResultClass?.length <= 0}
                                >
                                    {t("pages.training.suggestion-result.modal.label.reset")}
                                </Button>
                                <Button
                                    color="primary"
                                    variant="contained"
                                    onClick={() => handleSuggestionResultModal("COMPARE-IMAGES")}
                                    size="small"
                                    disabled={selectedImages.length == 2 ? false : true}
                                >
                                    {t("pages.training.suggestion-result.modal.label.compare-images")}
                                </Button>
                                <Button
                                    color="primary"
                                    variant="contained"
                                    size="small"
                                    disabled={false}
                                    onClick={() =>setShowTransferedImagesOnly((isOpen)=>!isOpen)}
                                >
                                    {showTransferedImagesOnly
                                    ? t("pages.training.suggestion-result.controls.all-images")
                                    : t("pages.training.suggestion-result.controls.transferred-images")}
                                </Button>
                                <Button 
                                    color="primary" 
                                    variant="contained" 
                                    size="small" 
                                    disabled={false} 
                                        onClick={() => setOpenModal("SAVE-CHANGES")}
                                >
                                    {t("pages.training.suggestion-result.controls.finish")}
                                </Button>
                            </div>
                        </div>
                        <CustomConfirmation
                            open={openModal === "RESET"}
                            onClose={() => setOpenModal("")}
                            onSubmit={reset}
                            primary={"pages.training.input-parameter.controls.ok"}
                            secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                            title={t("pages.training.suggestion-result.modal.label.reset")}
                            message={t("pages.training.suggestion-result.modal.messages.unsaved-selected")}
                        />
                        <CustomConfirmation
                            open={openModal === "RESET-ALL"}
                            onClose={() => setOpenModal("")}
                            onSubmit={reset}
                            primary={"pages.training.input-parameter.controls.ok"}
                            secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                            title={t("pages.training.suggestion-result.modal.label.reset-all")}
                            message={t("pages.training.suggestion-result.modal.messages.unsaved")}
                        />
                        <CustomConfirmation
                            open={openModal === "SAVE-CHANGES"}
                            onClose={() => setOpenModal("")}
                            onSubmit={saveChanges}
                            primary={"pages.training.input-parameter.controls.ok"}
                            secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                            title={t("pages.training.suggestion-result.modal.label.save-changes")}
                            message={t("pages.training.suggestion-result.modal.messages.save-changes")}
                        />
                    </Paper>
                </div>
            )}
        </Observer>
    );
});

export default SuggestionResultFix;
