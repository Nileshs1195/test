import { useContext, useState } from "react";
import AppStore from "./../../../../../../stores/appstore";
import TrainingManagementStore from "../../../../../../stores/trainingmanagementstore";
import CustomTables from "../../../../../../components/customtable/table";
import { API_RESPONSE } from '../../../../../../appconstants';

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions,
  disableAddButton,
  disableButton,
  disableCheckBox
}) => {

  const trainingManagementStore = useContext(TrainingManagementStore);
  const appStore = useContext(AppStore);
  const { fetchImageGroupData } = trainingManagementStore;
  let selectedRowCount = 0;

  const isSelected = id => {
    const selected = trainingManagementStore.selectedTrainingDataset.filter(
      item => item.seqNo === id
    );
    return selected.length > 0;
  };

  const getBodyData = data => {
    data = JSON.parse(JSON.stringify(data));
    if (data.length > 0) {
      return data.map(item => {
        item._id = item.seqNo;
        item.selected = isSelected(item._id);
        if (item.selected) {
          selectedRowCount++;
        }
        return item;
      });
    }
  };

  const handleSelectAllClick = event => {
    if (records?.length > 0 && !disableCheckBox) {
      const { checked } = event.target;
      if (checked) {
        disableAddButton(true);
        disableButton(true);
        records.forEach(imageGroup => {
          const isImageGroupPresent = trainingManagementStore.selectedTrainingDataset.filter(
            selectedImageGroup => selectedImageGroup.seqNo === imageGroup.seqNo
          );
          if (!(isImageGroupPresent.length > 0)) {
            trainingManagementStore.setSelectedTrainingDataset(imageGroup);
          }
        });
      } else {
        disableAddButton(false);
        disableButton(false);
        const deselectedTrainingDataset = [];
        records.forEach(imageGroup => {
          if (
            trainingManagementStore.selectedTrainingDataset.some(
              selectedImageGroup => selectedImageGroup.seqNo === imageGroup.seqNo
            )
          ) {
            deselectedTrainingDataset.push(imageGroup.seqNo);
          }
        });
        trainingManagementStore.removeSelectedTrainingDatasets(
          deselectedTrainingDataset
        );
      }
    }
  };

  const onRowSelect = (event, imageGroupId) => {
    if (!disableCheckBox) {
      const rowData = records.filter(item => item.seqNo === imageGroupId);
      const selected = isSelected(imageGroupId);

      if (selected) {
        trainingManagementStore.removeSelectedTrainingDataset(imageGroupId);
      } else {
        trainingManagementStore.setSelectedTrainingDataset(rowData[0]);
      }

      if (trainingManagementStore.selectedTrainingDataset.length > 0) {
        disableAddButton(true);
        if (trainingManagementStore.selectedTrainingDataset.length > 1) {
          disableButton(true);
        } else {
          disableButton(false);
        }
      } else {
        disableAddButton(false);
      }
    }
  };
  
  let data = getBodyData(records);

  const onDragEnd = (result) => {
  }

  const changeDataOrder = (trainingId, classes) => {
    trainingManagementStore.changeDatasetOrder(trainingId, { classes }).then(res => {
      if (res && res.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        trainingManagementStore.fetchTrainingDataset(trainingId)
      }
    }).catch(err => {
      console.log(err);
    });
  }

  return (
    <>
      {/* we can also implement onDragEnd for here using the onDragEnd Prop. */}
      <CustomTables
        enableDrag={true}
        loading={loading}
        rowCount={records.length}
        classname={containerClassName}
        headerData={columnDefinitions}
        selectedRowCount={selectedRowCount}
        onAllRowSelected={handleSelectAllClick}
        onRowSelect={onRowSelect}
        disableCheckbox={disableCheckBox}
        bodyData={data}
        // onDragEnd={onDragEnd}
        callback={changeDataOrder}
      />
    </>

  );
};

export default Grid;
