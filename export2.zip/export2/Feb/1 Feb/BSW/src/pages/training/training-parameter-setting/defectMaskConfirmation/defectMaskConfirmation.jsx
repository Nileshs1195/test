import { Paper, Divider, Button, FormControlLabel, Switch } from "@material-ui/core";
import { useEffect, useContext, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { Observer } from "mobx-react-lite";
import { useStyles } from "./style";
import AppStore from "../../../../stores/appstore";
import ImageListComponent from "../../../../components/image-list/imageListComponent";
import { API_URL, APP_ROUTES } from "../../../../appconstants";
import Pagination from "../../../../shared/components/basictable/pagination";
import Breadcrumb from "../../../../shared/components/ui/breadcrumb";
import BackButton from "../../../../components/backbutton";
import { useTranslation } from "react-i18next";
import { arrayMultiSplit, arrayUnique } from "../../../../helpers/arrayutils";

const DefectMaskConfirmation = () => {
  const history = useHistory();
  const classes = useStyles();
  const params = useParams();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);

  const pageSize = 5;

  const [currentClasses, setCurrentClasses] = useState([]);
  const [totalClasses, setTotalClasses] = useState([]);
  const [pageNo, setPageNo] = useState(1);
  const [expanded, setExpanded] = useState(false);
  const [imageType, setImageType] = useState("all");
  const [showMaskingOutput, setShowMaskingOutput] = useState(true);
  const [selectedClasses, setSelectedClasses] = useState(params.classes);

  useEffect(() => {
    appStore.removeAllBreadcrumbs();
    appStore.addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", params.classes),
      label: "pages.training.training-parameter.breadcrumb.subclassification"
    });
    appStore.addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.DEFECT_MASK_CONFIRMATION.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.defectMaskConfirmation"
    });
  }, [appStore.addBreadcrumb]);

  useEffect(() => {
    splitClasses();
  }, [selectedClasses, pageNo]);

  const splitClasses = () => {
    let currentPageNo = pageNo > 0 ? pageNo - 1 : pageNo;
    let uniqueClasses = arrayUnique(selectedClasses?.split(","));
    let selectedClass = arrayMultiSplit(uniqueClasses, pageSize);
    setTotalClasses(uniqueClasses);
    selectedClass?.length > 0 && setCurrentClasses(selectedClass[currentPageNo]);
  };

  const handleShowMaskingOutputToggle = () => {
    setShowMaskingOutput((prevOpen) => !prevOpen);
  };

  const onPagination = (obj) => {
    setPageNo(obj.pageNo);
  };

  const handleBackButton = () => {
    history.goBack();
  };

  const handleReexecuteMasking = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKINGLIST.replace(":id", params.id).replace(":classes", params.classes));
  };

  const handleReturnToSubclassification = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", params.classes));
  };

  return (
    <Observer>
      {() => (
        <Paper className={classes.pageContent}>
          <div className={classes.top}>
            <div className={classes.breadcrumbWraper}>
              <BackButton handleBackButton={handleBackButton} />
              <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
            </div>
          </div>
          <Divider className={classes.divider} />
          <div className={classes.top}>
            <div>
              <hr className={classes.legend} />
              <div className={classes.legendText}>{t("pages.training.masking.messages.masked-images")}</div>
            </div>
            <div className={classes.buttonWrapper}>
              <FormControlLabel
                control={
                  <Switch checked={showMaskingOutput} onChange={handleShowMaskingOutputToggle} name="showMaskingOutput" color="primary" />
                }
                label={t("pages.training.masking.show-masking-output")}
                labelPlacement="start"
              />
              <Button color="primary" variant="contained" onClick={handleReexecuteMasking}>
                {t("pages.training.masking.controls.re-execute")}
              </Button>
              <Button color="primary" variant="contained" onClick={handleReturnToSubclassification}>
                {t("pages.training.masking.controls.return-subclassification")}
              </Button>
            </div>
          </div>
          <div className={classes.pagination}>
            <Pagination
              onChange={onPagination}
              itemCount={totalClasses.length}
              pageNo={pageNo + 1}
              pageSize={pageSize}
              disableItemPerPage={true}
              disabled={false}
            />
          </div>
          <ImageListComponent
            classes={currentClasses}
            url={API_URL.GET_IMAGES_FOR_DATASET}
            order={{ desc: "updatedAt" }}
            expand={expanded}
            masking={false}
            maskConfirmation={true}
            imageType={imageType}
            imageSelection={false}
            carouselView
            showMoveImages={false}
            showEditClass={false}
            showEditClassName={false}
            showDeleteImageshowAddImage={false}
            showSecondImageSet={showMaskingOutput}
            isDragDropDisabled={true}
          />
        </Paper>
      )}
    </Observer>
  );
};
export default DefectMaskConfirmation;
