import { useContext } from 'react'
import AppStore from './../../../../stores/appstore'
import TrainingManagementStore from '../../../../stores/trainingmanagementstore'
import PopoverTables from '../popover/index'
import CustomTables from '../../../../components/customtable/table'

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions,
  disableAddButton,
  disableEditButton,
  disableDeleteButton
}) => {
  const trainingManagementStore = useContext(TrainingManagementStore)
  const appStore = useContext(AppStore)
  let selectedRowCount = 0
  const isSelected = (id) => {
    const selected = trainingManagementStore.selectedTrainingListData.filter(
      (item) => item._id === id,
    )
    return selected.length > 0
  }

  const getBodyData = (data) => {
    data = JSON.parse(JSON.stringify(data));
    return data.map((item) => {
      item.selected = isSelected(item._id);
      item.premodelUsed = item.trainParameter.preModel;
      if (item.selected) {
        selectedRowCount++;
      }
      return item;
    });
  };

  const handleSelectAllClick = (event) => {
    if (records?.length > 0) {
      const { checked } = event.target
      if (checked) {
        records.forEach((trainingList) => {
          const isTrainingListPresent = trainingManagementStore.selectedTrainingListData.filter(
            (selectedTrainingList) =>
              selectedTrainingList._id === trainingList._id,
          )
          if (!(isTrainingListPresent.length > 0)) {
            trainingManagementStore.setSelectedTrainingListRecord(trainingList)
          }
        })
        disableAddButton(true)
        if (trainingManagementStore.selectedTrainingListData.length > 1) {
          disableDeleteButton(false);
          disableEditButton(true);
         
        }
      } else {
        const deselectedTrainingList = []
        records.forEach((trainingList) => {
          if (
            trainingManagementStore.selectedTrainingListData.some(
              (selectedTrainingList) =>
                selectedTrainingList._id === trainingList._id,
            )
          ) {
            deselectedTrainingList.push(trainingList._id)
          }
        })
        trainingManagementStore.removeSelectedTrainingListDataList(
          deselectedTrainingList,
        )
        disableDeleteButton(false);
        disableAddButton(false)
        disableEditButton(false)
      }
    }
  }

  const onRowMouseOver = (trainingListId) => {
    const rowMouseOverData = records.filter((item) => item._id === trainingListId)
  }
  const onRowSelect = (event, trainingListId) => {
    const rowData = records.filter((item) => item._id === trainingListId)
    const selected = isSelected(trainingListId)

    if (selected) {
      trainingManagementStore.removeSelectedTrainingListData(trainingListId)
    } else {
      trainingManagementStore.setSelectedTrainingListRecord(rowData[0])
    }

    if (trainingManagementStore.selectedTrainingListData.length > 0) {
      disableAddButton(true)
      if (trainingManagementStore.selectedTrainingListData.length > 1) {
        disableDeleteButton(false);
        disableEditButton(true)
      } else {
        disableEditButton(false)
        disableDeleteButton(false);
      }
    } else {
      disableAddButton(false)
    }
  }

  const data = getBodyData(records)
  
  const PopoverTable = (props) => {
    let component = null
    switch (props.type) {
      case 'classes':
        component = <PopoverTables rowsData={props.data}/>
        break;
      default:
        break
    }
    return component
  }

  return (
    <CustomTables 
      loading={loading}  
      rowCount={records.length}
      headerData={columnDefinitions} 
      classname={containerClassName}
      onAllRowSelected={handleSelectAllClick}
      selectedRowCount={selectedRowCount}
      PopoverComponent={PopoverTable}
      onRowMouseOver = {onRowMouseOver}
      onRowSelect={onRowSelect}
      bodyData={data}
    ></CustomTables>
  )
}

export default Grid
