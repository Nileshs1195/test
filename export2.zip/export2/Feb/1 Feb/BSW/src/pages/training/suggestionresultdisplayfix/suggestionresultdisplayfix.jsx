import { Paper, Divider, FormControlLabel, Switch, Button } from "@material-ui/core";
import { Observer } from "mobx-react-lite";
import { useStyles } from "./style";
import { useContext, useEffect, useState } from "react";
import Pagination from "../../../shared/components/basictable/pagination";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import AppStore from "../../../stores/appstore";
import { API_RESPONSE, APP_ROUTES } from "../../../appconstants";
import ClassComponent from "./droppableclasscomponent/droppableclasscomponent";
import { DragDropContext } from "react-beautiful-dnd";
import { useHistory, useParams } from "react-router-dom";
import ImageManagementStore from "../../../stores/imagemanagementstore";
import TrainingManagementStore from "./../../../stores/trainingmanagementstore";
import CompareImageView from "./compareimageview";
import { useTranslation } from "react-i18next";
import CustomConfirmation from "../../../components/modal/CustomConfirmation";
import userPreventReload from "./userPreventReload";
import BackButton from "../../../components/backbutton";
import { Loader } from "../../../shared/components/ui";
import ThresholdSlider from "../../../components/threshold-slider";
import AddNewClass from "../../../components/add-class";

const SuggestionResultDisplayFix = () => {
  const initialProbabilityTreshold = 0.8;
  const decimalPoints = 4;
  const params = useParams();
  const classes = useStyles();
  const history = useHistory();
  const { t } = useTranslation();
  const imageManagementStore = useContext(ImageManagementStore);
  const [probabilityTreshold, setProbabilityTreshold] = useState(initialProbabilityTreshold.toFixed(decimalPoints));
  const [classNames, setClassNames] = useState([]);
  const [showTransferedImagesOnly, setShowTransferedImagesOnly] = useState(false);
  const appStore = useContext(AppStore);
  const { addBreadcrumb, updateLastBreadcrumb, removeLastBreadcrumb } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [isCompareImageview, setCompareImageview] = useState(false);
  const [isAddClassButton, setIsAddClassButton] = useState(false);
  const [openModal, setOpenModal] = useState("");
  const [showReload, setShowReload] = useState(false);
  const [loader, setLoader] = useState(false);
  const [suggestionList, setSuggestionList] = useState([]);
  const [columns, setColumns] = useState([]);
  const [selectedClasses, setSelectedClsses] = useState(params.classes);
  const [selectedSeqNo, setSelectedSeqNo] = useState([]);
  const [showGraph, setShowGraph] = useState(false);
  const [comparedImages, setComparedImages] = useState([]);
  const seqNoList = (JSON.parse(localStorage.getItem("selectedTrainingDatasets")))

  const handleShowTransferedImagesOnly = () => {
    setShowTransferedImagesOnly((prevOpen) => !prevOpen);
  };

  userPreventReload(showReload);

  const handleShowGraphToggle = () => {
    setShowGraph((prevOpen) => !prevOpen);
  };

  const setBreadCrumbs = () => {
    removeLastBreadcrumb();
    updateLastBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", seqNoList),
      label: "pages.training.training-parameter.breadcrumb.subclassification"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUGGESTION_RESULT_DISPLAY_AND_FIX,
      label: "pages.training.training-parameter.breadcrumb.suggestionResultDisplay"
    });
  };

  const initLoad = async () => {
    appStore.clearSelectedSuggestionResultClass(appStore.selectedSuggestionResultClass);
    appStore.updatePaginationStartIndex(0);
    // imageManagementStore.clearSelectedClassImages();
    await trainingManagementStore.fetchSuggestionResultData(params.id, params.batchNo);
    // getSubclassificationResult();
    getClassesData();
  };

  useEffect(async () => {
    initLoad();
    // return () => {
    //   imageManagementStore.clearSelectedClassImages();
    // };
  }, []);

  useEffect(() => {
    setBreadCrumbs();
  }, [addBreadcrumb]);

  useEffect(() => {
    getClassesData();
    let className = [];
    trainingManagementStore?.suggestionResultData.forEach((element) => {
      className.push({ label: element.className, value: element.seqNo });
    });

    setClassNames(className);
  }, [trainingManagementStore.suggestionResultData]);

  const handleImageClassEdit = async (sourceClassSeqNo, destinationClassSeqNo, selectedImagesSeqNos) => {
    let sourceClassIndex = trainingManagementStore.suggestionResultData.findIndex((e) => e.seqNo === sourceClassSeqNo);
    let destinationClassIndex = trainingManagementStore.suggestionResultData.findIndex((e) => e.seqNo === destinationClassSeqNo);

    const otherColumns = JSON.parse(JSON.stringify(trainingManagementStore.suggestionResultData));

    // Set start and end variables
    const start = otherColumns[sourceClassIndex];
    const end = otherColumns[destinationClassIndex];

    // Filter the start list
    let newStartList = {
      imageLeft: start.list.imageLeft.filter((element) => !selectedImagesSeqNos.includes(element.seqNo)),
      imageRight: start.list.imageRight.filter((element) => !selectedImagesSeqNos.includes(element.seqNo))
    };

    const movedItem = {
      imageLeft: start.list.imageLeft.filter((element) => selectedImagesSeqNos.includes(element.seqNo)),
      imageRight: start.list.imageRight.filter((element) => selectedImagesSeqNos.includes(element.seqNo))
    };

    if (movedItem.imageLeft.length > 0) {
      movedItem.imageLeft.forEach((element) => {
        if (!element.originalClass) {
          element.originalClass = start.seqNo;
        }
        if (element.originalClass !== end.seqNo) {
          element.isMoved = true;
        } else {
          element.isMoved = false;
        }
      });
    }
    if (movedItem.imageRight.length > 0) {
      movedItem.imageRight.forEach((element) => {
        if (!element.originalClass) {
          element.originalClass = start.seqNo;
        }
        if (element.originalClass !== end.seqNo) {
          element.isMoved = true;
        } else {
          element.isMoved = false;
        }
      });
    }
    // Make a new destination list array
    const newEndList = {
      imageRight: movedItem.imageRight.length > 0 && end?.list?.imageRight?.length > 0 ? [...movedItem.imageRight, ...end?.list?.imageRight] : end?.list?.imageRight,
      imageLeft: movedItem.imageLeft.length > 0 && end?.list?.imageLeft?.length > 0 ? [...movedItem.imageLeft, ...end?.list?.imageLeft] : end?.list?.imageLeft
    };

    otherColumns[sourceClassIndex].list = newStartList;
    otherColumns[destinationClassIndex].list = newEndList;

    trainingManagementStore.setSuggestionResultData(otherColumns);
  };

  const updateClassName = (data) => {
    let columnsData = [];
    columns.forEach((column) => {
      if (data.seqNo === column.seqNo) {
        column.className = data.className;
        column.modelName = data.modelName;
      }
      columnsData.push(column);
    });
    let updatedClassNames = classNames.map(item => {
      return item?.value === data?.seqNo ? { label: data?.className, value: data?.seqNo } : item
    });

    setClassNames(updatedClassNames);
    // updateClassData(data);
    setShowReload(true);
    setColumns(columnsData);
  };

  const updateClassData = (data) => {
    trainingManagementStore.addClassSuggestionResultData(appStore.paginationStartIndex, data);
    setShowReload(true);
    let columnsData = [data];
    columns.forEach((column) => {
      columnsData.push(column);
    });
    columnsData.pop();
    setColumns(columnsData);
    if (data) {
      let classes = selectedClasses + "," + data.seqNo;
      setSelectedClsses(classes);
    }
  };

  const getImageAccodian = () => {
    let result = [];
    columns.forEach((element) => {
      result.push(
        <ClassComponent
          selectedClass={handleSelectedClass}
          classData={element}
          suggestionList={suggestionList}
          key={element.seqNo}
          classesAvailable={classNames}
          updateClassName={updateClassName}
          showGraph={showGraph}
          showTransferedImagesOnly={showTransferedImagesOnly}
          probabilityTreshold={probabilityTreshold}
          imageClassEditAction={handleImageClassEdit}
          selectedSeqNos={selectedSeqNo}
        // classImageList={element.list?.length>0?element.list:null}
        />
      );
    });
    return result;
  };

  const isClassSelected = (seqNo) => {
    let count = appStore.selectedSuggestionResultClass.filter((item) => item.seqNo === seqNo);
    return count.length > 0;
  };

  const handleSelectedClass = (classInfo) => {
    const isClassSelect = isClassSelected(classInfo.seqNo);
    if (isClassSelect) {
      appStore.removeSelectedSuggestionResultClass(classInfo);
      setSelectedSeqNo(getUniqueSeqNos(appStore.selectedSuggestionResultClass, "seqNo"));
    } else {
      appStore.setSelectedSuggestionResultClass(classInfo);
      setSelectedSeqNo(getUniqueSeqNos(appStore.selectedSuggestionResultClass, "seqNo"));
    }
  };

  const handleSuggestionResultModal = (label) => {
    switch (label) {
      case "ADD":
        setIsAddClassButton((isOpen) => !isOpen);
        break;
      case "RESET-ALL":
        handleResetAll();
        break;
      case "RESET":
        handleReset();
        break;
      case "COMPARE-IMAGES":
        setCompareImageview((isOpen) => !isOpen);
        let comparedImageData = [];
        imageManagementStore.selectedClassImages.forEach((e) => {
          comparedImageData.push({
            className: e.className,
            image: trainingManagementStore.subclassificationImages.filter((image) => image.seqNo === e.imageSeqNo)[0]
          });
        });
        setComparedImages(comparedImageData);
        break;
      case "TRANSFERRED-IMAGES":
        handleShowTransferedImagesOnly();
        break;
      case "SAVE-CHANGES":
        let seqNos = selectedClasses.split(",").map((item) => Number(item));
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.CORRECTION_RESULT_DISPLAY.replace(":id", params.id).replace(":classes", seqNos.join()).replace(":seqNo", params.batchNo));
        break;
      case "FINISH":
        break;
      default:
    }
  };

  const getUniqueSeqNos = (obj, field) => {
    let seqNos = [];
    for (let i in obj) {
      if (seqNos.indexOf(obj[i][field]) == -1) {
        seqNos.push(obj[i][field]);
      }
    }
    return seqNos;
  };

  const handleReset = () => {
    let seqNo = getUniqueSeqNos(appStore.selectedSuggestionResultClass, "seqNo");
    if (seqNo?.length > 0) {
      trainingManagementStore.subclassificationResult(params.id, params.batchNo).then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          trainingManagementStore.fetchSuggestionResultData(params.id, params.batchNo);
          // setColumns(appStore.suggestionResult);
          initLoad();
        }
      });
    }
  };

  const handleResetAll = () => {
    trainingManagementStore.subclassificationResult(params.id, params.batchNo).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        trainingManagementStore.fetchSuggestionResultData(params.id, params.batchNo);
        // setColumns(appStore.suggestionResult);
        initLoad();
      }
    });
  };
  const onDragEnd = async ({ source, destination }) => {
    // Make sure we have a valid destination
    if (destination === undefined || destination === null || source.droppableId === destination.droppableId) return null;
    let sourceClassIndex = trainingManagementStore.suggestionResultData.findIndex((e) => e.seqNo.toString() === source.droppableId);
    let destinationClassIndex = trainingManagementStore.suggestionResultData.findIndex((e) => e.seqNo.toString() === destination.droppableId);
    const otherColumns = JSON.parse(JSON.stringify(trainingManagementStore.suggestionResultData));
    // Set start and end variables
    const start = otherColumns[sourceClassIndex];
    const end = otherColumns[destinationClassIndex];
    const saveImageData = {
      src_seqNo: start.seqNo,
      dst_seqNo: end.seqNo,
      seqNos: [source.index]
    };
    await trainingManagementStore.suggestionResultImageMove(params.id, saveImageData).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        // Filter the start list
        let newStartList = {
          imageLeft: start?.list?.imageLeft?.filter((element) => element.seqNo !== source.index),
          imageRight: start?.list?.imageRight?.filter((element) => element.seqNo !== source.index)
        };
        const movedItem = {
          imageLeft: start?.list?.imageLeft?.filter((element) => element.seqNo === source.index),
          imageRight: start?.list?.imageRight?.filter((element) => element.seqNo === source.index)
        };
        if (movedItem?.imageLeft?.length > 0 && !movedItem?.imageLeft?.[0]?.originalClass) {
          movedItem.imageLeft[0].originalClass = start.seqNo;
        }
        if (movedItem?.imageRight?.length > 0 && !movedItem?.imageRight?.[0]?.originalClass) {
          movedItem.imageRight[0].originalClass = start.seqNo;
        }
        if (movedItem?.imageLeft?.length > 0) {
          if (movedItem.imageLeft[0].originalClass !== end.seqNo) {
            movedItem.imageLeft[0].isMoved = true;
            movedItem.imageLeft[0].modeOfChange = 2;
          } else {
            movedItem.imageLeft[0].isMoved = false;
            movedItem.imageLeft[0].modeOfChange = 1;
          }
        }
        if (movedItem?.imageRight?.length > 0) {
          if (movedItem.imageRight[0].originalClass !== end.seqNo) {
            movedItem.imageRight[0].isMoved = true;
            movedItem.imageRight[0].modeOfChange = 2;
          } else {
            movedItem.imageRight[0].isMoved = false;
            movedItem.imageRight[0].modeOfChange = 1;
          }
        }
        // Make a new destination list array
        if (end?.list?.imageLeft === undefined) {
          end.list = { ...end.list, imageLeft: [] }
        } else if (end?.list?.imageRight === undefined) {
          end.list = { ...end.list, imageRight: [] };
        }
        const newEndList = {
          imageRight: movedItem.imageRight[0] ? [movedItem.imageRight[0], ...end.list.imageRight] : end.list.imageRight,
          imageLeft: movedItem.imageLeft[0] ? [movedItem.imageLeft[0], ...end.list.imageLeft] : end.list.imageLeft
        };
        otherColumns[sourceClassIndex].list = newStartList;
        otherColumns[destinationClassIndex].list = newEndList;
        trainingManagementStore.setSuggestionResultData(otherColumns);
        imageManagementStore.removeSelectedClassImage([source.index], start.seqNo);
      } else {
        console.log("Error occurred while saving image group record");
      }
    });
  };

  const getSubclassificationResult = async () => {
    await trainingManagementStore
      .subclassificationResult(params.id, params.batchNo)
      .then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE && response?.seqNos?.length > 0 && response?.data?.length > 0) {
          setSuggestionList(response?.data);
        }
      })
      .catch(() => { });
  };

  const handleTresholdChangeCommit = (tresholdValue) => {
    setProbabilityTreshold(tresholdValue);
  };

  const onPagination = (options) => {
    appStore.updatePaginationStartIndex((options.pageNo > 0 ? options.pageNo - 1 : options.pageNo) * options.pageSize);
    appStore.clearSelectedSuggestionResultClass(appStore.selectedSuggestionResultClass);
    getClassesData();
  };

  const getClassesData = () => {
    if (trainingManagementStore?.suggestionResultData?.length > 0) {
      const initialColumns = JSON.parse(JSON.stringify(trainingManagementStore.suggestionResultData)).slice(
        appStore.paginationStartIndex,
        appStore.paginationStartIndex + 5
      );
      setColumns(initialColumns);
    } else {
      setColumns([]);
    }
  };

  const handleBackButton = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", seqNoList))
  };

  const createClass = (id, className) => {
    setLoader(true);
    trainingManagementStore
      .suggestionResultCreateClass(params.id, { className, seqNo: params.batchNo })
      .then((response) => {
        setLoader(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setClassNames([...classNames, { label: response.data.className, value: response.data.seqNo }]);
          
          console.log(response.data);
          updateClassData(response.data);
        }
      })
      .catch((erro) => {
        // t("pages.training.input-parameter.modal.already-exist")
        setLoader(false);
      });
    // trainingManagementStore
    //   .datasetsCreateClass(params.id, {
    //     className
    //   })
    //   .then((response) => {
    //     if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE && response?.data) {
    //       trainingManagementStore.TrainingDataset.push(response?.data);
    //       handleNewClass(response?.data);
    //     }
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });
  };

  return (
    <Observer>
      {() => (
        <div>
          {loader && <Loader size={24} />}
          {/* <Prompt when={showReload} message={t("pages.training.suggestion-result.modal.messages.unsaved")} /> */}
          <AddNewClass
            open={isAddClassButton}
            dataset={trainingManagementStore.suggestionResultData}
            setAddClass={setIsAddClassButton}
            handleCreateClass={createClass}
          />
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <div className={classes.wrapContent}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>

              <Button color="primary" variant="contained" onClick={() => handleSuggestionResultModal("ADD")}>
                {t("pages.training.suggestion-result.controls.add-class")}
              </Button>
            </div>

            {imageManagementStore.selectedClassImages.length === 2 && (
              <CompareImageView open={isCompareImageview} imageData={comparedImages} onClose={() => setCompareImageview((isOpen) => !isOpen)} />
            )}
            <Divider className={classes.divider} />
            <br />
            <div>
              <hr className={classes.imageLegendAuto} />
              <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.autoLegend")}</div>
              <hr className={classes.imageLegendManual} />
              <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.manualLegend")}</div>
              <hr className={classes.imageLegendNone} />
              <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.noneLegend")}</div>
              <div className={classes.modelNameLAbel}>
                   <label htmlFor="">{t("pages.training.training-list.grid.title") + ": "}</label><label><b>{imageManagementStore.selectedTrainingModelName}</b></label>
              </div>
            </div>
            
            <div className={classes.controlContainer}>
              <Pagination
                disabled={false}
                disableItemPerPage={true}
                itemCount={trainingManagementStore.suggestionResultData.length}
                onChange={onPagination}
                pageNo={appStore.inspectionSearchFilter.pageNo + 1}
                pageSize={5}
              />
              <div className={classes.buttonWrapper}>
                <FormControlLabel
                  control={<Switch checked={showGraph} onChange={handleShowGraphToggle} name="showGraph" color="primary" />}
                  label="Show Graph"
                  labelPlacement="start"
                />
                <ThresholdSlider
                  onThresholdChange={handleTresholdChangeCommit}
                  disabled={false}
                  initialProbabilityTreshold={initialProbabilityTreshold}
                  decimalPoints={4}
                />
              </div>
            </div>
            <DragDropContext onDragEnd={onDragEnd}>{getImageAccodian()}</DragDropContext>
            <div className={classes.buttonWrapper}>
              <Button color="primary" onClick={() => setOpenModal("RESET-ALL")} variant="contained" size="small" disabled={false}>
                {t("pages.training.suggestion-result.modal.label.reset-all")}
              </Button>
              <Button
                color="primary"
                onClick={() => setOpenModal("RESET")}
                variant="contained"
                size="small"
                disabled={appStore?.selectedSuggestionResultClass?.length <= 0}
              >
                {t("pages.training.suggestion-result.modal.label.reset")}
              </Button>
              <Button
                color="primary"
                variant="contained"
                onClick={() => handleSuggestionResultModal("COMPARE-IMAGES")}
                size="small"
                disabled={imageManagementStore.selectedClassImages.length == 2 ? false : true}
              >
                {t("pages.training.suggestion-result.modal.label.compare-images")}
              </Button>
              <Button
                color="primary"
                variant="contained"
                size="small"
                disabled={false}
                onClick={() => handleSuggestionResultModal("TRANSFERRED-IMAGES")}
              >
                {showTransferedImagesOnly
                  ? t("pages.training.suggestion-result.controls.all-images")
                  : t("pages.training.suggestion-result.controls.transferred-images")}
              </Button>
              <Button color="primary" variant="contained" size="small" disabled={false} onClick={() => setOpenModal("SAVE-CHANGES")}>
                {t("pages.training.suggestion-result.controls.finish")}
              </Button>
            </div>
            <>
              <CustomConfirmation
                open={openModal === "RESET"}
                onClose={() => setOpenModal("")}
                onSubmit={() => handleSuggestionResultModal(openModal)}
                primary={"pages.training.input-parameter.controls.ok"}
                secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                title={t("pages.training.suggestion-result.modal.label.reset")}
                message={t("pages.training.suggestion-result.modal.messages.unsaved-selected")}
              />
              <CustomConfirmation
                open={openModal === "RESET-ALL"}
                onClose={() => setOpenModal("")}
                onSubmit={() => handleSuggestionResultModal(openModal)}
                primary={"pages.training.input-parameter.controls.ok"}
                secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                title={t("pages.training.suggestion-result.modal.label.reset-all")}
                message={t("pages.training.suggestion-result.modal.messages.unsaved")}
              />
              <CustomConfirmation
                open={openModal === "SAVE-CHANGES"}
                onClose={() => setOpenModal("")}
                onSubmit={() => handleSuggestionResultModal(openModal)}
                primary={"pages.training.input-parameter.controls.ok"}
                secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                title={t("pages.training.suggestion-result.modal.label.save-changes")}
                message={t("pages.training.suggestion-result.modal.messages.save-changes")}
              />
            </>
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default SuggestionResultDisplayFix;
