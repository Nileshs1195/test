import React from "react";
import { useEffect, useContext, useState, useCallback } from "react";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Typography, Accordion, AccordionSummary, AccordionDetails, Grid } from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useStyles } from "./style";
import AppStore from "../../../../../stores/appstore";
import { API_RESPONSE, API_URL, APP_ROUTES } from "../../../../../appconstants";
import Breadcrumb from "../../../../../shared/components/ui/breadcrumb";
import LinearProgressBar from "../../../../../components/linearprogressbar";
import { useTranslation } from "react-i18next";
import { useParams, useHistory } from "react-router-dom";
import BackButton from "../../../../../components/backbutton";
import ExecutionLogTable from "./ExecutionLogTable";
import TrainingManagementStore from "./../../../../../stores/trainingmanagementstore";
import TestManagementStore from "../../../../../stores/testManagementStore";
import CustomSnackBar from "../../../../../components/snackbar";
import CustomConfirmation from "../../../../../components/modal/CustomConfirmation";
import { Loader } from "../../../../../shared/components/ui";
import Model from "./modals";
import * as CommonMethod from "../../../../../helpers/CommonMethods";
import { SETTINGS } from "../../../../../appsettings";
import AddClassificationTest from "../../../../../components/add-test";
import GraphImage from "../../../../../components/graph-images";

const ExecutionLog = () => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb, updateLastBreadcrumb, breadcrumbs } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const testManagementStore = useContext(TestManagementStore);
  const { fetchExecutionLogData } = trainingManagementStore;
  const [isResultSetVisible, setResultSetVisibility] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [startExecution, setStartExecution] = useState(false);
  const [addTest, setAddTest] = useState(false);
  const [batchData, setBatchData] = useState({});
  const [fetchLog, setFetchLog] = useState(false);
  const [executionLogData, setExecutionLogData] = useState([]);
  const [loader, setLoader] = useState(false);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [loading, setLoading] = useState(false);
  const[graphData, setGrapData]= useState({});
  const [stopExecution, setStopExecution] = useState(false)
  const [resultSet, setResultSet] = useState({
    progress: 0,
    pgr: 0,
    Rate: 0,
    Ploss: 0,
    Closs: 0,
    elptime: 0,
    modelName: "",
    noOfFeatures: 0
  });
  const [toggleModel, setToggleModel] = useState(false);
  const [modalName, setModalName] = useState("");
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [testingData, setTestingData] = useState({
    title: "",
    deviceName: "",
    designGroup: "",
    processGroup: "",
    lotId: 0,
    comment: "",
    trainingId: params.id
  });

  useEffect(() => {
    removeLastBreadcrumb();
    updateLastBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING,
      label: "pages.training.training-parameter.breadcrumb.train-param-search.execution-log"
    });
  }, [addBreadcrumb]);

  useEffect(() => {
    setLoader(true);
    trainingManagementStore
      .getBatch(params.id, params.seqNo)
      .then(async (response) => {
        setLoader(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setBatchData(response?.data);
          if (response?.data?.mode === "training") {
            if (response.data.status === "Stop" || response.data.status === "Stopping" || response.data.status === "Stopped") {
              setsnapbarMessage({
                message: t("pages.training.errors.training-list.execution-cancelled", {
                  type: t("pages.training.errors.training-list.training")
                }),
                timeout: 100000
              });
            } else {
              setStartExecution(true);
            }
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.training-list.invalid-execution") });
            setStartExecution(false);
          }
        } else {
          setStartExecution(false);
          setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
        }
      })
      .catch((xhr) => {
        setLoader(false);
        setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
      });
  }, []);

  const fetchExecutionLogDataList = useCallback(async () => {
    if (!fetchLog) {
      setFetchLog(true);
      setLoader(true);
      setLoading(true);
      await fetchExecutionLogData(params.id, params.seqNo)
        .then((response) => {
          setFetchLog(false);
          setLoader(false);
          if (response?.status === 200) {
            setResultSetVisibility(true);
            setExecutionLogData(response.data);
            let executionLogs = response?.data;
            setGrapData({
              accuracyData: {
                image: executionLogs[executionLogs?.length - 1]?.accuracyImage,
                data: t("pages.training.training-parameter.train-parameter.graph-data.accuracy-data").split(","),
                color: t("pages.training.training-parameter.train-parameter.graph-data.accuracy-color").split(",")
              },
              lossData: {
                image: executionLogs[executionLogs?.length - 1]?.lossImage,
                data: t("pages.training.training-parameter.train-parameter.graph-data.loss-data").split(","),
                color: t("pages.training.training-parameter.train-parameter.graph-data.loss-color").split(",")
              }
            });
          }
        })
        .catch((err) => {
          setLoader(false);
          setFetchLog(false);
          console.log("error", err);
        });
    }
    setLoading(false);
  });

  const gotoTrainParameterSetting = () => {
    setOpenModal(false);
    setLoader(true);
    trainingManagementStore
      .stopExecution(params.id, params.seqNo)
      .then(async (response) => {
        setLoader(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setStopExecution(true);
          setTimeout(() => {
            history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
          }, 1000);
        } else {
          setsnapbarMessage({message: t("pages.training.errors.training-list.exec-cancel-failed")});
        }
      })
      .catch((xhr) => {
        setLoader(false);
      });
  };

  const gotoTrainingList = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING);
  };

  const handleBackButton = () => {
    if (startExecution && resultSet?.progress < 100 && resultSet?.status < 3) {
      setOpenModal(true);
    } else {
      setLoader(true);
      trainingManagementStore.setTabIndex(2);
      setTimeout(() => {
        setLoader(false);
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
      }, 1000);
    }
  };

  const goToDisplayAdvisor = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.ADVISOR.replace(":id", params.id).replace(":seqNo", params.seqNo));
  };

  const handleTestCreationModals = (label) => {
    switch (label) {
      case "ADD":
        setTestingData({
          title: "",
          deviceName: "",
          designGroup: "",
          processGroup: "P1",
          lotId: 0,
          comment: "",
          trainingId: params.id
        });
        setModalName("ADD");
        setToggleModel((isOpen) => !isOpen);
        break;
      case "CLOSE":
        setModalFormErrors({});
        setToggleModel((isOpen) => !isOpen);
      default:
        break;
    }
  };

  const handleTestingInputField = (name, value) => {
    setTestingData((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };

  const onChangeFieldData = (event) => {
    const { name, value } = event.target;
    handleTestingInputField(name, value);
  };

  const handleModalFormErrors = (errorData) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, errorData));
  };

  const handleValidation = (data) => {
    let errorMessage = t("pages.training.training-list.modal.error-text");
    let status = CommonMethod.validateModalForm(data, modalFormErrors, errorMessage, handleModalFormErrors);
    return status;
  };

  const saveTestingList = (testingData) => {
    setsnapbarMessage({ message: "" });
    testManagementStore
      .insertTestingList(testingData)
      .then((response) => {
        if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          testManagementStore.setSelectedTestModel(response.data._id, params.id);
          history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS.replace(":id", response.data._id));
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.training-list.save-failed") });
        }
      })
      .catch((error) => {
        console.log("error", error);
        setsnapbarMessage({ message: t("pages.training.errors.training-list.save-failed") });
      });
  };

  const createTestingList = () => {
    // console.log("handleValidation(testingData)", testingData, handleValidation({title: testingData?.title, comment: testingData?.comment}));
    if (handleValidation({ title: testingData?.title, comment: testingData?.comment })) {
      saveTestingList(testingData);
    } else {
      setToggleModel((isOpen) => !isOpen);
    }
  };

  return (
    <Observer>
      {() => (
        <div>
          {loader && <Loader size={24} />}
          {snapbarMessage.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          <AddClassificationTest open={addTest} setOpen={setAddTest} id={params.id} askTrainingModel={true} />
          <Model
            type={modalName}
            open={toggleModel}
            onClose={() => handleTestCreationModals("CLOSE")}
            inputField={testingData}
            onChange={onChangeFieldData}
            create={createTestingList}
            modalFormErrors={modalFormErrors}
          />
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <div className={classes.buttonWrapper}>
                <Button color="primary" variant="contained" disabled={resultSet?.status !== 7} onClick={goToDisplayAdvisor}>
                  {t("pages.training.training-parameter.train-parameter.controls.run-advisor")}
                </Button>
                <Button color="primary" variant="contained" disabled={resultSet?.status !== 7} onClick={() => setAddTest(true)}>
                  {t("pages.training.training-parameter.train-parameter.controls.test-model")}
                </Button>
                <Button color="primary" disabled={
                  resultSet?.status < 3
                } variant="contained" onClick={gotoTrainingList}>
                  {t("pages.training.training-parameter.train-parameter.controls.return-training")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={resultSet?.status > 2}
                  onClick={() => handleBackButton()}
                >
                  {t("pages.training.training-parameter.train-parameter.controls.cancel")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.mtop}>
              {startExecution && (
                <LinearProgressBar
                  setResultSet={setResultSet}
                  stopExecution={stopExecution}
                  batchData={batchData}
                  displayData={fetchExecutionLogDataList}
                  method="executionProgress"
                  executionType="trainingExecution"
                />
              )}
            </div>
            <CustomConfirmation
              open={openModal}
              onClose={() => setOpenModal(false)}
              onSubmit={gotoTrainParameterSetting}
              primary={"pages.training.input-parameter.controls.ok"}
              secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
              title={t("pages.training.input-parameter.modal.confirm-cancel-execution.title")}
              message={t("pages.training.input-parameter.modal.confirm-cancel-execution.text")}
            />

            {resultSet?.progress > 0 && (
              <div className={classes.accordionContainer}>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                    className={classes.accSummary}
                  >
                    <Typography className={classes.accSumTitle}>
                      {t("pages.training.training-parameter.train-parameter.accordian.title")}
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails className={classes.accDetails}>
                    <ExecutionLogTable
                      executionLogData={executionLogData}
                      loading={loading}
                    />
                  </AccordionDetails>
                </Accordion>             
                  {
                    graphData && <GraphImage graphData={graphData} params={params} />
                  }
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default ExecutionLog;
