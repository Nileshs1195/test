export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true
  },
  {
    key: "drag",
    type: "empty",
    value: "drag",
    isSticky: true    
  },
  {
    key: "updatedAt",
    text: "pages.training.training-list.grid.update-date-time",
    type: "date",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "className",
    text: "pages.training.training-parameter.grid.class-name",
    type: "string",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "imgCount",
    text: "pages.training.training-parameter.grid.total-images",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "trainImgCount",
    text: "pages.training.training-parameter.grid.train-images",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "trainPercentage",
    text: "pages.training.training-parameter.grid.train-percent",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validationCount",
    text: "pages.training.training-parameter.grid.valid-images",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "validationPercentage",
    text: "pages.training.training-parameter.grid.valid-percent",
    type: "number",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "defectSize",
    text: "pages.training.training-parameter.grid.defect-size-kb",
    type: "number",
    validation: { required: true, pattern: "//" }
  }
];
