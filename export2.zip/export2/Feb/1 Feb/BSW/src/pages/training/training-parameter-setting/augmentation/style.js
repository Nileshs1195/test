import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
    pageContent: {
        height: "calc(100vh - 230px)",
        position: "relative"
    },
    paperCustom: {
        paddingTop: 16,
        paddingRight: 16,
        paddingBottom: 8,
        paddingLeft: 16,
    },
    paperTitle: {
        textAlign: "center",
        fontSize: 16,
        fontWeight: "600"
    },
    radioGroup: {
        display: "flex",
        justifyContent: "center",
        // border: "1px solid black"
    },
    buttonWrapper: {
        position: "absolute",
        right: "16px",
        bottom: "16px"
    },
    divider: {
        marginTop: theme.spacing(2),
        marginBottom: theme.spacing(2)
    },
    mB1: {
        marginBottom: 8
    },
    buttonWrapperleft: {
        width : "80%",
        display: "flex",   
        float: "left",
        paddingBottom:"2%"
      },
      labelPosition: {
        paddingRight : "2%"
      },
}));