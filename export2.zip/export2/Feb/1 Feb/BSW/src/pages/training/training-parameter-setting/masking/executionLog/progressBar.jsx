import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Grid,
  Paper,
  Typography,
  Box,
  Button,
  Divider,
} from '@material-ui/core'
import { Observer } from 'mobx-react-lite'
import React, { useContext, useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { useHistory, useParams } from 'react-router'
import { API_RESPONSE, APP_ROUTES } from '../../../../../appconstants'
import BackButton from '../../../../../components/backbutton'
import LinearProgressBar from '../../../../../components/linearprogressbar'
import CustomConfirmation from '../../../../../components/modal/CustomConfirmation'
import CustomSnackBar from '../../../../../components/snackbar'
import { Breadcrumb } from '../../../../../shared/components/ui'
import AppStore from '../../../../../stores/appstore'
import TrainingManagementStore from '../../../../../stores/trainingmanagementstore'
import { useStyles } from './style'
import { Loader } from '../../../../../shared/components/ui'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'

const MaskingProgressBar = () => {
  const params = useParams()
  const history = useHistory()
  const classes = useStyles()
  const { t } = useTranslation()
  const appStore = useContext(AppStore)
  const { addBreadcrumb, updateLastBreadcrumb, removeLastBreadcrumb } = appStore
  const trainingManagementStore = useContext(TrainingManagementStore)
  const [isResultSetVisible, setResultSetVisibility] = useState(false)
  const [openModal, setOpenModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [stopExecution, setStopExecution] = useState(false)
  const [startExecution, setStartExecution] = useState(false)
  const [batchData, setBatchData] = useState({})
  const [snapbarMessage, setsnapbarMessage] = useState({
    message: '',
  })
  const [resultSet, setResultSet] = useState({
    progress: 0,
    Rate: 0,
    Ploss: 0,
    Closs: 0,
    elapsedTime: 0,
    modelName: '',
    noOfFeatures: 0,
    status: 0,
    mode: 0,
  })
  const [inputData, setInputData] = useState({
    trainingId: '',
    seqNos: '',
  })
  useEffect(() => {
    removeLastBreadcrumb()
    updateLastBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: 'pages.training.training-parameter.breadcrumb.training',
    })
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(
        ':id',
        params.id,
      ),
      label:
        'pages.training.training-parameter.breadcrumb.trainingParameterSettings',
    })
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(
        ':id',
        params.id,
      ).replace(':classes', params.classes),
      label: 'pages.training.training-parameter.breadcrumb.subclassification',
    })
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.maskingExecutionLog"
    });
    // addBreadcrumb({
    //     path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKINGLIST.replace(":id", params.id).replace(":classes", params.classes),
    //     label: "pages.training.training-parameter.breadcrumb.masking-list"
    // });
  }, [])

  useEffect(() => {
    setLoading(true);
    trainingManagementStore
      .getBatch(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          console.log(response);
          if (response?.data?.mode === "masking") {
            setBatchData(response.data);
            if (response.data.status === "Stop" || response.data.status === "Stopping" || response.data.status === "Stopped") {
              setsnapbarMessage({
                message: t("pages.training.errors.training-list.execution-cancelled", { "type": t("pages.training.errors.training-list.training") }),
                timeout: 100000
              })
            }
            setStartExecution(true);
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.training-list.invalid-execution") });
            setStartExecution(false);
          }
        } else {
          setStartExecution(false);
          setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
        }
      })
      .catch((xhr) => {
        setLoading(false);
        setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
      });
  }, [])

  useEffect(async () => {
    if (resultSet?.status === 8) {
      // await trainingManagementStore.stopExecution(params.id);
      setsnapbarMessage({
        message: t("pages.training.errors.subclassification.execution-failed"),
        type: "error",
        open: true
      });
      // setTimeout(() => {
      //   history.goBack();
      // }, 1000);
    }
  }, [resultSet]);

  const handleBackButton = () => {
    if(startExecution && resultSet?.progress < 100 && resultSet?.status < 3) {
      setOpenModal(true)
    } else {
      history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(':id',params.id))
    }
  }

  const stopExecutionLog = () => {
    setOpenModal(false);
    setLoading(true);
    trainingManagementStore
      .stopExecution(params.id, params.seqNo)
      .then(async (response) => {
        setLoading(false);
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setStopExecution(true);
          history.replace();
          history.goBack();
        } else {
          setsnapbarMessage({message: t("pages.training.errors.masking.exec-cancel-failed")})
        }
      })
      .catch((xhr) => {
        setLoading(false);
        setsnapbarMessage({message: t("pages.training.errors.masking.exec-cancel-failed")})
      });
  }

  const displayData = () => {
    setResultSetVisibility(true);
  }

  const goToMaskingConfirmation = () => {
    let classes = params.classes;
    if (!classes) {
      classes = localStorage.getItem('maskingSeqnos')
    }
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.DEFECT_MASK_CONFIRMATION.replace(":id", params.id).replace(":batchSeqNo", params.seqNo).replace(':classes', classes));
  }

  return (
    <Observer>
      {() => (
        <div>
          {loading && <Loader size={24} />}
          {snapbarMessage?.message && (
            <CustomSnackBar snapbarMessage={snapbarMessage} />
          )}
          <Paper className={classes.pageContent}>
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton
                  handleBackButton={handleBackButton}
                />
                <Breadcrumb
                  breadcrumbs={appStore.breadcrumbs}
                  removeBreadcrumb={appStore.removeBreadcrumb}
                />
              </div>
              <div>
                <Button
                  color="primary"
                  variant="contained"
                  disabled={resultSet?.status !== 7}
                  onClick={() => goToMaskingConfirmation()}
                >
                  {t('pages.training.input-parameter.controls.show-masking-result')}
                </Button>{' '}
                &nbsp;
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => {
                    history.goBack()
                  }}
                  disabled={resultSet?.status !== 7 && resultSet?.status !== 8}
                >
                  {t('pages.training.input-parameter.controls.back')}
                </Button>
                &nbsp;&nbsp;
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => handleBackButton()}
                  disabled={resultSet?.progress > 2}
                >
                  {t('pages.training.input-parameter.controls.cancel-btn')}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.mtop}>
              <CustomConfirmation
                open={openModal}
                onClose={() => setOpenModal(false)}
                onSubmit={stopExecutionLog}
                primary={'pages.training.input-parameter.controls.ok'}
                secondary={'pages.training.input-parameter.grid.cutomization.modal.cancel-btn'}
                title={t('pages.training.input-parameter.modal.confirm-cancel-execution.title')}
                message={t('pages.training.input-parameter.modal.confirm-cancel-execution.text')}
              />
              {startExecution && (
                <LinearProgressBar
                  stopExecution={stopExecution}
                  setResultSet={setResultSet}
                  displayData={displayData}
                  batchData={batchData}
                  resultSet={resultSet}
                  method="executionProgress"
                  inputData={inputData}
                  trainingId={params.id}
                  seqNumber={params.seqNo}
                />
              )}
            </div>

            {isResultSetVisible && (
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <Typography className={classes.heading}>
                    {t('pages.training.input-parameter.show-hide')}
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Box
                    m={1}
                    p={1}
                    bgcolor="background.paper"
                    className={classes.resultBox}
                    flexGrow={1}
                  >
                    <Box p={1} className={classes.boxwidth}>
                      <Paper variant="outlined" className={classes.paperPadd}>
                        <Grid container spacing={1}>
                          <Grid item xs={12} className={classes.textCenter}>
                            <Typography variant="h6" gutterBottom>
                              {t('pages.training.input-parameter.result')}
                            </Typography>
                            <Divider />
                          </Grid>
                          <Grid item xs={12} className={classes.buttonWrapper}>
                            {/* <Button color="primary" variant="contained" onClick={() => goToSuggestionResultPage()}>
                              {t("pages.training.input-parameter.controls.show-suggestion-result")}
                            </Button> */}
                          </Grid>
                        </Grid>
                      </Paper>
                    </Box>
                  </Box>
                </AccordionDetails>
              </Accordion>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  )
}

export default MaskingProgressBar
