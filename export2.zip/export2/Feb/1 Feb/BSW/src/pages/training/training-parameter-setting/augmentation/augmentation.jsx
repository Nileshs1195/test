import React from "react";
import { useEffect, useContext, useState } from "react";
import AppStore from "../../../../stores/appstore";
import { APP_ROUTES } from "../../../../appconstants";
import { Observer } from "mobx-react-lite";
import { Box, FormControlLabel, RadioGroup, Radio, Button, Divider, Paper, Grid } from "@material-ui/core";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import { useParams } from "react-router-dom";
import { API_RESPONSE } from "../../../../appconstants";
import CustomSnackBar from "../../../../components/snackbar";
import { Loader } from "../../../../shared/components/ui";

export default function Augmentation(props) {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { TrainingDataset,isActionDisabled, loading, tabIndex, setTabIndex } = props;
  const [loader, setLoader] = useState(false);
  const { 
    saveAugmentationMode, 
    getAugmentationMode     
  } = trainingManagementStore;
  const [augmentationMode, setAugmentationMode] = useState(null);
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [trainingId, setTrainingId] = useState(params.id);

  useEffect(() => {
    removeLastBreadcrumb();
    const breadcrumb = {
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING,
      label: "pages.training.training-parameter.augmentation.title"
    };
    addBreadcrumb(breadcrumb);
  }, [addBreadcrumb]);

  useEffect(() => {
    let selectedTraining = Object.assign({}, trainingManagementStore?.selectedTrainingListData?.[0] ?? trainingManagementStore.selectedTrainingListData[0]);
    if (selectedTraining?.augmentationMode) {
      setAugmentationMode(selectedTraining?.augmentationMode);
    }
  }, [trainingManagementStore]);

  const readAugmentationMode = () => {
    getAugmentationMode(trainingId).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setAugmentationMode(response.data);
        console.log("Augmentation mode fetched successfully");
      } else {
        setsnapbarMessage({ message: t("pages.training.errors.augmentation-mode.read-failed") });
      }
    }).catch((err) => {
      console.log('error', err);
    });
    setsnapbarMessage({ message: "" });
  }

  const handleAugmentationMode = event => {
    const { value } = event.target;
    setAugmentationMode(value);
  };

  const onClickSave = () => {
    let reqPayload = {
      augmentationMode: augmentationMode
    };
    setLoader(true);
    saveAugmentationMode(trainingId, reqPayload).then((response) => {
      setLoader(false);
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        if(response?.training) {
          trainingManagementStore.clearSelectedTrainingListData();
          trainingManagementStore.setSelectedTrainingListRecord(response?.training)
        }
        setsnapbarMessage({ message: t("pages.training.success.augmentation-mode.updated") });
        gotoTrainParameterSearch();
      } else {
        setsnapbarMessage({ message: t("pages.training.errors.augmentation-mode.update-failed") });
      }
    }).catch((err) => {
      setLoader(false);
      console.log('error', err);
    });
    setsnapbarMessage({ message: "" });
  };

  const gotoTrainParameterSearch = () => {
    setTimeout(() => {
      props.setTabIndex(2);
    });
  };
  let totalImages =0, totalValidationImages =0, totalTrainingImages =0;
    for(var i in TrainingDataset){
      totalImages = totalImages+ TrainingDataset[i].imgCount;
      totalValidationImages=totalValidationImages+TrainingDataset[i].validationCount;
      totalTrainingImages= totalTrainingImages+TrainingDataset[i].trainImgCount;    
   } 
  return (
    <Observer>
      {() => (
        <Box p={2} className={classes.pageContent}>
          {loader && <Loader size={24} /> }
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}          
          <div>
            <Grid container justify="center">
              <Grid item xs={8}>
                <Paper variant="outlined" className={classes.paperCustom}>
                  <Box className={classes.paperTitle}>
                    {t("pages.training.training-parameter.augmentation.setting-mode.title")}
                  </Box>
                  <Divider className={`${classes.divider} ${classes.mB1}`} />
                  <Box className={classes.radioGroup}>
                    <RadioGroup
                      aria-label="mode"
                      name="mode"
                      value={augmentationMode}
                      onChange={handleAugmentationMode}
                      row="true"
                    >
                      <FormControlLabel
                        disabled={props.isActionDisabled}
                        value="simple"
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.augmentation.setting-mode.simple")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        disabled={props.isActionDisabled}
                        value="recommended"
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.augmentation.setting-mode.recommended")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        disabled={props.isActionDisabled}
                        value="advanced"
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.augmentation.setting-mode.advanced")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        disabled={props.isActionDisabled}
                        value="developerMode"
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.augmentation.setting-mode.developer")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        disabled={props.isActionDisabled}
                        value="skip"
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.augmentation.setting-mode.skip")}
                        labelPlacement="end"
                      />
                    </RadioGroup>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </div>
          <div className={classes.buttonWrapper} justifyContent="flex-end">
            <Button
              color="primary"
              variant="contained"
              disabled={props.isActionDisabled}
              onClick={() => onClickSave()}
            >
              {t("pages.training.training-parameter.augmentation.controls.save-proceed")}
            </Button>
          </div>
        </Box>
      )}
    </Observer>
  )
}
