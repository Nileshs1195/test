export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true
  },
  {
    key: "drag",
    type: "empty",
    value: "drag",
    isSticky: true    
  },
  {
    key: "priorKnowledge",
    text: "pages.training.input-parameter.grid.prior-knowledge",

    type: "stringWithCheckbox",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "className",
    text: "pages.training.input-parameter.grid.class-name",
    type: "string",
    validation: { required: true, pattern: "//" }
  },

  {
    key: "imgCount",
    text: "pages.training.input-parameter.grid.total-images",
    type: "string",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "manualMaskedCount",
    text: "pages.training.input-parameter.grid.masked-images",
    type: "string",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "autoMaskedCount",
    text: "pages.training.input-parameter.grid.auto-masked-images",
    type: "string",
    validation: { required: true, pattern: "//" }
  }
];
