import React, { useEffect, useState } from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableRow from "@material-ui/core/TableRow";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";

const ImageDetailsBox = ({ imageData, suggestionList }) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const [rowData, setRowData] = useState([]);
  const rows = [
    {
      title: t("pages.training.manageImages.messages.fileName"),
      text: imageData.uploadFileName
    },
    {
      title: t('pages.training.manageImages.messages.probability'),
      text: imageData.probabilityValue
    },
    {
      title: t("pages.training.manageImages.messages.fileSize"),
      text: Math.floor(imageData.fileSize / 1024) + " KB"
    },
    {
      title: t("pages.training.manageImages.messages.pixelSize"),
      text: imageData.dimentionX + " X " + imageData.dimentionY
    },
    { title: t("pages.training.manageImages.messages.className"), text: imageData.probabilityValue }
  ];

  const getListData = () => {
    let imageProbabilities = [];
    if (imageData?.probabilities?.length > 0) {
      imageData?.probabilities.forEach((probability, key) => {
        imageProbabilities.push({
          title: probability?.className, //suggestionList?.[key]?.className,
          text: probability?.probability,
          seqNo: suggestionList?.[key]?.seqNo,
        });
      });

      imageProbabilities.sort((a, b) => a.text < b.text ? - 1 : Number(a.text > b.text)).reverse();
      imageProbabilities = imageProbabilities.splice(0, 5);
    }
    setRowData(imageProbabilities);
  }

  useEffect(() => {
    getListData();
  }, [imageData]);

  return (
    <TableContainer>
      <Table className={classes.table} aria-label="simple table">
        <TableBody>
          <TableRow key={0} className={classes.tRow}>
            <TableCell><b>Prediction Probability</b></TableCell>
          </TableRow>
          {rowData.map((row, key) => (
            <TableRow key={row.seqNo} className={classes.tRow}>
              <TableCell>{row.title}</TableCell>
              <TableCell>{row.text}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};
export default ImageDetailsBox;
