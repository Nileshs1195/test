import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    overflow: "hidden",
    minHeight: "calc(100vh - 82px)",
    maxHeight: "auto"
  },
  legend: {
    display: "inline-block",
    width: "15px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    border: "none",
    backgroundColor: "#dd0a55",
    verticalAlign: "middle"
  },
  legendText: {
    display: "inline-block",
    verticalAlign: "middle",
    marginRight: "16px"
  },
  breadcrumbWraper: {
    display: "flex"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  top: {
    marginTop: theme.spacing(2),
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  pagination: {
    marginTop: theme.spacing(2)
  }
}));
