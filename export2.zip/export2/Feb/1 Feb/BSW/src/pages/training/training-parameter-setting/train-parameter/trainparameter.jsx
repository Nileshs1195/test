import React from "react";
import { Button, Divider, TextField, FormControl } from "@material-ui/core";
import ArrowRightAltIcon from "@material-ui/icons/ArrowRightAlt";
import { useEffect, useContext, useState } from "react";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import AppStore from "../../../../stores/appstore";
import { APP_ROUTES } from "../../../../appconstants";
import GridMaterial from "@material-ui/core/Grid";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import Box from "@material-ui/core/Box";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import { Observer } from "mobx-react-lite";
import { API_RESPONSE } from "../../../../appconstants";
import { useParams, useHistory } from "react-router-dom";
import { validateModalForm, validateFloatAndIntValue, validateDigits } from "../../../../helpers/CommonMethods";
import CustomSnackBar from "../../../../components/snackbar";
import CustomConfirmation from "../../../../components/modal/CustomConfirmation";
import { Loader } from "../../../../shared/components/ui";
import { Autocomplete } from '@material-ui/lab'

export default function TrainParameter(props) {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb, updateLastBreadcrumb } = appStore;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { TrainingDataset, isActionDisabled, loading, tabIndex } = props;
  const {
    executedModels,
    insertTrainParamsCommonData,
    selectedTrainingListData
  } = trainingManagementStore;
  const [loader, setLoader] = useState(false);
  const [trainingId, setTrainingId] = useState(params.id);
  const [trainParamData, setTrainParamData] = useState({
    trainParameter: {
      mode: "",
      preModel: null
    }, developerMode: {
      ftFlag: 0,
      gpuID: 0,
      holdTemp: 0,
      learningRateCLoss: null,
      learningRatePLoss: null,
      learningRate: null,
      FeatureSize: null,
      batchSize: null,
      maxIter: null
    }, parameterSearchBatch: {
    }
  });
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [trainingList, setTrainingList] = useState([])

  useEffect(() => {
    removeLastBreadcrumb();
    updateLastBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", trainingId),
      label: "pages.training.training-parameter.trainParameter"
    });
  }, [addBreadcrumb]);

  useEffect(() => {
    let selectedTraining = Object.assign({}, selectedTrainingListData?.[0]);
    if (selectedTraining) {
      const trainingDropdownArray = executedModels.reduce(
        (trainingDropdownList, trainingItem) => {
          trainingDropdownList.push({
            label: trainingItem.modelName,
            value: trainingItem.id,
          })
          return trainingDropdownList
        }, [])
      setTrainingList(trainingDropdownArray);

      const selectedModel = trainingDropdownArray.filter(
        (item) => item.value === selectedTraining?.trainParameter?.preModel
      )
      handleSetTrainData("trainParameter", { mode: selectedTraining?.trainParameter?.mode, preModel: selectedModel[0]?.value });
      handleSetTrainData("developerMode", selectedTraining?.developerMode);
      handleSetTrainData("parameterSearchBatch", selectedTraining?.parameterSearchBatch);
    }
  }, [selectedTrainingListData]);

  const handleValidation = (data) => {
    let errorMessage = t("pages.training.training-list.modal.error-text");
    let status = validateModalForm(
      data,
      modalFormErrors,
      errorMessage,
      handleModalFormErrors
    );
    return status;
  }

  const handleSetTrainData = (name, value) => {
    setTrainParamData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleModalFormErrors = data => {
    console.log("data2", data);
    setModalFormErrors(Object.assign({}, modalFormErrors, data));
  };
  const onChangeTrainParamData = event => {
    const { name, value } = event.target;
    let trainParameter = {
      ...trainParamData.trainParameter, [name]: value
    };
    handleSetTrainData("trainParameter", trainParameter);
  }
  const onChangeDeveloperData = (event, type = "int") => {
    const { name, value } = event.target;
    const fieldError = `${name}ErrorMsg`;

    let isValid = true;
    if (type === "int") {
      isValid = validateDigits(value);
    } else if (type === "float") {
      isValid = validateFloatAndIntValue(value);
    }
    if (isValid || !value) {
      handleModalFormErrors({
        [name]: false,
        [fieldError]: ""
      });
      let developerMode = {
        ...trainParamData.developerMode, [name]: value
      };
      handleSetTrainData("developerMode", developerMode)
    } else {
      handleModalFormErrors({
        [name]: true,
        [fieldError]: type === "float" ? t("pages.training.errors.modal-errors.floatAndIntError") : t("pages.training.errors.modal-errors.only-integer")
      });
    }
  }

  const onClickSave = (event, saveOnly = false) => {
    let validationdata, data;
    if (trainParamData?.trainParameter?.mode === "developerMode") {
      data = {
        trainParameter: trainParamData?.trainParameter,
        developerMode: trainParamData?.developerMode,
      }
      validationdata = {
        mode: trainParamData?.trainParameter?.mode,
        learningRateCLoss: trainParamData?.developerMode?.learningRateCLoss,
        learningRatePLoss: trainParamData?.developerMode?.learningRatePLoss,
        learningRate: trainParamData?.developerMode?.learningRate,
        FeatureSize: trainParamData?.developerMode?.FeatureSize,
        batchSize: trainParamData?.developerMode?.batchSize,
        maxIter: trainParamData?.developerMode?.maxIter
      }
    } else {
      data = {
        trainParameter: trainParamData?.trainParameter
      }
      validationdata = { mode: trainParamData?.trainParameter?.mode };
    }
    let isValid = handleValidation(validationdata);
    if (isValid) {
      saveTrainParamModeData({ ...data, preModel: trainParamData.preModel }, saveOnly);
    }
  };

  const showConfirmation = () => {
    return (<CustomConfirmation open={snapbarMessage?.open} onClose={() => {
      setsnapbarMessage({
        open: false
      });
    }} onSubmit={redirectToProgress} primary={"pages.training.errors.training-list.fail-redirect"} secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"} title={snapbarMessage.title} message={snapbarMessage.info} />);
  }
  const redirectToProgress = () => {
    switch (snapbarMessage.type) {
      case "parameterSearch":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      case "subclassification":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      case "training":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      default:
        break;
    }
  }

  const saveTrainParamModeData = (data, saveOnly) => {
    setLoader(true);
    insertTrainParamsCommonData(
      trainingId,
      data
    ).then((response) => {
      setLoader(false);
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setsnapbarMessage({ message: t("pages.training.success.train-param.mode-updated") });
        if (response?.training) {
          trainingManagementStore.clearSelectedTrainingListData();
          trainingManagementStore.setSelectedTrainingListRecord(response?.training)
        }
        if (!saveOnly) {
          setLoader(true);
          trainingManagementStore.startExecution(trainingId, "parameterSearch", {}).then(res => {
            setLoader(false);
            if (res?.status === 200 && res?.data?.seqNo && res?.data?.mode === "parameterSearch") {
              trainingManagementStore.setSelectedTrainingListRecord(response?.training)
              history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH.replace(":id", trainingId).replace(":seqNo", res?.data?.seqNo));
            } else {
              if (res?.data?.mode === "training") {
                setsnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-training"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
              } else if (res?.data?.mode === "subclassification") {
                setsnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-subclassification"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
              } else {
                setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
              }
            }
          }).catch(error => {
            setLoader(false);
          });
        }
      } else {
        setsnapbarMessage({ message: t("pages.training.errors.train-param.update-mode-failed") });
      }
    }).catch(error => {
      setLoader(false);
    });;
    setsnapbarMessage({ message: "" });
  };

  const handleTrainingModel = (event, value) => {
    let trainParameter = {
      ...trainParamData.trainParameter, ["preModel"]: value.value
    };
    handleSetTrainData("trainParameter", trainParameter);
  }
  let totalImages = 0, totalValidationImages = 0, totalTrainingImages = 0;
  for (var i in TrainingDataset) {
    totalImages = totalImages + TrainingDataset[i].imgCount;
    totalValidationImages = totalValidationImages + TrainingDataset[i].validationCount;
    totalTrainingImages = totalTrainingImages + TrainingDataset[i].trainImgCount;
  }
  return (
    <Observer>
      {() => (
        <Box p={2} className={classes.pageContent}>
          {loader && <Loader size={24} />}
          {showConfirmation()}
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          {<Box className={classes.trainParameterContainer} alignItems="center">
            <GridMaterial container justify="center">
              <GridMaterial item xs={12} md={8} lg={8} className={classes.border}>
                <div className={classes.paperTitle}>
                  {t("pages.training.training-parameter.train-parameter.train-parameter-mode")}
                </div>
                <Divider className={classes.divider} />
                <div className={classes.timeInfo}>
                  {t("pages.training.training-parameter.train-parameter.low")}{" "}
                  <ArrowRightAltIcon className={classes.arrowFlip} />
                  <ArrowRightAltIcon className={classes.arrowFlip} />{" "}
                  {t("pages.training.training-parameter.train-parameter.training-time")}{" "}
                  <ArrowRightAltIcon />
                  <ArrowRightAltIcon />{" "}
                  {t("pages.training.training-parameter.train-parameter.high")}
                </div>
                <FormControl component="fieldset" alignItems="center">
                  <Box display="flex" alignItems="center">
                    <RadioGroup
                      aria-label="mode"
                      name="mode"
                      value={trainParamData?.trainParameter?.mode}
                      onChange={onChangeTrainParamData}
                      row="true"
                    >
                      <FormControlLabel
                        value="simple"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.simple")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        value="recommended"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.recommended")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        value="advanced"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.advanced")}
                        labelPlacement="end"
                      />
                      <FormControlLabel
                        value="developerMode"
                        disabled={props.isActionDisabled}
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.train-parameter.setting-mode.developer")}
                        labelPlacement="end"
                      />
                    </RadioGroup>
                  </Box>
                </FormControl>
              </GridMaterial>
            </GridMaterial>
            <form autoComplete="off">
              <GridMaterial container justify="center">
                <GridMaterial container item xs={12} md={10} lg={8} justify="center" spacing={2}>
                  <GridMaterial item xs={12} md={4} lg={4}>
                    <Autocomplete
                      id="combo-box"
                      disableClearable
                      value={trainingList.length > 0 && trainingList.filter(item => item.value === trainParamData?.trainParameter?.preModel)?.[0]}
                      options={trainingList}
                      getOptionLabel={(option) => option.label}
                      onChange={(event, value) => handleTrainingModel(event, value)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label={t("pages.training.training-parameter.train-parameter.select-training-model")}
                          id="preModel"
                          name="preModel"
                          margin="normal"
                          error={modalFormErrors['preModel']}
                        />
                      )}
                    />
                  </GridMaterial>
                </GridMaterial>
                {trainParamData?.trainParameter?.mode == "developerMode" && (
                  <>
                    <GridMaterial container item xs={12} md={10} lg={8} justify="center" spacing={2}>
                      <GridMaterial item xs={6} md={4} lg={4}>
                        <FormControl className={classes.formControl} margin="dense">
                          <TextField
                            fullWidth
                            disabled={props.isActionDisabled}
                            id="batchSize"
                            name="batchSize"
                            label={t("pages.training.training-parameter.train-parameter.batch-size")}
                            value={trainParamData?.developerMode?.batchSize}
                            onChange={(event) => onChangeDeveloperData(event, "int")}
                            error={modalFormErrors["batchSize"]}
                            helperText={
                              modalFormErrors["batchSizeErrorMsg"] !== "" &&
                              modalFormErrors["batchSizeErrorMsg"]
                            }
                          />
                        </FormControl>
                      </GridMaterial>
                      <GridMaterial item xs={6} md={4} lg={4}>
                        <FormControl className={classes.formControl} margin="dense">
                          <TextField
                            fullWidth
                            disabled={props.isActionDisabled}
                            id="FeatureSize"
                            name="FeatureSize"
                            label={t("pages.training.training-parameter.train-parameter.training-features")}
                            value={trainParamData?.developerMode?.FeatureSize}
                            onChange={(event) => onChangeDeveloperData(event, "int")}
                            error={modalFormErrors["FeatureSize"]}
                            helperText={
                              modalFormErrors["FeatureSizeErrorMsg"] !== "" &&
                              modalFormErrors["FeatureSizeErrorMsg"]
                            }
                          />
                        </FormControl>
                      </GridMaterial>
                      <GridMaterial item xs={6} md={4} lg={4}>
                        <FormControl className={classes.formControl} margin="dense">
                          <TextField
                            fullWidth
                            disabled={props.isActionDisabled}
                            id="maxIter"
                            name="maxIter"
                            label={t("pages.training.training-parameter.train-parameter.Iterations")}
                            value={trainParamData?.developerMode?.maxIter}
                            onChange={(event) => onChangeDeveloperData(event, "int")}
                            error={modalFormErrors["maxIter"]}
                            helperText={
                              modalFormErrors["maxIterErrorMsg"] !== "" &&
                              modalFormErrors["maxIterErrorMsg"]
                            }
                          />
                        </FormControl>
                      </GridMaterial>
                    </GridMaterial>
                    <GridMaterial container item xs={12} md={10} lg={8} justify="center" spacing={2} >
                      <GridMaterial item xs={6} md={4} lg={4}>
                        <FormControl className={classes.formControl} margin="dense">
                          <TextField
                            fullWidth
                            disabled={props.isActionDisabled}
                            id="learningRateCLoss"
                            name="learningRateCLoss"
                            label={t("pages.training.training-parameter.train-parameter.closs-factor")}
                            value={trainParamData?.developerMode?.learningRateCLoss}
                            onChange={(event) => onChangeDeveloperData(event, "float")}
                            error={modalFormErrors["learningRateCLoss"]}
                            helperText={
                              modalFormErrors["learningRateCLossErrorMsg"] !== "" &&
                              modalFormErrors["learningRateCLossErrorMsg"]
                            }
                          />
                        </FormControl>
                      </GridMaterial>
                      <GridMaterial item xs={6} md={4} lg={4}>
                        <FormControl className={classes.formControl} margin="dense">
                          <TextField
                            fullWidth
                            disabled={props.isActionDisabled}
                            id="learningRatePLoss"
                            name="learningRatePLoss"
                            label={t("pages.training.training-parameter.train-parameter.ploss-factor")}
                            value={trainParamData?.developerMode?.learningRatePLoss}
                            onChange={(event) => onChangeDeveloperData(event, "float")}
                            error={modalFormErrors["learningRatePLoss"]}
                            helperText={
                              modalFormErrors["learningRatePLossErrorMsg"] !== "" &&
                              modalFormErrors["learningRatePLossErrorMsg"]
                            }
                          />
                        </FormControl>
                      </GridMaterial>
                      <GridMaterial item xs={6} md={4} lg={4}>
                        <FormControl className={classes.formControl} margin="dense">
                          <TextField
                            fullWidth
                            disabled={props.isActionDisabled}
                            id="learningRate"
                            name="learningRate"
                            label={t("pages.training.training-parameter.train-parameter.eloss-factor")}
                            value={trainParamData?.developerMode?.learningRate}
                            onChange={(event) => onChangeDeveloperData(event, "float")}
                            error={modalFormErrors["learningRate"]}
                            helperText={
                              modalFormErrors["learningRateErrorMsg"] !== "" &&
                              modalFormErrors["learningRateErrorMsg"]
                            }
                          />
                        </FormControl>
                      </GridMaterial>
                    </GridMaterial>
                  </>
                )}
              </GridMaterial>
            </form>
          </Box>}
          <div className={classes.buttonWrapper} justifyContent="flex-end">
            {trainParamData?.parameterSearchBatch?.seqNo &&
              <Button
                color="primary"
                variant="contained"
                disabled={!props.isActionDisabled}
                onClick={() => {
                  history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH_VIEW.replace(":id", params.id).replace(":seqNo", trainParamData?.parameterSearchBatch?.seqNo));
                }}
              >
                {t("pages.training.training-parameter.train-parameter.view-parameter-search")}
              </Button>} &nbsp; &nbsp;
            <Button
              color="primary"
              variant="contained"
              disabled={props.isActionDisabled}
              onClick={(event) => {
                onClickSave(event, true);
              }}
            >
              {t("pages.training.training-parameter.train-parameter.save-parameter")}
            </Button>
            <Button
              color="primary"
              variant="contained"
              disabled={props.isActionDisabled}
              onClick={onClickSave}
            >
              {t("pages.training.training-parameter.train-parameter.save-proceed")}
            </Button>
          </div>
        </Box>
      )}
    </Observer>
  );
}
