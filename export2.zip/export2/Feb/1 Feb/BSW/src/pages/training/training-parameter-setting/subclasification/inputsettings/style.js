import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  paperCustom: {
    padding: 16
  },
  paperTitle: {
    textAlign: "center",
    lineHeight: "100%",
    fontWeight: theme.typography.fontWeightRegular
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2)
  },
  tableContainerFooter: {
    height: "calc(100vh - 318px)",
    marginTop: "8px"
  },
  tableContainer: {
    height: "calc(100vh - 268px)",
    marginTop: "8px"
  },
  footerContainer: {
    justifyContent: "space-between",
    backgroundColor: theme.palette.primary.main,
    display: "flex",
    paddingTop: 3,
    paddingBottom: 3,
    maxHeight: 55,
    padding: "0px 5px"
  },
  noOfDevicesWrapper: {
    color: "#fff",
    alignSelf: "center"
  },
  buttonGroup: {
    display: "flex",
    alignSelf: "center",
    "& > *": {
      margin: theme.spacing(0.75)
    }
  },
  buttons: {
    color: "#fff",
    borderColor: "white",
    "&:disabled": {
      color: "rgba(255, 255, 255, .35)",
      borderColor: "rgba(255, 255, 255, .35)"
    }
  },
  mB1: {
    marginBottom: 8
  }
}));
