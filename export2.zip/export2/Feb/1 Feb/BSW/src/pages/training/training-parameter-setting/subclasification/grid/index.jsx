import { useContext } from "react";
import AppStore from "./../../../../../stores/appstore";
import TrainingManagementStore from "../../../../../stores/trainingmanagementstore";
import CustomTables from '../../../../../components/customtable/table';
import { API_RESPONSE } from '../../../../../appconstants';

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions,
  disableAddButton,
  disableEditButton,
  disableMasking,
  disableCheckBox,
  onPriorKnowledge
}) => {
  
  const trainingManagementStore = useContext(TrainingManagementStore);
  let selectedRowCount = 0;

  const isSelected = id => {
    const selected = trainingManagementStore.selectedInputParameter.filter(
      item => item.seqNo === id
    );
    disableMasking(!(trainingManagementStore.selectedInputParameterCount === records.length))
    return selected.length > 0;
  };

  const getBodyData = data => {
    data = JSON.parse(JSON.stringify(data));
    return data.map(item => {
      item._id = item.seqNo;
      item.selected = isSelected(item._id);
      if (item.selected) {
        selectedRowCount++;
      }
      return item;
    });
  };

  const handleSelectAllClick = event => {
    if (records?.length > 0 && !disableCheckBox ) {
    const { checked } = event.target;
    if (checked) {
      disableAddButton(true);
      disableEditButton(true);
      records.forEach(inputParameter => {
        const isInputParameterPresent = trainingManagementStore.selectedInputParameter.filter(
          selectedInputParameter =>
            selectedInputParameter.seqNo === inputParameter.seqNo
        );
        if (!(isInputParameterPresent.length > 0)) {
          trainingManagementStore.setselectedInputParameter(inputParameter);
        }
      });
    } else {
      disableAddButton(false);
      disableEditButton(false);
      const deselectedInputParameter = [];
      records.forEach(inputParameter => {
        if (
          trainingManagementStore.selectedInputParameter.some(
            selectedInputParameter =>
              selectedInputParameter.seqNo === inputParameter.seqNo
          )
        ) {
          deselectedInputParameter.push(inputParameter.seqNo);
        }
      });
      trainingManagementStore.removeselectedInputParameters(
        deselectedInputParameter
      );
    }
  }
  };

  const onRowSelect = (event, inputParameterId) => {
    if(!disableCheckBox){
    const rowData = records.filter(item => item.seqNo === inputParameterId);
    const selected = isSelected(inputParameterId);
    if (selected) {
      trainingManagementStore.removeselectedInputParameter(inputParameterId);
    } else {
      trainingManagementStore.setselectedInputParameter(rowData[0]);
    }
    if (trainingManagementStore.selectedInputParameter.length > 0) {
      disableAddButton(true);
      if (trainingManagementStore.selectedInputParameter.length > 1) {
        disableEditButton(true);
      } else {
        disableEditButton(false);
      }
    } else {
      disableAddButton(false);
    }
  }
  };
  
  const changeDataOrder = (trainingId,classes) =>{
    trainingManagementStore.changeDatasetOrder(trainingId,{ classes }).then((res)=>{
      if(res && res.status=== API_RESPONSE.SUCCESS_STATUS_CODE){
        trainingManagementStore.fetchTrainingDataset(trainingId);
      }
    }).catch(err=>{
      console.log(err);
    })
  }

  const data = getBodyData(records);

  return (
    <>
      {/* we can also implement onDragEnd for here using the onDragEnd Prop. */}
      <CustomTables
        enableDrag={true}
        loading={loading}
        rowCount={records.length}
        classname={containerClassName}
        headerData={columnDefinitions}
        selectedRowCount={selectedRowCount}
        onAllRowSelected={handleSelectAllClick}
        onRowSelect={onRowSelect}
        bodyData={data}
        callback={changeDataOrder}
        onCheckboxClick={onPriorKnowledge}
      />
    </>
  );
};

export default Grid;
