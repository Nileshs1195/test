import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%"
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  wrapContent:{
    display:"flex"
  },
  tableContainerFooter: {
    height: "calc(100vh - 286px)"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  controlContainer: {
    display: "flex",
    alignItems: "center",
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
    justifyContent: "space-between"
  },
  container: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between"
  },
  thumbheader: {
    display: "flex",
    padding: "16px 16px 0 16px"
  },
  thumbWrap: {
    padding: "16px 16px 8px 16px"
  },
  thumbItem: {
    position: "relative",
    zIndex: 0
  },
  thumbImg: {
    width: "121px",
    height: "100%",
    borderRadius: "4px"
  },
  sliderRoot: { width: 350 },
  sliderClass: {
    marginBottom: "0px",
    "& .MuiSlider-markLabel": {
      left: "16px !important",
      fontSize: "12px",
      fontWeight: 300,
      lineHeight: "100%",
      "&[data-index='1']": {
        right: "-25px",
        left: "inherit !important"
      }
    }
  },
  buttonWrapper: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  footerContainer: {
    justifyContent: "flex-end",
    backgroundColor: theme.palette.primary.main,
    display: "flex",
    paddingTop: 3,
    paddingBottom: 3,
    maxHeight: 55,
    padding: "0px 5px"
  },
  buttonGroup: {
    display: "flex",
    alignSelf: "center",
    "& > *": {
      margin: theme.spacing(0.75)
    }
  },
  thresholdInput: {
    width: "100px"
  },
  imageLegendAuto: {
    display: "inline-block",
    width: "13px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    backgroundColor: "#3a5faa",
    verticalAlign: "middle"
  },
  imageLegendManual: {
    display: "inline-block",
    width: "13px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    backgroundColor: "#dd0a55",
    verticalAlign: "middle"
  },
  imageLegendNone: {
    display: "inline-block",
    width: "13px",
    height: "4px",
    margin: "8px 8px 8px 0px",
    backgroundColor: "#cccccc",
    verticalAlign: "middle"
  },
  imageLegendText: {
    display: "inline-block",
    verticalAlign: "middle",
    marginRight: "16px"
  },
  modelNameLAbel:{
    display: "inline-block",
    float: "right",
    paddingRight:"1%"
  }
}));
