export const ValidateModalForm = (
  validateData,
  handleModalFormErrors,
  setErrorMessage,
  modalFormErrors
) => {
  let errorObj = {
    isFormValid: true,
    modalFormErrors: {}
  };
  for (const fieldName in validateData) {
    if (validateData[fieldName] === "") {
      setErrorMessage(errorObj, fieldName, `${fieldName}ErrorMsg`);
    } else {
      if (modalFormErrors["className"]) {
        errorObj.isFormValid = false;
      }
    }
  }
  handleModalFormErrors(errorObj.modalFormErrors);
  return errorObj.isFormValid;
};

export const onChangeDataSetting = (
  event,
  handleSetTrainingData,
  handleModalFormErrors,
  checkClassName,
  errMsg
) => {
  const { name, value } = event.target;
  const fieldName = name;
  const fieldError = `${name}ErrorMsg`;
  if (name === "priorKnowledge") {
    handleSetTrainingData(name, event.target.checked);
  } else {
    handleSetTrainingData(name, value);
    const classNameExist = checkClassName(value.trim());
    let validReg = validateFreeText(value);
    if (classNameExist) {
      let errorObj = {
        isFormValid: true,
        modalFormErrors: {}
      };
      errorObj.modalFormErrors[fieldName] = true;
      errorObj.modalFormErrors[fieldError] = errMsg["errExist"];
      handleModalFormErrors(errorObj.modalFormErrors);
    } else {
      if (value.length > 0) {
        if (validReg) {
          handleModalFormErrors({
            [fieldName]: false,
            [fieldError]: ""
          });
        } else {
          handleModalFormErrors({
            [fieldName]: true,
            [fieldError]: errMsg["errAlphanumeric"]
          });
        }
      }
    }
  }
};

const validateFreeText = value => {
  let regExp1 = new RegExp("^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9_ -]+$");
  let status = regExp1.test(value) ? true : false;
  return status;
};
