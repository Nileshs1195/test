import { Button, Divider, Paper } from "@material-ui/core";
import GridMaterial from "@material-ui/core/Grid";
import { Observer, observer } from "mobx-react-lite";
import { useHistory, useParams } from "react-router-dom";
import { useCallback, useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import Breadcrumb from "../../../../shared/components/ui/breadcrumb";
import AppStore from "../../../../stores/appstore";
import TrainingManagementStore from "./../../../../stores/trainingmanagementstore";
import ImageManagementStore from "./../../../../stores/imagemanagementstore";
import { API_URL, APP_ROUTES } from "../../../../appconstants";
import InputSetting from "./inputsettings";
import ParameterSetting from "./parameterSetting";
import { useStyles } from "./style";
import { API_RESPONSE } from "../../../../appconstants";
import BackButton from "../../../../components/backbutton";
import CustomSnackBar from "../../../../components/snackbar";
import CustomConfirmation from "../../../../components/modal/CustomConfirmation";
import EditClass from "../../../../components/subclassification-forms/EditClass";
import * as CommonMethods from '../../../../helpers/CommonMethods';

const SubClasicication = observer((props) => {
  const classes = useStyles();
  const params = useParams();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { setUploaderAction, newlyCreatedClasses, setNewlyCreatedClasses, imageUploadStatus } = imageManagementStore;
  const { TrainingDataset } = trainingManagementStore;
  const { inspectionSearchFilter, addBreadcrumb, removeLastBreadcrumb } = appStore;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [isAddButtonDisabled, disableAddButton] = useState(false);
  const [isEditAndNextDisabled, disableEditButton] = useState(false);
  const [inputParameter, setTrainingInputParameter] = useState({ className: "", priorKnowledge: "" });
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [isDelete, setDelete] = useState(false);
  const [editClass, setEditClass] = useState(false);
  const [isFileDeleteModal, toggleFileDeleteModal] = useState(false);
  const [isAddClassModal, toggleAddclassModal] = useState(false);
  const [isMasking, setMasking] = useState(false);
  const [showMaskingSubclass, setShowMaskingSubclass] = useState(false);
  const [trainingList, setTrainingList] = useState([])

  const fetchInputParameter = async (data) => {
    data.map((item) => {
      if (item.priorKnowledge === true || item.priorKnowledge === "Yes") {
        item.priorKnowledge = "Yes";
      } else {
        item.priorKnowledge = "No";
      }
    });
    await trainingManagementStore.setInputparameter([...data]);
    await trainingManagementStore.setInputParameterTotalCount(data.length);
  };

  const getTrainingInputParameter = useCallback(
    async (data) => {
      if (data?.length > 0) {
        setLoading(true);
        await fetchInputParameter(data);
        setLoading(false);
      }
    },
    [fetchInputParameter, inspectionSearchFilter]
  );

  useEffect(() => {
    if (trainingManagementStore.TrainingInputparameter.length === 0) {
      getTrainingInputParameter(trainingManagementStore.selectedTrainingDataset);
    }
  }, [getTrainingInputParameter, trainingManagementStore.TrainingInputparameter]);

  useEffect(() => {
    removeLastBreadcrumb();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
      label: "pages.training.training-parameter.breadcrumb.trainingParameterSettings"
    });
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", params.classes),
      label: "pages.training.training-parameter.breadcrumb.subclassification"
    });
    // updateTrainingDetails();
  }, [addBreadcrumb]);

  useEffect(() => {
    const checkPriorKnowledege = CommonMethods.getUniqueDataByField(trainingManagementStore.TrainingInputparameter,'priorKnowledge');
    if(checkPriorKnowledege.length>0 && !checkPriorKnowledege.includes('Yes')){
      let options = {
        checked:true,
        messages: false
      }
      onPriorKnowledge(options,trainingManagementStore.TrainingInputparameter[0])
    }
    return () => {
      trainingManagementStore.TrainingInputparameter = [];
      trainingManagementStore.clearselectedInputParameter();
    };
  }, []);

  let checkArray = (arr, target) => target.every((v) => arr.includes(v));

  useEffect(async () => {
    if ((imageUploadStatus === "in-progress" || imageUploadStatus === "completed") && newlyCreatedClasses?.length > 0) {
      let datasets = [];
      let selectedSeqNos = [];
      let seqNos = params?.classes ? params.classes.split(",").map((item) => Number(item)) : [];
      await TrainingDataset.forEach((dataset) => {
        if (newlyCreatedClasses.includes(dataset.className)) {
          selectedSeqNos.push(Number(dataset.seqNo));
        }
      });
      if (checkArray(seqNos, selectedSeqNos)) {
        selectedSeqNos = seqNos;
      } else {
        selectedSeqNos = [...selectedSeqNos, ...seqNos].sort().reverse();
        history.replace(
          APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", selectedSeqNos.join())
        );
      }
      if (selectedSeqNos && selectedSeqNos.length > 0) {
        await TrainingDataset.forEach((dataset) => {
          if (selectedSeqNos.includes(dataset.seqNo)) {
            datasets.push(dataset);
          }
        });
      }
      localStorage.setItem("selectedTrainingDatasets", JSON.stringify(selectedSeqNos));
      fetchInputParameter(datasets);
      setNewlyCreatedClasses([]);
    } else {
      if (params?.classes && TrainingDataset) {
        let selectedSeqNos = params.classes.split(",").map((item) => Number(item));
        if (selectedSeqNos?.length > 0) {
          addSelectedDatasets(selectedSeqNos);
        }
      }
    }
  }, [imageUploadStatus, newlyCreatedClasses]);

  useEffect(() => {
    if (params?.classes) {
      let selectedSeqNos = params.classes.split(",").map((item) => Number(item));
      let datasets = [];
      if (selectedSeqNos?.length > 0) {
        trainingManagementStore.TrainingDataset.forEach((dataset) => {
          if (selectedSeqNos.includes(dataset.seqNo)) {
            datasets.push(dataset);
          }
        });
      }
      localStorage.setItem("selectedTrainingDatasets", JSON.stringify(selectedSeqNos));
      fetchInputParameter(datasets);
    }
  }, [trainingManagementStore.TrainingDataset]);

  const addSelectedDatasets = async (seqList) => {
    let selectedDatasets = [];
    trainingManagementStore.TrainingDataset.forEach((dataset) => {
      if (dataset.seqNo && seqList && seqList.includes(dataset.seqNo)) {
        selectedDatasets.push(dataset);
      }
    });
    fetchInputParameter(selectedDatasets);
  };

  const showConfirmation = () => {
    return (
      <CustomConfirmation
        open={snapbarMessage?.open}
        onClose={() => {
          setsnapbarMessage({
            open: false
          });
        }}
        onSubmit={redirectToProgress}
        primary={"pages.training.errors.training-list.fail-redirect"}
        secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
        title={snapbarMessage.title} message={snapbarMessage.info} />);
  }

  const redirectToProgress = () => {
    switch (snapbarMessage.type) {
      case "parameterSearch":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      case "subclassification":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      case "training":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(":id", params.id).replace(":seqNo", snapbarMessage.seqNo));
        break;
      default:
        break;
    }
  }

  const handleNewInputParameterModal = async (label, isMasked = false) => {
    switch (label) {
      case "prior":
        getTrainingInputParameter(trainingManagementStore.TrainingInputparameter);
        break;
      case "EDIT":
        setTrainingInputParameter({
          className: trainingManagementStore.selectedInputParameter[0]?.className,
          priorKnowledge: trainingManagementStore.selectedInputParameter[0]?.priorKnowledge == "Yes" ? true : false,
          seqNos: trainingManagementStore.selectedInputParameter[0]?.seqNo
        })
        setEditClass(true);
        break;
      case "EXECUTE":
        setShowMaskingSubclass(false);
        if (params.id) {
          let reqPayload = {
            seqNos: trainingManagementStore.TrainingInputparameter.map((item) => item.seqNo),
            isMasked: isMasked,
          };
          let selectedTraining = Object.assign(
            {},
            trainingManagementStore?.selectedTrainingListData?.[0] ?? trainingManagementStore.selectedTrainingListData[0]
          );
          if (selectedTraining?.mode === 4 && (selectedTraining?.status === 2 || selectedTraining?.status === 7)) {
            //Execuation already in progress or already completed
          } else {
          }
          setLoading(true);
          let res = await trainingManagementStore.startExecution(params.id, "subclassification", reqPayload);
          if (res?.status === API_RESPONSE.SUCCESS_STATUS_CODE && res?.data?.seqNo && res?.data?.mode === "subclassification") {
            history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION.replace(":id", params.id).replace(":seqNo", res?.data?.seqNo));
            setLoading(false);
          } else {
            setLoading(false);
            if (res?.data?.mode === "training") {
              setsnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-training"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
            } else if (res?.data?.mode === "parameterSearch") {
              setsnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-parameter-search"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
            } else {
              setsnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
            }
          }
        }
        break;
      case "DELETE":
        setDelete(true);
        break;
      case "MASKING":
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKINGLIST.replace(":id", params.id).replace(":classes", params.classes))
        break;
      case "CLOSE":
        trainingManagementStore.selectedInputParameter = [];
        disableAddButton(false);
    }
  };

  const onPriorKnowledge = (options,data) => {

    const payload = {
      seqNos: data?.seqNo,
      className: data?.className,
      priorKnowledge: options?.checked
    }

    setsnapbarMessage({ message: "" });
    trainingManagementStore
    .editDatasetAPI(params?.id, payload)
    .then((response) => {
        if (response?.status === API_RESPONSE?.SUCCESS_STATUS_CODE) {
          if (response?.data?.exists && options?.messages) {
            setsnapbarMessage({ message: t("pages.training.errors.dataset.record-exists") });
          } else {
            trainingManagementStore.clearselectedInputParameter();
            trainingManagementStore.updateTrainingInputparameterList(payload, response?.data?.dataset?.[0]?.seqNo);
            handleNewInputParameterModal('prior');
            options?.messages && setsnapbarMessage({ message: t("pages.training.success.dataset.updated") });
          }
        } else {
          setsnapbarMessage({ message: t("pages.training.errors.dataset.update-failed") });
        }
    })
    .catch((error) => {
        // setLoading(false);
        console.log("error", error);
        setsnapbarMessage({ message: t("pages.training.errors.dataset.update-failed") });
    });
  }



  const handleSubclassificationDelete = () => {
    let reqPayload = {
      seqNo: trainingManagementStore.selectedInputParameter.map((item) => item.seqNo)
    };
    setLoading(true);
    trainingManagementStore
      .deleteDatasetRecords(params.id, reqPayload)
      .then((response) => {
        setLoading(false);
        if (response && response.data && response.data.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          // fetchTrainingSubClass();
          if (response?.data?.data) {
            trainingManagementStore.clearselectedInputParameter();
            trainingManagementStore.clearSelectedTrainingDataset();
            fetchInputParameter(response?.data?.data)
            trainingManagementStore.setTrainingDataset(response?.data?.data);
            trainingManagementStore.setTrainingDatasetTotalCount(response?.data?.data.length);
          }
          let seqNos = params.classes.split(",").filter((item) => !reqPayload.seqNo.includes(Number(item)));
          history.replace(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", seqNos.join()));
          setsnapbarMessage({
            message: t("pages.training.success.dataset.deleted")
          });
        } else {
          setsnapbarMessage({
            message: t("pages.training.errors.dataset.delete-failed")
          });
          console.log("Error occurred while deleting dataset record");
        }
      })
      .catch((err) => {
        setLoading(false);
        console.log("error", err);
      });
    setsnapbarMessage({ message: "" });
    disableAddButton(false);
  };

  const checkMaskingStatus = () => {
    setLoading(true);
    trainingManagementStore
      .getMaskingStatus(params.id, [])
      .then((response) => {
        setLoading(false);
        console.log("response", response);
        if (response?.data?.seqNo) {
          setShowMaskingSubclass(true)
        } else {
          handleNewInputParameterModal("EXECUTE");
        }
      })
      .catch((err) => {
        setLoading(false);
        setShowMaskingSubclass(true)
        handleNewInputParameterModal("EXECUTE");
      });
  }
  
  const fetchTrainingSubClass = () => {
    const filterData = trainingManagementStore.TrainingInputparameter.filter(
      (item) => !trainingManagementStore.selectedInputParameter.includes(item)
    );
    fetchInputParameter(filterData);
  };

  const handleBackButton = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id))
  };

  return (
    <Observer>
      {() => (
        <div>
          {editClass && <EditClass subClassification={inputParameter} trainingId={params.id} open={editClass} setOpen={setEditClass} callBack={getTrainingInputParameter} setLoading={setLoading} setSnapbar={setsnapbarMessage} disableAddButton={disableAddButton} />}
          <Paper className={classes.pageContent}>
            {showConfirmation()}
            {snapbarMessage && snapbarMessage.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
            <div className={classes.top}>
              <div className={classes.buttonWrapper}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <CustomConfirmation
                open={isDelete}
                onClose={() => setDelete(false)}
                onSubmit={handleSubclassificationDelete}
                widthClass={classes.confirmationModalWidth}
                primary={"pages.training.input-parameter.modal.delete-btn"}
                secondary={"pages.training.input-parameter.modal.cancel-btn"}
                title={t("pages.training.input-parameter.modal.deleteRecordTitle")}
                message={t("pages.training.input-parameter.modal.deleteRecordMessage")}
              />
              <CustomConfirmation
                open={showMaskingSubclass}
                onClose={() => {
                  handleNewInputParameterModal("EXECUTE");
                }}
                noImmediateClose
                onSubmit={() => handleNewInputParameterModal("EXECUTE", true)}
                widthClass={classes.confirmationModalWidth}
                primary={"pages.training.input-parameter.modal.yes-btn"}
                secondary={"pages.training.input-parameter.modal.no-btn"}
                title={t("pages.training.input-parameter.modal.title-confirm-masking-use")}
                message={t("pages.training.input-parameter.modal.text-confirm-masking-use")}
              />
              <div className={classes.buttonWrapper}>
                <Button
                  variant="contained"
                  color="primary"
                  // size="small"

                  onClick={() => handleNewInputParameterModal("MASKING")}
                >
                  {t("pages.training.input-parameter.controls.masking")}
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.buttons}
                  // size="small"
                  onClick={() => checkMaskingStatus()}
                >
                  {t("pages.training.input-parameter.controls.execute")}
                </Button>
                <Button color="primary" variant="contained" disabled={isAddButtonDisabled} onClick={() => setUploaderAction({
                  isOpen: true,
                  uploaderType: "add-class",
                  className: "",
                  id: params?.id
                })}>
                  {t("pages.training.input-parameter.controls.add-class")}
                </Button>
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.modelNameLAbel}>
                <label htmlFor="">{t("pages.training.training-list.grid.title") + ": " +(trainingManagementStore.selectedTrainingListData[0]?.modelName?trainingManagementStore.selectedTrainingListData[0]?.modelName:"")}</label>
            </div>
            <GridMaterial container spacing={2}>
              <GridMaterial item xs={12} md={8}>
                <InputSetting
                  loading={loading}
                  uploadStatus={props.uploadStatus}
                  disableAddButton={disableAddButton}
                  disableEditButton={disableEditButton}
                  disableMaskingButton={setMasking}
                  isEditAndNextDisabled={isEditAndNextDisabled}
                  handleNewInputParameterModal={handleNewInputParameterModal}
                  onPriorKnowledge={onPriorKnowledge}
                />
              </GridMaterial>
              <GridMaterial item xs={12} md={4}>
                <ParameterSetting
                  setLoading={setLoading} />
              </GridMaterial>
            </GridMaterial>
          </Paper>
        </div>
      )
      }
    </Observer >
  );
});

export default SubClasicication;
