import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
    pageContent: {
        padding: theme.spacing(2, 2),
        width: "100%",
        minHeight: "100vh"
    },
    top: {
        alignItems: "center",
        display: "flex",
        justifyContent: "space-between"
    },
    breadcrumbWraper: {
        display: "flex",
        alignItems: "center"
    },
    divider: {
        marginTop: theme.spacing(2),
    },
    paperCustom: {
        padding: 16,
        marginTop: 16
    },
    box: {
        display: "flex",
        justifyContent: "space-between"
    },
    inLine: {
        display: "flex",
        // alignItems: "center"
    },
    iconSize: {
        fontSize: 15
    },
    text: {
        lineHeight: "15px",
        paddingLeft: "5px"
    },
    textPadding: {
        paddingLeft: "7px",
        fontWeight: 500
    },
    thumbIcon: {
        color: "dodgerblue",
        fontSize: 20
    },
    warningIcon: {
        color: "orange",
        fontSize: 20
    },
    mTop1: {
        marginTop: "6px"
    },
    imageCenter: {
        position: 'relative',
        border: '1px solid rgb(203, 203, 203,1)',
        borderRadius: 3,
        maxWidth: '400px',
        alignContent:'center',
        minHeight: '400px',
        objectFit: 'contain',
        overflow: 'hidden',
      }
}));