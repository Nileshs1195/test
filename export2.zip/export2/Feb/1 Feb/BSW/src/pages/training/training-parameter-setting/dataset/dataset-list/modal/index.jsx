import React, { useState, useEffect, useContext } from "react";
import { useTranslation } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import { useStyles } from "./style";
import { TextField, FormControl, InputAdornment, FormControlLabel, Checkbox, FormHelperText, RadioGroup, Radio } from "@material-ui/core";
import GridMaterial from "@material-ui/core/Grid";
import TrainingManagementStore from "./../../../../../../stores/trainingmanagementstore";
import ImageManagementStore from "./../../../../../../stores/imagemanagementstore";
import { APP_ROUTES } from "../../../../../../appconstants";
import { validateModalForm, validateString, validateDigits } from "../../../../../../helpers/CommonMethods";
import CustomSnackBar from "../../../../../../components/snackbar";
import CustomConfirmation from "../../../../../../components/modal/CustomConfirmation";
import { Autocomplete } from '@material-ui/lab'

const ModalComponent = (props) => {
  const params = useParams();
  const history = useHistory();
  const classes = useStyles();
  const { t } = useTranslation();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const { TrainingDataset, selectedTrainingDataset, executedModels } = trainingManagementStore;
  const { setUploaderAction } = imageManagementStore;
  const { action, imageList, setModalActive, handleAPICall, disableAddButton, setTabIndex, handleFileUploadOpen, parameterMode } = props;
  const [isDataSetModalOpen, toggoleDataSetModal] = useState(false);
  const [modal_title, setModalTitle] = useState("");
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [pastExecutionCheckbox, setPastExecutionCheckbox] = useState(false);
  const [buttonKeys, setButtonKeys] = useState({
    primaryButtonText: "",
    secondaryButtonText: "pages.training.training-parameter.dataset-mode.controls.cancel"
  });
  const [isTextFieldDisabled, disableTextField] = useState(true);
  const [datasetRecord, setDatasetRecord] = useState({
    className: "",
    // trainingPercent: null,
    defectSize: null
  });
  const [trainingData, setTrainingData] = useState({
    pastModalData: {
      modelName: "",
      trainingPercent: null,
      validationPercent: null
    },
    pastTrainingData: {}
  });
  const [trainingList, setTrainingList] = useState([]);
  const [radioValue, setRadioValue] = useState("Keep");
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });

  useEffect(() => {
    if (action.isOpen) {
      handleDataSetModal(action.actionName);
    }
  }, [action]);

  const handleDataSetModal = (actionParam) => {
    switch (actionParam) {
      case "ADD-DATASET":
        if (executedModels?.length > 0) {
          setModalDetails(
            t("pages.training.training-parameter.dataset-mode.modal.add-dataset"),
            ("pages.training.training-parameter.dataset-mode.controls.upload")
          );
          setPastExecutionCheckbox(false);
        } else {
          setUploaderAction({
            isOpen: true,
            uploaderType: "add-dataset",
            className: "",
            id: params?.id
          });
        }
        break;
      case "MANAGE-IMAGES":
        let isPresent = handleAPICall("VALIDATE-PERCENTAGE", selectedTrainingDataset);
        if (isPresent) {
          const seqNoList = selectedTrainingDataset.reduce((seqNos, datasetDetails) => {
            seqNos.push(datasetDetails.seqNo);
            return seqNos;
          }, []);
          if (parameterMode) {
            history.push(
              APP_ROUTES.TRAINING_MANAGEMENT_PAGES.PARAMETER_IMAGE_LIST.replace(":id", params.id).replace(":classes", seqNoList.join())
            );
          } else {
            history.push(
              APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST.replace(":id", params.id).replace(":classes", seqNoList.join())
            );
          }
        } else {
          setTrainingPercentDetails();
        }
        break;
      case "DELETE":
        setModalDetails(
          t("pages.training.training-parameter.dataset-mode.modal.delete"),
          ("pages.training.training-parameter.dataset-mode.controls.delete")
        );
        break;
      case "UPLOAD-FILES":
        setModalDetails(
          t("pages.training.training-parameter.dataset-mode.modal.upload-files"),
          ("pages.training.training-parameter.dataset-mode.controls.upload")
        )
        break;
      case "SAVE-AND-AUGMENTATION":
        let isPresents = handleAPICall("VALIDATE-PERCENTAGE", TrainingDataset);
        if (isPresents) {
          setTabIndex(1); // redirect to augmentation mode tab
        } else {
          setTrainingPercentDetails();
        }
        break;
      case "CLOSE":
        setModalActive();
        disableAddButton(false);
        trainingManagementStore.clearSelectedTrainingDataset();
        toggoleDataSetModal((isOpen) => !isOpen);
        break;
      default:
    }
  };

  const setTrainingPercentDetails = () => {
    setModalFormErrors({});
    setDatasetRecord({
      trainingPercent: null
    });
    setModalDetails(
      t("pages.training.training-parameter.dataset-mode.modal.manage-images")
        ("pages.training.training-parameter.dataset-mode.controls.save")
    );
    // if (params.id) {
    //   trainingManagementStore.changeTrainingStatus(params.id, "training");
    // }
  };

  const setModalDetails = (title, primaryText) => {
    setModalTitle(title);
    setButtonKeys((prevState) => ({
      ...prevState,
      primaryButtonText: primaryText
    }));
    toggoleDataSetModal((isOpen) => !isOpen);
  };

  const renderMagageImages = () => {
    return (
      <form autoComplete="off">
        <GridMaterial container spacing={2} className={classes.m2}>
          <GridMaterial item xs={12} className={classes.mB1}>
            <FormControl className={classes.formControl} margin="none">
              <div className={classes.fontsize}>{t("pages.training.training-parameter.dataset-mode.modal.percentageMsg")}</div>
            </FormControl>
          </GridMaterial>
          <GridMaterial item xs={7} className={classes.mB1}>
            <FormControl className={classes.formControl} margin="none">
              <TextField
                fullWidth
                id="trainingPercent"
                name="trainingPercent"
                label={t("pages.training.training-parameter.dataset-mode.modal.trainPercentage")}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">{t("pages.training.training-parameter.dataset-mode.modal.percentSign")}</InputAdornment>
                  )
                }}
                value={datasetRecord.trainingPercent}
                onChange={onChangeFieldData}
                error={modalFormErrors["trainingPercent"]}
                helperText={modalFormErrors["trainingPercentErrorMsg"] !== "" && modalFormErrors["trainingPercentErrorMsg"]}
              />
            </FormControl>
          </GridMaterial>
        </GridMaterial>
      </form>
    );
  };

  const renderDeleteDataset = () => {
    return <div className={classes.fontsize}>{t("pages.training.training-parameter.dataset-mode.modal.deleteMsg")}</div>;
  };

  const renderFileUpload = () => {
    return (
      <div>
        <label className={classes.fontsize}>
          {t("pages.image-management.image-group-list.modal.image-count-text")} : {imageList.length}
        </label>
        <br />
        <label className={classes.fontsize}>{t("pages.image-management.image-group-list.modal.confirm-upload")} </label>
      </div>
    );
  };

  const renderAddDataset = () => {
    return (
      <form autoComplete="off" className={classes.mT3}>
        {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
        <GridMaterial container spacing={0}>
          <GridMaterial item xs={12}>
            <FormControl className={classes.formControl} margin="none">
              <FormControlLabel
                control={
                  <Checkbox
                    checked={pastExecutionCheckbox}
                    onChange={handlePastExecutonCheckbox}
                    name="past-execution"
                    color="primary"
                  />
                }
                label={
                  <label className={classes.fontsize}>
                    {t("pages.training.training-parameter.dataset-mode.modal.past-execution-title")}
                  </label>
                }
              />
            </FormControl>
          </GridMaterial>
          {
            pastExecutionCheckbox && (
              <div>
                <GridMaterial item xs={12}>
                <Autocomplete
                      id="combo-box"
                      disableClearable
                      value={trainingList.length > 0 && trainingList.filter(item => item.value === trainingData.pastModalData.id)?.[0]}
                      options={trainingList}
                      getOptionLabel={(option) => option.label}
                      onChange={(event, value) => onChangePastModalData(event, value, "modelName")}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label={t("pages.training.training-parameter.train-parameter.select-training-model")}
                          id="modelName"
                          name="modelName"
                          margin="normal"
                        />
                      )}
                    />
                </GridMaterial>
                <GridMaterial container item xs={12} justify="center" spacing={2} className={classes.mT2}>
                  <GridMaterial item xs={7}>
                    <label className={classes.font}>
                      {t("pages.training.training-parameter.dataset-mode.modal.trainPercentage")}
                    </label>
                    <RadioGroup
                      aria-label="mode"
                      name="mode"
                      value={radioValue}
                      onChange={handleRadioChange}
                      row="true"
                    >
                      <FormControlLabel
                        value="Keep"
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.dataset-mode.modal.keep")}
                        labelPlacement="end"
                        disabled={trainingData.pastModalData?.modelName ? false : true}
                        error={modalFormErrors["radioValue"]}
                        helperText={modalFormErrors["radioValueErrorMsg"] !== "" && modalFormErrors["radioValueErrorMsg"]}
                      />
                      <FormControlLabel
                        value="New"
                        control={<Radio color="primary" />}
                        label={t("pages.training.training-parameter.dataset-mode.modal.new")}
                        labelPlacement="end"
                        disabled={trainingData.pastModalData?.modelName ? false : true}
                        error={modalFormErrors["radioValue"]}
                        helperText={modalFormErrors["radioValueErrorMsg"] !== "" && modalFormErrors["radioValueErrorMsg"]}
                      />
                    </RadioGroup>
                    <FormHelperText error>
                      {modalFormErrors["radioValueErrorMsg"] !== "" && modalFormErrors["radioValueErrorMsg"]}
                    </FormHelperText>
                  </GridMaterial>
                  <GridMaterial item xs={5}>
                    <FormControl margin="none">
                      <TextField
                        disabled={isTextFieldDisabled}
                        className={classes.textSize}
                        fullWidth
                        id="trainingPercent"
                        name="trainingPercent"
                        label={
                          <label style={{ fontSize: "14px" }}>
                            {t("pages.training.training-parameter.dataset-mode.modal.new-percentage")}
                          </label>
                        }
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">{t("pages.training.training-parameter.dataset-mode.modal.percentSign")}</InputAdornment>
                          )
                        }}
                        value={trainingData.pastModalData.trainingPercent}
                        onChange={(event) => onChangePastModalData(event, event.target.value, "trainingPercent")}
                        error={modalFormErrors["trainingPercent"]}
                        helperText={modalFormErrors["trainingPercentErrorMsg"] !== "" && modalFormErrors["trainingPercentErrorMsg"]}
                      />
                    </FormControl>
                  </GridMaterial>
                </GridMaterial>
              </div>
            )
          }
        </GridMaterial>
      </form>
    );
  }

  const handleTrainingData = (fieldName, value) => {
    setTrainingData((prevState) => ({
      ...prevState,
      pastModalData: { ...prevState.pastModalData, [fieldName]: value }
    }));
  };

  const handlePastExecutonCheckbox = event => {
    setRadioValue("Keep");
    setModalFormErrors({});
    disableTextField(true);
    handleTrainingData("trainingPercent", "");
    handleTrainingData("modelName", "");
    setTrainingData((prevState) => ({
      ...prevState,
      ["trainingData"]: {}
    }));
    const { checked } = event.target;
    setPastExecutionCheckbox(checked);
    if (checked) {
      const filteredList = executedModels.filter((obj) => obj.id !== params.id);
      const trainingDropdownArray = filteredList.reduce(
        (trainingDropdownList, trainingItem) => {
          trainingDropdownList.push({
            label: trainingItem.modelName,
            value: trainingItem.id,
          })
          return trainingDropdownList
        }, [])
      setTrainingList(trainingDropdownArray);
      setButtonKeys((prevState) => ({
        ...prevState,
        primaryButtonText: ("pages.training.training-parameter.dataset-mode.controls.save")
      }));
    } else {
      setButtonKeys((prevState) => ({
        ...prevState,
        primaryButtonText: ("pages.training.training-parameter.dataset-mode.controls.upload")
      }));
    }
  };

  const onChangePastModalData = (event, value, name) => {
    const fieldName = name;
    const fieldError = `${name}ErrorMsg`;
    const dataValue = { minPercent: 1, maxPercent: 99 };

    let newValue = value;
    if(fieldName === "trainingPercent") {
      newValue = event.target.value;
      setTrainingData((prevState) => ({
        ...prevState,
        pastModalData: { ...prevState.pastModalData, [fieldName]: newValue }
      }));
    }

    if(fieldName === "modelName") {
      setTrainingData((prevState) => ({
        ...prevState,
        pastModalData: { ...prevState.pastModalData, [fieldName]: newValue.label, id: newValue.value }
      }));
    }

    if (newValue) {
      if (fieldName === "modelName") {
        setModalFormErrors({});
        disableTextField(true);
        handleTrainingData("trainingPercent", "");
        let tempTrainingData = {
          id: trainingData.pastModalData.id,
          modelName: trainingData.pastModalData.modelName,
          trainingPercent: trainingData.pastModalData.trainingPercent
        };
        setTrainingData((prevState) => ({
          ...prevState,
          ["trainingData"]: tempTrainingData,
        }));
      }
      if (fieldName === "trainingPercent") {
        let isValidDigit = validateDigits(newValue);
        if (isValidDigit) {
          if (newValue >= dataValue["minPercent"] && newValue <= dataValue["maxPercent"]) {
            handleModalFormErrors({
              [fieldName]: false,
              [fieldError]: ""
            });
          } else {
            handleModalFormErrors({
              [fieldName]: true,
              [fieldError]: t("pages.training.errors.modal-errors.percentage-limit", { maxValue: dataValue["maxPercent"] })
            });
          }
        } else {
          handleModalFormErrors({
            [fieldName]: true,
            [fieldError]: t("pages.training.errors.modal-errors.digits")
          });
        }
      }
    } else {
      handleModalFormErrors({
        [fieldName]: false,
        [fieldError]: ""
      });
    }
  }

  const handleRadioChange = event => {
    const { value } = event.target;
    setRadioValue(value);
    if (value === "Keep") {
      disableTextField(true);
      setTrainingData((prevState) => ({
        ...prevState,
        ["pastModalData"]: trainingData?.pastModalData
      }));
      if (trainingData?.pastModalData) {
        setModalFormErrors({});
      }
    } else {
      disableTextField(false);
      handleTrainingData("trainingPercent", "");
    }
  }

  const handleAddDatasetOperations = () => {
    pastExecutionCheckbox ?
      savepastExecutionDetails() :
      setUploaderAction({
        isOpen: true,
        uploaderType: "add-dataset",
        className: "",
        id: params?.id
      });
  };

  const savepastExecutionDetails = () => {
    let id = "";
    const excludeCurrentTraining = executedModels.filter((obj) => obj.id !== params.id);
    excludeCurrentTraining.map((item, index) => {
      if (item.modelName === trainingData.pastModalData.modelName) {
        id = item.id
      }
    });
    let data = {
      modelNameId: id,
      radioValue,
      trainingPercent: trainingData.pastModalData?.trainingPercent > 0 ? parseInt(trainingData.pastModalData.trainingPercent) : null
    };
    if (radioValue === "Keep") {
      data = {
        radioValue,
        modelNameId: id,
      };
    }
    let isValid = handleValidation(data);
    if (isValid) {
      handleAPICall(action.actionName, data);
    } else {
      toggoleDataSetModal((isOpen) => !isOpen);
    }
  };

  const onChangeFieldData = (event) => {
    const { name, value } = event.target;
    const fieldName = name;
    const fieldError = `${name}ErrorMsg`;
    let isValidDigit = validateDigits(value);
    let isValidString = validateString(value);

    if ((fieldName === "trainingPercent" || fieldName === "defectSize") && value.length > 0) {
      isValidDigit ? handleDataset(fieldName, Number(value)) : handleDataset(fieldName, value);
    } else {
      handleDataset(fieldName, value);
    }
    const dataValue = { minPercent: 1, maxPercent: 99 };
    if (value.length > 0) {
      if (fieldName === "trainingPercent" || fieldName === "defectSize") {
        if (isValidDigit) {
          handleModalFormErrors({
            [fieldName]: false,
            [fieldError]: ""
          });
          if (fieldName === "trainingPercent") {
            if (value >= dataValue["minPercent"] && value <= dataValue["maxPercent"]) {
              handleModalFormErrors({
                [fieldName]: false,
                [fieldError]: ""
              });
            } else {
              handleModalFormErrors({
                [fieldName]: true,
                [fieldError]: t("pages.training.errors.modal-errors.percentage-limit", { maxValue: dataValue["maxPercent"] })
              });
            }
          }
        } else {
          handleModalFormErrors({
            [fieldName]: true,
            [fieldError]: t("pages.training.errors.modal-errors.digits")
          });
        }
      } else {
        if (fieldName === "className" && isValidString) {
          handleModalFormErrors({
            [fieldName]: false,
            [fieldError]: ""
          });
        } else {
          handleModalFormErrors({
            [fieldName]: true,
            [fieldError]: t("pages.training.errors.modal-errors.alphanumeric")
          });
        }
      }
    } else {
      handleModalFormErrors({
        [fieldName]: false,
        [fieldError]: ""
      });
    }
  };

  const handleDataset = (name, value) => {
    setDatasetRecord((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleModalFormErrors = (data) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, data));
  };

  const editDatasetRecord = () => {
    let data = {
      trainingPercent: datasetRecord.trainingPercent
    };
    let isValid = handleValidation(data);
    if (TrainingDataset && data.className) {
      let duplicateClass = false;
      TrainingDataset.forEach(training => {
        if (training.className === data.className) {
          duplicateClass = true;
        }
      });
      if (duplicateClass) {
        setModalFormErrors({
          className: true,
          classNameErrorMsg: "Class name already exist, please try another"
        });
        isValid = false;
      }
    }
    if (isValid) {
      handleAPICall(action.actionName, data);
    } else {
      toggoleDataSetModal((isOpen) => !isOpen);
    }
  };

  const handleValidation = (data) => {
    let errorMessage = t("pages.training.training-list.modal.error-text");
    console.log("data ===>", data, modalFormErrors, errorMessage)
    let status = validateModalForm(
      data,
      modalFormErrors,
      errorMessage,
      handleModalFormErrors
    );
    return status;
  }

  const renderData = () => {
    let data;
    switch (action.actionName) {
      case "ADD-DATASET":
        data = renderAddDataset();
        break;
      case "MANAGE-IMAGES":
      case "SAVE-AND-AUGMENTATION":
        data = renderMagageImages();
        break;
      case "DELETE":
        data = renderDeleteDataset();
        break;
      case "UPLOAD-FILES":
        data = renderFileUpload();
        break;
      default:
    }
    return data;
  };

  const handleSubmitActions = (actionParam) => {
    switch (actionParam) {
      case "MANAGE-IMAGES":
      case "SAVE-AND-AUGMENTATION":
        editDatasetRecord();
        break;
      case "UPLOAD-FILES":
        handleAPICall(action.actionName);
        break;
      case "DELETE":
        handleAPICall(action.actionName);
        break;
      case "ADD-DATASET":
        handleAddDatasetOperations();
        break;
      default:
    }
  };

  return (
    <div>
      <CustomConfirmation
        showControls
        noImmediateClose={false}
        widthClass={classes.confirmationModalWidth}
        open={isDataSetModalOpen}
        onClose={() => handleDataSetModal("CLOSE")}
        onSubmit={() => handleSubmitActions(action.actionName)}
        primary={buttonKeys.primaryButtonText}
        secondary={buttonKeys.secondaryButtonText}
        title={modal_title} message={renderData()} />
    </div>
  );
};

export default ModalComponent;
