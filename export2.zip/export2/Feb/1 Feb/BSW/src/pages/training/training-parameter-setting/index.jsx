import { Button, Divider, Paper } from "@material-ui/core";
import { Observer, observer } from "mobx-react-lite";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import Breadcrumb from "../../../shared/components/ui/breadcrumb";
import { useHistory } from "react-router-dom";
import AppStore from "../../../stores/appstore";
import TrainingManagementStore from "./../../../stores/trainingmanagementstore";
import { useStyles } from "./style";
import TabListComponent from "./tablist";
import { useCallback, useContext, useEffect, useState } from "react";
import { APP_ROUTES } from "../../../appconstants";
import BackButton from "../../../components/backbutton";
import SubClasicication from "./subclasification";
import ImageUploader from "../../../components/imageuploader";
import ProgressBar from "./subclasification/executionLog/progressBar";
import CustomSnackBar from "../../../components/snackbar";
import CustomConfirmation from "../../../components/modal/CustomConfirmation";
import ImageList from "./image-list";
import Imagemanagementstore from "../../../stores/imagemanagementstore";
import {setSelectedTrainingModelName} from "../../../stores/imagemanagementstore";

const TrainParameterSetting = observer((props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(Imagemanagementstore);
  const { inspectionSearchFilter } = appStore;
  const { uploaderAction, setUploaderAction, imageUploadStatus, setImageUploadStatus, setNewlyCreatedClasses } = imageManagementStore;
  const { TrainingDataset, selectedDataSetCount, fetchTrainingDatasetWithTraining, setTrainingId } = trainingManagementStore;
  // const [uploaderAction, setUploaderAction] = useState({
  //   uploaderType: "",
  //   isOpen: false
  // });
  const [loading, setLoading] = useState(false);
  const [isActionDisabled, setActionDisabled] = useState(false);
  const [selectedTraining, setSelectedTraining] = useState(false);
  const [parameterMode, setParameterMode] = useState(false);
  const [reloadCurrentList, setReloadCurrentList] = useState(false);
  const [newClassNamesList, setnewClassNamesList] = useState([]);
  const [className, setClassName] = useState("");
  const [uploadStatus, setUploadStatus] = useState([]);
  const [snapbarMessage, setSnapbarMessage] = useState({
    message: ""
  });
  const [openModal, setOpenModal] = useState(false);

  const getTrainingDataset = useCallback(
    async (status, newClassNames) => {
      setLoading(true);
      await fetchTrainingDatasetWithTraining(params.id);
      if (status === "uploadProgress" || status === "uploadComplete") {
        setReloadCurrentList(true);
        setImageUploadStatus(status);
        setNewlyCreatedClasses(newClassNames);
      }
      setLoading(false);
      redirectToNewClass(newClassNames, status);
    },
    [fetchTrainingDatasetWithTraining, inspectionSearchFilter]
  );

  const redirectToNewClass = (newClassNames, status) => {
    setUploadStatus(status);
    if (status) {
      if (status === "uploadProgress") {
        disaleActions(true);
      } else {
        disaleActions(false);
      }
    } else {
      //
    }
    setnewClassNamesList(newClassNames);
  };

  useEffect(() => {
    let training = Object.assign(
      {},
      trainingManagementStore?.selectedTrainingListData?.[0] ?? trainingManagementStore.selectedTrainingListData[0]
    );
    setSelectedTraining({
      ...training
    });
    imageManagementStore.selectedTrainingModelName=selectedTraining?.modelName;    // if (selectedTraining?.mode === "training" && (selectedTraining?.status === "Ok" || selectedTraining?.status === "Executed")) {
    //   disaleActions(true);
    // }
  }, [trainingManagementStore?.selectedTrainingListData]);

  useEffect(() => {
    let snapbar = Object.assign({}, trainingManagementStore?.snapbarMessage);
    setSnapbarMessage(snapbar);
  }, [trainingManagementStore?.snapbarMessage?.open]);

  useEffect(() => {
    if (props?.match?.path) {
      if (
        props.match.path == APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER ||
        props.match.path == APP_ROUTES.TRAINING_MANAGEMENT_PAGES.PARAMETER_IMAGE_LIST ||
        trainingManagementStore?.viewParameter
      ) {
        trainingManagementStore.setViewParameter(true);
        disaleActions(true);
      }
    }
  }, [props]);

  const disaleActions = (action = false) => {
    setTrainingId(params.id);
    setActionDisabled(action);
  };

  useEffect(async () => {
    await getTrainingDataset();
  }, []);

  useEffect(() => {
    uploaderAction?.isOpen && uploaderAction?.className && setClassName(uploaderAction?.className);
  }, [uploaderAction]);

  const handleBackButton = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING);
  };

  const handleFileUploadOpen = (type = "add-dataset", originalClassName = "") => {
    // console.log("props ===:::", props)
    // props.uploadFiles({
    //   type,
    //   isOpen: true
    // });
    setUploaderAction({ uploaderType: "", isOpen: false });
    setUploaderAction({ uploaderType: type, isOpen: true });
    setReloadCurrentList(false);
    if (originalClassName !== "") {
      setClassName(originalClassName);
    }
  };

  const handleFileUploadClose = () => {
    setUploaderAction({ uploaderType: "", isOpen: false });
  };

  const gotoTrainingList = () => {
    imageManagementStore.setImageUploadInProgress(false);
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING);
  };

  const gotoExecutionLogScreen = () => {
    setSnapbarMessage({ message: "" });
    if (isActionDisabled || TrainingDataset?.length <= 0) {
      setLoading(false);
      setSnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
      return;
    }
    setLoading(true);
    trainingManagementStore.startExecution(params.id, "training", {}).then(res => {
      setLoading(false);
      if (res?.status === 200 && res?.data?.seqNo && res?.data?.mode === "training") {
        history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG.replace(":id", params.id).replace(":seqNo", res?.data?.seqNo));
      } else {
        if (res?.data?.mode === "subclassification") {
          setSnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-subclassification"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
        } else if (res?.data?.mode === "parameterSearch") {
          setSnapbarMessage({ title: t("pages.training.errors.training-list.execution-failed-title"), info: t("pages.training.errors.training-list.execution-failed-parameter-search"), seqNo: res?.data?.seqNo, type: res?.data?.mode, open: true });
        } else {
          setSnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
        }
      }
    }).catch(error => {
      setLoading(false);
      setSnapbarMessage({ message: t("pages.training.errors.training-list.execution-failed") });
    });

  };

  return (
    <Observer>
      {() => (
        <div>
          {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
          <ImageUploader
            reloadCurrentList={getTrainingDataset}
            isActionDisabled={isActionDisabled}
            uploaderAction={false}
            className={className}
            handleFileUploadClose={handleFileUploadClose}
          />
          {(props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.IMAGE_LIST || props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.PARAMETER_IMAGE_LIST) ? (
            <ImageList
              handleFileUploadOpen={handleFileUploadOpen}
              parameterMode={parameterMode}
              uploadStatus={uploadStatus}
              setnewClassNamesList={setnewClassNamesList}
            />
          ) : props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION ? (
            <SubClasicication
              reloadCurrentList={reloadCurrentList}
              TrainingDataset={TrainingDataset}
              handleFileUploadOpen={handleFileUploadOpen}
              newClassNamesList={newClassNamesList}
              uploadStatus={uploadStatus}
              setnewClassNamesList={setnewClassNamesList}
            />
          ) : props?.match?.path === APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION ? (
            <ProgressBar
              reloadCurrentList={reloadCurrentList}
              TrainingDataset={TrainingDataset}
              handleFileUploadOpen={handleFileUploadOpen}
              newClassNamesList={newClassNamesList}
              uploadStatus={uploadStatus}
              setnewClassNamesList={setnewClassNamesList}
            />
          ) : (
            <Paper className={classes.pageContent}>
              <div className={classes.top}>
                <div className={classes.breadcrumbWraper}>
                  <BackButton handleBackButton={handleBackButton} />
                  <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
                </div>
                <div className={classes.buttonWrapper}>
                  <Button
                    color="primary"
                    variant="contained"
                    disabled={isActionDisabled || !TrainingDataset || TrainingDataset?.length <= 0 || imageUploadStatus === "in-progress"}
                    onClick={gotoExecutionLogScreen}
                  >
                    {t("pages.training.training-parameter.dataset-mode.auto-param-search.run-training")}
                  </Button> &nbsp; &nbsp;

                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => { setOpenModal(true) }}
                    disabled={isActionDisabled}
                  >
                    {t("pages.training.training-parameter.controls.cancel-btn")}
                  </Button>
                  <CustomConfirmation open={openModal} onClose={() => {
                    setOpenModal(false);
                  }} onSubmit={gotoTrainingList} primary={"pages.training.input-parameter.controls.ok"} secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"} title={t("pages.training.cofirm.parameter-settings.cancel-unsaved.title")} message={t("pages.training.cofirm.parameter-settings.cancel-unsaved.message")} />
                </div>
              </div>
              <Divider className={classes.divider} />
              <div className={classes.top}>
                <div className={classes.breadcrumbWraper}>
                  {selectedTraining?.modelName && t("pages.training.training-list.grid.title") + ": " + selectedTraining?.modelName} &nbsp;
                </div>               
              </div>
              <Divider className={classes.divider} />
              <TabListComponent
                handleFileUploadOpen={handleFileUploadOpen}
                loading={loading}
                setLoading={setLoading}
                params={params}
                parameterMode={trainingManagementStore.viewParameter}
                TrainingDataset={TrainingDataset}
                selectedDataSetCount={selectedDataSetCount}
                isActionDisabled={isActionDisabled}
              />
            </Paper>
          )}
        </div>
      )}
    </Observer>
  );
});

export default TrainParameterSetting;
