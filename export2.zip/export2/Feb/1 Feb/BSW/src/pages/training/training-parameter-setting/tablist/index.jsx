import React, { useState, useContext } from 'react';
import { Tab, Tabs, Card } from "@material-ui/core";
import { Observer } from "mobx-react-lite";
import { useTranslation } from "react-i18next";
import TabPanel from "../../../../shared/components/tabpanel";
import DataSet from "../dataset/dataset-list/dataset";
import TrainingManagementStore from "../../../../stores/trainingmanagementstore";
import { useStyles } from "./style";
import Augmentation from '../augmentation/augmentation';
import TrainParameter from '../train-parameter/trainparameter';

const TabList = (props) => {
    const { t } = useTranslation();
    const {
        handleNewDataSetModal,
        loading,
        setLoading
    } = props;

    const classes = useStyles();
    const trainingManagementStore = useContext(TrainingManagementStore);
    const {
        TrainingDataset,
        selectedTrainingListData
    } = trainingManagementStore;

    // change tabs between (dataset, augmentation, trainParameter)
    const handleChange = (event, newValue) => {
        let gotoTab = false;
        if (trainingManagementStore.tabIndex === 0 && (newValue === 1 || newValue === 2)) {
            TrainingDataset.forEach(data => {
                let dataset = Object.assign({}, data);
                if (dataset?.trainPercentage > 0) {
                    gotoTab = true;
                }
            });
        } else if (trainingManagementStore.tabIndex === 1 && (newValue === 2)) {
            let selectedTraining = Object.assign({}, selectedTrainingListData);
            selectedTraining = Object.assign({}, selectedTraining?.[0]);
            if(selectedTraining?.datasetMode !== null) {
                gotoTab = true;
            }
        } else {
            gotoTab = true;
        }
        if (gotoTab) {
            trainingManagementStore.setTabIndex(newValue);
        }
    };

    return (
        <Observer>
            {() => (
                <div>
                    <Card className={classes.root}>
                        <Tabs
                            value={trainingManagementStore.tabIndex}
                            onChange={handleChange}
                            indicatorColor="primary"
                            textColor="primary"
                            variant="fullWidth"
                            aria-label="full width"
                            className={`${classes.tabRootCustom} MuiPaper-elevation3`}
                        >
                            <Tab
                                label={t("pages.training.training-parameter.tabs.dataset")}
                                className={`${classes.tabRootCustom} ${classes.MuiTab}`}
                            />
                            <Tab
                                label={t("pages.training.training-parameter.tabs.augmentation")}
                                className={`${classes.tabRootCustom} ${classes.MuiTab}`}
                            />
                            <Tab
                                label={t("pages.training.training-parameter.tabs.train-param-search")}
                                className={`${classes.tabRootCustom} ${classes.MuiTab}`}
                            />
                        </Tabs>

                        <TabPanel
                            value={trainingManagementStore.tabIndex}
                            index={0}
                            className={classes.tabPanel}
                            p={3}
                        >
                            <DataSet
                                params={props.params}
                                setLoading={setLoading}
                                handleFileUploadOpen={props.handleFileUploadOpen}
                                TrainingDataset={trainingManagementStore.TrainingDataset}
                                selectedDataSetCount={
                                    trainingManagementStore.selectedDataSetCount
                                }
                                parameterMode={props.parameterMode}
                                isActionDisabled={props.isActionDisabled}
                                handleNewDataSetModal={handleNewDataSetModal}
                                loading={loading}
                                setTabIndex={trainingManagementStore.setTabIndex}
                            />
                        </TabPanel>
                        <TabPanel value={trainingManagementStore.tabIndex} index={1} className={classes.tabPanel}>
                            <Augmentation
                                loading={loading}
                                isActionDisabled={props.isActionDisabled}
                                TrainingDataset={trainingManagementStore.TrainingDataset}
                                tabIndex={trainingManagementStore.tabIndex}
                                setTabIndex={trainingManagementStore.setTabIndex}
                            />
                        </TabPanel>

                        <TabPanel value={trainingManagementStore.tabIndex} index={2} className={classes.tabPanel}>
                            <TrainParameter
                                loading={loading}
                                isActionDisabled={props.isActionDisabled}
                                TrainingDataset={trainingManagementStore.TrainingDataset}
                                tabIndex={trainingManagementStore.tabIndex}
                            />
                        </TabPanel>
                    </Card>
                </div>
            )}
        </Observer>
    )
}

export default TabList
