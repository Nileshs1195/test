import React, { useState, useContext } from 'react'
import Grid from "./grid";
import { useStyles } from "./style";
import { columnDefinitions } from "./grid/columndefinitions";

const ExecutionLogTable = (props) => {
    const { executionLogData, loading } = props;
    const classes = useStyles();

    return (
        <>
            <Grid
                loading={loading}
                records={executionLogData}
                containerClassName={classes.tableContainer}
                columnDefinitions={columnDefinitions}
            />
        </>
    )
}

export default ExecutionLogTable
