import { makeStyles } from '@material-ui/core/styles'

export const useStyles = makeStyles((theme) => ({
  modalWidth: {
    minWidth: "20%",
    maxWidth: "25%",
    minHeight: "auto"
  },
  modalTextPadding: {
    paddingBottom: '16px',
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: 18,
    fontWeight: "normal",
    Height: "42px",
    margin: "-25px -25px 0px -25px",
    padding: "8px 16px",
    borderRadius: "4px 4px 0 0"
  },
  formControl: {
    minWidth: "100%"
  },
  mT1:{
    marginTop: 8
  }
}))
