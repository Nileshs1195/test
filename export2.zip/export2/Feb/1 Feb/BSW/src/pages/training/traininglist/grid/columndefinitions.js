import { APP_ROUTES } from "../../../../appconstants";

export const columnDefinitions = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true,    
  },
  {
    key: "updatedAt",
    text: "pages.training.training-list.grid.update-date-time",
    type: "date",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "modelName",
    text: "pages.training.training-list.grid.title",
    type: "string",
    validation: { required: true, pattern: "//" },
    style: {
      width: "250px"
    },
    wrap: true
  },
  {
    key: "comment",
    text: "pages.training.training-list.grid.comment",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "statusString",
    text: "pages.training.training-list.grid.status",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "subClassificationStatus",
    text: "pages.training.training-list.grid.subclass",
    type: "customStringWithLink",
    url: {
      subclassification: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION,
    },
    validation: { required: true, pattern: "//" },
  },
  {
    key: "maskingStatus",
    text: "pages.training.training-list.grid.masking",
    type: "customStringWithLink",
    url: {
      masking: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.MASKING_EXECUTION,
    },
    validation: { required: true, pattern: "//" },
  },
  {
    key: "progress",
    text: "pages.training.training-list.grid.progress",
    type: "customProgressBgWithLink",
    url: {
      // subclassification: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION_EXECUTION,
      training: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAIN_PARAMETER_EXECUTION_LOG,
      parameterSearch: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.AUTOMATIC_PARAMETER_SEARCH,
    },
    topColor:"rgb(14 202 72 / 50%)",
    color: "#000",
    bgColor:"rgb(255, 255, 255)",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "elapsedTime",
    text: "pages.training.training-list.grid.elapsed-time",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "classes",
    text: "pages.training.training-list.grid.no-of-classes",
    type: "string",
    hover: true,
    validation: { required: true, pattern: "//" },
  },
  {
    key: "totalImages",
    text: "pages.training.training-parameter.grid.total-images",
    type: "string",
    hover: true,
    validation: { required: true, pattern: "//" },
  },
  {
    key: "datasetMode",
    text: "pages.training.training-list.grid.dataset-mode",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "augmentationMode",
    text: "pages.training.training-list.grid.augmentation-mode",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "trainParamMode",
    text: "pages.training.training-list.grid.trainParam-mode",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
  {
    key: "premodelUsed",
    text: "pages.training.training-list.grid.premodel-used",
    type: "string",
    validation: { required: true, pattern: "//" },
  },
];
