import React, { useState, useContext, useEffect, useRef } from "react";
import { Observer, observer } from "mobx-react-lite";
import { Paper, Divider, Button } from "@material-ui/core";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import AppStore from "../../../../stores/appstore";
import { API_URL, APP_ROUTES } from "../../../../appconstants";
import Breadcrumb from "../../../../shared/components/ui/breadcrumb";
import { useHistory, useParams } from "react-router-dom";
import TrainingManagementStore from "../../../../stores/trainingmanagementstore";
import BackButton from "../../../../components/backbutton";
import ImageManagementStore from "../../../../stores/imagemanagementstore";
import Pagination from "../../../../shared/components/basictable/pagination";
import { arrayMultiSplit, arrayUnique, objToArray } from "../../../../helpers/arrayutils";
import ImageListComponent from "../../../../components/image-list/imageListComponent";
import AddClass from "../../../../components/imagelist-forms/AddClass";
import CustomSnackBar from "../../../../components/snackbar";

const ImageList = observer((props) => {
  const params = useParams();
  const classes = useStyles();
  const { t } = useTranslation();
  const appStore = useContext(AppStore);
  const { addBreadcrumb, removeLastBreadcrumb } = appStore;
  const history = useHistory();
  const trainingManagementStore = useContext(TrainingManagementStore);
  const imageManagementStore = useContext(ImageManagementStore);
  const [selectedClasses, setSelectedClasses] = useState(params.classes);
  const [totalClasses, setTotalClasses] = useState([]);
  const [currentClasses, setCurrentClasses] = useState([]);
  const [trainingDetails, setTrainingDetails] = useState([]);
  const [classNames, setClassNames] = useState([]);
  const [imageType, setImageType] = useState("all");
  const [addClass, setAddClass] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [page, setPage] = useState({ pageSize: 5, pageNo: 1 });
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });

  const breadCurmbs = () => {
    removeLastBreadcrumb();
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING,
      label: "pages.training.training-parameter.breadcrumb.training"
    });
    if (trainingManagementStore.viewParameter) {
      addBreadcrumb({
        path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING_VIEW_PARAMETER.replace(":id", params.id),
        label: "pages.training.training-parameter.breadcrumb.dataset"
      });
    } else {
      addBreadcrumb({
        path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id),
        label: "pages.training.training-parameter.breadcrumb.dataset"
      });
    }
    addBreadcrumb({
      path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SUB_CLASIFICATION.replace(":id", params.id).replace(":classes", params.classes),
      label: "pages.training.training-parameter.breadcrumb.manageImages"
    });
  };

  useEffect(async () => {
    breadCurmbs();
    await trainingManagementStore.fetchTrainingDatasetWithTraining(params.id);

    let trainingList = JSON.parse(JSON.stringify(trainingManagementStore.selectedTrainingListData));
    setTrainingDetails(trainingList?.[0]);
    let classes = trainingList?.[0]?.classData ? objToArray(trainingList?.[0]?.classData) : [];
    classes = classes.length > 0 ? classes.map((item) => item.className) : [];
    setClassNames(classes);
    return () => {
      imageManagementStore.clearSelectedClassImages();
      trainingManagementStore.clearSelectedTrainingDataset();
      trainingManagementStore.setReloadList(true);
    };
  }, []);

  useEffect(() => {
    splitClasses(page);
  }, [selectedClasses]);

  const splitClasses = (obj) => {
    let pageNo = obj.pageNo > 0 ? obj.pageNo - 1 : obj.pageNo;
    let uniqueClasses = arrayUnique(selectedClasses?.split(","));
    let selectedClass = arrayMultiSplit(uniqueClasses, obj?.pageSize);
    setTotalClasses(uniqueClasses);
    selectedClass?.length > 0 && setCurrentClasses(selectedClass[pageNo]);
  };

  const handleBackButton = () => {
    history.goBack();
  };

  const gotoTrainParameterSetting = () => {
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.TRAINING_PARAMETER_SETTING.replace(":id", params.id));
  };

  const onPagination = (obj) => {
    setPage(obj);
    splitClasses(obj);
  };

  const handleImageView = async (type) => {
    setImageType(type);
    // await setCurrentClasses([]);
    // splitClasses(page);
  };
  return (
    <Observer>
      {() => (
        <React.Fragment>
          <div>
            {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
            <Paper className={classes.pageContent}>
              <div className={classes.pageHeader}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
                <div className={classes.modelNameSection}>
                  <label htmlFor="">{t("pages.training.training-list.grid.title")} : <b>{trainingDetails?.modelName}</b></label>
                </div>
              </div>
              {!trainingManagementStore.viewParameter && (
                <AddClass
                  open={addClass}
                  setOpen={setAddClass}
                  trainingId={params.id}
                  page={page}
                  selectedClasses={selectedClasses}
                  setSelectedClasses={setSelectedClasses}
                  setSnapbar={setsnapbarMessage}
                  classData={classNames}
                />
              )}
              <Divider className={classes.divider} />
              <div className={classes.top}>
                <div>
                  <hr className={classes.imageLegendTraining} />
                  <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.trainingLegand")}</div>
                  <hr className={classes.imageLegendValidation} />
                  <div className={classes.imageLegendText}>{t("pages.training.manageImages.messages.validationLegand")}</div>
                </div>
                <div className={classes.buttonWrapper}>
                  <Button color="primary" variant="contained" disabled={trainingManagementStore.viewParameter} onClick={() => setAddClass(true)}>
                    {t("pages.training.manageImages.controls.addClass")}
                  </Button>
                  <Button color="primary" variant="contained" disabled={imageType === "all"} onClick={() => handleImageView("all")}>
                    {t("pages.training.manageImages.controls.showAllImages")}
                  </Button>
                  {imageType === "training" ? (
                    <Button color="primary" variant="contained" onClick={() => handleImageView("validation")}>
                      {t("pages.training.manageImages.controls.showOnlyValidationImages")}
                    </Button>
                  ) : (
                    <Button color="primary" variant="contained" onClick={() => handleImageView("training")}>
                      {t("pages.training.manageImages.controls.showOnlyTrainingImages")}
                    </Button>
                  )}
                  <Button color="primary" variant="contained" onClick={() => setExpanded(!expanded)}>
                    {expanded ? t("pages.training.manageImages.controls.expandAll") : t("pages.training.manageImages.controls.collapseAll")}
                  </Button>
                </div>
              </div>
              <div className={classes.mTop}>
                <div>
                  <Pagination
                    onChange={onPagination}
                    itemCount={totalClasses.length}
                    pageNo={imageManagementStore.classPaginationStartIndex + 1}
                    pageSize={page.pageSize}
                    disableItemPerPage={true}
                    disabled={false}
                  />
                </div>
              </div>
              <ImageListComponent
                classes={currentClasses}
                url={API_URL.GET_IMAGES_FOR_DATASET}
                trainingDetails={trainingDetails}
                order={{ desc: "updatedAt" }}
                expand={expanded}
                imageType={imageType}
                showAddImage
                showDeleteImage
                showMoveImages
                imageSelection
                showEditClass
                carouselView
                trainingClasses={trainingManagementStore.TrainingDataset}
                isDragDropDisabled={trainingManagementStore.viewParameter}
              />
              <div className={classes.btnBottom}>
                <Button color="primary" variant="contained" onClick={gotoTrainParameterSetting}>
                  {t("pages.training.manageImages.controls.parameterSettings")}
                </Button>
              </div>
            </Paper>
          </div>
        </React.Fragment>
      )}
    </Observer>
  );
});

export default ImageList;
