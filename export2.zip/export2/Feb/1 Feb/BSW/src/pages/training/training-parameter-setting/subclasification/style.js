import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%"
  },
  paper: {
    maxHeight: "35%"
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  buttonWrapper: {
    display: "flex",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  modelNameLAbel:{
    paddingTop:"1%",
    paddingBottom:"1%"
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2)
  },
  buttonMargin: {
    maxWidth: 35,
    minWidth: 35,
    maxHeight: 35,
    alignSelf: "center"
  },
  controlContainer: {
    display: "flex",
    alignItems: "center",
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1)
  },
  checkboxIcon: {
    borderRadius: 5,
    width: 14,
    height: 14,
    boxShadow: "inset 0 0 0 1px #10161a, inset 0 -1px 0 #10161a",
    backgroundColor: "white"
  },
  controlGroup: {
    marginRight: theme.spacing(1)
  },
  datePicker: {
    width: theme.spacing(25)
  },

  searchButton: {
    maxWidth: 35,
    minWidth: 35,
    maxHeight: 35
  },
  flexAuto: {
    flex: "auto"
  },
  paperList: {
    display: "flex",
    flexWrap: "wrap",
    listStyle: "none",
    padding: theme.spacing(0.5),
    margin: 0
  },
  chipContainer: {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingBottom: theme.spacing(1),
    "& div ": {
      margin: theme.spacing(1, 1, 1, 0)
    }
  },
  tableContainer: {
    height: "calc(100vh - 268px)",
    marginTop: "8px"
  },

  tableContainerFooter: {
    height: "calc(100vh - 318px)",

    marginTop: "8px"
  },
  modalWidth: {
    minWidth: "25%",
    maxWidth: "25%",
    minHeight: "auto"
  },
  modalTextPadding: {
    paddingBottom: "16px"
  },
  helperText: {
    error: {
      "&.MuiFormHelperText-root.Mui-error": {
        color: theme.palette.common.red
      }
    }
  },
  selectErrorHelperText: {
    "&.MuiFormHelperText-root.Mui-error": {
      color: theme.palette.common.red
    }
  },
  mode: {
    paddingRight: "20px"
  },
  tabRootCustom: {
    fontSize: "18px !important",
    fontWeight: "600"
  },
  formControl: {
    minWidth: "100%"
  },
  formFields: {
    height: "32px"
  },
  mT1: {
    marginTop: 8
  },
  mT0: {
    marginTop: 0
  },
  mB1: {
    marginBottom: 8
  },
  alignRight: {
    textAlign: "right"
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: 18,
    fontWeight: "normal",
    Height: "42px",
    margin: "-16px -16px 0px -16px",
    padding: "8px 16px",
    borderRadius: "4px 4px 0 0"
  },
  fileUpload: {
    display: "none"
  },
  confirmationModalWidth: {
    minWidth: "370px",
    maxWidth: "25%",
    minHeight: "auto"
  },
  confirmationModalPadding: {
    paddingTop: "10px"
  }
}));
