import { Observer } from "mobx-react-lite";
import { Grid, Popover, Checkbox } from "@material-ui/core";
import { useStyles } from "./style";
import ImageDetailsBox from "../imagedetailsbox";
import { useState, useEffect, useContext } from "react";
import { SETTINGS } from "../../../../appsettings";
import { Draggable } from "react-beautiful-dnd";
import ImageManagementStore from "./../../../../stores/imagemanagementstore";
import { Loader } from "../../../../shared/components/ui";

const DatasetClassImage = ({ imageData, onImageSelect, index, classSeqNo, suggestionList }) => {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const [selected, setSelected] = useState(false);
  const imageManagementStore = useContext(ImageManagementStore);
  const [loaded, setLoaded] = useState(false);
  const imageThumbnailURL = SETTINGS.IMAGE_THUMBNAIL_URL;

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  useEffect(() => {
    const selectedImages = JSON.parse(JSON.stringify(imageManagementStore.selectedClassImages));
    const index = selectedImages.findIndex((image) => image.classSeqNo === classSeqNo && image.imageSeqNo === imageData.seqNo);
    setSelected(index >= 0);
  }, [imageManagementStore.selectedClassImages, imageData]);

  const opened = Boolean(anchorEl);
  return (
    <Observer>
      {() => (
        <>
          <Grid item xs={4} sm={4} md className={classes.thumbItem} key={imageData.seqNo} id={"image_item" + imageData.seqNo}>
            <Draggable draggableId={imageData.seqNo.toString()} index={index}>
              {(provided) => (
                <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
                  <Checkbox
                    className={classes.thumbCheckbox}
                    color="primary"
                    checked={selected}
                    onChange={(event) => onImageSelect(event, imageData.seqNo)}
                    id={"image_checkbox" + imageData.seqNo}
                  />
                  <div
                    key={imageData.seqNo}
                    aria-owns={opened ? "mouse-over-popover" : undefined}
                    aria-haspopup="true"
                    onMouseEnter={handlePopoverOpen}
                    onMouseLeave={handlePopoverClose}
                    onClick={handlePopoverClose}
                    onWheel={handlePopoverClose}
                    className={
                      imageData.modeOfChange === 2 ? classes.movedThumbImg :
                        imageData.modeOfChange === 1 ? classes.transferedThumbImg : classes.thumbImg
                    }
                  >
                    {loaded ? null : (
                      <Loader size={20} />
                    )}
                    <img
                      onLoad={() => { setLoaded(true) }}
                      src={imageThumbnailURL + imageData.fileName}
                      alt={imageData.uploadFileName}
                      id={"image" + imageData.seqNo}
                      className={classes.imageCenter}
                    />
                  </div>
                </div>
              )}
            </Draggable>
          </Grid>

          <Popover
            id="mouse-over-popover"
            className={classes.popover}
            classes={{
              paper: classes.popover_paper
            }}
            open={opened}
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left"
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "left"
            }}
            onClose={handlePopoverClose}
            disableRestoreFocus
          >
            <ImageDetailsBox suggestionList={suggestionList} imageData={imageData} />
          </Popover>
        </>
      )}
    </Observer>
  );
};
export default DatasetClassImage;
