import { useContext, useEffect } from "react";
import { columnDefinition } from './columnsDefinitions';
import PopoverTables from './popover/index'
import CustomTables from '../../../../components/customtable/table'
import AppStore from "../../../../stores/appstore";
import TestManagementStore from "../../../../stores/testManagementStore";

    const TableGrid = ({ loading, records, containerClassName, disableAddButton, disableEditButton, disableDeleteButton }) => {
    const appStore = useContext(AppStore);
    const testManagementStore = useContext(TestManagementStore);
    let selectedRowCount = 0;

    useEffect(() => {
        if (testManagementStore.selectedTestingListCount > 0) {
            disableAddButton(true);
            if (testManagementStore.selectedTestingListCount > 1) {
                disableEditButton(true);
                disableDeleteButton(false);
            } else {
                disableEditButton(false);
                disableDeleteButton(false);
            }
        } else {
            disableAddButton(false);
        }
    }, [testManagementStore.selectedTestingListCount]);

    const isSelected = (id) => {
        return testManagementStore.selectedTestingList.filter((item) => item._id === id).length > 0
    }

    const getBodyData = (data) => {
        data = JSON.parse(JSON.stringify(data))
        return data.map((item) => {
            item.selected = isSelected(item._id)
            if (item.selected) {
                selectedRowCount++
            }
            return item
        });
    }

    const handleSelectAllClick = (event) => {
        if (records?.length > 0) {
            records.forEach((testingList) => {
                const { checked } = event.target
                if (checked) {

                    const isTestingListPresent = testManagementStore.selectedTestingList.filter(
                        (selectedTestingList) =>
                            selectedTestingList._id === testingList._id,
                    )
                    if (!(isTestingListPresent.length > 0)) {
                        testManagementStore.setSelectedTestingListRecord(testingList)
                    }
                } else {
                    testManagementStore.removeSelectedTestingListRecord(testingList?._id);
                }
            })
        }

    }

    const onRowMouseOver = (trainingListId) => {
        const rowMouseOverData = records.filter((item) => item._id === trainingListId)
    }
    const onRowSelect = (event, testingListID) => {
        const selected = isSelected(testingListID);
        let selectedData = records.filter((item) => item._id === testingListID)[0];
        if (selected) {
            testManagementStore.removeSelectedTestingListRecord(testingListID);
        } else {
            testManagementStore.setSelectedTestingListRecord(selectedData);
        }
    }

    const data = getBodyData(records);
    const PopoverTable = (props) => {
        let component = null;
        switch (props.type) {
            case 'classesUsed':
                component = <PopoverTables rowsData={props.data} />
                break;
            default:
                break;
        }
        return component
    }
    return (
        <CustomTables
            loading={loading}
            classname={containerClassName}
            rowCount={records?.length}
            headerData={columnDefinition}
            onAllRowSelected={handleSelectAllClick}
            selectedRowCount={selectedRowCount}
            PopoverComponent={PopoverTable}
            onRowMouseOver={onRowMouseOver}
            onRowSelect={onRowSelect}
            bodyData={data}
        />
    )
}

export default TableGrid;