import React, { useState, useContext, useEffect, useCallback } from "react";
import { useStyles } from "./style";
import { Button, Divider, Paper } from "@material-ui/core";
import { Observer } from "mobx-react-lite";
import { useHistory } from "react-router-dom";
import { Breadcrumb } from "../../../shared/components/ui";
import AppStore from "../../../stores/appstore";
import TestManagementStore from "../../../stores/testManagementStore";
import { API_RESPONSE, APP_ROUTES } from "../../../appconstants";
import { useTranslation } from "react-i18next";
import Pagination from "../../../shared/components/basictable/pagination";
import TableGrid from "./TableGrid";
import Modals from "./modals";
import CustomSnackBar from "../../../components/snackbar";
import AddClassificationTest from "../../../components/add-test";
import EditClassificationTest from "../../../components/add-test/EditClassificationTest";


const TestingList = () => {
  const classes = useStyles();
  const { t } = useTranslation();
  const history = useHistory();
  const appStore = useContext(AppStore);
  const testManagementStore = useContext(TestManagementStore);
  const [loading, setLoading] = useState(false);
  const [toggle, setToggle] = useState(false);
  const [modalName, setModalName] = useState("");
  const [snapbarMessage, setsnapbarMessage] = useState({ message: "" });
  const [isAddButton, disableAddButton] = useState(false);
  const [addTest, setAddTest] = useState(false);
  const [editTest, setEditTest] = useState(false);
  const [isEditButton, disableEditButton] = useState(false);
  const [isDeleteDisabled, disableDeleteButton] = useState(false);
  const [editPopupTitle, setEditPopupTitle] = useState("");
  const [openModel, setOpenModel] = useState(false);
  const [testingData, setTestingData] = useState({
    title: "",
    comment: ""
  });

  useEffect(() => {
    breadCrumb();
    testManagementStore.clearSelectedTestingList();
    // getTestingList();
  }, []);

  const breadCrumb = () => {
    appStore.removeAllBreadcrumbs();
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
      label: "pages.classification-test.testing-list.title"
    });
  };

  const getTestingList = useCallback(async () => {
    setLoading(true);
    await testManagementStore.fetchTestingList();
    setLoading(false);
  });

  const handleTestingListModals = (label) => {
    switch (label) {
      case "ADD":
        setTestingData({
          title: "",
          deviceName: " ",
          designGroup: " ",
          processGroup: " ",
          lotId: 0,
          comment: ""
        });
        setEditTest((isOpen) => !isOpen);
        break;
      case "DELETE":
        setModalName("DELETE");
        setToggle((isOpen) => !isOpen);
        break;
      case "EDIT":
        setTestingData(testManagementStore.selectedTestingList?.[0])
        setEditPopupTitle("pages.classification-test.testing-list.modal.edit-testing");
        setOpenModel(true);
        break;
      case "COPY-AND-REEXECUTE":
        setTestingData(() => ({
          ...testManagementStore.selectedTestingList[0],
          ["title"]: t("pages.classification-test.testing-list.modal.copy") + testManagementStore.selectedTestingList[0].title,
          ["comment"]: testManagementStore?.selectedTestingList?.[0]?.comment
        }));
        setEditPopupTitle("pages.classification-test.testing-list.modal.copy-and-reexecute");
        setOpenModel(true);
        break;
      case "CLOSE":
        setToggle((isOpen) => !isOpen);
      default:
        break;
    }
  };

  const deleteTestingList = () => {
    var idArray = { ids: [] };
    testManagementStore.selectedTestingList.map(function (v) {
      idArray.ids.push(v._id);
    });
    testManagementStore
      .deleteMultipleTestingList(idArray)
      .then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setsnapbarMessage({ message: t("pages.classification-test.success.testing-list.deleted") });
          getTestingList();
          testManagementStore.clearSelectedTestingList();
        } else {
          setsnapbarMessage({ message: t("pages.classification-test.errors.testing-list.delete-failed") });
        }
      })
      .catch((error) => {
        console.log("error", error);
        setsnapbarMessage({ message: t("pages.classification-test.errors.testing-list.delete-failed") });
      });
  };

  const onPagination = (options) => {
    appStore.updateInspectionGridPageNo((options.pageNo > 0 ? options.pageNo - 1 : options.pageNo) * options.pageSize);
    getTestingList();
  };

  const handleViewResult = () => {
    const selectedTestId = testManagementStore?.selectedTestingList?.[0]?._id;
    const batchSeqNo = testManagementStore?.selectedTestingList?.[0]?.batch?.seqNo;
    if (selectedTestId && batchSeqNo) {
      history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CONFUSION_MATRIX.replace(":id", selectedTestId).replace(":batchSeqNo", batchSeqNo));
    }
  };

  const handleShowModal = () => {
    const seletcedTests = JSON.parse(JSON.stringify(testManagementStore.selectedTestingList));
    const selectedModals = seletcedTests.filter((element) => {
      return element.trainingSeqNo !== '' && element.trainingSeqNo !== null;
    }).map(item => { return item.trainingSeqNo });
    history.push(APP_ROUTES.TRAINING_MANAGEMENT_PAGES.SELECTED_TRAINING.replace(":seqNo", selectedModals.join()));
  };

  return (
    <Observer>
      {() => (
        <div>
          <AddClassificationTest open={addTest} setOpen={setAddTest} />
          {openModel && (
            <EditClassificationTest
              testing={testingData}
              open={openModel}
              callBack={getTestingList}
              setOpen={setOpenModel}
              title={editPopupTitle}
            />
          )}
          <Modals type={modalName} open={toggle} onClose={() => setToggle(false)} deleted={deleteTestingList} />
          <Paper className={classes.pageContent}>
            {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <div className={classes.buttonWrapper}>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => {
                    setAddTest(true);
                  }}
                  disabled={isAddButton}
                >
                  {t("pages.classification-test.testing-list.controls.add-btn")}
                </Button>
                {/* <Button color="primary" variant="contained">
                  {t("pages.classification-test.testing-list.controls.apply-default-filter-btn")}
                </Button> */}
                {/* <Button color="primary" variant="contained">
                  {t("pages.classification-test.testing-list.controls.customize-btn")}
                </Button> */}
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.controlContainer}>
              <Pagination
                disabled={false}
                onChange={onPagination}
                itemCount={testManagementStore.testingList?.length}
                pageNo={appStore.inspectionSearchFilter.pageNo + 1}
                pageSize={5}
              />
            </div>
            <TableGrid
              loading={loading}
              records={testManagementStore.testingList}
              containerClassName={testManagementStore.selectedTestingListCount > 0 ? classes.tableContainerFooter : classes.tableContainer}
              columnDefinitions={appStore.inspectionGridColumnPreference}
              disableAddButton={disableAddButton}
              disableEditButton={disableEditButton}
              disableDeleteButton={disableDeleteButton}
            />
            {testManagementStore.selectedTestingListCount > 0 && (
              <div className={classes.footerContainer}>
                <div className={classes.buttonGroup}>
                  <span className={classes.noOfDevicesWrapper}>
                    {t("pages.classification-test.testing-list.controls.selected")}
                    {": "}
                    {testManagementStore.selectedTestingListCount}
                  </span>
                </div>
                <div className={classes.buttonGroup}>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleShowModal()}
                    disabled={isDeleteDisabled}
                  >
                    {t("pages.classification-test.testing-list.controls.show-modal")}
                  </Button>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleTestingListModals("COPY-AND-REEXECUTE")}
                    disabled={isEditButton}
                  >
                    {t("pages.classification-test.testing-list.controls.copy-and-reexecute")}
                  </Button>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleViewResult()}
                    disabled={isEditButton || testManagementStore?.selectedTestingList?.[0]?.statusString !== "Executed"}
                  >
                    {t("pages.classification-test.testing-list.controls.view-results")}
                  </Button>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleTestingListModals("DELETE")}
                    disabled={isDeleteDisabled}
                  >
                    {t("pages.classification-test.testing-list.controls.delete")}
                  </Button>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleTestingListModals("EDIT")}
                    disabled={isEditButton}
                  >
                    {t("pages.classification-test.testing-list.controls.edit")}
                  </Button>
                </div>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
};

export default TestingList;

