import { useContext, useState } from "react";
import { columnDefinitions } from "./columnsDefinitions";
import AppStore from "../../../../stores/appstore";
import TestManagementStore from "../../../../stores/testManagementStore";
import { API_RESPONSE } from '../../../../appconstants'
import CustomTables from "../../../../components/customtable/table";

const TableGrid = ({ records, loading, containerClassName, disableAddButton, disableEditButton,disableCheckBox }) => {
  const testManagementStore = useContext(TestManagementStore);
  const appStore = useContext(AppStore);
  const [bodyData, setBodyData] = useState([]);

  let selectedRowCount = 0;
  const isSelected = (id) => {
    const selected = testManagementStore.selectedTestDataset.filter((item) => item.seqNo === id);
    return selected.length > 0;
  };

  const getBodyData = (data) => {
    data = JSON.parse(JSON.stringify(data));
    if (data.length > 0) {
      return data.map((item) => {
        item._id = item.seqNo;
        item.selected = isSelected(item._id);
        if (item.selected) {
          selectedRowCount++;
        }
        return item;
      });
    }
  };

  const handleSelectAllClick = (event) => {
    if(records?.length> 0 && !disableCheckBox){
      const { checked } = event.target;
      if (checked) {
        records.forEach((dataset) => {
          const istestDatasetPresent = testManagementStore.selectedTestDataset.filter((selectedData) => selectedData.seqNo === dataset.seqNo);
          if (!(istestDatasetPresent.length > 0)) {
            testManagementStore.setSelectedTestDatasetRecord(dataset);
          }
        });
        disableAddButton(true);
        if (testManagementStore.selectedTestDataset.length > 1) {
          disableEditButton(true);
        }
      } else {
        disableAddButton(false);
        disableEditButton(false);
        const deselectedTestDataset = [];
        records.forEach((dataset) => {
          if (testManagementStore.selectedTestDataset.some((selectedDataset) => selectedDataset.seqNo === dataset.seqNo)) {
            deselectedTestDataset.push(dataset.seqNo);
          }
        });
        testManagementStore.removeSelectedTestDatasetRecord(deselectedTestDataset);
      }
    }
  };

  const changeDataOrder = (testingId, classes) => {
    testManagementStore.changeDatasetOrder(testingId, { classes }).then(res => {
      if (res && res.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        testManagementStore.fetchTestDataset(testingId);
      }
    }).catch(err => {
      console.log(err);
    });
  }

  const onRowSelect = (event, datasetId) => {
    if(!disableCheckBox){
    const rowData = records.filter((item) => item.seqNo === datasetId);
    const selected = isSelected(datasetId);

    if (selected) {
      testManagementStore.removeSelectedTestDatasetRecord([datasetId]);
    } else {
      testManagementStore.setSelectedTestDatasetRecord(rowData[0]);
    }

    if (testManagementStore.selectedTestDataset.length > 0) {
      disableAddButton(true);
      if (testManagementStore.selectedTestDataset.length > 1) {
        disableEditButton(true);
      } else {
        disableEditButton(false);
      }
    } else {
      disableAddButton(false);
    }
  }
  };

  const data = getBodyData(records);
  return (
    <CustomTables
      enableDrag={true}
      loading={loading}
      classname={containerClassName}
      rowCount={records?.length}
      headerData={columnDefinitions}
      onAllRowSelected={handleSelectAllClick}
      selectedRowCount={selectedRowCount}
      hideFilter={false}
      disableCheckBox={disableCheckBox} 
      onRowSelect={onRowSelect}
      bodyData={bodyData?.length>0?bodyData:data}
      setBodyData= {setBodyData}
      callback={changeDataOrder}
    />
    // <Table loading={loading} className={containerClassName}>
    //   <TableHead
    //     rowCount={records?.length}
    //     headerData={columnDefinitions}
    //     onAllRowSelected={handleSelectAllClick}
    //     selectedRowCount={selectedRowCount}
    //     noEmptyColumn={true}
    //     hideFilter={true}
    //   />
    //   <MuiTableBody>

    //   <CustomTable bodyData={data} disableCheckBox={disableCheckBox} onRowSelect={onRowSelect} headerData={columnDefinitions} noEmptyColumn={true} />
    //   </MuiTableBody>
    // </Table>
  );
};

export default TableGrid;
