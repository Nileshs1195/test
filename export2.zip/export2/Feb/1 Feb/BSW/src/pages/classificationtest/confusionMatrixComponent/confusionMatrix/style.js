import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    minHeight: "100vh"
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  tableContainer: {
    height: "calc(100vh - 490px)",
    marginTop: "8px",
    '& table thead th':{
      zIndex:1
    }
  },
  thresholdSlider: {
    position: "absolute",
    right: "515px",
    top: "-7px",
    zIndex: "5",
    padding: "2px"
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  accMarginTop: {
    // marginTop: theme.spacing(2),
    '&.MuiAccordion-root':{
      transition: 'none !important'
    },
    '& table thead th:first-child':{
      zIndex:2
    }
  },
  accSummaryLabel:{
    marginTop:4, 
    marginLeft:4
  },
  accSummary: {
    "&.MuiAccordion-root":{
      transition: 'none'
    },
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      minHeight: "48px !important",
      // marginTop: theme.spacing(2),
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      // marginTop: theme.spacing(2),
    }
  },
  accDetails: {
    padding: "10px",
    border: "1px solid rgba(0, 0, 0, .125)",
    display: "block"
  },
  pagination: {
    position: "absolute",
    right: "48px",
    top: "5px",
    zIndex: "5",
    padding: "2px"
  }
}));
