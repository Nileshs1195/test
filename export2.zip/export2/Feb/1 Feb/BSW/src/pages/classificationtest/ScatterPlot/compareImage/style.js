import { makeStyles } from '@material-ui/core/styles'

export const useStyles = makeStyles((theme) => ({
  modalWidth: {
    minWidth: '25%',
    maxWidth: '25%',
    maxHeight: '25%',
  },
  modalTextPadding: {
    paddingBottom: '35px',
  },
  modalTitle: {
    backgroundColor: theme.palette.primary.main,
    color: 'white',
    fontSize: 18,
    fontWeight: 'normal',
    height: '42px',
    margin: '-25px -25px 0px -25px',
    padding: '8px 16px',
    borderRadius: '4px 4px 0 0',
  },
  box: {
    padding: theme.spacing(1),
    textAlign: 'center',
    '@media (min-width: 1920px)': {
      width: '100%',
      heigth: 'auto',
    },
    [theme.breakpoints.up('xl')]: {
      height: '100%',
      width: '100%',
    },
    [theme.breakpoints.between('lg', 'xl')]: {
      height: 512,
      width: 512,
    },
    [theme.breakpoints.between('sm', 'lg')]: {
      minHeight: 420,
      minWidth: 420,
    },
  },
  imageCenter: {
    position: 'relative',
    border: '1px solid rgb(203, 203, 203,1)',
    borderRadius:3,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    overflow: 'hidden',
  },
  content: {
    display: 'flex',
  },
  imageLabel: {
    position: 'relative',
    display: 'flex',
    justifyContent: 'center',
    marginBottom:30,
    width: '100%',
  },
}))
