import React, { useState, useContext, useEffect } from 'react'
import { useStyles } from "./style";
import { Observer } from "mobx-react-lite";
import { Paper, Divider, Button, Box, Grid, Typography } from "@material-ui/core";
import BackButton from "../../../../components/backbutton";
import Breadcrumb from "../../../../shared/components/ui/breadcrumb";
import AppStore from "../../../../stores/appstore";
import { API_RESPONSE, API_URL, APP_ROUTES } from "../../../../appconstants";
import { useParams, useHistory } from "react-router-dom";
import { Warning, ThumbUp, FiberManualRecord } from '@material-ui/icons';
import { useTranslation } from "react-i18next";
import trainingmanagementstore from '../../../../stores/trainingmanagementstore';
import { SETTINGS } from '../../../../appsettings';
import AddClassificationTest from '../../../../components/add-test';
import { Loader } from '../../../../shared/components/ui';
import { arrayVariance } from '../../../../helpers/arrayutils';

const DisplayAdvisor = () => {
    const classes = useStyles();
    const params = useParams();
    const { t } = useTranslation();
    const history = useHistory();
    const appStore = useContext(AppStore);
    const trainingManagementStore = useContext(trainingmanagementstore);
    // const { fetchExecutionLogData } = trainingManagementStore;
    const { addBreadcrumb, removeLastBreadcrumb } = appStore;
    const [displayAdvisorData, setDisplayAdvisorData] = useState({
        advices: t("pages.classification-test.testing-list.confusion-matrix.advisor-data").split(","),
        cautions: t("pages.classification-test.testing-list.confusion-matrix.caution-data").split(",")
    });
    const [loader, setLoader] = useState(false);

    const [addTest, setAddTest] = useState(false);
    useEffect(() => {
        removeLastBreadcrumb();
        appStore.addBreadcrumb({
            path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
            label: "pages.classification-test.testing-list.confusion-matrix.title"
        });
        appStore.addBreadcrumb({
            path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
            label: "pages.classification-test.testing-list.title"
        });
        appStore.addBreadcrumb({
            path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS.replace(":id", params.id),
            label: "pages.classification-test.testing-settings.title"
        });
        appStore.addBreadcrumb({
            path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CONFUSION_MATRIX.replace(":id", params.id).replace(":batchSeqNo", params.batchSeqNo),
            label: "pages.classification-test.confusion-matrix.title"
        });
        addBreadcrumb({
            path: APP_ROUTES.TRAINING_MANAGEMENT_PAGES.ADVISOR.replace(":id", params.id).replace(":seqNo", params.batchSeqNo),
            label: "Performance improvement advisor"
        });
    }, [addBreadcrumb]);


    const handleBackButton = () => {
        history.goBack();
    };

    const reDirectTestResult = () => {
        history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CONFUSION_MATRIX.replace(":id", params.id).replace(":batchSeqNo", params.batchSeqNo));
    }

    return (
        <Observer>
            {() => (
                <div>
                    <AddClassificationTest open={addTest} setOpen={setAddTest} id={params.id} />
                    <Paper className={classes.pageContent}>
                        {loader && <Loader size={24} />}
                        <div className={classes.top}>
                            <div className={classes.breadcrumbWraper}>
                                <BackButton
                                    handleBackButton={handleBackButton}
                                />
                                <Breadcrumb
                                    breadcrumbs={appStore.breadcrumbs}
                                    removeBreadcrumb={appStore.removeBreadcrumb}
                                />
                            </div>

                            <div className={classes.buttonWrapper}>
                                <Button color="primary" variant="contained" onClick={reDirectTestResult}>
                                    {t("pages.classification-test.classification-images.controls.back")}
                                </Button>
                            </div>
                        </div>
                        <Divider className={classes.divider} />
                        <Paper variant="outlined" className={classes.paperCustom}>
                            <Grid container spacing={0}>
                                <Grid item xs={12} sm={6}>

                                    <div className={classes.inLine}>
                                        <div>
                                            <Warning className={classes.warningIcon} />
                                        </div>
                                        <div className={classes.textPadding}>
                                            {
                                                t("pages.training.training-parameter.train-parameter.advisor.caution")
                                            }

                                        </div>
                                    </div>
                                    {displayAdvisorData?.cautions?.length > 0 && displayAdvisorData?.cautions?.map(caution => {
                                        return (
                                            <div className={classes.inLine} style={{ marginTop: "6px" }}>
                                                <div>
                                                    <FiberManualRecord className={classes.iconSize} />
                                                </div>
                                                <div className={classes.text}>{caution}</div>
                                            </div>
                                        )
                                    })}
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <div className={classes.inLine}>
                                        <div>
                                            <ThumbUp className={classes.thumbIcon} />
                                        </div>
                                        <div className={classes.textPadding}>
                                            {t("pages.training.training-parameter.train-parameter.advisor.advice")}
                                        </div>
                                    </div>
                                    {displayAdvisorData?.advices?.length > 0 && displayAdvisorData?.advices?.map(advice => {
                                        return <div className={classes.inLine} style={{ marginTop: "6px" }}>
                                            <div>
                                                <FiberManualRecord className={classes.iconSize} />
                                            </div>
                                            <div className={classes.text}>
                                                {/* {t("pages.training.training-parameter.train-parameter.advisor.trainingCount")} */}
                                                {advice}
                                            </div>
                                        </div>
                                    })}

                                </Grid>
                            </Grid>
                        </Paper>
                    </Paper>
                </div>
            )}
        </Observer>
    )
}

export default DisplayAdvisor;
