import React, { useState, useContext, useEffect, useCallback } from 'react'
import { useStyles } from './style'
import { Button, Divider, FormControl, Paper, TextField } from '@material-ui/core'
import { observer, Observer } from 'mobx-react-lite'
import { Breadcrumb } from '../../../shared/components/ui'
import AppStore from '../../../stores/appstore'
import TestManagementStore from '../../../stores/testManagementStore'
import TrainingManagementStore from '../../../stores/trainingmanagementstore'
import ImageManagementStore from '../../../stores/imagemanagementstore'
import { API_RESPONSE, APP_ROUTES } from '../../../appconstants'
import { useTranslation } from 'react-i18next'
import Pagination from '../../../shared/components/basictable/pagination'
import TableGrid from './TableGrid'
import Modals from './modals'
import CustomSnackBar from '../../../components/snackbar'
import { Autocomplete } from '@material-ui/lab'
import { useParams, useHistory } from 'react-router-dom'
import GridMaterial from '@material-ui/core/Grid'
import BackButton from '../../../components/backbutton'
import CustomConfirmation from '../../../components/modal/CustomConfirmation'

const TestingList = observer(() => {
  const classes = useStyles()
  const { t } = useTranslation()
  const params = useParams()
  const history = useHistory();
  const appStore = useContext(AppStore)
  const testManagementStore = useContext(TestManagementStore)
  const trainingManagementStore = useContext(TrainingManagementStore)
  const imageManagementStore = useContext(ImageManagementStore)
  const { setUploaderAction, imageUploadStatus } = imageManagementStore
  const [loading, setLoading] = useState(false)
  const [snapbarMessage, setsnapbarMessage] = useState({ message: '' })
  const [modalFormErrors, setModalFormErrors] = useState({})
  const [isAddButton, disableAddButton] = useState(false);
  const [isExecute, setExecute] = useState(true);
  const [isEditButton, disableEditButton] = useState(false)
  const [action, setAction] = useState({ actionName: '', isOpen: false })
  const [trainingList, setTrainingList] = useState([])
  const [testModel, setTestModel] = useState({});
  const [openUploadCancelModal, setOpenUploadCancelModal] = useState(false);
  const [firstLoad, setFirstLoad] = useState(true);

  useEffect(() => {
    testManagementStore.clearSelectedTestingList()
    if (trainingManagementStore?.reloadList) {
      getTestDatasetList()
      trainingManagementStore.setReloadList(false)
    }
    if (testManagementStore?.selectedTestDatasetCount > 1) {
      disableEditButton(true);
    }
  }, [trainingManagementStore?.reloadList])

  useEffect(() => {
    if (trainingManagementStore?.executedModels?.length > 0) {
      const trainingDropdownArray = trainingManagementStore.executedModels.reduce(
        (trainingDropdownList, trainingItem) => {
          trainingDropdownList.push({
            label: trainingItem.modelName,
            value: trainingItem.id,
          })
          return trainingDropdownList
        }, [])
      setTrainingList(trainingDropdownArray)
      const selectedTraining = trainingDropdownArray.filter(
        (item) => item.value === testManagementStore.testingData.trainingId
      )
      setTestModel({ value: selectedTraining?.[0]?.value, id: selectedTraining?.[0]?.label });
    }
  }, [trainingManagementStore.executedModels])

  const breadCrumb = () => {
    appStore.removeAllBreadcrumbs()
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST,
      label: 'pages.classification-test.testing-list.title',
    })
    appStore.addBreadcrumb({
      path: APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_SETTINGS,
      label: 'pages.classification-test.testing-settings.title',
    })
  }

  useEffect(() => {
    breadCrumb()
    // getTestDatasetList()
    testManagementStore.clearSelectedTestingList()
    getExecutedTrainings();
  }, [])

  const getExecutedTrainings = useCallback(async () => {
    setLoading(true)
    await trainingManagementStore.fetchListingExecutedModal();
    setLoading(false)
    getTestDatasetList();
  })

  const getTestDatasetList = useCallback(async () => {
    setLoading(true)
    let currentTraining = await testManagementStore.fetchTestDataset(params.id);
    if (currentTraining?.testing?.trainingId) {
      setExecute(false);
      setFirstLoad(false);
      setTestModel({ value: currentTraining?.testing?.trainingId })
      // onSelectTestModel(null, { value: currentTraining?.testing?.trainingId });
    }
    setLoading(false)
  })

  const handleTestingListModals = (label, datasetRecord) => {
    switch (label) {
      case 'ADD':
        setUploaderAction({ uploaderType: 'add-class', isOpen: true })
        break
      case 'DELETE':
        deleteDatasetRecord()
        break
      case 'EDIT':
        editDataset(datasetRecord)
        break
      case 'CLOSE':
        setModalFormErrors({})
      default:
    }
  }

  const editDataset = (datasetRecord) => {
    const reqPayload = {
      className: datasetRecord.className,
      seqNos: [testManagementStore.selectedTestDataset[0].seqNo],
    }
    setLoading(true)
    testManagementStore
      .updateTestDataset(params.id, reqPayload)
      .then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          testManagementStore.clearSelectedTestDataset()
          getTestDatasetList()
          setLoading(false)
          disableAddButton(false)
          setsnapbarMessage({
            message: t('pages.training.success.dataset.updated'),
          })
        } else {
          setsnapbarMessage({
            message: t('pages.training.errors.dataset.update-failed'),
          })
        }
      })
      .catch((err) => {
        setLoading(false)
        console.log('error', err)
      })
    setsnapbarMessage({ message: '' })
  }

  const deleteDatasetRecord = () => {
    let reqPayload = {
      seqNo: testManagementStore.selectedTestDataset.map((item) => item.seqNo),
    }
    setLoading(true)
    testManagementStore
      .deleteTestDataset(params.id, reqPayload)
      .then((response) => {
        if (response?.data?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          testManagementStore.clearSelectedTestDataset()
          getTestDatasetList()
          setLoading(false)
          disableAddButton(false)
          setsnapbarMessage({
            message: t('pages.training.success.dataset.deleted'),
          })
        } else {
          setsnapbarMessage({
            message: t('pages.training.errors.dataset.delete-failed'),
          })
        }
      })
      .catch((err) => {
        console.log('error', err)
      })
  }

  const executeTesting = () => {
    let reqPayload = {
      seqNos: testManagementStore.selectedTestDataset.map((item) => item.seqNo)
    };
    testManagementStore.executeTesting(params.id, reqPayload).then(res => {
      if (res?.status === 200 && res?.data?.seqNo) {
        history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.TESTING_EXECUTION.replace(":id", params.id).replace(":seqNo", res?.data?.seqNo));
      }
    }).catch(error => {
      console.log(error);
    });
  };

  const onPagination = (options) => {
    appStore.updateInspectionGridPageNo(
      (options.pageNo > 0 ? options.pageNo - 1 : options.pageNo) *
      options.pageSize,
    )
    if(!firstLoad) {
      getTestDatasetList();
    }
  }

  const onSelectTestModel = (event, value) => {
    if (value) {
      setExecute(false);
      let reqPayload = {
        trainingId: value?.value
      };
      testManagementStore.saveTestModel(params.id, reqPayload).then(res => {
        if (res?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          setTestModel(value)
          console.log("Selected Test Model Saved");
        }
      }).catch(error => {
        console.log(error);
      });
    } else {
      setTestModel({})
      setExecute(true);
    }
  }

  const handleFileUploadClose = () => {
    setUploaderAction({ uploaderType: '', isOpen: false })
  }

  const handleModalActions = (name) => {
    setAction({ actionName: name, isOpen: true })
  }

  const setModalActive = () => {
    setAction({ actionName: action.actionName, isOpen: false }) // display file upload confirmation modal
  }

  const getTrainingList = () => {
    return (
      <form autoComplete="off">
        <FormControl className={classes.formControl}>          
          <Autocomplete
            id="combo-box"
            disableClearable
            value={trainingList?.length > 0 && trainingList.filter(res => res.value === testModel?.value)?.[0]}
            options={trainingList}
            getOptionLabel={(option) => option.label}
            onChange={(event, value) => onSelectTestModel(event, value)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Model"
                id="selectModel"
                name="selectModel"
                margin="normal"
                error={modalFormErrors['modelName']}
                helperText={
                  modalFormErrors['modelNameErrorMsg'] !== '' &&
                  modalFormErrors['modelNameErrorMsg']
                }
              />
            )}
          />
        </FormControl>
      </form>
    )
  }

  const handleFolderUpload = () => {
    setTimeout(() => {
      setsnapbarMessage({ message: '' })
    }, 2000)
    if (testModel?.value) {
      setUploaderAction({
        isOpen: true,
        uploaderType: 'add-testing-class',
        className: '',
        id: params?.id,
      })
    } else {
      setsnapbarMessage({
        message: t('pages.classification-test.errors.testing-setting.select-test-model'),
      })
    }
  }

  const handleBackButton = () => {
    history.goBack();
  };

  const goToTestListPage = () => {
    imageManagementStore.setImageUploadInProgress(false);
    history.push(APP_ROUTES.CLASSIFICATION_MANAGEMENT_PAGES.CLASSIFICATION_TEST);
  };

  return (
    <Observer>
      {() => (
        <div>
          <Modals action={action} setModalActive={setModalActive} handleAPICall={handleTestingListModals} disableAddButton={disableAddButton} />
          <Paper className={classes.pageContent}>
            {snapbarMessage?.message && <CustomSnackBar snapbarMessage={snapbarMessage} />}
            <div className={classes.top}>
              <div className={classes.breadcrumbWraper}>
                <BackButton handleBackButton={handleBackButton} />
                <Breadcrumb breadcrumbs={appStore.breadcrumbs} removeBreadcrumb={appStore.removeBreadcrumb} />
              </div>
              <div className={classes.buttonWrapper}>
                <Button color="primary" variant="contained" onClick={handleFolderUpload} disabled={isAddButton}>
                  {t("pages.classification-test.testing-settings.controls.add-test-folders-btn")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={executeTesting}
                  disabled={
                    testManagementStore?.testDataset?.length <= 0 ||
                    testModel === undefined ||
                    testModel.value === undefined ||
                    testModel.value === "" ||
                    imageUploadStatus === "in-progress"
                  }
                >
                  {t("pages.classification-test.testing-settings.controls.execute-testing")}
                </Button>
                <Button
                  color="primary"
                  variant="contained"
                  onClick={() => {
                    setOpenUploadCancelModal(true);
                  }}
                >
                  {t("pages.classification-test.testing-settings.controls.cancel-btn")}
                </Button>
                <CustomConfirmation
                  open={openUploadCancelModal}
                  onClose={() => {
                    setOpenUploadCancelModal(false);
                  }}
                  onSubmit={goToTestListPage}
                  primary={"pages.classification-test.testing-settings.controls.ok"}
                  secondary={"pages.classification-test.testing-settings.controls.cancel-btn"}
                  title={t("pages.classification-test.testing-settings.cancel-unsaved-data.title")}
                  message={t("pages.classification-test.testing-settings.cancel-unsaved-data.message")}
                />
              </div>
            </div>
            <Divider className={classes.divider} />
            <div className={classes.controlContainer}>
              <GridMaterial container>
                <GridMaterial item xs={6}>
                  <Pagination
                    disabled={false}
                    onChange={onPagination}
                    itemCount={testManagementStore.testDataset?.length}
                    pageNo={appStore.inspectionSearchFilter.pageNo + 1}
                    pageSize={5}
                    disableItemPerPage={true}
                  />
                </GridMaterial>
                <GridMaterial item xs={6}>                  
                  {getTrainingList()}
                </GridMaterial>
              </GridMaterial>
            </div>
            <TableGrid
              loading={loading}
              records={testManagementStore.testDataset}
              containerClassName={testManagementStore.selectedTestDatasetCount > 0 ? classes.tableContainerFooter : classes.tableContainer}
              disableAddButton={disableAddButton}
              disableEditButton={disableEditButton}
              disableCheckBox={imageUploadStatus === "in-progress"}
            />
            {testManagementStore?.selectedTestDatasetCount > 0 && (
              <div className={classes.footerContainer}>
                <div className={classes.buttonGroup}>
                  <span className={classes.noOfDevicesWrapper}>
                    {t("pages.classification-test.testing-settings.controls.selected")}
                    {": "}
                    {testManagementStore.selectedTestDatasetCount}
                  </span>
                </div>
                <div className={classes.buttonGroup}>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleModalActions("DELETE")}
                    disabled={false}
                  >
                    {t("pages.classification-test.testing-settings.controls.delete")}
                  </Button>
                  <Button
                    variant="outlined"
                    className={classes.buttons}
                    size="small"
                    onClick={() => handleModalActions("EDIT")}
                    disabled={isEditButton}
                  >
                    {t("pages.classification-test.testing-settings.controls.edit")}
                  </Button>
                </div>
              </div>
            )}
          </Paper>
        </div>
      )}
    </Observer>
  );
})

export default TestingList
