import React, { useEffect, useState } from "react";
import {
    TableBody as MuiTableBody,
    Table as MuiTable,
    TableCell as MuiTableCell,
    TableRow as MuiTableRow,
    TableContainer as MuiTableContainer,
    TableHead as MuiTableHead,
  } from '@material-ui/core'
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";

const PopoverTables = ({rowsData}) => {
  const classes = useStyles();
  const { t } = useTranslation();
  return (
    <MuiTableContainer>
    <MuiTable className={classes.table} aria-label="simple table">
      <MuiTableHead>
        <MuiTableRow className={classes.tRow}>
          <MuiTableCell>{t("pages.classification-test.testing-list.grid.className")}</MuiTableCell>
          <MuiTableCell>{t("pages.classification-test.testing-list.grid.totalImages")}</MuiTableCell>
        </MuiTableRow>
      </MuiTableHead>
      <MuiTableBody>
      {Object.values(rowsData?.classesData??{}).map((row) => ( 
        <MuiTableRow className={classes.tRow}>
          <MuiTableCell>{row?.className}</MuiTableCell>
          <MuiTableCell>{row?.imageCount}</MuiTableCell>
        </MuiTableRow>
      ))} 
      </MuiTableBody>
    </MuiTable>
  </MuiTableContainer>
  );
};
export default PopoverTables;
