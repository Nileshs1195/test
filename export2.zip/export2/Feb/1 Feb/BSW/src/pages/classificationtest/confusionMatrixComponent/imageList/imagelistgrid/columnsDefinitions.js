export const columnDefinition = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true
  },
  {
    key: "uploadFileName",
    text: "pages.classification-test.testing-list.grid.img-file-name",
    type: "string",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "probability",
    text: "pages.classification-test.testing-list.grid.probability",
    type: "commaSeparatedData",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "actualClassName",
    text: "pages.classification-test.testing-list.grid.uploaded-class-name",
    type: "string",
    validation: { required: true, pattern: "//" }
  },
  {
    key: "setClassName",
    text: "pages.classification-test.testing-list.grid.set-class",
    type: "string",
    validation: { required: true, pattern: "//" }
  }
];
