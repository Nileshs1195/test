export const columnDefinition = [
  {
    key: "checkbox",
    type: "checkbox",
    isSticky: true
  },
  {
    key: "className",
    text: "pages.classification-test.testing-list.grid.uploaded-class-name",
    type: "string",
    validation: { required: true, pattern: "//" }
  }
];
