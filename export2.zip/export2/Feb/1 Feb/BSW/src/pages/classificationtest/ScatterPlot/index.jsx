import { Observer } from 'mobx-react-lite';
import React, { useState, useCallback, useEffect, useContext, useRef } from 'react';
import Plotly from 'plotly.js-basic-dist';
import { RadioGroup } from '../../../shared/components/ui/index.js';
import { Accordion, AccordionDetails, AccordionSummary, Box, Grid } from '@material-ui/core';
import { useStyles } from './styles';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { useTranslation } from 'react-i18next';
import TestManagementStore from '../../../stores/testManagementStore.js';
import { API_RESPONSE } from '../../../appconstants'
import * as GraphSettings from './settings';
import * as CommonMethods from '../../../helpers/CommonMethods';
import ButtonControls from './buttonControls.jsx';
import { useParams } from 'react-router';
import CompareImage from './compareImage/index.jsx';
import DragIndicatorIcon from '@material-ui/icons/DragIndicator';
import ResizablePanel  from '../../../components/resizable/index.jsx';

const ScatterGraph = (props) => {
  const { probabilityThreshold , drag } = props;
  const classes = useStyles();
  const params = useParams();
  const { t } = useTranslation();
  const ref = useRef(null);
  const [radioValue, setRadioValue] = useState('actualClassName');
  const [selectedPlotData, setSelectedPlotData] = useState({});
  const [traceData, setTraceData] = useState([]);
  const [layout, setLayout] = useState({});
  const [graphData, setImageListData] = useState([]);
  const [colors,setColors] = useState({});
  const testManagementStore = useContext(TestManagementStore);
  const [showHeatImage, disableHeatImage] = useState(false);
  const [resizeDrag,setResizeDrag] = useState(false);

  const items = [
    {
      label: t(
        'pages.classification-test.testing-list.confusion-matrix.graph-controls.original',
      ),
      value: 'actualClassName',
    },
    {
      label: t(
        'pages.classification-test.testing-list.confusion-matrix.graph-controls.classified',
      ),
      value: 'setClassName',
    },
  ];

  const getImageList =useCallback(async () =>{
    const selectedData = JSON.parse(JSON.stringify(testManagementStore.selectedConfusionMatrixClasses));
    let classes = selectedData.reduce((classList, item) => {
      if (!classList[item.setClassName]) {
        classList[item.setClassName] = [];
      }
      classList[item.setClassName].push(item.actualClassName);
      return classList;
    }, {});

    let payload = { probability: probabilityThreshold, classes: classes,  asc: "seqNo" };
    await testManagementStore
      .fetchConfusionMatrixImageListData(params.id, payload)
      .then((response) => {
        if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
          let classes = [
            ...response?.data.map((obj)=>obj.actualClassName), 
            ...response?.data.map((obj)=> obj.setClassName)
          ];
          setColors(setClassColor([...new Set(classes)]));
          setImageListData(response?.data);
        }
      })
      .catch((error) => {
        setImageListData([]);
      });
  });

  const setClassColor = (classes) =>{
    let colorsJSON = {};
    classes.forEach(item => colorsJSON[item] = GraphSettings.getColor?.())
    return colorsJSON;
  }

  useEffect(()=>{
    getImageList();
  },[testManagementStore.selectedConfusionMatrixClasses?.length,probabilityThreshold]);

  const handleRadioButton = (event) => {
    setRadioValue(event.target.value)
  }

  const createTrace = (object, name) => {
    return {
      x: object.map((item) => item.xaxis),
      y: object.map((item) => item.yaxis),
      mode: 'markers',
      type: 'scatter',
      name: name.replace(/(.{10})/g, "$1<br>"),
      text: object,
      marker: { size: 5, color: colors[name] },
      hoverinfo: 'none',
    };
  }

  const handleTraceList = (object, type) => {
    let trace = {};
    if (type === 'actualClassName') {
      trace = createTrace(object, object[0]['actualClassName']);
    } else {
      let classes = CommonMethods.getUniqueDataByField(object, radioValue);
      for (var i = 0; i < classes.length; i++) {
        let filtered = object.filter((item) => item.setClassName === classes[i]);
        trace = createTrace(filtered, classes[i]);
      }
    }
    return trace;
  }

  const classifiedData = (data) => {
    Plotly.newPlot(ref.current, data, layout, { responsive: true });
    GraphSettings.exces(ref,setSelectedPlotData,disableHeatImage,testManagementStore);
  }

  const handleDraw = useCallback(() => {
    const data = [];
    const record = CommonMethods.getUniqueDataByField(graphData, radioValue);
    record.forEach((i) => {
      const classes = graphData.filter((item) => item[radioValue] === i);
      data.push(handleTraceList(classes, radioValue));
    });
    setTraceData(data);
  }, [radioValue, graphData])

  const onClosePopUp = () =>{
    disableHeatImage((isOpen)=>!isOpen)
    Plotly.restyle(ref.current, {selectedpoints: [null]});
    testManagementStore.clearConfusionMatrixImages();
    setSelectedPlotData({});
  }

  useEffect(() => {
    setLayout({
      showlegend: true,
      height:400,
      margin: {
        l: 75,
        r: 75,
        b: 40,
        t: 10,
        pad: 4
      },
      dragmode: '',
      zoom: 'in',
      clickmode: 'event+select',
    });
    handleDraw();
  }, [radioValue, graphData])

  useEffect(() => {
    classifiedData(traceData.sort((a,b)=>a?.name.localeCompare(b?.name, undefined, {numeric: true})));
  }, [traceData])

  const handleAccordionChange = (ev,isExpanded)=>{
    setResizeDrag(isExpanded)
  }

  return (
    <Observer>
      {() => (
        <ResizablePanel hideDrag={resizeDrag} overflow="hidden">
        <Accordion defaultExpanded={false} onChange={handleAccordionChange} className={classes.accMarginTop}>
          <AccordionSummary
            className={classes.accSummary}
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1bh-content"
            id="panel1bh-header"
          >
            <div {...drag}>
              <DragIndicatorIcon />
            </div>
            <label className={classes.accSummaryLabel}>
              {t('pages.classification-test.testing-list.grid.scatterplot')}
            </label>
          </AccordionSummary>
          <AccordionDetails className={classes.accDetails}>
            <div className={classes.root}>
              <ButtonControls  graphref={ref} layout={layout} setSelectedPlotData={setSelectedPlotData}/>
              <Grid container>
                <Grid item xs={12} sm={12} lg={6}>
                  <div
                    ref={ref}
                    id="scatterPlot"
                    className={classes.scatterGraph}
                  ></div>
                  <Box className={classes.box}>
                    <RadioGroup
                      className={classes.radioWrapper}
                      items={items}
                      selected={radioValue}
                      onChange={handleRadioButton}
                    />
                  </Box>
                </Grid>
                { Object.keys(selectedPlotData).length > 0 && (
                  <CompareImage open={showHeatImage} onClose={onClosePopUp} imageData={selectedPlotData}/>
                )}
              </Grid>
            </div>
          </AccordionDetails>
        </Accordion>
        </ResizablePanel>
    
      )}
    </Observer>
  )
}
export default ScatterGraph
