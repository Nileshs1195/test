import React from "react";
import { useEffect, useState } from "react";
import { Observer } from "mobx-react-lite";
import { Accordion, AccordionSummary, AccordionDetails } from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useStyles } from "./style";
import { useTranslation } from "react-i18next";
import Pagination from "../../../../shared/components/basictable/pagination";
import ConfusionMatrixGrid from "./confusionmatrixgrid/confusionMatrixGrid";
import ThresholdSlider from "../../../../components/threshold-slider";
import { columnDefinition } from "./confusionmatrixgrid/columnsDefinitions";
import { useParams } from "react-router-dom";
import DragIndicatorIcon from "@material-ui/icons/DragIndicator";
import ResizablePanel from "../../../../components/resizable";

const ConfusionMatrix = ({
  drag,
  loading,
  confusionMatrixData,
  setProbabilityThreshold,
  selectedConfusionMatrixClassesCount,
  testList,
  setClasses,
  disableAdvisorButton
}) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const [columnDef, setColumnDef] = useState([]);
  const [testTitle, setTestTitle] = useState("");
  const [resizeDrag, setResizeDrag] = useState(false);
  
  useEffect(() => {
    if (setClasses?.length > 0) {
      let newColumnDef = JSON.parse(JSON.stringify(columnDefinition));
      // disableAdvisorButton(!(confusionMatrixData?.length === setClasses.length));
      setClasses.forEach((item) => {
        newColumnDef.push({
          key: item.className,
          text: item.className,
          defaultValue: 0,
          type: "dataWithCheckbox",
          validation: { required: true, pattern: "//" }
        });
      });
      setColumnDef(newColumnDef);
    }
  }, [setClasses]);

  const handleSliderOnChange = (value) => {
    setProbabilityThreshold(value);
  };

  useEffect(() => {
    const test = testList.filter((element) => element._id === params.id);
    setTestTitle(test?.[0]?.title);
  }, [testList]);

  const onPagination = (options) => {};

  const handleAccordionChange = (ev, isExpanded) => {
    setResizeDrag(isExpanded);
  };
  return (
    <Observer>
      {() => (
        <ResizablePanel hideDrag={resizeDrag}>
          <Accordion defaultExpanded={true} className={classes.accMarginTop} onChange={handleAccordionChange}>
            <AccordionSummary
              className={classes.accSummary}
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1bh-content"
              id="panel1bh-header"
            >
              <div {...drag}>
                <DragIndicatorIcon />
              </div>
              <label className={classes.accSummaryLabel}>
                {t("pages.classification-test.testing-list.grid.confusion-matrix")} {testTitle && ": " + testTitle}
              </label>
            </AccordionSummary>
            <AccordionDetails className={classes.accDetails}>
              <div className={classes.thresholdSlider}>
                <ThresholdSlider onThresholdChange={handleSliderOnChange} disabled={false} initialProbabilityTreshold={0.8} decimalPoints={4} />
              </div>
              <div className={classes.pagination}>
                <Pagination
                  disabled={false}
                  onChange={onPagination}
                  itemCount={confusionMatrixData?.length}
                  pageNo={1}
                  pageSize={10}
                  disableItemPerPage={true}
                  disablePageNumber={true}
                />
              </div>
              <ConfusionMatrixGrid
                loading={loading}
                records={confusionMatrixData}
                selectedRecordsCount={selectedConfusionMatrixClassesCount}
                containerClassName={classes.tableContainer}
                columnDefinition={columnDef}
                disableAdvisorButton = {disableAdvisorButton}
              />
            </AccordionDetails>
          </Accordion>
        </ResizablePanel>
      )}
    </Observer>
  );
};

export default ConfusionMatrix;
