import { Grid, Tooltip } from '@material-ui/core'
import React from 'react'
import Modal from '../../../../shared/components/ui/modal'
import { SETTINGS } from '../../../../appsettings'
import { useStyles } from './style'
import { useTranslation } from 'react-i18next'
import { useParams } from 'react-router'
import { API_URL } from '../../../../appconstants'

const CompareImage = (props) => {
  const { open, onClose, imageData } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams()
  const imageThumbnailURL = SETTINGS.IMAGE_FULL_URL

  const getHeatMapImage = () => {
    return API_URL.HEATMAP_IMAGE.replace("{id}", params.id).replace("{seqNo}", params.batchSeqNo).replace("{fileName}", imageData.heatmapFileName)
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      widthClass={classes.modalwidth}
    >
      <div className={classes.modalTextPadding}>
        <h3 className={classes.modalTitle}>
          {t('pages.classification-test.confusion-matrix.modal.scatter-plot-image-view')}
        </h3>

        <div className={classes.content}>
          <Grid item xs={12} sm={6} className={classes.box}>
            <label>{t("pages.classification-test.confusion-matrix.modal.original-image")}</label>

             <img
              src={imageThumbnailURL + imageData.fileName}
              alt={imageData.uploadFileName}
              className={classes.imageCenter}
            />
            <Tooltip title={imageData.probabilities}>
              <label className={classes.imageLabel}>
                {t(
                  'pages.classification-test.confusion-matrix.modal.compare-images-data',
                  {
                    name: imageData.uploadFileName,
                    actualclass: imageData.actualClassName,
                    setclass: imageData.setClassName,
                    probability: imageData.probability
                  },
                )}
              </label>
            </Tooltip>
          </Grid>
          <Grid item xs={12} sm={6} className={classes.box}>
            <label>{t("pages.classification-test.confusion-matrix.modal.heatMap-image")}</label>
            <img
              src={SETTINGS.BASE_API_URL + getHeatMapImage()}
              alt={imageData.heatmapFileName}
              className={classes.imageCenter}
            />
          </Grid>
        </div>
      </div>
    </Modal>
  )
}
export default CompareImage
