import { useContext } from "react";
import { Table, TableHead } from "../../../../../shared/components/basictable";
import { TableBody as MuiTableBody } from "@material-ui/core";
import { columnDefinition } from "./columnsDefinitions";
import TestManagementStore from "../../../../../stores/testManagementStore";
import CustomTable from "../../../../../components/customtable";

const ImageListGrid = ({ records, loading, selectedImagesCount, containerClassName }) => {
  const testManagementStore = useContext(TestManagementStore);
  let selectedRowCount = 0;

  const isSelected = (id) => {
    const selected = testManagementStore.selectedconfusionMatrixImages.filter(
      (item) => item.imageSeqNo === id.imageSeqNo && item.classSeqNo === id.classSeqNo
    );
    return selected.length > 0;
  };

  const getBodyData = (data) => {
    data = JSON.parse(JSON.stringify(data));
    if (data.length > 0) {
      return data.map((item) => {
        item._id = { imageSeqNo: item.seqNo, classSeqNo: item.classSeqNo };
        item.selected = isSelected(item._id);
        if (item.selected) {
          selectedRowCount++;
        }
        return item;
      });
    }
  };

  const handleSelectAllClick = (event) => {
    if (records?.length > 0) {
      const { checked } = event.target;
      testManagementStore.clearConfusionMatrixImages();
      if (checked) {
        let selectedRecords = records.reduce((result, element) => {
          result.push({ imageSeqNo: element.seqNo, classSeqNo: element.classSeqNo });
          return result;
        }, []);
        testManagementStore.addConfusionMatrixImages(selectedRecords);
      }
    }
  };

  const onRowSelect = (event, imageGroupId) => {
    const { checked } = event.target;
    if (checked) {
      testManagementStore.addConfusionMatrixImages([imageGroupId]);
    } else {
      testManagementStore.removeConfusionMatrixImages(imageGroupId);
    }
  };

  const data = getBodyData(records);
  return (
    <Table loading={loading} className={containerClassName}>
      <TableHead
        rowCount={records.length}
        headerData={columnDefinition}
        onAllRowSelected={handleSelectAllClick}
        selectedRowCount={selectedRowCount}
        hideFilter={true}
        noEmptyColumn={true}
      />
      <MuiTableBody>
        <CustomTable onRowSelect={onRowSelect} bodyData={data} headerData={columnDefinition} />
      </MuiTableBody>
    </Table>
  );
};

export default ImageListGrid;
