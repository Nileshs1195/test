import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    minHeight: "calc(100vh - 82px)",
    maxHeight: "auto",
    position: "relative",
    paddingBottom: "68px"
  },
  top: {
    marginTop: theme.spacing(2),
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  breadcrumbWraper: {
    display: "flex"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  pagination: {
    marginTop: theme.spacing(2)
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    },
    zIndex: 1
  }
}));
