import React, {useState, useContext} from 'react';
import { useTranslation } from 'react-i18next';
import { useStyles } from './styles';
import { Tooltip } from '@material-ui/core';
import { Add, GestureOutlined, HighlightOff, PanTool, Remove, Search, TabUnselected, ArrowDownward } from '@material-ui/icons';
import { IconButton } from '../../../shared/components/ui/index.js';
import Plotly from 'plotly.js-basic-dist';
import TestManagementStore from '../../../stores/testManagementStore.js';

const ButtonControls = (props) => {
    const { graphref, layout, setSelectedPlotData } = props;
    const classes = useStyles();
    const { t } = useTranslation();
    const [enableTool, disableTool] = useState({});
    const testManagementStore = useContext(TestManagementStore);

    const handleSaveGraph = () => {
        Plotly.downloadImage(graphref.current, {
          format: 'png',
          height: 720,
          width: 1024,
          filename: 'myPlot',
        });
    }

    const handleZoomIn = (ev) => {
        const container = document.getElementById('scatterPlot');
        container._fullLayout._modeBar.buttons[2][0].click(container, ev);
      }
    
      const handleZoomOut = (ev) => {
        const container = document.getElementById('scatterPlot');
        container._fullLayout._modeBar.buttons[2][1].click(container, ev);
      }
    
      const handleReset = (ev) => {
        const container = document.getElementById('scatterPlot');
        container._fullLayout._modeBar.buttons[2][1].click(container, ev);
        Plotly.restyle(graphref.current, {selectedpoints: [null]});
        testManagementStore.clearConfusionMatrixImages();
        setSelectedPlotData({});
      }
    
      const handleGraphButtons = (type) => {
        disableTool({
          [type]: !enableTool[type],
        });
        layout.dragmode = !enableTool[type] ? type : '';
        Plotly.relayout('scatterPlot', layout);
      }
    return (
        <div className={classes.leftButtonContainer}>
                <IconButton
                  id="gesture"
                  variant="outlined"
                  onClick={handleSaveGraph}
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.download',
                    )}
                  >
                    <ArrowDownward
                      fontSize="small"
                      className={classes.iconColor}
                    />
                  </Tooltip>
                </IconButton>
                <IconButton
                  id="gesture"
                  variant="outlined"
                  className={enableTool?.lasso && classes.iconButton}
                  onClick={() => handleGraphButtons('lasso')}
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.lasso',
                    )}
                  >
                    <GestureOutlined
                      fontSize="small"
                      className={classes.iconColor}
                    />
                  </Tooltip>
                </IconButton>
                <IconButton
                  id="selectionDraw"
                  variant="outlined"
                  className={enableTool?.select && classes.iconButton}
                  onClick={() => handleGraphButtons('select')}
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.selection',
                    )}
                  >
                    <TabUnselected
                      fontSize="small"
                      className={classes.iconColor}
                    />
                  </Tooltip>
                </IconButton>
                <IconButton
                  id="search"
                  variant="outlined"
                  className={enableTool?.zoom && classes.iconButton}
                  onClick={() => handleGraphButtons('zoom')}
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.zoom',
                    )}
                  >
                    <Search fontSize="small" className={classes.iconColor} />
                  </Tooltip>
                </IconButton>
                <IconButton
                  id="pan"
                  variant="outlined"
                  className={enableTool?.pan && classes.iconButton}
                  onClick={() => handleGraphButtons('pan')}
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.pan',
                    )}
                  >
                    <PanTool fontSize="small" className={classes.iconColor} />
                  </Tooltip>
                </IconButton>
                <IconButton
                  id="add"
                  onClick={handleZoomIn}
                  data-attr="zoom"
                  data-val="in"
                  variant="outlined"
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.zoom_in',
                    )}
                  >
                    <Add fontSize="small" className={classes.iconColor} />
                  </Tooltip>
                </IconButton>
                <IconButton
                  onClick={handleZoomOut}
                  data-attr="zoom"
                  data-val="out"
                  id="remove"
                  variant="outlined"
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.zoom_out',
                    )}
                  >
                    <Remove fontSize="small" className={classes.iconColor} />
                  </Tooltip>
                </IconButton>
                <IconButton
                  onClick={handleReset}
                  data-attr="zoom"
                  data-val="reset"
                  id="highlight"
                  variant="outlined"
                >
                  <Tooltip
                    title={t(
                      'pages.classification-test.testing-list.confusion-matrix.graph-controls.reset',
                    )}
                  >
                    <HighlightOff
                      fontSize="small"
                      className={classes.iconColor}
                    />
                  </Tooltip>
                </IconButton>
              </div>
    )
}
export default ButtonControls;