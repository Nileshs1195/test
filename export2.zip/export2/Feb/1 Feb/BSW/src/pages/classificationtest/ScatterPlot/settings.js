export const exces = (ref,setSelectedPlotData,disableHeatImage,testManagementStore) =>{

  const element = ref.current;

  element.on('plotly_legendclick',(data)=>{
    data.data[data.expandedIndex]['visible'] = true
  });

  let dragLayer = document.getElementsByClassName('nsewdrag')[0]
  element.on('plotly_hover', function(data){
    dragLayer.style.cursor = 'pointer'
  });
  
  element.on('plotly_unhover', function(data){
    dragLayer.style.cursor = ''
  });
  
  ref.current.on('plotly_click', (data) => {
    const probabilityValue = data.points[0].text.probability
      .map((prob) => prob.toFixed(4))
      .join();
    setSelectedPlotData({
      actualClassName: data.points[0].text.actualClassName,
      uploadFileName: data.points[0].text.uploadFileName,
      heatmapFileName: data.points[0].text.heatmapFileName,
      fileName: data.points[0].text.fileName,
      probabilities: probabilityValue,
      probability: probabilityValue.slice(0,20),
      setClassName: data.points[0].text.setClassName,
    });
    disableHeatImage((isOpen)=>!isOpen)
  });

  ref.current.on('plotly_selected', (data) => {
    console.log(data);
    testManagementStore.clearConfusionMatrixImages();
    let selectedImages = [];
    for (var i = 0; i < data.points.length; i++) {
      selectedImages.push({
        imageSeqNo: data.points[i].text.seqNo,
        classSeqNo: data.points[i].text.classSeqNo,
      });
    }
    console.log(testManagementStore.selectedconfusionMatrixImages)
    testManagementStore.addConfusionMatrixImages(selectedImages);
  })
}  

export const getColor = () => {
  return `#${Math.floor(Math.random()*16777216).toString(16)}`
}
