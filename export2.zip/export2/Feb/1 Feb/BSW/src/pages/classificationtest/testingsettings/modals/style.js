import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(theme => ({
    confirmationModalWidth: {
        minWidth: "370px",
        maxWidth: "25%",
        minHeight: "auto",
    },
    modalTitle: {
        backgroundColor: theme.palette.primary.main,
        color: "white",
        fontSize: 18,
        fontWeight: "normal",
        Height: "42px",
        margin: "-16px -16px 0px -16px",
        padding: "8px 16px",
        borderRadius: "4px 4px 0 0"
    },
    modalTextPadding: {
        paddingBottom: "16px"
    },
    formControl: {
        minWidth: "100%"
    },
    mT1: {
        marginTop: "16px"
    },
    mT2: {
        marginTop: "8px"
    },
    fontsize: {
        fontSize: "16px"
    },
    font: {
        fontSize: "16px",
        fontWeight: 400
    },
    mT3: {
        marginTop: "-8px"
    },
    mT4: {
        "&.MuiFormControl-marginNormal": {
            marginTop: "8px",
            marginBottom: "8px"
        },
        minWidth: "100%"
    },
    textSize: {
        "&.MuiFormLabel-root ": {
            fontSize: "14px"
        },
        minWidth: "100%"
    }
}));