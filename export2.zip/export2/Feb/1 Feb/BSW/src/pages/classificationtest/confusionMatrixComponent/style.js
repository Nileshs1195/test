import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
    overflow: 'hidden',
    minHeight: "calc(100vh - 82px)",
    maxHeight: "auto",
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between"
  },
  breadcrumbWraper: {
    display: "flex"
  },
  divider: {
    marginTop: theme.spacing(2)
  },
  tableContainer: {
    height: "calc(100vh - 490px)",
    marginTop: "8px"
  },
  thresholdSlider: {
    position: "absolute",
    right: "515px",
    top: "-7px",
    zIndex: "5",
    padding: "2px"
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2)
    }
  },
  accMarginTop: {
    marginTop: theme.spacing(2)
  },
  accSummary: {
    "&.Mui-expanded": {
      borderBottom: "1px solid rgba(0, 0, 0, .12)",
      minHeight: "48px !important"
    },
    "& .MuiAccordionSummary-content.Mui-expanded": {
      margin: 0
    }
  },
  accDetails: {
    padding: "10px",
    border: "1px solid rgba(0, 0, 0, .125)",
    display: "block"
  },
  pagination: {
    position: "absolute",
    right: "48px",
    top: "5px",
    zIndex: "5",
    padding: "2px"
  }
}));
