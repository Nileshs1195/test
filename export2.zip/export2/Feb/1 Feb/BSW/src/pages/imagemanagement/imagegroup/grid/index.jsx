import { useContext } from "react";
import {
  Table,
  TableBody,
  TableHead
} from "../../../../shared/components/basictable";
import AppStore from "./../../../../stores/appstore";
import ImageManagementStore from "../../../../stores/imagemanagementstore";

const Grid = ({
  records,
  loading,
  containerClassName,
  columnDefinitions,
  disableAddButton,
  disableEditButton
}) => {
  const imageManagementStore = useContext(ImageManagementStore);
  const appStore = useContext(AppStore);
  let selectedRowCount = 0;
  const isSelected = id => {
    const selected = imageManagementStore.selectedImageGroups.filter(
      item => item._id === id
    );
    return selected.length > 0;
  };

  const getBodyData = data => {
    data = JSON.parse(JSON.stringify(data));
    return data.map(item => {
      item.selected = isSelected(item._id);
      if (item.selected) {
        selectedRowCount++;
      }
      return item;
    });
  };

  const handleSelectAllClick = event => {
    const { checked } = event.target;
    if (checked) {
      disableAddButton(true);
      disableEditButton(true);
      records.forEach(imageGroup => {
        const isImageGroupPresent = imageManagementStore.selectedImageGroups.filter(
          selectedImageGroup => selectedImageGroup._id === imageGroup._id
        );
        if (!(isImageGroupPresent.length > 0)) {
          imageManagementStore.setSelectedImageGroups(imageGroup);
        }
      });
    } else {
      disableAddButton(false);
      disableEditButton(false);
      const deselectedImageGroups = [];
      records.forEach(imageGroup => {
        if (
          imageManagementStore.selectedImageGroups.some(
            selectedImageGroup => selectedImageGroup._id === imageGroup._id
          )
        ) {
          deselectedImageGroups.push(imageGroup._id);
        }
      });
      imageManagementStore.removeSelectedImageGroups(deselectedImageGroups);
    }
  };

  const onRowSelect = (event, imageGroupId) => {
    const rowData = records.filter(item => item._id === imageGroupId);
    const selected = isSelected(imageGroupId);

    if (selected) {
      imageManagementStore.removeSelectedImageGroup(imageGroupId);
    } else {
      imageManagementStore.setSelectedImageGroups(rowData[0]);
    }

    if (imageManagementStore.selectedImageGroups.length > 0) {
      disableAddButton(true);
      if (imageManagementStore.selectedImageGroups.length > 1) {
        disableEditButton(true);
      } else {
        disableEditButton(false);
      }
    } else {
      disableAddButton(false);
    }
  };

  const data = getBodyData(records);
  return (
    <Table loading={loading} className={containerClassName}>
      <TableHead
        rowCount={records.length}
        headerData={columnDefinitions}
        onAllRowSelected={handleSelectAllClick}
        selectedRowCount={selectedRowCount}
        filters={appStore.inspectionSearchFilter.filter}
        sort={appStore.inspectionSearchFilter.sort}
      />
      <TableBody
        bodyData={data}
        onRowSelect={onRowSelect}
        headerData={columnDefinitions}
      />
    </Table>
  );
};

export default Grid;
