import { makeStyles } from "@material-ui/core/styles";

const drawerWidth = 214;

export const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    height: 48
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    height: 48
  },
  appBarShift: {
    width: "100%",
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    paddingLeft: 0,
    fontSize: 12,
    minHeight: "48px !important",
    height: 48,
    "& button": {
      padding: "16px 16px",
      marginLeft: "2px",
      marginRight: "2px",
      width: "44px",
      height: "44px"
    }

    // necessary for content to be below app bar
    // ...theme.mixins.toolbar
  },
  toolbarElements: {
    display: "flex",
    alignItems: "center"
  },
  menuButton: {},

  toolbarDrawerCollapsedText: {
    marginLeft: 0,
    minHeight: "48px !important"
  },

  notificationIcon: {},
  drawerPaper: {
    height: `calc(100vh - 48px)`,
    top: 48,
    background: "white",
    paddingTop: 8,
    zIndex: 0,
    position: "relative",
    whiteSpace: "nowrap",
    width: drawerWidth,
    overflowX: "hidden",
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  drawerPaperClose: {
    overflowX: "hidden",

    zIndex: 0,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    // width: theme.spacing(7),
    width: 48,
    [theme.breakpoints.up("sm")]: {
      // width: theme.spacing(9)
      width: 48
    }
  },
  collapsedList: {
    position: "absolute",
    active: {
      width: "47px",
      height: "48px"
    }
  },

  toolbarDrawer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
    fontSize: 12,
    backgroundColor: theme.palette.primary.main,
    color: "#ffffff",
    // necessary for content to be below app bar
    ...theme.mixins.toolbar
  },
  content: {
    flexGrow: 1,
    height: "100vh",
    overflow: "auto"
  },
  //appBarSpacer: theme.mixins.toolbar,
  appBarSpacer: {
    minHeight: 48
  },
  container: {
    paddingTop: theme.spacing(2),
    paddingLeft: "16px",
    paddingRight: "16px",
    paddingBottom: "16px"
  },
  alignRight: {
    marginLeft: "auto"
  },
  drawerList: {
    "& > *": {
      display: "flex",
      alignItems: "center",
      placeContent: "center",
      backgroundColor: "#e3e3e3c0"
    }
  },
  displayNone: {
    display: "none"
  },
  listItemText: {
    marginLeft: "1em"
  },
  containerMaxWidth: {
    maxWidth: "100%"
  },
  menuHorizontal: {
    display: "inline-block",
    width: 100,
    bottam: 0
  },
  boldText: {
    fontWeight: "bold",
    fontSize: 14
  },
  MuiTab: {
    minWidth: "unset !important",
    fontSize: 14,
    fontWeight: 600,
    backgroundColor: "#f5f5f5"
  },
  papers: {
    justifyContent: "space-between",
    padding: 10,
    display: "flex",
    boxShadow: "none"
  },
  tabheight: {
    height: "calc(100vh - 224px)",
    overflow: "auto"
  },
  menubottam: {
    position: "absolute",
    bottom: 30
  },
  sidebarbutton: {
    fontSize: 14
  },
  sidebarappmenu: {
    backgroundColor: "white",
    padding: "0px",
    height: 48,

    "& span": {
      fontSize: "14px",
      paddingLeft: 10,
      color: "#323130"
      // marginTop:"1px"
    }
  },
  defaultSidebarSelection: {
    backgroundColor: "#dcecf9",
    padding: "0",
    marginTop: "0",
    height: "48px",
    width: "100%",
    textAlign: "center",
    alignItems: "center",
    justifyContent: "left",
    "& span": {
      color: "#3a5faa",
      fontSize: 14,
      // marginTop: "1px",
      paddingLeft: 10,
      fontWeight: 600
    }
  },
  sidebarappmenuselect: {
    backgroundColor: "rgba(0 0 0 0.07)",
    padding: "0px",
    height: 48,
    "& span": {
      color: "#3a5faa",
      fontSize: 14,
      // marginTop: "1px",
      paddingLeft: 10,
      fontWeight: 600
    }
  },
  sidebarmenuicon: {
    fontSize: 20,
    fontWeight: 300
  },
  sidebarAppTextCollapsed: {
    justifyContent: "left",
    "& div": {
      // fontSize: 12
    },
    "& div:first-child": {
      fontSize: 12,
      fontWeight: 400,
      width: "28px",
      height: "28px",
      margin: "0 10px",
      // border:"1px solid #3a5faa",
      justifyContent: "center",
      alignItems: "center"
    },
    minWidth: "48px !important"
    // margin: "0 8px"
  },

  hamburgerClose: {
    marginLeft: 130
  }
}));
