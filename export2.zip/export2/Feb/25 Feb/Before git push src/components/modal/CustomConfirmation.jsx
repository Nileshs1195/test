import React from "react";
import Modal from "../../shared/components/ui/modal";
import { useStyles } from "./style";

const CustomConfirmation = (props) => {
    const { open, onClose, onSubmit, onEscape, widthClass, primary, secondary, title, message, noImmediateClose, disableApply } = props;
    const classes = useStyles();

    return (
        <div>
            <Modal
                open={open}
                onClose={() => onClose()}
                onSubmit={() => onSubmit()}
                widthClass={widthClass || classes.modalWidth}
                showControls
                id={props?.title ? title.replace(/ /g, "-") : Math.random().toString(16)}
                primaryButtonTextKey={primary}
                secondaryButtonTextKey={secondary}
                onEscape={onEscape}
                disableApply={disableApply}
                noImmediateClose={noImmediateClose}
            >
                <div className={classes.modalTextPadding}>
                    <h3 className={classes.modalTitle}>
                        {title}
                    </h3>
                    <div className={classes.confirmationModalPadding}>
                        {message}
                    </div>
                </div>
            </Modal>
        </div>
    );
};
export default CustomConfirmation;
