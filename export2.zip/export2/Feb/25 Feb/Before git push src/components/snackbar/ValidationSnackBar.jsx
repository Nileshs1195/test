import { IconButton, Snackbar } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useState } from "react";
import { useStyles } from "./style";
import { Alert } from "@material-ui/lab";

const ValidationSnackBar = props => {
  const classes = useStyles();
  const { t } = useTranslation();
  const {
    messages,
    timeout
  } = props;
  const [open, setOpen] = useState(true);

  useEffect(() => {
    handleClose();
    if (open) {
      setOpen(true);
      setTimeout(() => {
        handleClose();
      }, timeout || 10000)
    }
  }, [open])

  const handleClose = (event, reason) => {
    setOpen(false);
  };

  return (
    <>
      <Snackbar
        open={open}
        autoHideDuration={timeout || 10}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right"
        }}
        maxSnack={10}
        action={
          <IconButton
            key="close"
            aria-label="close"
            color="inherit"
            className={classes.close}
            onClick={handleClose}
          >
            <CloseIcon />
          </IconButton>
        }
      >
        <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>{messages?.length > 0 && messages?.map((msg, key) => {
          return <div className={classes.validationMessages} key={key}>
            {msg}
          </div>
        })}</Alert>
      </Snackbar>
    </>
  );
};

export default ValidationSnackBar;