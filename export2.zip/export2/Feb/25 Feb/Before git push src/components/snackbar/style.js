import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
  pageContent: {
    padding: theme.spacing(2, 2),
    width: "100%",
  },
  paper: {
    maxHeight: "35%",
  },
  top: {
    alignItems: "center",
    display: "flex",
    justifyContent: "space-between",
  },
  buttonWrapper: {
    display: "flex",
    alignItems: "center",
    "& > :not(:last-child)": {
      marginRight: theme.spacing(2),
    },
  },
  divider: {
    marginTop: theme.spacing(2),
  },
  footerContainer: {
    justifyContent: "space-between",
    backgroundColor: theme.palette.primary.main,
    display: "flex",
    paddingTop: 3,
    paddingBottom: 3,
    maxHeight: 55,
    padding: "0px 5px",
  },
  buttonGroup: {
    display: "flex",
    alignSelf: "center",
    "& > *": {
      margin: theme.spacing(0.75),
    },
  },
  buttons: {
    color: "#fff",
    borderColor: "white",
    "&:disabled": {
      color: "rgba(255, 255, 255, .35)",
      borderColor: "rgba(255, 255, 255, .35)",
    },
  },
  noOfDevicesWrapper: {
    color: "#fff",
    alignSelf: "center",
  },
  buttonMargin: {
    maxWidth: 35,
    minWidth: 35,
    maxHeight: 35,
    alignSelf: "center",
  },
  controlContainer: {
    display: "flex",
    alignItems: "center",
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
  checkboxIcon: {
    borderRadius: 5,
    width: 14,
    height: 14,
    boxShadow: "inset 0 0 0 1px #10161a, inset 0 -1px 0 #10161a",
    backgroundColor: "white",
  },
  controlGroup: {
    marginRight: theme.spacing(1),
  },
  datePicker: {
    width: theme.spacing(25),
  },
  //tableContainer: {
  //  maxHeight: "60vh",
  //  minHeight: "60vh"
  //},
  searchButton: {
    maxWidth: 35,
    minWidth: 35,
    maxHeight: 35,
  },
  paperList: {
    display: "flex",
    flexWrap: "wrap",
    listStyle: "none",
    padding: theme.spacing(0.5),
    margin: 0,
  },
  chipContainer: {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingBottom: theme.spacing(1),
    "& div ": {
      margin: theme.spacing(1, 1, 1, 0),
    },
  },
  tableContainer: {
    height: "calc(100vh - 237px)",
  },

  tableContainerFooter: {
    height: "calc(100vh - 286px)",
  },
  modalWidth: {
    minWidth: "25%",
    maxWidth: "25%",
    minHeight: "auto",
  },
  confirmationModalWidth: {
    minWidth: "370px",
    maxWidth: "25%",
    minHeight: "auto",
  },
  formControl: {
    minWidth: "100%",
  },
  fileUpload: {
    display: "none",
  },
  modalTextPadding: {
    paddingBottom: "16px",
  },
  confirmationModalPadding: {
    paddingTop: "10px",
  },
  helperText: {
    error: {
      "&.MuiFormHelperText-root.Mui-error": {
        color: theme.palette.common.red,
      },
    },
  },
  validationMessages: {
    marginTop: "5px",
    marginBottom: "5px"
  }
}));
