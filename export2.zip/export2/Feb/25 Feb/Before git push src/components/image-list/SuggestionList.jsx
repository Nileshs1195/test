import { observer } from "mobx-react-lite";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { useStyles } from "./SuggestionListStyles";
import { useCallback, useState, useRef, useContext, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Grid, Button, Accordion, AccordionSummary, AccordionDetails, FormControl, TextField, Checkbox, FormControlLabel, Switch } from "@material-ui/core";
import { Tooltip } from "@material-ui/core";
import ImageManagementStore from "../../stores/imagemanagementstore";
import Pagination from "../../shared/components/basictable/pagination";
import TrainingManagementStore from "../../stores/trainingmanagementstore";
import Loader from "../../shared/components/ui/loader";
import Carousel from "../carousel";
import { ErrorOutline } from "@material-ui/icons";
import { useParams } from "react-router-dom";
import { API_RESPONSE, API_URL } from "../../appconstants";
import ViewImage from "../view-image";
import CustomConfirmation from "../modal/CustomConfirmation";
import AppStore from "../../stores/appstore";
import { Autocomplete } from "@material-ui/lab";
import ThresholdSlider from "../threshold-slider";
import { SETTINGS } from "../../appsettings";
import { sort } from "../../helpers/arrayutils";
import { Droppable } from 'react-beautiful-dnd';
import useInfinityScroll from "../../helpers/hooks/useInfinityScroll";
import ProbabilityGraph from "../graphs/spline-range/ProbabilityGraph";
import EditClassName from "../add-class/EditClassName";

const SuggestionList = observer((props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const appStore = useContext(AppStore);
  const leftScrollRef = useRef();
  const rightScrollRef = useRef();
  const [isLeftScroll, setIsLeftScroll] = useState(false);
  const [isRightScroll, setIsRightScroll] = useState(false);
  const [editClassName, setEditClassName] = useState(false);
  const imageManagementStore = useContext(ImageManagementStore);
  const trainingManagementStore = useContext(TrainingManagementStore);
  const { key, selectAll, reload, seqNo, expand, trainingDetails, showAddImage, showDeleteImage, showEditClass, carouselView, url, imageSelection, showTransferedImagesOnly, overallThreshold, showEditClassName, trainingClasses, showOverallGraph, handleControls } = props;
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [fixedClassName, setFixedClassName] = useState("");
  const [leftImages, setLeftImages] = useState([]);
  const [rightImages, setRightImages] = useState([]);
  const [leftImageData, setLeftImageData] = useState([]);
  const [rightImageData, setRightImageData] = useState([]);
  const [images, setImages] = useState([]);
  const [totalImageCount, setTotalImageCount] = useState(0);
  const [confirmAction, setConfirmAction] = useState("");
  const [pageLeft, setPageLeft] = useState({
    startPage: 1,
    endPage: 3,
    imageCount: 15,
    pageNo: 1,
    nextPage: 2,
    previousPage: 0,
    pageSize: 5
  });
  const [pageRight, setPageRight] = useState({
    startPage: 1,
    endPage: 3,
    imageCount: 12,
    pageNo: 1,
    nextPage: 2,
    previousPage: 0,
    pageSize: 4
  });
  const [leftLoader, setLeftLoader] = useState(false);
  const [rightLoader, setRightLoader] = useState(false);
  const [classList, setClassList] = useState(trainingClasses);
  const [allClasses, setAllClasses] = useState([]);
  const [isImageviewLeft, setImageviewLeft] = useState(false);
  const [isImageviewRight, setImageviewRight] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const [expanded, setExpanded] = useState(expand);
  const [classDetails, setClassDetails] = useState({
    selected: true
  });
  const [showGraph, setShowGraph] = useState(showOverallGraph);
  const [selectedImages, setSelectedImages] = useState([]);
  const [selectedSeqNo, setSelectedSeqNo] = useState("");
  const [currentClassName, setCurrentClassName] = useState();
  const [probabilityTreshold, setProbabilityTreshold] = useState(0);
  const [selectPlots, setSelectPlots] = useState(true)
  const { updateDatasetImageCount, destinationClassSeqNo, setDestinationClassSeqNo, viewParameter, fetchSuggestionResultData } = trainingManagementStore;
  const { setsnapbarMessage } = appStore;
  const { getImagesForDataset, deleteImagesForDataset, imageUploadStatus, uploaderAction, setUploaderAction } = imageManagementStore;

  useEffect(() => {
    setExpanded(expand);
  }, [expand]);

  useEffect(() => {
    classDetails?.selected && setShowGraph(showOverallGraph);
  }, [showOverallGraph]);

  useEffect(() => {
    classDetails?.selected && handleTresholdChangeCommit(overallThreshold);
  }, [overallThreshold]);

  useEffect(() => {
    getImages();
  }, []);

  useEffect(() => {
    let classData = trainingClasses?.find(dataset => dataset?.seqNo === seqNo);
    setCurrentClassName(classData?.className);
    if (classData?.fixedClass !== "" && classData?.fixedClass !== null) {
      setFixedClassName(classData?.fixedClass)
    }
    setAllClasses(trainingClasses)
  }, [trainingClasses]);

  useEffect(() => {
    if (reload.length > 0) {
      reload.forEach((classSeqNo) => {
        classSeqNo === seqNo && getImages();
      })
      handleControls('reload')
    }
  }, [reload]);

  useEffect(() => {
    splitImages(probabilityTreshold);
  }, [images]);

  useEffect(() => {
    setClassDetails({
      ...classDetails, selected: selectAll ? true : false
    });
  }, [selectAll]);

  useEffect(() => {
    if (destinationClassSeqNo === classDetails.seqNo) {
      setDestinationClassSeqNo("");
      getImages();
    }
  }, [destinationClassSeqNo]);

  useEffect(() => {
    leftImages?.length >= 0 &&
      setLeftImageData([...getImagesFromList({ page: pageLeft, imagesList: leftImages, ref: leftScrollRef })]);
  }, [leftImages]);

  useEffect(() => {
    rightImages?.length >= 0 &&
      setRightImageData([...getImagesFromList({ page: pageRight, imagesList: rightImages, ref: rightScrollRef })]);
  }, [rightImages]);

  const getClassLists = () => {
    let allClasses = trainingClasses?.filter(dataset => dataset?.className !== classDetails?.className);
    setClassList(allClasses)
  };

  const handleTresholdChangeCommit = (tresholdValue) => {
    setProbabilityTreshold(tresholdValue);
    setRightLoader(true);
    setLeftLoader(true);
    splitImages(tresholdValue);
  };

  const onPaginationLeft = (obj) => {
    setPageLeft(obj);
    setLeftImageData(getImagesFromList({ page: obj, imagesList: leftImages, ref: leftScrollRef }));
    // splitImages(probabilityTreshold);
  }
  const onPaginationRight = (obj) => {
    setPageRight(obj);
    // splitImages(probabilityTreshold);
    setRightImageData(getImagesFromList({ page: obj, imagesList: rightImages, ref: rightScrollRef }));
  }

  const getImages = () => {
    let data = {
      // probability: probabilityTreshold,
      conditions: [
        {
          column: "modeOfChange",
          case: "lte",
          value: 2
        }
      ],
      // imageCase: "lt",
      desc: "probabilityValue"
    };
    if (showTransferedImagesOnly) {
      data = {
        ...data,
        conditions: [
          {
            column: "modeOfChange",
            case: "ne",
            value: 0
          }
        ],
        // imageCase: "gte",
        // desc: "probability"
      };
    }
    setLeftLoader(true);
    setLeftLoader(true);
    getImagesForDataset(API_URL.SUBCLASSIFICATION_RESULT_FIX, params.id, seqNo, data).then(result => {
      setRightImages([]);
      setLeftImages([]);
      setRightLoader(false);
      setLeftLoader(false);
      if (result?.status === API_RESPONSE.SUCCESS_STATUS_CODE && result?.data) {
        setTotalImageCount(result?.data?.count);
        let imageData = sort(result?.data?.images, "probabilityValue", false);
        setImages(imageData);
        setClassDetails({
          ...classDetails,
          seqNo: result?.data?.classSeqNo,
          className: result?.data?.className,
          modelName: result?.data?.modelName,
        });
      }
    }).catch(error => {
      setRightLoader(false);
      setLeftLoader(false);
      setLeftImages([]);
      setRightImages([]);
    });
  }

  const splitImages = async (threshold) => {
    let rightImageData = [];
    let leftImageData = [];
    if (images?.length > 0) {
      await images?.map((img) => {
        if (img?.probabilityValue) {
          if (img?.probabilityValue < threshold) {
            rightImageData.push(img);
          } else {
            leftImageData.push(img);
          }
        }
      });
    }
    setRightImages(rightImageData);
    setLeftImages(leftImageData);
    setRightLoader(false);
    setLeftLoader(false);
  }

  const handleViewImage = (index, type = 0) => {
    setActiveImage(index);
    if (type === 1) {
      setImageviewRight((isOpen) => !isOpen);
    } else {
      setImageviewLeft((isOpen) => !isOpen);
    }
  }

  const selectImages = (image) => {
    // image = { ...image, selected: !image?.selected };
    let selected = selectedImages;
    if (selected.some((item) => item.seqNo === image?.seqNo)) {
      selected.splice(
        selected.findIndex((item) => item.seqNo === image?.seqNo),
        1
      );
    } else {
      selected.push({ seqNo: image?.seqNo, imageMode: image?.imageMode, className: classDetails.seqNo });
    }
    setSelectedImages([...selected]);
    trainingManagementStore.setSubclassificationSelectedGraphImages([...selected]);
    handleControls?.('selectedImageData', [...selected]);
  }


  const deleteSelectedImages = () => {
    if (selectedImages?.length > 0 && classDetails?.seqNo) {
      const reqPayload = {
        img_seqNo: selectedImages.map((img) => img.seqNo)
      };
      setLeftLoader(true);
      setRightLoader(true);
      deleteImagesForDataset(params.id, classDetails.seqNo, reqPayload)
        .then((response) => {
          if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            setsnapbarMessage({
              message: t("pages.training.manageImages.messages.imageRecordDeleted")
            });
            getImages();
            setSelectedImages([]);
            updateDatasetImageCount(classDetails.seqNo, response?.data?.length);
            setLeftLoader(false);
            setRightLoader(false);
          } else {
            setsnapbarMessage({ message: t("pages.training.errors.delete-failed") });
          }
        })
        .catch((error) => {
          setLeftLoader(false);
          setRightLoader(false);
          setsnapbarMessage({ message: t("pages.training.errors.delete-failed") });
        });
    }
  }

  const onSelectImageClass = (event, value) => {
    if (value?.value) {
      setSelectedSeqNo(value?.value);
    }
  }

  const moveSelectedImages = async () => {
    let payload = {
      seqNos: selectedImages.map((img) => img.seqNo),
      src_seqNo: classDetails?.seqNo,
      dst_seqNo: selectedSeqNo,
    }
    setRightLoader(true);
    setLeftLoader(true);
    await trainingManagementStore.suggestionResultImageMove(params.id, payload).then((response) => {
      setRightLoader(false);
      setLeftLoader(false);
      if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setsnapbarMessage({
          message: t("pages.training.manageImages.messages.imageRecordUpdated")
        });
        setSelectedImages([]);
        setDestinationClassSeqNo(selectedSeqNo);
        getImages();
      } else {

      }
    });
  }
  // const moveSelectedImages1 = () => {
  //   // SUGGESTION_RESULT_IMAGE_MOVE
  //   if (classDetails?.seqNo && selectedSeqNo) {
  //     // let pageUrl = API_URL.GET_IMAGES_FOR_DATASET;
  //     let pageUrl = API_URL.SUGGESTION_RESULT_IMAGE_MOVE;
  //     let image_seqNos = selectedImages.map((img) => img.seqNo);
  //     // if (url === API_URL.CORRECTION_IMAGES) {
  //     //   pageUrl = API_URL.SUGGESTION_CLASS_UPDATE;
  //     // }
  //     setLeftLoader(true);
  //     setRightLoader(true);
  //     console.log(classDetails?.seqNo,{ seqNos: image_seqNos, src_seqNo: classDetails?.seqNo, dst_seqNo: selectedSeqNo, })
  //     imageManagementStore
  //       .saveEditImageClassDetails(pageUrl, params.id, classDetails?.seqNo, { seqNos: image_seqNos, src_seqNo: classDetails?.seqNo, dst_seqNo: selectedSeqNo, })
  //       .then((response) => {
  //         console.log(response)
  //         setLeftLoader(false);
  //         setRightLoader(false);
  //         if (response && response.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
  //           setsnapbarMessage({
  //             message: t("pages.training.manageImages.messages.imageRecordUpdated")
  //           });
  //           setSelectedImages([]);
  //           setDestinationClassSeqNo(selectedSeqNo);
  //           getImages();
  //         } else {
  //         }
  //       })
  //       .catch((error) => {
  //         setLeftLoader(false);
  //         setRightLoader(false);
  //       });
  //   }
  // }

  const updateClassName = (className) => {
    if (className === classDetails?.className) {
      return;
    }
    let data = {
      className: className,
      batchSeqNo: params.batchNo
    };
    trainingManagementStore.suggestionResultClassUpdate(params.id, seqNo, data).then((response) => {
      if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
        setClassDetails((prev) => ({
          ...prev,
          className: className
        }));
        let classData = classList?.map((item) => {
          if (item?.seqNo === seqNo) {
            item = { ...item, className };
          }
          return item;
        });
        setClassList(classData)
        setAllClasses(classData);
        setCurrentClassName(className);
        handleControls('updateClass', { seqNo: seqNo, className: classDetails?.className })
      }
    });
  }
  const { getImagesFromList, isScroll, setIsScroll } = useInfinityScroll({ scrolling: true });

  const scrollLeftFunc = () => {
    const { scrollLeft, scrollWidth, clientWidth } = leftScrollRef.current;
    if (isScroll) {
      if ((scrollLeft + clientWidth) >= (scrollWidth - 5) && (Math.ceil(leftImages.length / 5) > pageLeft?.endPage)) {
        setIsScroll(false);
        onPaginationLeft({
          "pageSize": 5,
          "type": 1,
          "imageCount": pageLeft?.imageCount,
          "startPage": pageLeft?.startPage + 1,
          "endPage": pageLeft?.endPage + 1,
        })
      } else if (scrollLeft === 0 && pageLeft?.startPage > 1) {
        setIsScroll(false);
        onPaginationLeft({
          "pageSize": 5,
          "type": 0,
          "imageCount": pageLeft?.imageCount,
          "startPage": pageLeft?.startPage - 1,
          "endPage": pageLeft?.endPage - 1
        })
      }
    }
  }

  const scrollRightFunc = () => {
    const { scrollLeft, scrollWidth, clientWidth } = rightScrollRef.current;
    if (isScroll) {
      if ((scrollLeft + clientWidth) >= (scrollWidth - 5) && (Math.ceil(rightImages.length / 4) > pageRight?.endPage)) {
        setIsScroll(false);
        onPaginationRight({
          "pageSize": 4,
          "type": 1,
          "imageCount": pageRight?.imageCount,
          "startPage": pageRight?.startPage + 1,
          "endPage": pageRight?.endPage + 1,
        })
      } else if (scrollLeft === 0 && pageRight?.startPage > 1) {
        setIsScroll(false);
        onPaginationRight({
          "pageSize": 4,
          "type": 0,
          "imageCount": pageRight?.imageCount,
          "startPage": pageRight?.startPage - 1,
          "endPage": pageRight?.endPage - 1
        })
      }
    }
  }

  const renderLeftImages = () => {
    return leftLoader ? (
      <div className={classes.loaderPosition} >
        <Loader size={24} />
      </div>
    ) : leftImageData.length > 0 ? (
      <Grid ref={leftScrollRef} onScroll={scrollLeftFunc} key={key} style={{ overflowX: "auto", display: "flex" }} spacing={2}>
        {reverseImages(leftImageData).map((image, key) => {
          return (
            <ViewImage
              isDragDropDisabled={false}
              selectedImages={selectedImages}
              selectImages={selectImages}
              imageKey={key}
              index={image.seqNo}
              imageData={{ ...image, className: classDetails?.className }}
              handleViewImage={(index, imageData) => handleViewImage(index, 0)}
              viewParameter={viewParameter}
              imageSelection={imageSelection}
              url={url}
            />
          )
        })}
      </Grid>
    ) : (
      !leftLoader && (
        <div className={classes.noContentMiddle}>
          <div className={classes.noContent}>
            <span>
              <ErrorOutline fontSize="large" className={classes.warningIcon} />
            </span>
            <span className={classes.noContentLabel}>{t("components.basic-table.no-content")}</span>
          </div>
        </div>
      )
    )
  }

  const renderRightImages = () => {
    return rightLoader ? (
      <div className={classes.loaderPosition}>
        <Loader size={24} />
      </div>
    ) : rightImageData?.length > 0 ? (
      <Grid key={key} ref={rightScrollRef} onScroll={scrollRightFunc} style={{ overflowX: "auto", display: "flex" }} spacing={2}>
        {reverseImages(rightImageData).map((image, key) => {
          return (
            <ViewImage
              isDragDropDisabled={false}
              selectedImages={selectedImages}
              selectImages={selectImages}
              imageKey={key}
              index={image.seqNo}
              imageData={{ ...image, className: classDetails?.className }}
              handleViewImage={(index, imageData) => handleViewImage(index, 1)}
              viewParameter={viewParameter}
              imageSelection={imageSelection} url={url}
            />
          )
        })}
      </Grid>
    ) : (
      !rightLoader && (
        <div className={classes.noContentMiddle}>
          <div className={classes.noContent}>
            <span>
              <ErrorOutline fontSize="large" className={classes.warningIcon} />
            </span>
            <span className={classes.noContentLabel}>{t("components.basic-table.no-content")}</span>
          </div>
        </div>
      )
    )
  }

  const handleShowGraphToggle = () => {
    setShowGraph((prevOpen) => !prevOpen);
  };

  const reverseImages = (imageContent) => {
    let allImages = imageContent;
    if (showTransferedImagesOnly) {
      return allImages.filter((img) => img.modeOfChange !== 0)
    } else {
      return imageContent;
    }
    // return imageContent; //!important: In order to avoid array reverse during production build this is required
  }

  const handleClick = (type) => {
    if (viewParameter) {
      return;
    }
    switch (type) {
      case 0: {
        setUploaderAction({
          isOpen: true,
          uploaderType: "add-images",
          className: classDetails?.className,
          id: params?.id
        });
        break;
      }
      case 1: {
        setConfirmAction("delete");
        break;
      }
      case 2: {
        getClassLists();
        setConfirmAction("move");
        break;
      }
      case 3: {
        setCurrentClassName(classDetails?.className);
        setEditClassName(true)
        break;
      }
    }
    // if (type === 0) {
    //   setUploaderAction({
    //     isOpen: true,
    //     uploaderType: "add-images",
    //     className: classDetails?.className,
    //     id: params?.id
    //   });
    // } else if (type === 1) {
    //   setConfirmAction("delete");
    // } else if (type === 2) {
    //   getClassLists();
    //   setConfirmAction("move");
    // } else if (type === 3) {
    //   setCurrentClassName(classDetails?.className);
    //   setConfirmAction("edit");
    // }
  };

  const handleOnClick = (event) => {
    setClassDetails({
      ...classDetails, selected: !classDetails.selected
    })
    event.stopPropagation();
  };

  const renderImages = () => {
    return (
      <Droppable direction={"horizontal"} droppableId={seqNo.toString()}>
        {(provided) => (
          <div {...provided.droppableProps} ref={provided.innerRef}>
            <Grid spacing={0} key={key} className={classes.imageList}>
              <Grid item xs={7} md={6} className={classes.left}>
                <div style={{ marginRight: "10px" }}>
                  {renderLeftImages()}
                </div>
              </Grid>
              <Grid item xs={5} md={6} className={classes.right}>
                <div style={{ marginLeft: "10px" }}>
                  {renderRightImages()}
                </div>
              </Grid>
            </Grid>
          </div>
        )}
      </Droppable>
    )
  }

  return (
    <>
      <Accordion
        key={key}
        expanded={!expanded}
        onChange={() => setExpanded(!expanded)}
        defaultExpanded={true}
        className={classes.accMarginTop}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          className={classes.accSummary}
        >
          {classDetails &&
            <div> <Tooltip title={currentClassName}>
              <Grid>

                <FormControlLabel
                  control={
                    <Checkbox
                      // className={classes.thumbCheckbox}
                      color="primary"
                      checked={classDetails.selected}
                      id={currentClassName}
                      name={currentClassName}
                      onClick={(event) => handleOnClick(event)}
                    />
                  }
                  onClick={(event) => {
                    handleOnClick(event);
                  }}
                  label={fixedClassName !== "" ? currentClassName + " " + t("pages.training.suggestion-result.modal.label.fixed-class", { className: fixedClassName }) : currentClassName}
                  className={classes.classCheckboxWrap}
                />

              </Grid></Tooltip></div>
          }
        </AccordionSummary>
        <AccordionDetails className={classes.accDetails}>
          <div className={classes.container}>
            <div className={classes.accordionTitle}>

              <div style={{ marginTop: "25px" }}>
                {images?.length > 0 && (
                  <label style={{ marginRight: "38.5%" }}>
                    {t("pages.training.training-parameter.grid.total-images")} : <b>{leftImages?.length}</b>
                  </label>
                )}
                {images?.length > 0 && (
                  <label style={{ marginRight: "10px" }}>
                    {t("pages.training.training-parameter.grid.total-images")} : <b>{rightImages?.length}</b>
                  </label>
                )}
              </div>
              {/* <Pagination
                onChange={onPaginationLeft}
                itemCount={totalImageCount}
                pageNo={pageLeft?.pageNo || 1}
                pageSize={pageLeft?.pageSize || 5}
                disableItemPerPage={true}
                disabled={false}
              /> */}
            </div>
            {/* <div className={classes.navR}>
              <Pagination
                onChange={onPaginationRight}
                itemCount={totalImageCount}
                pageNo={pageRight?.pageNo || 1}
                pageSize={pageRight?.pageSize || 4}
                disableItemPerPage={true}
                disabled={false}
              />
            </div> */}
            <div className={classes.thumbWrap}>
              {renderImages()}
              <Grid spacing={0} key={key} className={classes.imageList}>
                {showGraph && <ProbabilityGraph images={images} className={classDetails.className} setSelectedImages={setSelectedImages} selectedImages={selectedImages} />}
              </Grid>
            </div>
            <div className={classes.bottom}>
              <div className={classes.buttonWrapper}>
                {SETTINGS.subclass.ENABLE_INDIVIDUAL_THRESHOLD && <div style={{ marginLeft: "10px" }}><ThresholdSlider
                  onThresholdChange={handleTresholdChangeCommit}
                  disabled={false}
                  initialProbabilityTreshold={probabilityTreshold}
                  decimalPoints={4}
                /></div>}
                {SETTINGS.subclass.ENABLE_INDIVIDUAL_SHOW_GRAPH && <div style={{ marginTop: "10px" }}>
                  <FormControlLabel
                    control={<Switch checked={showGraph} onChange={handleShowGraphToggle} name="showGraph" color="primary" />}
                    label={t("pages.training.suggestion-result.controls.show-graph")}
                    labelPlacement="start"
                  />
                </div>}
                {showAddImage && <>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.bottomButtons}
                    onClick={() => handleClick(0)}
                    disabled={selectedImages?.length > 0 || viewParameter}
                  >
                    {t("pages.training.manageImages.controls.addImages")}
                  </Button>
                  &nbsp;&nbsp;
                </>
                }
                {showDeleteImage && <>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.bottomButtons}
                    onClick={() => handleClick(1)}
                    disabled={selectedImages?.length < 1 || viewParameter}
                  >
                    {t("pages.training.manageImages.controls.deleteImages")}
                  </Button>
                  &nbsp;&nbsp;
                  <CustomConfirmation
                    open={confirmAction === "delete"}
                    onClose={() => {
                      setConfirmAction("");
                    }}
                    onSubmit={deleteSelectedImages}
                    primary={"pages.training.manageImages.modal.delete-btn"}
                    secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                    title={t("pages.training.manageImages.modal.deleteRecordTitle")}
                    message={t("pages.training.manageImages.modal.deleteRecordMessage")}
                  />
                </>}

                {showEditClass && <>
                  <CustomConfirmation
                    open={confirmAction === "move"}
                    onClose={() => {
                      setConfirmAction("");
                    }}
                    onSubmit={moveSelectedImages}
                    primary={"pages.training.manageImages.modal.ok-btn"}
                    secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
                    title={t("pages.training.manageImages.modal.editImageClassTitle")}
                    message={<>
                      <FormControl className={classes.formControl}>
                        <Autocomplete
                          id="combo-box"
                          clearOnEscape
                          options={classList?.map(dataset => {
                            return { label: dataset.className, value: dataset.seqNo };
                          })}
                          getOptionLabel={(option) => option?.label}
                          onChange={(event, value) => onSelectImageClass(event, value)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Class Name"
                              id="className"
                              name="className"
                              margin="normal"
                              error={modalFormErrors["className"]}
                              helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
                            />
                          )}
                        />
                      </FormControl>
                    </>}
                  />
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.bottomButtons}
                    onClick={() => handleClick(2)}
                    disabled={selectedImages?.length < 1 || viewParameter}
                  >
                    {t("pages.training.manageImages.controls.editImageClass")}
                  </Button></>
                }
                {showEditClassName && <>
                  <EditClassName
                    open={editClassName}
                    dataset={allClasses}
                    currentClassName={currentClassName}
                    setEditClassName={setEditClassName}
                    updateClassName={updateClassName}
                  />
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.bottomButtons}
                    onClick={() => handleClick(3)}
                    disabled={selectedImages?.length > 0 || viewParameter}
                  >
                    {t("pages.training.manageImages.controls.editClass")}
                  </Button></>
                }
              </div>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      {carouselView && <>
        {isImageviewLeft && <Carousel
          open={isImageviewLeft}
          onClose={() => {
            setImageviewLeft((isOpen) => !isOpen);
            // reverseImages();
          }}
          active={activeImage}
          page={pageLeft}
          totalImageCount={leftImages?.length}
          setActiveImage={setActiveImage}
          sliderData={reverseImages(leftImages)}
        />}

        {isImageviewRight && <Carousel
          open={isImageviewRight}
          onClose={() => {
            setImageviewRight((isOpen) => !isOpen);
            // reverseImages();
          }}
          active={activeImage}
          page={pageRight}
          totalImageCount={rightImages?.length}
          setActiveImage={setActiveImage}
          sliderData={reverseImages(rightImages)}
        />}
      </>}
    </>
  );
});

export default SuggestionList;
