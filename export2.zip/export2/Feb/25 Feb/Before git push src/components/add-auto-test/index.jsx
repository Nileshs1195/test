import { Observer } from 'mobx-react-lite';
import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import GridMaterial from '@material-ui/core/Grid';
import { FormControl, InputLabel, MenuItem, Select, TextField } from '@material-ui/core';
import { useStyles } from '../../pages/autotestbatch/autotestinglist/style';
import { checkNotNullFromArray, objToArray } from '../../helpers/arrayutils';
import CustomConfirmation from '../modal/CustomConfirmation';
import { useValidation } from '../../helpers/validate';
import { Autocomplete } from '@material-ui/lab';

const AddAutoTest = (props) => {
  const { open, setOpen, trainingList } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  const form = useRef();
  const formData = {
    modelName: '',
    setupId: '',
    stepId: '',
    lotId: '',
    waferId: '',
    classFieldName: '',
    trainingModel: '',
    comment: '',
  }
  const [formError, setFormError] = useState({});
  const [closed, setClosed] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [validationErrors, setValidationErrors] = useState(formData);
  const [config, setConfig] = useState({
    fields: {
      modelName: {
        initialValue: '',
        isRegexMatch: {
          regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9-_]+(?: [a-zA-Z0-9-_]+)*$/,
          message: t('validation.message.alphanum', {
            field: t('validation.field.modelName'),
          }),
        },
        isRequired: {
          message: t('validation.message.required', {
            field: t('validation.field.modelName'),
          }),
        },
      },
      setupId: {
        initialValue: '',
        isRegexMatch: {
          regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9-_]+(?: [a-zA-Z0-9-_]+)*$/,
          message: t('validation.message.alphanum', {
            field: t('validation.field.setupid'),
          }),
        },
      },
      stepId: {
        initialValue: '',
        isRegexMatch: {
          regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9-_]+(?: [a-zA-Z0-9-_]+)*$/,
          message: t('validation.message.alphanum', {
            field: t('validation.field.stepid'),
          }),
        },
      },
      lotId: {
        initialValue: '',
        isRegexMatch: {
          regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9-_]+(?: [a-zA-Z0-9-_]+)*$/,
          message: t('validation.message.alphanum', {
            field: t('validation.field.lotid'),
          }),
        },
      },
      waferId: {
        initialValue: '',
        isRegexMatch: {
          regex: /^[0-9]+(?:-[0-9]+)?(,[0-9]+(?:-[0-9]+)?)*$/gm,
          message: 'wafer id numbers are invalid.',
        },
      },
      classFieldName: {
        initialValue: '',
      },
      trainingModel: {
        initialValue: '',
        isRequired: {
          message: t('validation.message.required', {
            field: t('validation.field.trainingModel'),
          }),
        },
      },
      comment: {
        initialValue: '',
        isRequired: {
          message: t('validation.message.required', {
            field: t('validation.field.modelName'),
          }),
        },
      },
    },
    onSubmit: (state) => {
      setSubmitted(state?.submitted)
      if (state?.errors) {
        setFormError({ ...state.errors })
      }
    },
    showErrors: 'blur',
    submitted: false,
  });
  const [formContent, setFormContent] = useState({
    modelName: '',
    comment: '',
    lotId: '',
    setupId: '',
    stepId: '',
    classFieldName: '',
    trainingModel: '',
  });
  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  useEffect(() => {
    //Sets values after change
    setFormContent({ ...formContent, ...values })
  }, [values])

  useEffect(() => {
    //This is required to validate and show error message
    errors && !submitted && !closed && setFormError(errors)
    setClosed(false)
    submitted && setSubmitted(false)
  }, [errors])

  useEffect(() => {
    //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(
      new Event('submit', { bubbles: true, cancelable: true }),
    )
  }, [form?.current])

  const classFieldsOptions = [
    {
      id: 1,
      label: 'Fine Bin Number',
    },
    {
      id: 2,
      label: 'Rough Bin Number',
    },
    {
      id: 3,
      label: 'Class Number',
    },
  ]

  const onClose = () => {
    setOpen(false);
  }

  const createClass = () => {
    form.current.dispatchEvent(
      new Event('submit', { bubbles: true, cancelable: true }),
    );
    let formArray = objToArray(formError);
    let notNull = checkNotNullFromArray(formArray);
    let payload = JSON.parse(JSON.stringify(formContent));
    // payload.modelName = payload.modelName.replace(/  +/g, ' ').trim()
    setValidationErrors(formData);
    if (formArray?.length <= 0 || !notNull) {
      // setOpen(false)
    }
  }
  const renderMenuItems = (menuList) => {
    return menuList.map((item, index) => (
      <MenuItem key={index} value={item.label}>
        {item.label}
      </MenuItem>
    ))
  }
  return (
    <Observer>
      {() => (
        <CustomConfirmation
          open={open}
          onSubmit={createClass}
          onClose={onClose}
          noImmediateClose={true}
          primary={'pages.training.input-parameter.controls.ok'}
          secondary={
            'pages.training.input-parameter.grid.cutomization.modal.cancel-btn'
          }
          title={t('pages.auto-test.auto-testing-list.modal.new-auto-testing')}
          message={
            <>
              <form
                action="javascript:;"
                ref={form}
                autoComplete="off"
                {...getFormProps()}
              >
                <GridMaterial container spacing={2} className={classes.mT1}>
                  <GridMaterial item xs={6}>
                    <TextField
                      fullWidth
                      id="modelName"
                      name="modelName"
                      label={'Model Name'}
                      margin="normal"
                      value={formContent?.modelName}
                      {...getFieldProps('modelName')}
                      error={formError.modelName}
                      helperText={formError.modelName}
                    />
                  </GridMaterial>
                  <GridMaterial item xs={6}>
                    <TextField
                      fullWidth
                      id="setupId"
                      name="setupId"
                      label={'Setup ID'}
                      margin="normal"
                      value={formContent?.setupId}
                      {...getFieldProps('setupId')}
                      error={formError.setupId}
                      helperText={formError.setupId}
                    />
                  </GridMaterial>
                  <GridMaterial item xs={6}>
                    <TextField
                      fullWidth
                      id="stepId"
                      name="stepId"
                      label={'Step ID'}
                      margin="normal"
                      value={formContent?.stepId}
                      {...getFieldProps('stepId')}
                      error={formError.stepId}
                      helperText={formError.stepId}
                    />
                  </GridMaterial>
                  <GridMaterial item xs={6}>
                    <TextField
                      fullWidth
                      id="lotId"
                      name="lotId"
                      label={'Lot ID'}
                      margin="normal"
                      value={formContent?.lotId}
                      {...getFieldProps('lotId')}
                      error={formError.lotId}
                      helperText={formError.lotId}
                    />
                  </GridMaterial>
                  <GridMaterial item xs={6}>
                    <TextField
                      fullWidth
                      id="waferId"
                      name="waferId"
                      label={'Wafer ID/Slot'}
                      margin="normal"
                      value={formContent?.waferId}
                      {...getFieldProps('waferId')}
                      error={formError.waferId}
                      helperText={formError.waferId}
                    />
                  </GridMaterial>
                  <GridMaterial item xs={6}>
                    <FormControl
                      className={classes.mT4}
                      margin="normal"
                      error={formError.classFieldName}
                    >
                      <InputLabel id="pastExecutionLabel">
                        {t(
                          'pages.training.training-parameter.dataset-mode.modal.past-execution-label',
                        )}
                      </InputLabel>
                      <Select
                        labelId="classFieldName"
                        id="classFieldName"
                        value={formContent?.classFieldName}
                        {...getFieldProps('classFieldName')}
                        name="classFieldName"
                        renderValue={(value) => value}
                      >
                        {renderMenuItems(classFieldsOptions)}
                      </Select>
                    </FormControl>
                  </GridMaterial>
                  <GridMaterial item xs={12}>
                    <FormControl className={classes.mT4}>
                      <Autocomplete
                        id="combo-box"
                        disableClearable
                        value={
                          classFieldsOptions?.length > 0 &&
                          classFieldsOptions.filter(
                            (res) => res.label === formContent?.trainingModel,
                          )?.[0]
                        }
                        options={classFieldsOptions}
                        getOptionLabel={(option) => option.label}
                        {...getFieldProps('trainingModel')}
                        // onChange={(event, value) => onSelectTestModel(event, value)}
                        renderInput={(params) => (
                          <TextField
                            fullWidth
                            {...params}
                            label="Select Model"
                            id="selectModel"
                            name="selectModel"
                            margin="normal"
                            {...getFieldProps('trainingModel')}
                            {...params}
                            label={'Training Model'}
                          />
                        )}
                      />
                    </FormControl>
                  </GridMaterial>
                </GridMaterial>
              </form>
            </>
          }
        />
      )}
    </Observer>
  )
}
export default AddAutoTest
