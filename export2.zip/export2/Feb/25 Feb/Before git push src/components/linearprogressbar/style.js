import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles(({
    root: {
        width: "100%"
    },
    bar: {
        "&.MuiLinearProgress-root": {
            height: "8px",
            borderRadius: "4px"
        }
    },
    executionDuration: {
        textAlign: "center",
    },
    textExecutionError: {
        textAlign: "center",
        fontSize: "18px",
        marginTop: "20vh"
    },
    statusInfo: {
        textAlign: "right"
    },
    statusGreen: {
        textTransform: "capitalize",
        color: "green"
    },
    statusRed: {
        textTransform: "capitalize",
        color: "red"
    },
    statusGrey: {
        textTransform: "capitalize",
        color: "grey"
    },
    statusYellow: {
        textTransform: "capitalize",
        color: "yellow"
    },
    statusBlue: {
        textTransform: "capitalize",
        color: "blue"
    }
}));