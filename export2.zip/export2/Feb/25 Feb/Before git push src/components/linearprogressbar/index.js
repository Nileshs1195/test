import React, { useState, useEffect, useContext } from "react";
import LinearProgress from "@material-ui/core/LinearProgress";
import Typography from "@material-ui/core/Typography";
import { useParams } from "react-router-dom";
import Box from "@material-ui/core/Box";
import { useStyles } from "./style";
import IO from "socket.io-client";
import { SETTINGS } from "../../appsettings";
import { useTranslation } from "react-i18next";
import AppStore from "../../stores/appstore";
import { ErrorOutlineOutlined } from "@material-ui/icons";
import { Loader } from "../../shared/components/ui";
import { secondsToHms } from "../../helpers/CommonMethods";
import { CircularProgress } from "@material-ui/core";
const socket = IO(SETTINGS.SOCKET_URL, {
  withCredentials: true,
  upgrade: true,
  // transports:["socket"]
});

const getStatusAndColor = (resultSet) => {
  let resultStatus = "processing", color = "Grey";
  if (resultSet?.status === 1) {
    resultStatus = "waiting";
  } else if (resultSet?.status === 2) {
    resultStatus = "running";
    color = "Blue";
  } else if (resultSet?.status === 3 || resultSet?.status === 4) {
    resultStatus = "cancelling";
  } else if (resultSet?.status === 5) {
    resultStatus = "cancelled";
    color = "Red";
  } else if (resultSet?.status === 7) {
    resultStatus = "success";
    color = "Green";
  } else if (resultSet?.status === 8) {
    resultStatus = "failed";
    color = "Red";
  }

  return {
    resultStatus,
    color
  }
}

const LinearProgressWithLabel = props => {
  const classes = useStyles();
  const { t } = useTranslation();
  const { resultSet } = props;
  const [status, setStatus] = useState("processing");
  const [statusColor, setStatusColor] = useState("Grey");

  useEffect(() => {
    if (SETTINGS?.execution?.SHOW_STATUS) {
      let result = getStatusAndColor(resultSet);
      setStatus(result?.resultStatus);
      setStatusColor(result?.color);
    }
  }, [resultSet]);

  return (
    <div>
      <Box display="flex">
        <Box width="50%">
          <Typography variant="body2">{`${t(
            "pages.training.training-parameter.dataset-mode.auto-param-search.progress"
          )}: ${Math.round(props?.value)}%`}</Typography>
        </Box>
        <Box width="30%">
          {
            props.executionType === "trainingExecution" &&
            <Typography variant="body2">
              {`${t(
                "pages.training.training-parameter.dataset-mode.auto-param-search.passed-time"
              )}:
              ${props?.passedTime?.hours +
                ":" +
                props?.passedTime?.minutes +
                ":" +
                props?.passedTime?.seconds}`}
            </Typography>
          }
        </Box>

        {SETTINGS?.execution?.SHOW_STATUS && <Box width="20%" className={classes.statusInfo}>
          <Typography variant="body2">
            {t("pages.execution.execution-status")}: &nbsp;
            <b className={classes["status" + statusColor]}>
              {t("pages.execution.execution-" + status)}
            </b>
            &nbsp;{resultSet?.status < 5 && <CircularProgress disableShrink size={12} />}
          </Typography>
        </Box>}
      </Box>
      <Box display="flex" alignItems="center" mt={1}>
        <Box width="100%">
          <LinearProgress
            className={classes.bar}
            variant="determinate"
            color={resultSet?.status !== 8 && resultSet?.status !== 5 ? "primary" : "secondary"}
            value={props.value}
            {...props}
          />
        </Box>
      </Box>
    </div>
  );
};


const LinearIndeterminateWithLabel = props => {
  const classes = useStyles();
  const { t } = useTranslation();
  const { resultSet } = props;
  const [status, setStatus] = useState("processing");
  const [statusColor, setStatusColor] = useState("Grey");

  useEffect(() => {
    if (SETTINGS?.execution?.SHOW_STATUS) {
      let result = getStatusAndColor(resultSet);
      setStatus(result?.resultStatus);
      setStatusColor(result?.color);
    }
  }, [resultSet]);

  return (
    <>
      <Box display="flex">
        <Box width="30%">
          {
            props?.executionType !== "parameterSearch" &&
            <Typography variant="body2">{`${t(
              "pages.training.training-parameter.dataset-mode.auto-param-search.progress"
            )}: ${Math.round(props?.value)}%`}</Typography>
          }
        </Box>
        <Box width="40%">
          {
            (props?.executionType === "parameterSearch" || props?.executionType === "trainingExecution") &&
            <Typography className={classes.executionDuration} variant="body2">
              {`${t(
                "pages.training.training-parameter.dataset-mode.auto-param-search.passed-time"
              )}:
                ${props?.passedTime?.hours +
                ":" +
                props?.passedTime?.minutes +
                ":" +
                props?.passedTime?.seconds}`}
            </Typography>
          }
        </Box>
        {SETTINGS?.execution?.SHOW_STATUS && <Box width="30%" className={classes.statusInfo}>
          <Typography variant="body2">
            {t("pages.execution.execution-status")}: &nbsp;
            <b className={classes["status" + statusColor]}>
              {t("pages.execution.execution-" + status)}
            </b>
            &nbsp;{resultSet?.status < 5 && <CircularProgress disableShrink size={12} />}
          </Typography>
        </Box>}
      </Box>

      <Box display="flex" alignItems="center" mt={1}>
        <Box width="100%">
          <LinearProgress
            className={classes.bar}
            color={resultSet?.status !== 8 && resultSet?.status !== 5 ? "primary" : "secondary"}
            variant={props.value > 99 ? "determinate" : "indeterminate"}
            {...props}
          />
        </Box>
      </Box>
    </>
  );
};

const LinearProgressBar = props => {
  const {
    setResultSet,
    displayData,
    method,
    stopExecution,
    executionType,
    loadingAction,
    batchData,
  } = props;
  const params = useParams();
  const { t } = useTranslation();
  const classes = useStyles();
  const appStore = useContext(AppStore);
  const { setsnapbarMessage } = appStore;
  const [progressPercentage, setProgressPercentage] = useState(batchData?.progress || 0);
  const [elapsedTime, setElapsedTime] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0,
    milliseconds: 0
  });
  const [loader, setLoader] = useState(false);
  const [resultSet, setResultData] = useState();
  const [executionFailed, setExecutionFailed] = useState(false);

  useEffect(() => {
    setProgressPercentage(batchData?.progress);
  }, [batchData]);

  useEffect(() => {
    if (!socket.connected) {
      socket.connect();
    }
    runExecutionLog(params.id, progressPercentage);
    setTimeout(() => {
      if (!resultSet || resultSet?.status === 0) {
        setExecutionFailed(true);
        if (progressPercentage === 100) {
          setExecutionFailed(false);
        }
      }
    }, SETTINGS.EXECUTION_TIMEOUT || 1000 * 60);
  }, []);

  useEffect(() => {
    if (stopExecution && socket.connected) {
      socket.disconnect();
    }
  }, [stopExecution]);

  const runExecutionLog = (id, pgr) => {
    setLoader(false);
    socket.emit(method, { id, seqNo: params.seqNo, pgr }, result => {
      setLoader(false);
      if (result?.seqNo == params.seqNo) {
        renderData({ ...result }, pgr);
        if (result?.status === 5) {
          setsnapbarMessage({
            message: t("pages.training.errors.training-list.execution-cancelled", {
              type: t("pages.training.errors.training-list.training")
            })
          });
          setExecutionFailed(true);
          setLoader(false);
          socket.disconnect();
        } else if (result?.status === 8) {
          setsnapbarMessage({
            message: t("pages.training.errors.training-list.execution-failed")
          });
          setExecutionFailed(true);
          setLoader(false);
          socket.disconnect();
        } else if (result?.status === 7) {
          // setsnapbarMessage({
          //   message: t("pages.training.errors.training-list.execution-failed")
          // });
          setExecutionFailed(true);
          setLoader(false);
          socket.disconnect();
        } else if (result?.status < 5 && result?.baseMode === 0) {
          if (result?.status !== 7) {
            setsnapbarMessage({
              message: t("pages.training.errors.training-list.execution-failed")
            });
            setExecutionFailed(true);
          }
          setLoader(false);
          socket.disconnect();
        } else if (result?.baseMode > 0 && (result?.status < 5 || result?.status === 6)) {
          setTimeout(() => {
            setLoader(true);
          }, 5000);
          runExecutionLog(id, result.progress);
        } else {
          setLoader(false);
          socket.disconnect();
        }
      } else {
        setLoader(false);
        socket.disconnect();
      }
    });
  };

  const renderData = (data, previousPercentage) => {
    let time = msToTime(data?.elapsedTime);
    data.time = time;
    setProgressPercentage(data.progress);
    setResultSet(data);
    setResultData(data);
    setLoader(false);
    if (data.progress === 100 || (data.progress > previousPercentage && executionType === "trainingExecution")) {
      data?.mode > 0 && displayData();
    }
  };

  const msToTime = duration => {
    let time = secondsToHms(duration);
    setElapsedTime(time);
    return time;
  };

  return (
    <div className={classes.root}>
      {/* {
        progressPercentage >= 100 && (resultSet?.status === 3 || resultSet?.status === 4 || resultSet?.status === 6) && <Loader size={24} />
      } */}
      {
        <>
          {!loadingAction && progressPercentage > 0 ?
            <>
              {
                progressPercentage < 100 && loader && <Loader size={24} />
              }
              <LinearProgressWithLabel
                value={progressPercentage}
                passedTime={elapsedTime}
                resultSet={resultSet}
                executionType={executionType}
              /></> :
            <LinearIndeterminateWithLabel
              value={progressPercentage}
              passedTime={elapsedTime}
              resultSet={resultSet}
              executionType={executionType}
            />
          }
        </>
      }
      {resultSet?.baseMode === 0 && resultSet?.status !== 7 && <div className={classes.textExecutionError}>
        <ErrorOutlineOutlined style={{ fontSize: "24px" }} />
        <br />
        {resultSet?.status === 5 ? t("pages.training.errors.training-list.execution-cancelled", {
          type: t("pages.training.errors.training-list.training")
        }) : t("pages.training.errors.training-list.execution-failed-title")}
      </div>}
    </div>
  );
};
export default LinearProgressBar;
