import { Observer } from "mobx-react-lite";
import { useStyles } from "./style";
import { useState } from "react";
import GridMaterial from "@material-ui/core/Grid";
import { FormControl, TextField } from "@material-ui/core";
import { useTranslation } from "react-i18next";
import Loader from "../../shared/components/ui/loader";
import { useParams } from "react-router-dom";
import CustomConfirmation from "../modal/CustomConfirmation";
import * as CommonMethod from "./commonMethods";
import { validateModalForm } from "../../helpers/CommonMethods";

const AddNewClass = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const params = useParams();
  const { open, dataset, setAddClass, handleCreateClass } = props;
  const [loader, setLoader] = useState(false);
  const [modalFormErrors, setModalFormErrors] = useState({});
  const [className, setClassName] = useState("");
  const [submitDisabled, setSubmitDisabled] = useState(true);

  const createClass = () => {
    let errorMessage = t("pages.training.training-list.modal.error-text");
    let isValid = validateModalForm(
      {
        className
      },
      modalFormErrors,
      errorMessage,
      handleModalFormErrors
    );
    if (isValid) {
      setLoader(true);
      handleCreateClass(params.id, className);
      setLoader(false);
      setAddClass(false);
      setClassName("");
    } else {
      setTimeout(() => setAddClass(true), 0);
    }
  };

  const handleClassData = (value) => {
    setSubmitDisabled(value === "");
    setClassName(value);
  };
  const onClose = () => {
    setClassName("");
    setAddClass(false);
    setModalFormErrors({});
  }

  const checkClassName = (name) => {
    let exist = false;
    if (dataset?.length > 0) {
      const classListData = dataset.map((item) => {
        const container = {};
        container["name"] = item.className;
        return container;
      });
      const result = classListData.some((item) => item?.name?.toLowerCase() === name.toLowerCase());
      exist = result;
    }
    return exist;
  };

  const handleModalFormErrors = (errorData) => {
    setModalFormErrors(Object.assign({}, modalFormErrors, errorData));
    setSubmitDisabled(errorData["className"]);
  };

  const onChangeFieldData = (event) => {
    event.target.value =  event.target.value.replace(/\s\s+/g, ' ');
    let errMsg = [];
    errMsg["errExist"] = t("pages.training.input-parameter.modal.already-exist");
    errMsg["errAlphanumeric"] = t("pages.training.input-parameter.modal.alphanumeric");
    CommonMethod.onChangeDataSetting(event, handleClassData, handleModalFormErrors, checkClassName, errMsg);
  };

  return (
    <Observer>
      {() => (
        <>
          {loader && <Loader size={24} />}
          <CustomConfirmation
            open={open}
            onClose= {onClose}
            onSubmit={createClass}
            disableSubmit={submitDisabled}
            noImmediateClose={true}
            primary={"pages.training.input-parameter.controls.ok"}
            secondary={"pages.training.input-parameter.grid.cutomization.modal.cancel-btn"}
            title={t("pages.training.suggestion-result.modal.add-class")}
            message={
              <>
                <GridMaterial container spacing={2} className={classes.mT1}>
                  <GridMaterial item xs={12}>
                    <FormControl className={classes.formControl} margin="none">
                      <TextField
                        fullWidth
                        id="className"
                        name="className"
                        label={t("pages.training.input-parameter.grid.class-name")}
                        value={className} autoFocus
                        onChange={onChangeFieldData}
                        error={modalFormErrors["className"]}
                        helperText={modalFormErrors["classNameErrorMsg"] !== "" && modalFormErrors["classNameErrorMsg"]}
                      />
                    </FormControl>
                  </GridMaterial>
                </GridMaterial>
              </>
            }
          />
        </>
      )}
    </Observer>
  );
};

export default AddNewClass;
