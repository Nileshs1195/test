import React, { useEffect, useState } from "react";
import Modal from "../../shared/components/ui/modal";
import { useTranslation } from "react-i18next";
import CompareImageSlide from "./compareImageSlide";
import useInfinityScroll from "../../helpers/hooks/useInfinityScroll";

const CompareImageCarousel = (props) => {
  const {
    open,
    onClose,
    sliderData,
    active,
    setActiveImage,
    totalImageCount,
    page,
    imageData,
    maskData,
    className,
    maskingConfirmation,
    heatMapImages
  } = props;
  const { t } = useTranslation();
  const [currentIndex, setCurrentIndex] = useState(() => active);
  const [currentData, setCurrentData] = useState([]);
  const [currentPage, setCurrentPage] = useState(page);

  const  { getImagesFromList } = useInfinityScroll({ scrolling: false });

  useEffect(()=>{
    setCurrentPage(page);
    setCurrentData([...getImagesFromList({ page: page, imagesList: sliderData })])
  },[sliderData,page,open])

  useEffect(() => {
    setCurrentIndex(active);  
    if(active === page?.imageCount - 1 && active !== totalImageCount) {
      updateImages(
        Object.assign(
          JSON.parse(JSON.stringify(page)), 
          {
            startPage: page?.startPage + 1,
            endPage: page?.endPage + 1,
          }
        ),
        active - page?.pageSize,
      );
    } else if (active === 0) {
      previous();
    }
  }, [active]);

  useEffect(() => {
    window.addEventListener("keyup", onKeyup);
  }, []);

  const onKeyup = (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      previous();
    } else if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      next();
    }
  };
  
  const updateImages = (pageObj, activeIndex) => {
    setCurrentPage(pageObj);
    setActiveImage(activeIndex);
    setCurrentData([...getImagesFromList({ page: pageObj, imagesList: sliderData })])
  }
  const next = () => {
    let nextIndex = active + 1 <= sliderData?.length ? active + 1 : active;
    if(nextIndex > (page?.imageCount - 3) && Math.ceil(totalImageCount / page?.pageSize) >  currentPage?.endPage) {
      let pageObj = {
        pageSize: currentPage?.pageSize,
        imageCount: currentPage?.imageCount,
        type: 1,
        startPage: currentPage?.startPage + 1,
        endPage: currentPage?.endPage + 1,
      }
      updateImages(pageObj, nextIndex - page?.pageSize);  
    } else {
      setActiveImage(nextIndex);
    }
  };

  const previous = () => {
    let prevIndex = active - 1 >= 0 ? active - 1 : 0;
    if(prevIndex < 3 && currentPage?.startPage > 1) {
      let pageObj = {
        pageSize: currentPage?.pageSize,
        imageCount: currentPage?.imageCount,
        type: 0,
        startPage: currentPage?.startPage - 1,
        endPage: currentPage?.endPage - 1,
      }
      updateImages(pageObj, prevIndex + page?.pageSize)
    } else {
      setActiveImage(prevIndex);
    }
  };

  return (
    <Modal open={open} onClose={onClose}>
      <CompareImageSlide
        index={currentIndex + 1}
        totalImages={sliderData.length}
        page={currentPage}
        totalImageCount={totalImageCount}
        previous={previous}
        next={next}
        imageData={imageData}
        maskData={maskData}
        className={className}
        maskingConfirmation={maskingConfirmation}
        heatMapImages={heatMapImages}
      />
    </Modal>
  );
};
export default CompareImageCarousel;
