import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from '@material-ui/core';
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TrainingManagementStore from '../../stores/trainingmanagementstore';
import { API_RESPONSE } from "../../appconstants";
import { checkNotNullFromArray, objToArray } from "../../helpers/arrayutils";

const EditDataset = (props) => {
  const { t } = useTranslation();
  const form = useRef();
  const { open, setOpen, callBack, trainingId, dataset, setSnapbar } = props;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [formError, setFormError] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [config, setConfig] = useState({
    fields: {
      className: {
        initialValue: dataset?.className || "",
        isRequired: { message: t("validation.message.required", { field: t("validation.field.className") }) },
        isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum", { field: t("validation.field.className") }) }
      },
      defectSize: {
        initialValue: dataset?.defectSize ? dataset?.defectSize?.toString() : "512",
        isRequired: { message: t("validation.message.required", { field: t("validation.field.defectSize") }) },
        isRegexMatch: { regex: /^[0-9]+$/, message: t("validation.message.numeric", { field: t("validation.field.defectSize") }) } //Always use string 
      }
    },
    onSubmit: state => {
      setSubmitted(state?.submitted);
      if (state?.errors) {
        setFormError({ ...state.errors });
      }
    },
    showErrors: 'blur',
    submitted: false
  });
  const [formContent, setFormContent] = useState({
    className: dataset?.className || "",
    defectSize: dataset?.defectSize || ""
  });
  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  useEffect(() => { //Sets values after change
    setFormContent({ ...formContent, ...values });
  }, [values]);

  useEffect(() => {//This is required to validate and show error message
    errors && !submitted && setFormError(errors);
    submitted && setSubmitted(false);
  }, [errors])

  useEffect(() => { //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
  }, [form?.current])

  const handleDuplicateEntry = (data) => {
    let s = JSON.parse(JSON.stringify(trainingManagementStore.TrainingDataset));
    let find = trainingManagementStore.TrainingDataset.filter(e => e.className.toLowerCase() === data.className.toLowerCase());
    return !find.length;
  }

  const updateTrainingPercentage = (e) => {
    form.current.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    let formArray = objToArray(formError);
    let notNull = checkNotNullFromArray(formArray);
    // let isNotDuplicate = handleDuplicateEntry(formContent);
    if ((formArray?.length <= 0 || !notNull) && trainingId) {
      const reqPayload = {
        seqNos: dataset.seqNo,
        className: formContent.className,
        defectSize: formContent.defectSize
      };
      //Validation passed
      trainingManagementStore
        .editDatasetAPI(trainingId, reqPayload)
        .then((response) => {
          if (response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            if (response.data.exists) {
              setSnapbar({
                message: t("pages.training.errors.dataset.record-exists")
              });
            } else {
              setSnapbar({ message: t("pages.training.success.dataset.updated") });
              trainingManagementStore.clearSelectedTrainingDataset();
              setOpen(false);
              if (callBack) {
                callBack();
              }
            }
          } else {
            setSnapbar({ message: t("pages.training.errors.dataset.update-failed") });
          }
        })
        .catch((error) => {
          console.log("error", error);
          setSnapbar({ message: t("pages.training.errors.dataset.update-failed") });
        });
    } else {
      setSnapbar({ message: t("pages.training.errors.dataset.record-exists") });
    }
    setTimeout(() => {
      setSnapbar({ message: "" });
    }, 2000);
  };

  return (
    <Observer>
      {() => (
        <>
          <CustomConfirmation
            open={open}
            onClose={() => setOpen(false)}
            noImmediateClose={true}
            onSubmit={updateTrainingPercentage}
            primary={'pages.training.training-parameter.dataset-mode.controls.save'}
            secondary={'pages.training.training-parameter.dataset-mode.controls.cancel'}
            title={t("pages.training.training-parameter.dataset-mode.modal.edit")}
            message={<>
              <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                <TextField
                  fullWidth
                  aria-valuetext={formContent?.className}
                  id="className"
                  name="className"
                  margin="normal"
                  label={t("pages.training.training-parameter.dataset-mode.modal.className")}
                  value={formContent?.className} autoFocus
                  {...getFieldProps('className')}
                  error={formError.className}
                  helperText={formError.className}
                />
                <TextField
                  fullWidth
                  aria-valuetext={formContent?.defectSize}
                  id="defectSize"
                  name="defectSize"
                  margin="normal"
                  label={t("pages.training.training-parameter.dataset-mode.modal.defectSize")}
                  value={formContent?.defectSize}
                  {...getFieldProps('defectSize')}
                  error={formError.defectSize}
                  helperText={formError.defectSize}
                />
              </form>
            </>} />
        </>
      )}
    </Observer >
  );
};
export default EditDataset;
