import React, { useState, useEffect } from 'react';
import { useStyles } from './style';
import clsx from 'clsx';
import { ChevronLeft, ChevronRight, Close } from '@material-ui/icons';
import { IconButton, Typography } from '@material-ui/core';
import { SETTINGS } from '../../appsettings';
import LightTooltip from '../../shared/components/ui/tooltip';
import MaskingImage, { convertPixelToPercentage } from '../masking';
import CustomConfirmation from '../modal/CustomConfirmation';
import { useTranslation } from 'react-i18next';
import * as CommonMethods from '../../helpers/CommonMethods'

const Slide = (props) => {
  const { key, slideData, offset, seqNos, index, activeImage, maskingFunc, totalImages, onClose, previous, next, page, totalImageCount } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  const active = offset === 0 ? true : false;
  const [currentMasking, setCurrentMasking] = useState([]);
  const [lastMask, setLastMask] = useState({});
  const [confirmAction, setConfirmAction] = useState(false);
  const titleLimit = 20;
  const imageFullViewURL = SETTINGS.IMAGE_FULL_URL;
  const activateClass = active
    ? clsx(classes.slide, classes.slideActive)
    : clsx(classes.slide, classes.slideInActive);

  const returnFormat = {
    x: 'xmin',
    height: 'ymax',
    y: 'ymin',
    width: 'xmax',
    showSaveButton: false,
    showAreaCount: false,
  }

  useEffect(() => {
    if(maskingFunc) {
      handleCurrentData(maskingFunc?.maskData);
    }
  }, [activeImage, maskingFunc?.maskData]);

  const handleCurrentData = (imageData) => {
    if (index === activeImage + 1) {
      setCurrentMasking(
        imageData.filter(
          (obj) => obj.imageSeqNo === slideData?.seqNo,
        ),
      )
    }
  }

  const shortenFileName = (fileName) => {
    if (fileName) {
      let extensionIndex = fileName?.lastIndexOf('.');
      let fileNameWithoutExtension = fileName?.substring(0, extensionIndex);
      let extension = fileName.substring(extensionIndex);
      return fileName?.length > titleLimit
        ? fileNameWithoutExtension.substring(0, titleLimit) + '....' + extension
        : fileName;
    }
  }

  const onCloseButton = () => {
    if (maskingFunc?.unsavedData) {
      setConfirmAction(true);
    } else {
      onClose();
    }
  }

  const onMaskChange = (data, movedIndex, update = false) => {
    handleCurrentData(data);
    setLastMask(
      convertPixelToPercentage(
        data[movedIndex],
        {
          dimentionX: data[movedIndex]?.dimentionX,
          dimentionY: data[movedIndex]?.dimentionY
        },
        'px'
      )
    );
    if (update && maskingFunc) {
      const records = maskingFunc.maskData.filter(
        (obj) => obj.imageSeqNo === data?.[0]?.imageSeqNo,
      );
      const masksIndexed = new Set(records.map((obj) => obj?.data?.index));
      maskingFunc.setMaskData((prev) => [
        ...prev,
        ...data.filter((obj) => obj?.isDragged && !masksIndexed.has(obj?.data?.index))
      ]);
      maskingFunc.setUnsavesData(true);
      handleCurrentData(data);
    }
  }

  const ondeleteMask = (data) => {
    if (maskingFunc) {
      const remaining = maskingFunc.maskData.filter(
        (mask) =>
          mask.data.index !== data.data.index ||
          mask.imageSeqNo !== data.imageSeqNo,
      );
      maskingFunc.setUnsavesData(true);
      maskingFunc.setMaskData(remaining);
      handleCurrentData(remaining);
    }
  }

  const onsaveMasks = () => {
    if (maskingFunc) {
      // const uniqueSeqNo = CommonMethods.getUniqueDataByField(maskingFunc.maskData,'imageSeqNo');
      const uniqueSeqNo = seqNos.split(',')
      let maskedData = [];
      uniqueSeqNo.forEach(seqNo => {
        let data = maskingFunc.maskData.filter((obj) => obj.imageSeqNo === Number(seqNo));
        let defectData = data?.length > 0 && data.map((item) => {
          if (item) {
            return convertPixelToPercentage(item, { dimentionX: item?.dimentionX, dimentionY: item?.dimentionY }, "px");
          }
        });
        maskedData.push({
          imgSeqNo: Number(seqNo),
          defect_coordinates: defectData?.length > 0 ? defectData : []
        });
      });
      // {dimentionX:data[0]?.dimentionX,dimentionY: data[0]?.dimentionY}
      maskingFunc.updateMasking(maskedData);
      maskingFunc.setUnsavesData(false);
      // maskingFunc.reloadMaskData();
    }
    setConfirmAction(false);
    onClose();
  }

  const onCancelMasking = () => {
    if (maskingFunc) {
      setConfirmAction(false);
      maskingFunc.setMaskData(maskingFunc?.maskData?.filter( (mask) => mask?.saved === true))
      maskingFunc.setUnsavesData(false);
      maskingFunc.reloadMaskData()
      onClose();
    }
  }

  return (
    <div
      key={key}
      className={activateClass}
      style={{
        '--offset': offset,
      }}
    >
      <CustomConfirmation
        open={confirmAction}
        onClose={onCancelMasking}
        onSubmit={onsaveMasks}
        noImmediateClose
        primary={"pages.training.masking.modal.save-btn"}
        secondary={
          "pages.training.input-parameter.grid.cutomization.modal.cancel-btn"
        }
        title={t("pages.training.masking.modal.title")}
        message={t("pages.training.masking.messages.modal-message")}
      />
      {active && (
        <IconButton
          className={classes.closeBtn}
          onClick={onCloseButton}
          size="small"
        >
          <Close fontSize="small" />
        </IconButton>
      )}
      <Typography className={classes.textAlign}>
        {index + (page?.startPage - 1) * page?.pageSize}{' '}
        / {totalImageCount}
      </Typography>
      <div className={classes.imageBox}>
        {active && totalImages !== index && (
          <button
            className={classes.rightArrow}
            onClick={next}
          >
            <ChevronRight />
          </button>
        )}
        {maskingFunc?.imageMasking && slideData ? (
          <MaskingImage
            key={activeImage}
            returnFormat={returnFormat}
            totalMasks={currentMasking.length}
            currentId={slideData.seqNo}
            masks={currentMasking}
            onChange={onMaskChange}
            ondeleteMask={ondeleteMask}
            // onsaveMasks = {onsaveMasks}
            src={imageFullViewURL + slideData.fileName}
            alt={slideData.uploadFileName}
            imageClassName={classes.image}
            enableMask={index === activeImage + 1}
          />
        ) : (
          <img
            src={imageFullViewURL + slideData.fileName}
            alt={slideData.uploadFileName}
            className={classes.image}
            height="100%"
            width="100%"
          />
        )}
        {active && index !== 1 && (
          <button
            className={classes.leftArrow}
            onClick={previous}
          >
            <ChevronLeft />
          </button>
        )}
        {maskingFunc?.imageMasking && (
          <div data-count="count" className={classes.countMasks}>
            Area Masked on Image: {currentMasking.length}
          </div>
        )}
      </div>
      <div>
        {slideData && (
          <LightTooltip title={slideData?.uploadFileName}>
            <Typography className={classes.textAlign}>
              File Name: {shortenFileName(slideData?.uploadFileName)} File Size:
              {Math.floor(slideData?.fileSize / 1024)} kb SeqNo:{' '}
              {slideData?.seqNo}
            </Typography>
          </LightTooltip>
        )}
        {Object.keys(lastMask).length > 0 && active && <Typography className={classes.textAlign}>
          {t('pages.training.masking.modal.coordinates', {
            xmin: lastMask?.xmin,
            xmax: lastMask?.xmax,
            ymin: lastMask?.ymin,
            ymax: lastMask?.ymax
          })}
        </Typography>}
      </div>
    </div>
  )
}

export default Slide;