import { Observer } from "mobx-react-lite";
import { useEffect, useState, useRef, useContext } from "react";
import { useTranslation } from "react-i18next";
import { TextField } from '@material-ui/core';
import CustomConfirmation from "../modal/CustomConfirmation";
import { useValidation } from "../../helpers/validate";
import TrainingManagementStore from '../../stores/trainingmanagementstore';
import { API_RESPONSE } from "../../appconstants";
import { checkNotNullFromArray, extractValidations, objToArray } from "../../helpers/arrayutils";
import { SETTINGS } from "../../appsettings";
import ValidationSnackBar from "../snackbar/ValidationSnackBar";
import { Loader } from "../../shared/components/ui";

const EditTraining = (props) => {
  const { t } = useTranslation();
  const form = useRef();
  const { open, setOpen, callBack, training, setSnapbar, disableAddButton } = props;
  const trainingManagementStore = useContext(TrainingManagementStore);
  const [formError, setFormError] = useState({});
  const formData = { modelName: "", comment: "" };
  const [submitted, setSubmitted] = useState(false);
  const [loader, setLoader] = useState(false);
  const [validationErrors, setValidationErrors] = useState(formData);
  const [config, setConfig] = useState({
    fields: {
      modelName: {
        initialValue: training?.modelName || "",
        isRequired: { message: t("validation.message.required") },
        isRegexMatch: { regex: /^[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+|^[a-zA-Z0-9- _]+$/, message: t("validation.message.alphanum") },
        isMaxLength: { message: t("validation.message.maxLength", { field: t("validation.field.modelName"), length: SETTINGS.validation.TITLE_MAX_CHAR }), length: SETTINGS.validation.TITLE_MAX_CHAR },
      },
      comment: {
        initialValue: training?.comment || "",
        isRequired: { message: t("validation.message.required") },
        isMaxLength: { message: t("validation.message.maxLength", { field: t("validation.field.comment"), length: SETTINGS.validation.COMMENT_MAX_CHAR }), length: SETTINGS.validation.COMMENT_MAX_CHAR },
      }
    },
    onSubmit: state => {
      setSubmitted(state?.submitted);
      if (state?.errors) {
        setFormError({ ...state.errors });
      }
    },
    showErrors: 'blur',
    submitted: true
  });
  const [formContent, setFormContent] = useState({
    modelName: training?.modelName || "",
    comment: training?.comment || ""
  });
  const { getFieldProps, getFormProps, errors, values } = useValidation(config);

  useEffect(() => { //Sets values after change
    setFormContent({ ...formContent, ...values });
  }, [values]);

  useEffect(() => {//This is required to validate and show error message
    errors && !submitted && setFormError(errors);
    submitted && setSubmitted(false);
  }, [errors])

  useEffect(() => { //This is required to trigger the submit event on load
    form?.current?.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
  }, [form?.current])

  const handleDuplicateEntry = (data) => {
    let find = trainingManagementStore.trainingListData.filter(e => e.modelName === data.modelName);
    return !find.length;
  }

  const updateTraining = () => {
    form.current.dispatchEvent(
      new Event("submit", { bubbles: true, cancelable: true })
    );
    let formArray = objToArray(formError);
    let notNull = checkNotNullFromArray(formArray);
    let payload = JSON.parse(JSON.stringify(formContent))
    payload.modelName = payload.modelName.replace(/  +/g, " ").trim();
    // let isNotDuplicate = handleDuplicateEntry(formContent);
    setSnapbar({ message: "" });
    setValidationErrors(formData);
    if ((formArray?.length <= 0 || !notNull) && training?._id) {
      //Validation passed
      setLoader(true);
      trainingManagementStore
        .updateTrainingRecordData(training?._id, payload)
        .then((response) => {
          setLoader(false);
          if (response?.data && response?.status === API_RESPONSE.SUCCESS_STATUS_CODE) {
            if (response?.data?.exists) {
              setSnapbar({ message: t("pages.training.errors.training-list.record-exists") });
            } else {
              trainingManagementStore.clearSelectedTrainingListData();
              setSnapbar({ message: t("pages.training.success.training-list.update") });
              setOpen(false);
              disableAddButton(false);
              if (callBack) {
                callBack();
              }
            }
          } else if (response?.validations?.length > 0) {
            setValidationErrors(extractValidations(response?.validations));
          } else {
            setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
          }
        })
        .catch((error) => {
          setLoader(false);
          setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
        });
    } else {
      setSnapbar({ message: t("pages.training.errors.training-list.update-failed") });
    }
    setTimeout(() => {
      setSnapbar({ message: "" });
    }, 2000)
  }

  return (
    <Observer>
      {() => (
        <>
          {validationErrors?.messages && <ValidationSnackBar messages={validationErrors?.messages} />}
          <CustomConfirmation
            open={open}
            onClose={() => setOpen(false)}
            disableApply={loader}
            noImmediateClose={true}
            onSubmit={updateTraining}
            primary={'pages.training.training-list.controls.ok'}
            secondary={'pages.training.training-list.controls.cancel-btn'}
            title={t('pages.training.training-list.modal.update-training')}
            message={<>
              {loader && <Loader size={24} />}
              <form action="javascript:;" ref={form} autoComplete="off"  {...getFormProps()}>
                <TextField
                  disabled={loader}
                  fullWidth
                  aria-valuetext={formContent?.modelName}
                  id="modelName"
                  name="modelName"
                  margin="normal"
                  label={t("validation.field.modelName")}
                  value={formContent?.modelName} autoFocus
                  {...getFieldProps('modelName')}
                  error={formError.modelName}
                  helperText={formError.modelName}
                />
                <TextField
                  disabled={loader}
                  aria-valuetext={formContent?.comment}
                  fullWidth
                  id="comment"
                  name="comment"
                  margin="normal"
                  label={t("validation.field.comment")}
                  value={formContent?.comment}
                  {...getFieldProps('comment')}
                  error={formError?.comment}
                  helperText={formError?.comment}
                />
              </form>
            </>} />
        </>
      )}
    </Observer >
  );
};
export default EditTraining;
