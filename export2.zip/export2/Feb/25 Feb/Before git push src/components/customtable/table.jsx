import React, { useContext, useEffect } from "react";
import { DragDropContext, Droppable } from "react-beautiful-dnd";
import clsx from "clsx";
import { Table, TableHead } from "../../shared/components/basictable";
import { TableBody as MuiTableBody } from "@material-ui/core";
import AppStore from "../../stores/appstore";
import CustomTableRows from ".";
import { useStyles } from './style';
import { useParams } from "react-router-dom";

const CustomTables = (props) => {
  const {
    enableDrag,
    loading,
    classname,
    rowCount,
    selectedRowCount,
    onAllRowSelected,
    headerData,
    PopoverComponent,
    onRowMouseOver,
    onRowSelect,
    bodyData,
    onDragEnd,
    callback,
    hideFilter,
    onCheckboxClick
  } = props;

  const appStore = useContext(AppStore);
  const params = useParams();
  const classes = useStyles();

  useEffect(()=>{
    const dataRows = document?.getElementById('tablebody').querySelectorAll("tr");
    dataRows.forEach((row) => {
      setRowStyle(row);
    });
  },[headerData,bodyData]);

  const setRowStyle = (row) => {
    const cells = row.querySelectorAll("[data-sticky='true']");
    let width = 0;
    cells.forEach((cell) => {
      cell.style.left = `${width}px`;
      const rect = cell.getBoundingClientRect();
      width += rect.width;
    });
  };
  
  const renderTableHead = () => {
    return (
      <TableHead
        rowCount={rowCount}
        headerData={headerData}
        hideFilter={hideFilter}
        onAllRowSelected={onAllRowSelected}
        selectedRowCount={selectedRowCount}
        filters={appStore.inspectionSearchFilter.filter}
        sort={appStore.inspectionSearchFilter.sort}
        noEmptyColumn={true}
      />
    )
  }

  const renderTableRows = () => {
    return (
        <CustomTableRows
            enableDrag={enableDrag}
            PopoverComponent={PopoverComponent}
            onRowMouseOver={onRowMouseOver}
            onRowSelect={onRowSelect}
            bodyData={bodyData}
            headerData={headerData}
            noEmptyColumn={true}
            onCheckboxClick={onCheckboxClick}
        />
    )
  }
  const onDr = (result) =>{
    let payload = [];
    const { destination, source } = result;

    if (!destination) {
      return;
    }
    if (destination?.droppableId === source?.droppableId && destination?.index === source?.index) {
      return;
    }
    const order = bodyData;
    const record = order?.splice(source?.index, 1)[0];
    order?.splice(destination?.index, 0, record);
    order?.forEach((dataset,index)=>{
      payload.push({
        seqNo: dataset?.seqNo,
        classOrder: index+1
      })
    })
    callback && callback(params?.id,payload);
  }
  
  const renderDragTable = () => {
    return (
      <DragDropContext onDragEnd={onDragEnd?onDragEnd:onDr}>
        <Table loading={loading} className={clsx(classname, classes.table)} rowHeight="unset">
            {renderTableHead()}
            <Droppable droppableId="table">
              {(provided) => (
                <>
                <MuiTableBody id="tablebody" ref={provided.innerRef} {...provided.droppableProps} >
                  {renderTableRows()}
                </MuiTableBody>
                {provided.placeholder}
                </>
            )}
          </Droppable>
        </Table>
      </DragDropContext>
    )
  }
  
  return (
    <>
      {enableDrag ? (
        renderDragTable()
      ) : (
        <Table loading={loading} className={clsx(classname, classes.table)} rowHeight="unset">
          {renderTableHead()}
          <MuiTableBody id="tablebody">
            {renderTableRows()}
          </MuiTableBody>
        </Table>
      )}
    </>
  )
}

export default CustomTables
