import { WAFER } from "./appconstants";

const API_URL = window._env_.API_URL; //this will be invoked from external config

export const SETTINGS = {
    I18N: {
        LANGUAGES: {
            EN: "en",
            JP: "jp",
        },
        DEFAULT_LANG: "en",
    },
    DATE_TIME_FORMAT: "yyyy/MM/dd HH:mm:ss",
    BASE_API_URL: API_URL,
    IMAGE_THUMBNAIL_URL: API_URL + "api/image/",
    IMAGE_FULL_URL: API_URL + "api/image/full-view/",
    subclass: {
        ENABLE_SUBCLASS_SELECT_ALL: window._env_.ENABLE_INDIVIDUAL_THRESHOLD === 1 ? true : false,
        ENABLE_INDIVIDUAL_THRESHOLD: window._env_.ENABLE_INDIVIDUAL_THRESHOLD === 1 ? true : false,
        ENABLE_INDIVIDUAL_SHOW_GRAPH: window._env_.ENABLE_INDIVIDUAL_SHOW_GRAPH === 1 ? true : false
    },
    validation: {
        TITLE_MAX_CHAR: window._env_.TITLE_MAX_CHAR || 100,
        COMMENT_MAX_CHAR: window._env_.COMMENT_MAX_CHAR || 300
    },
    SOCKET_URL: API_URL,
    API_CONFIG: {
        TIMEOUT: 0,
    },
    execution: {
        SHOW_STATUS: window._env_.SHOW_EXEC_STATUS === 1 ? true : false,
    },
    EXECUTION_TIMEOUT: window._env_.EXEC_TIMEOUT || (1000 * 60 * 60),
    INSPECTION_GRID: {
        DATE_OFFSET: 30,
    },
    GRID: {
        PAGINATION: {
            DIRECTIONS: {
                PREV: "prev",
                NEXT: "next",
            },
            PAGE_SIZES: [
                { value: 25, label: 25 },
                { value: 50, label: 50 },
                { value: 75, label: 75 },
                { value: 100, label: 100 },
            ],
        },
    },
    DEFECT_IMAGE_INDEX: 1,
    LOCAL_STORAGE_KEYS: {
        I18N: "i18nextLng",
        INSPECTION_LIST_SORT_DATA: "inspectionGridSortData",
        SHOW_WAFER_SCALE: "showWaferScale",
    },
    IMAGE_LIST: {
        ITEM_PER_PAGE: 12,
        IMAGE_VIEW_SCROLL_HEIGHT: window._env_.IMAGE_VIEW_SCROLL_HEIGHT || "0.5em"
    },
};